import React, { Component } from 'react';
import { View, Button, Text } from 'native-base';
import { connect } from 'react-redux';
import { BackHandler, Alert } from 'react-native';
import _ from '../../../lang';

import Style from '../../../styles';
import {
  pageType as page, SMS_VERIFICATION_AGENT, CHECK_AGENT_VERIFICATION, CHECK_USER_ID,
} from '../ConfigHome';
import { authAction } from '../ActionHome';
// import { requestStatus } from '../../../utilities';
import LoadingModal from '../../../components/loading_modal';
import HomeScreen from '../components/HomeScreen';
import { InputFieldNew } from '../../../components';
import { requestStatus } from '../../../utilities';

const headers = [
  {
    keyHeader: 'X-CSRF-Token',
    valueHeader: 'Bearer undefined',
  },
];

class SMSVerification extends Component {
  constructor(props) {
    super(props);
    this.state = {
      token: '',
      isLoading: false,
      timer: 60,
      pageType: '',
      data: {},
    };
  }

  componentDidMount() {
    const pageType = this.props.navigation.getParam('pageType');
    const data = this.props.navigation.getParam('data', {});
    this.setState({ pageType, data });
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleBack();
      return true;
    });
    this.interval = setInterval(() => this.setState(prevState => ({ timer: prevState.timer - 1 })), 1000);
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props !== prevProps) {
      if ((this.props.status !== prevProps.status && this.props.status === requestStatus.FETCH)
        || (this.props.userIdStatus !== prevProps.userIdStatus && this.props.userIdStatus === requestStatus.FETCH)
        || (this.props.resendSMSStatus !== prevProps.resendSMSStatus && this.props.resendSMSStatus === requestStatus.FETCH)) {
        this.handleLoading(true);
      }

      if (this.props.status !== prevProps.status && this.props.status === requestStatus.SUCCESS) {
        this.handleLoading(false, () => {
          if (this.props.smsVerification.respCode === 200) {
            if (this.state.pageType === page.createPRUFastIDNoSFA) {
              this.props.navigation.replace('SignUpAgent', { route: 'SMSVerification', data: this.state.data, pageType: page.createPRUFastIDNoSFA });
            } else { this.getUserId(); }
          } else {
            Alert.alert('', 'Maaf kode verifikasi yang anda masukkan salah', [{ text: 'Ok', onPress: () => { this.handleLoading(false); } }]);
          }
        });
      }

      if (this.props.userIdStatus !== prevProps.userIdStatus && this.props.userIdStatus === requestStatus.SUCCESS) {
        switch (this.state.pageType) {
          case page.forgetPRUFastID:
            if (this.props.userId.errorCode === '000000') {
              this.handleLoading(false, () => {
                this.props.navigation.replace('SignInHome', { agentData: this.props.userId.agent });
              });
            } else {
              // temp, development purpose
              Alert.alert('', 'Gagal mendapatkan user Id', [{ text: 'Ok', onPress: () => { this.handleLoading(false); } }]);
            }
            break;
          case page.forgetSecurityQuestion:
            if (this.props.userId.agent !== undefined) {
              this.handleLoading(false, () => {
                this.props.navigation.replace('SignUpAgent',
                  { route: 'SMSVerification', username: this.props.userId.agent.salesforceId, pageType: page.forgetSecurityQuestion });
              });
            } else {
              // temp, development purpose
              Alert.alert('', 'Gagal mendapatkan user Id', [{ text: 'Ok', onPress: () => { this.handleLoading(false); } }]);
            }
            break;
          default:
            console.log(this.state.pageType);
            break;
        }
      }

      if (this.props.resendSMSStatus !== prevProps.resendSMSStatus && this.props.resendSMSStatus === requestStatus.SUCCESS) {
        if (this.props.resendSMS.body.respCode === 200) {
          this.handleLoading(false, () => {
            this.handleTimerBack();
          });
        } else {
          // temp, development purpose
          Alert.alert('', 'Gagal mengirim ulang kode verifikasi', [{ text: 'Ok', onPress: () => { this.handleLoading(false); } }]);
        }
      }

      if ((this.props.status !== prevProps.status && this.props.status === requestStatus.FAILED)
        || (this.props.userIdStatus !== prevProps.userIdStatus && this.props.userIdStatus === requestStatus.FAILED)
        || (this.props.resendSMSStatus !== prevProps.resendSMSStatus && this.props.resendSMSStatus === requestStatus.FAILED)) {
        this.handleLoading(false, () => {
          Alert.alert('', 'Gagal memanggil service', [{ text: 'Ok', onPress: () => { } }]);
        });
      }
    } else if (this.state !== prevState) {
      if (this.state.timer === 0) {
        clearInterval(this.interval);
      }
    }
  }

  componentWillUnmount() {
    this.backHandler.remove();
    clearInterval(this.interval);
  }

  handleLoading = (val, func) => {
    const callbackFunc = func || (() => { });
    this.setState({ isLoading: val }, callbackFunc);
  }

  handleTimerBack = () => {
    this.setState({ timer: 60 }, () => {
      this.interval = setInterval(() => this.setState(prevState => ({ timer: prevState.timer - 1 })), 1000);
    });
  }

  onVerify = () => {
    if (this.state.token === '') {
      Alert.alert('', 'Mohon input kode verifikasi', [{ text: 'Ok', onPress: () => { } }]);
    } else {
      const { agentId } = this.state.data;
      const data = { headers, params: `["${agentId}", "${this.state.token}"]` };

      this.props.verifySMS(data);
    }
  }

  resendSMSVerification = () => {
    const { agentId, birthdate } = this.state.data;
    const data = { headers, params: `["${agentId}", "${birthdate}", "new"]` };

    this.props.resendSMSVerif(data);
  }

  getUserId = () => {
    const { agentId, email } = this.state.data;
    const npaFlag = '0'; // angular reference
    const data = { headers, params: `["${agentId}", "${npaFlag}", "${email}"]` };
    let type = '';

    switch (this.state.pageType) {
      case page.forgetPRUFastID:
        type = CHECK_USER_ID.FETCH;
        break;
      case page.forgetSecurityQuestion:
        type = CHECK_USER_ID.FETCH;
        break;
      default:
        type = '';
        break;
    }

    this.props.checkUserId(type, data);
  }

  handleBack = () => {
    this.props.navigation.replace('AgentDataVerification', { pageType: this.state.pageType });
  }

  render() {
    return (
      <React.Fragment>
        <HomeScreen
          title="Verifikasi SMS"
          onBackClicked={this.handleBack}
          content={
            <React.Fragment>
              <Text style={[Style.Main.textGray, Style.Main.textCenter, Style.Main.font12, Style.Main.mb15, Style.Main.alignCenter]}>
                Kode OTP telah dikirimkan ke nomor {this.props.navigation.getParam('data', {}).phoneNumber}
              </Text>
              <View style={[Style.Main.mt10, Style.Main.width200, Style.Main.alignCenter]}>
                <InputFieldNew
                  value={this.state.token}
                  placeholder={_('Kode Verifikasi SMS')}
                  maxLength={8}
                  placeholderTextColor={[Style.Main.textGray]}
                  textInputStyle={[Style.Main.textCenter]}
                  onChangeText={token => this.setState({ token })}
                  isRequired={false}
                />
                <Button
                  rounded
                  danger
                  style={[Style.Main.mt35, Style.Main.buttonRed]}
                  onPress={this.onVerify}
                >
                  <Text style={[Style.Main.fontAlbert14, Style.Main.textWhite]}>{_('LANJUT')}</Text>
                </Button>
                <Text
                  onPress={this.state.timer > 0 ? () => { } : this.resendSMSVerification}
                  style={[
                    this.state.timer > 0 ? Style.Main.textGray : Style.Main.textRed,
                    Style.Main.textCenter,
                    Style.Main.font11,
                    Style.Main.mb15,
                    Style.Main.mt5,
                  ]}
                >
                  Kirim Ulang Verifikasi SMS {this.state.timer > 0 && `(${this.state.timer}s)`}
                </Text>
              </View>
            </React.Fragment>
          }
        />
        <LoadingModal
          show={this.state.isLoading}
          size="large"
          color="white"
        />
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  isOnline: state.connectionStatus.isOnline,
  smsVerification: state.home.smsVerification,
  userId: state.home.checkUserId,
  resendSMS: state.home.checkAgent,
  status: state.home.smsVerificationStatus,
  userIdStatus: state.home.checkUserIdStatus,
  resendSMSStatus: state.home.checkAgentStatus,
});

const mapDispatchToProps = dispatch => ({
  verifySMS: value => dispatch(authAction(SMS_VERIFICATION_AGENT.FETCH, value)),
  resendSMSVerif: value => dispatch(authAction(CHECK_AGENT_VERIFICATION.FETCH, value)),
  checkUserId: (type, value) => dispatch(authAction(type, value)),
});

export default connect(mapStateToProps, mapDispatchToProps)(SMSVerification);
