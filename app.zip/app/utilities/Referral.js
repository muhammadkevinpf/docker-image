import { resourceRequest } from './StoreApi';
import { GETREFERRALAPI } from '../modules/auth/ConfigAuth';
import SQLiteUtils from './SQLiteUtils';
import Database from '../config/Database';
import { saveLog, CONSTANT } from './Logger';
import Caches from './Caches';

export const getReferralFromAPI = (channel, token) => {
  const parameter = {
    params: `["${channel}"]`,
    headers: [
      {
        keyHeader: 'X-CSRF-Token',
        valueHeader: `Bearer ${token}`,
      },
    ],
  };
  resourceRequest(GETREFERRALAPI, 'post', parameter)
    .then((res) => {
      console.log(res.data);
      if (res.data.responseCode === '200' && res.data.data.length) {
        SQLiteUtils.executeTransaction(
          global.database.pruSmart,
          `DELETE FROM ${Database.pruSmart.tables.referral.name}`,
          [],
        ).then((resDelete) => {
          console.log(resDelete);
          saveLog(CONSTANT.INFO, `DELETE Referral ${resDelete}`);
          // eslint-disable-next-line max-len
          const dataToStore = res.data.data.map(referral => `("${referral.referralCode}","${referral.referralName}","${referral.channel}","${referral.rmPsid}","${referral.branchOfficeCode}")`);
          SQLiteUtils.executeTransaction(
            global.database.pruSmart,
            `INSERT INTO ${Database.pruSmart.tables.referral.name} VALUES ${dataToStore.join(',')}`,
            [],
          ).then((resInsert) => {
            console.log(resInsert);
            saveLog(CONSTANT.INFO, `Insert Referral ${resInsert}`);
          }, (err) => {
            console.log(err);
            saveLog(CONSTANT.ERROR, `Insert Referral ${JSON.stringify(err)}`);
          });
        }, (err) => {
          console.log(err);
          saveLog(CONSTANT.ERROR, `DELETE Referral ${JSON.stringify(err)}`);
        });
        Caches.set('Referral', res.data.data);
        console.log(Caches.dumpCache());
      } else {
        console.log('No Data For Referral From API');
        saveLog(CONSTANT.INFO, 'No Data For Referral From API');
      }
    }, (err) => {
      console.log(err);
      getReferralFromLocalDB();
      saveLog(CONSTANT.ERROR, `API Referral Error ${JSON.stringify(err)}`);
    });
};

export const getReferralFromLocalDB = () => {
  SQLiteUtils.executeQuery(
    global.database.pruSmart,
    `SELECT * FROM ${Database.pruSmart.tables.referral.name}`,
    [],
  ).then((res) => {
    console.log(res.rows);
    const referrals = [];
    for (let i = 0; i < res.rows.length; i += 1) {
      const referral = res.rows.item(i);
      referrals.push({
        referralCode: referral.REFERRAL_CODE,
        referralName: referral.REFERRAL_NAME,
        channel: referral.channel,
        rmPsid: referral.RM_PSID,
        branchOfficeCode: referral.BRANCH_OFFICE_CODE,
      });
    }
    Caches.set('Referral', referrals);
    console.log(Caches.dumpCache());
  }, (err) => {
    console.log(err);
    saveLog(CONSTANT.ERROR, `Get referral from local db error ${JSON.stringify(err)}`);
  });
};
