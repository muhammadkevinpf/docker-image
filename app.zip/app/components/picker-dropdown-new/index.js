/**
 * improve component dropdown picker from ahmdichsanb@gmail.com
 * use picker from native base
 * on Android one item picker is added in the first value to be used as a placeholder
*/

import React, { Component } from 'react';
import {
  Label, Text, View,
} from 'native-base';
import { Dropdown } from 'react-native-material-dropdown';
import PropTypes from 'prop-types';
import StylePicker from './StylePicker';
import Style from '../../styles';
import _ from '../../lang';

class PickerDropdown extends Component {
  constructor(props) {
    super(props);
    this.state = {
      errorMessage: this.props.errorMessage,
    };
  }

  // shouldComponentUpdate = (prevProps) => {
  //   if (JSON.stringify(this.props) === JSON.stringify(prevProps)) return false;
  //   // || this.props.selectedValue === prevProps.selectedValue) return false;
  //   return true;
  // }

  componentDidMount = () => {
    const { invoke } = this.props;
    if (invoke && !this.props.selectedValue && this.props.isRequired) {
      this.setState({ errorMessage: 'Wajib Diisi!' });
    }
  }

getRowData = (index) => {
  const { dropdownData } = this.props;
  let result;
  result = dropdownData[index];
  if (!result) {
    result = {};
  }
  return result;
}

dropdownValidation = (input, index) => {
  const {
    isRequired,
    onValueChange,
  } = this.props;
  let errorMessage = '';
  if (input === '') {
    if (isRequired) {
      errorMessage = 'Wajib Diisi!';
    } else {
      errorMessage = '';
    }
  }

  this.setState({
    errorMessage,
  });

  if (onValueChange) {
    onValueChange(input, this.getRowData(index));
  }
}

invokeValidation = (errorMessage) => {
  this.dropdownValidation(this.props.selectedValue);
  if (errorMessage) {
    this.setState({
      errorMessage,
    });
  }
}

render() {
  console.log('this dropdown being rendered');
  const {
    enabled,
    placeholder,
    stylePickerView,
    labelStyle,
    bottomLabelStyle,
    errorLabelStyle,
    valueProp,
    labelProp,
    bottomLabel,
    label,
    dropdownData,
    style,
    itemTextStyle,

    // add
    itemStyle,
    selectedValue,
  } = this.props;

  const {
    errorMessage,
    // isInitialLoad,
  } = this.state;
  // const selectedValue = this.state.selectedValue || (isInitialLoad ? this.props.selectedValue : this.state.selectedValue);
  // const selectedValue = this.props.selectedValue;

  const dropdown = dropdownData ? dropdownData.map((item) => {
    let obj = { ...item };

    if (labelProp) {
      obj = { ...obj, label: item[labelProp] };
    }
    if (valueProp) {
      obj = { ...obj, value: item[valueProp] };
    }
    return obj;
  }) : null;

  return (
    <View>
      <View style={[StylePicker.content, stylePickerView]}>
        {label && (<Label numberOfLines={1} style={[StylePicker.styleTextLabel, Style.Main.fontAlbert, labelStyle]}>{_(label)}</Label>)}
        <View style={[StylePicker.item, itemStyle]}>
          <Dropdown
            data={dropdown}
            // label={selectedValue ? '' : _(placeholder)}
            label=""
            value={selectedValue || ''}
            fontSize={14}
            // style={[Style.Main.fontAlbert, Style.Main.textColor3f3, Style.Main.font14, ]}
            placeholder={_(placeholder)}
            style={[
              Style.Main.noBorder,
              Style.Main.pl5, Style.Main.pr10,
              selectedValue ? Style.Main.textAlmostBlack : Style.Main.textBrightGray,
              !enabled ? Style.Main.textBrightGray : null,
              Style.Main.fontAlbert,
              style,
            ]}
            pickerStyle={[null]}
            containerStyle={[null]}
            itemTextStyle={[Style.Main.fontAlbert, Style.Main.gray83, Style.Main.font14, itemTextStyle]}
            onChangeText={(val, index) => this.dropdownValidation(val, index)}
            dropdownOffset={{ top: 0, left: 0 }}
            disabled={!enabled}
            animationDuration={0}
            inputContainerStyle={[null]}
            overlayStyle={[null]}
          />
        </View>
        {errorMessage !== '' && (<Text style={[StylePicker.styleBottomLabel, Style.Main.fontAlbert, errorLabelStyle]}>{_(errorMessage)}</Text>)}
        {bottomLabel.length !== 0 &&
          (
            bottomLabel.map(element => (
              <Text key={element.toString()} style={[StylePicker.styleBottomLabel, Style.Main.fontAlbert, bottomLabelStyle]}>{_(element)}</Text>
            ))
          )}
      </View>
    </View>
  );
}
}

PickerDropdown.propTypes = {
  enabled: PropTypes.bool,
  placeholder: PropTypes.string,
  selectedValue: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
  ]),
  dropdownData: PropTypes.arrayOf(PropTypes.object).isRequired,
  // stylePickerBody: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  stylePickerView: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  labelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  bottomLabelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  errorLabelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  itemTextStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  // labelProp: PropTypes.string,
  // valueProp: PropTypes.string,
  isRequired: PropTypes.bool,
  errorMessage: PropTypes.string,
  bottomLabel: PropTypes.arrayOf(PropTypes.string),
  label: PropTypes.string,
  onValueChange: PropTypes.func,

  // add
  itemStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  invoke: PropTypes.bool,
};

PickerDropdown.defaultProps = {
  enabled: true,
  placeholder: 'Select',
  selectedValue: null,
  // stylePickerBody: null,
  stylePickerView: null,
  labelStyle: null,
  style: null,
  itemTextStyle: null,
  bottomLabelStyle: Style.Main.textRed,
  errorLabelStyle: Style.Main.textRed,
  // labelProp: 'label',
  // valueProp: 'value',
  isRequired: true,
  errorMessage: '',
  bottomLabel: [],
  label: null,
  onValueChange: () => { },

  // add
  itemStyle: null,
  invoke: false,
};

export default PickerDropdown;
