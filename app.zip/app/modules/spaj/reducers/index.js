import { combineReducers } from 'redux';
import { spajReducer } from './SpajReducer';
import { fundReducer } from './FundReducer';
import { submissionReducer } from './SubmissionReducer';

const ReducerSpaj = combineReducers({
  data: spajReducer,
  fund: fundReducer,
  submission: submissionReducer,
});

export default ReducerSpaj;
