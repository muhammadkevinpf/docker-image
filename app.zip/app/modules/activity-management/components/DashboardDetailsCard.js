/* eslint-disable react-native/no-inline-styles */
/* eslint-disable max-len */
/* eslint-disable react/no-array-index-key */
import React, { PureComponent } from 'react';
// import PropTypes from 'prop-types';
// import moment from 'moment';
import { TouchableOpacity } from 'react-native';
import {
  Text, Card, View, Thumbnail,
} from 'native-base';
import Style from '../../../styles';
import { iconMyAccount } from '../../../assets/images';

export class DashboardListCard extends PureComponent {
  render() {
    const { data, withHeader, rightLabel } = this.props;
    return (
      <Card style={this.props.cardStyle}>
        <View
          style={[Style.Main.alignContentCenter, Style.Main.mV10, Style.Main.pb5]}
        >
          {
            withHeader && (
              <View style={[{ borderBottomWidth: 2 }, Style.Main.borderBottomGray, Style.Main.pb10, Style.Main.mb5]}>
                <View style={[Style.Main.rowDirectionSpaceBetween]}>
                  <Text style={[Style.Main.fontAlbertBold12, Style.Main.ph12, Style.Main.justifyCenter, Style.Main.textRed]}>{data.headerLabel || 'N/A'}</Text>
                </View>
              </View>
            )
          }
          <View style={[!withHeader && Style.Main.pv2, Style.Main.ph12, Style.Main.rowDirectionSpaceBetween]}>
            <View>
              <Text style={[Style.Main.fontAlbert12, Style.Main.textRed]}>{data.activityName || 'N/A'}</Text>
              <Text style={[Style.Main.fontAlbert12]}>{data.fullname || 'N/A'}</Text>
              <Text style={[Style.Main.fontAlbert12]}>{data.activityDate || 'N/A'}</Text>
            </View>
            <View>
              <Text style={[Style.Main.fontAlbert12, Style.Main.textRed]}>{rightLabel || ''}</Text>
            </View>
          </View>
        </View>
      </Card>
    );
  }
}

export class DashboardProfile extends PureComponent {
  renderTabs = () => {
    const tabs = [
      { value: 'day', name: 'Hari Ini' },
      { value: 'week', name: 'Minggu Ini' },
      { value: 'month', name: 'MTD' },
      { value: 'year', name: 'YTD' },
    ];

    const activeTab = this.props.activeTab || 'day';

    return tabs.map(item => (
      <TouchableOpacity onPress={() => (this.props.onTabChange ? this.props.onTabChange(item.value) : {})} style={[Style.Main.width25pr]}>
        <Text style={[
          Style.Main.fontAlbert16,
          Style.Main.alignCenter,
          Style.Main.justifyCenter,
          Style.Main.pv10,
          item.value === activeTab ? Style.Main.textRed : Style.Main.textGray,
        ]}
        >{item.name}
        </Text>
        <View style={[item.value === activeTab ? Style.Main.backgroundRed : null, Style.Main.height4]} />
      </TouchableOpacity>
    ));
  }

  render() {
    const iconUri = this.props.resAuth && this.props.resAuth.userAvatar && Number(this.props.resAuth.userAvatar.statusCode) === 200
      ? this.props.resAuth.userAvatar.text : null;
    return (
      <Card style={[this.props.cardStyle]}>
        <View
          onPress={this.props.onCardClicked}
          style={[Style.Main.alignContentCenter, Style.Main.mt10, Style.Main.pt15, this.props.withoutTab && { paddingBottom: 25 }]}
        >
          <View style={[Style.Main.ph12, Style.Main.rowDirection]}>
            <View style={[Style.Main.mr10]}>
              <Thumbnail
                source={iconUri ? { uri: iconUri } : iconMyAccount}
                style={[Style.Main.height40, Style.Main.resizeContain, Style.Main.alignCenter]}
              />
            </View>
            <View>
              <Text style={[Style.Main.fontAlbert16]}>{this.props.resAuth.userProfile.clientName}</Text>
              <Text style={[Style.Main.fontAlbert12]}>{this.props.resAuth.userProfile.agentCode}</Text>
            </View>
          </View>
          {
            !this.props.withoutTab && (
              <View style={[Style.Main.fullWidth, Style.Main.rowDirection, Style.Main.borderTopGray, Style.Main.mt15]}>
                {this.renderTabs()}
              </View>
            )
          }
        </View>
      </Card>
    );
  }
}
