/* eslint-disable import/no-cycle */
/* eslint-disable no-console */
import CryptoJS from 'crypto-js';
import { Alert } from 'react-native';
import NewSPAJStorageService from '../../sqs-spaj/services/NewSPAJStorageService';
import ConfigProductSPAJ from '../configs/ConfigProductSPAJ';

const {
  labelNameLA, labelNamePayor, productPAA, productPSAA, productPIA, productPSIA,
} = ConfigProductSPAJ;

function isPH(spaj, role) {
  let isSame = false;
  if (getCustomerId(spaj, 'ph') === getCustomerId(spaj, role)) isSame = true;
  return isSame;
}

function getLabelPolicyHolder(spaj) {
  let label = 'Pemegang Polis';
  if (this.isPH(spaj, '01')) label = `${label} (Tertanggung Utama)`;
  else if (this.isPH(spaj, '02')) label = `${label} (Tertanggung Tambahan 1)`;
  else if (this.isPH(spaj, '03')) label = `${label} (Tertanggung Tambahan 2)`;
  return label;
}

function getMainQuotation(spajData) {
  const mainQuotation = spajData.sqs.sqs.quickQuote
    .find(obj => obj.isMainQuotation === true);
  return mainQuotation;
}

function isSyariah(spajData) {
  if (getMainQuotation(spajData).tipe === 'Syariah') return true;
  return false;
}

function getLifeAssTotal(spajData) {
  return getMainQuotation(spajData).client.lifeAss.length;
}

function getSumAssured(spajData) {
  const { medical } = getMainQuotation(spajData);
  if (medical) {
    const { addcc, meninggal } = getMainQuotation(spajData).medical;
    return meninggal >= addcc ? meninggal : addcc;
  }
  return getMainQuotation(spajData).premium;
}

function getCustomerId(spajData, role) {
  const selectedQq = getMainQuotation(spajData).client;
  const findLa = selectedQq.lifeAss.find(x => x.role === role);
  let findId = '';
  if (role === 'ph') {
    findId = selectedQq.ph.customerId;
  } else {
    findId = findLa ? findLa.customerId : '';
  }

  return findId;
}

function getPersonalInformation(spajData) {
  const { ph, benef } = spajData.client;
  const { payor } = spajData.policy;
  const lifeAss1 = spajData.client.lifeAss.find(obj => obj.role === '01');
  const lifeAss2 = spajData.client.lifeAss.find(obj => obj.role === '02');
  const lifeAss3 = spajData.client.lifeAss.find(obj => obj.role === '03');
  const lifeAss4 = spajData.client.lifeAss.find(obj => obj.role === '04');
  const lifeAss5 = spajData.client.lifeAss.find(obj => obj.role === '05');
  const topupPayor = spajData.policy.topUp.payor;

  return {
    ph,
    benef,
    payor,
    lifeAss1,
    lifeAss2,
    lifeAss3,
    lifeAss4,
    lifeAss5,
    topupPayor,
  };
}

function mappingStep5SKA(spajData) {
  const coreFamilySingle = ['FA', 'MO', 'BS'];
  const coreFamilyMarried = ['HU', 'WI', 'DA', 'SO'];
  const coreFamilyWidow = ['DA', 'SO'];
  const { benef } = spajData.client;
  const filteredFamilySingle = benef.filter(item => !coreFamilySingle.includes(item.relation) && item.relation);
  const filteredFamilyMarried = benef.filter(item => !coreFamilyMarried.includes(item.relation) && item.relation);
  const filteredFamilyWidow = benef.filter(item => !coreFamilyWidow.includes(item.relation) && item.relation);
  const LaStatus = getPersonalInformation(spajData).lifeAss1.marryd;
  let validation = false;

  if (LaStatus === 'S' && filteredFamilySingle.length > 0) {
    validation = true;
  }
  if ((LaStatus === 'M' && filteredFamilyMarried.length > 0) || (LaStatus === 'W' && filteredFamilyWidow.length > 0)) {
    validation = true;
  }
  return validation;
}

function mappingStep1SKA(spajData) {
  const sumAssured = getSumAssured(spajData);
  const saReferrence = getMainQuotation(spajData).currCd === 'IDR' ? 500000000 : 62500;
  const mainLifeAss = getPersonalInformation(spajData).lifeAss1;
  const lifeAssAge = mainLifeAss.anb;
  let validation = false;

  if ((mainLifeAss.relation === 'FA' || mainLifeAss.relation === 'MO') && sumAssured > saReferrence && lifeAssAge >= 21) {
    validation = true;
  } else if (mainLifeAss.relation === 'GP' && lifeAssAge < 21) {
    validation = true;
  } else if (mainLifeAss.relation === 'UA' && lifeAssAge < 21) {
    validation = true;
  } else if (mainLifeAss.relation === 'MM') {
    validation = true;
  }

  return validation;
}

function isPHeqLA(spajData) {
  if (getMainQuotation(spajData).isPHeqLA) {
    return true;
  }
  return false;
}

function createHash(spajData) {
  return CryptoJS.SHA1(JSON.stringify(spajData)).toString();
}

const onCheckHash = (dataBefore, dataAfter, props, noCheck) => new Promise((resolve) => {
  if (ConfigProductSPAJ.viewModeSpaj.includes(props.spaj.policy.spajStatus) || noCheck) {
    resolve(true);
    return;
  }
  // function onCheckHash(dataBefore, dataAfter, policyData, updatePolicy) {
  const signArray = props.spaj.policy.sign.length;
  // let isDataChanged = true;
  if (dataBefore !== dataAfter && signArray > 0) {
    Alert.alert(
      'Warning',
      'Apakah Anda yakin ingin mengubah data dan mengulang tanda tangan?',
      [
        {
          text: 'Ya',
          onPress: () => {
            props.updatePolicy({ ...props.spaj.policy, sign: [] });
            resolve(true);
          },
        },
        {
          text: 'Tidak',
          onPress: () => {
            resolve(false);
          },
        },
      ],
    );
  } else { resolve(true); }
});

const storeSpajToRedux = async (props) => {
  const { agentCode } = props.resAuth.userProfile;
  const pruSmartDB = global.database.pruSmart;
  const spajCode = props.spaj.policy.proposalCd;
  const spajData = await NewSPAJStorageService.getByCode(pruSmartDB, { agentCode, spajCode });

  return props.updateSpaj(spajData);
};

const storeSpajToSql = async (props) => {
  if (ConfigProductSPAJ.viewModeSpaj.includes(props.spaj.policy.spajStatus)) {
    return;
  }
  const { agentCode } = props.resAuth.userProfile;
  const pruSmartDB = global.database.pruSmart;
  const spajCode = props.spaj.policy.proposalCd;

  await NewSPAJStorageService.upsert(pruSmartDB, { agentCode, data: props.spaj, spajCode });
  console.log('SPAJ data has been saved to SQL!');
};

const getProductCode = (spajData) => {
  const productCd = getMainQuotation(spajData).productCode;

  return productCd;
};

const getProductCategory = (spajData) => {
  const productCd = getProductCode(spajData);
  let category = '';
  if (productPAA.includes(productCd)) {
    category = 'PAA';
  } else if (productPSAA.includes(productCd)) {
    category = 'PSAA';
  } else if (productPIA.includes(productCd)) {
    category = 'PIA';
  } else if (productPSIA.includes(productCd)) {
    category = 'PSIA';
  }

  return category;
};

const getLabelLA = (spajData, role) => {
  const roleArray = labelNameLA[role];
  const category = getProductCategory(spajData);
  const title = roleArray[category];

  return title;
};

const getLabelPayor = (spajData) => {
  const category = getProductCategory(spajData);
  const title = labelNamePayor[category];

  return title;
};

const calculateAgeTMP = (birthDate) => {
  const today = new Date();
  let year;
  let month;
  let day = Math.round(((today - birthDate) / 24 / 60 / 60 / 1000) - 1);
  const yearTmp = today.getFullYear() - birthDate.getFullYear();
  const monthDOB = today.getMonth() - birthDate.getMonth();
  const dayDOB = today.getDate() - birthDate.getDate();
  if (monthDOB < 0) {
    year = yearTmp - 1;
    month = (month * 12) + today.getMonth() - birthDate.getMonth();
  } else if (monthDOB >= 0) {
    year = yearTmp;
    month = (year * 12) + today.getMonth() - birthDate.getMonth();
    if (monthDOB === 0 && dayDOB < 0) {
      year = yearTmp - 1;
      month = (year * 12) + today.getMonth() - birthDate.getMonth() + 11;
    }
  }
  if (today.getMonth() === birthDate.getMonth() && today.getDate() === birthDate.getDate()) {
    year -= 1;
    month -= 1;
    day -= 1;
  }
  const anb = year + 1;
  return {
    year, month, day, anb,
  };
};

export default {
  getProductCode,
  getMainQuotation,
  getLifeAssTotal,
  getPersonalInformation,
  isPHeqLA,
  createHash,
  onCheckHash,
  storeSpajToRedux,
  storeSpajToSql,
  getCustomerId,
  getLabelLA,
  getLabelPayor,
  isPH,
  getLabelPolicyHolder,
  calculateAgeTMP,
  isSyariah,
  mappingStep5SKA,
  mappingStep1SKA,
};
