/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

/* eslint-disable react-native/no-inline-styles */

import React, { Component } from 'react';
import {
  View, Dimensions, Platform,
} from 'react-native';
import {
  Picker,
} from 'native-base';
import Icon from 'react-native-vector-icons/FontAwesome';
import Styles from '../../../styles';

const iosMarginHorizontal = 60;
const iosIconMarginLeft = iosMarginHorizontal + 20;
const androidMarginHorizontal = 60;

let defaultPickerIOS = {
  width: Dimensions.get('window').width - iosMarginHorizontal,
  alignItems: 'center',
};
let defaultIosIcon = {
  position: 'absolute',
  width: 14,
  marginLeft: Dimensions.get('window').width - iosIconMarginLeft,
  padding: 0,
  fontSize: 14,
  color: Styles.Color.white,
};

let defaultPickerAndroid = {
  width: Dimensions.get('window').width - androidMarginHorizontal,
  marginRight: 0,
  color: Styles.Color.white,
  alignItems: 'center',
};

class PickerLogin extends Component {
  constructor(props) {
    super(props);

    this.state = {
      PickerInput: Platform.OS === 'ios' ? defaultPickerIOS : defaultPickerAndroid,
      iOSPickerIcon: defaultIosIcon,
    };
  }

  componentDidMount() {
    this.refreshDimensions();

    Dimensions.addEventListener('change', () => {
      this.refreshDimensions();
    });
  }

  refreshDimensions = () => {
    if (this.refView) {
      defaultPickerIOS = {
        ...defaultPickerIOS,
        width: Dimensions.get('window').width - iosMarginHorizontal,
      };
      defaultIosIcon = {
        ...defaultIosIcon,
        width: Dimensions.get('window').width - iosIconMarginLeft,
      };

      defaultPickerAndroid = {
        ...defaultPickerAndroid,
        width: Dimensions.get('window').width - androidMarginHorizontal,
      };

      this.setState({
        PickerInput: Platform.OS === 'ios' ? defaultPickerIOS : defaultPickerAndroid,
      });
    }
  }

  renderItems = data => data.map((item, i) => (
    /* eslint-disable react/no-array-index-key */
    <Picker.Item key={i} label={item.label} value={item.value} />
    /* eslint-enable react/no-array-index-key */
  ))

  render() {
    return (
      <View
        ref={(c) => { this.refView = c; }}
        style={[
          Styles.Main.formInputBg,
          Styles.Main.mr30,
          Styles.Main.ml30,
          Styles.Main.mb15,
          Styles.Main.noBorderBottom,
        ]}
      >
        <Picker
          mode="dialog"
          style={this.state.PickerInput}
          textStyle={{
            color: Styles.Color.white,
            textAlign: 'center',
            flex: 1,
            paddingLeft: 22,
            paddingRight: 22,
          }}
          iosIcon={<Icon name="angle-down" style={this.state.iOSPickerIcon} />}
          selectedValue={this.props.selectedValue}
          onValueChange={value => this.props.onValueChange(value)}
        >
          {this.renderItems(this.props.data)}
        </Picker>
      </View>
    );
  }
}

export default PickerLogin;
