import ViewsTodoList from './views';

export default {
  MainTodoList: { screen: ViewsTodoList.MainTodoList },
  PendingProposalList: { screen: ViewsTodoList.PendingProposal },
  CustomerBirthdayList: { screen: ViewsTodoList.CustomerBirthday },
  FollowUpDetails: { screen: ViewsTodoList.FollowUpDetails },
  FundHistoryDetails: { screen: ViewsTodoList.FundHistoryDetails },
  CustomerInformation: { screen: ViewsTodoList.CustomerInformation },
  PolicyDetail: { screen: ViewsTodoList.PolicyDetail },
  ClaimHistoryDetail: { screen: ViewsTodoList.ClaimHistoryDetail },
  InsuranceBenefits: { screen: ViewsTodoList.InsuranceBenefits },
  MainDueDate: { screen: ViewsTodoList.MainDueDate.MainDueDate },
  AfterDueDateList: { screen: ViewsTodoList.MainDueDate.AfterDueDateList },
  AfterDueDateDetail: { screen: ViewsTodoList.MainDueDate.AfterDueDateDetail },
  TransferHistory: { screen: ViewsTodoList.MainDueDate.TransferHistory },
  MedicalLetterPDF: { screen: ViewsTodoList.MedicalLetterPDF },
  DocumentViewer: { screen: ViewsTodoList.DocumentViewer },
  PremiInformationDetail: { screen: ViewsTodoList.MainDueDate.PremiInformationDetail },
};
