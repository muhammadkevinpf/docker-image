/*
* This code was written in Node.JS
* the purpose is for uploading code and DB to AppCenter CodePush server
*/

const { exec } = require('child_process');
const os = require('os');
const CONFIG = require('./config.json');
require('dotenv').config();

const createCodePushFolder = 'mkdir ./CodePush';
const db = process.env.ENVIRONTMENT === 'UAT' ? 'basqs_1.0.0.db' : 'basqs_1.0.0-prod.db';
const buildCodeAndAssets = `react-native bundle --dev false --platform ${CONFIG.platform} --entry-file index.js --bundle-output ./CodePush/${CONFIG.platform === 'ios' ? 'main.jsbundle' : 'index.android.bundle'} --assets-dest ./CodePush`;
const copyDBUnix = `cp ./www/${process.env.DBCHANNEL === 'BAC' ? db : 'newsqs.db'} ./CodePush/newsqs.db`;
const copyDBWindows = `copy ./www/${process.env.DBCHANNEL === 'BAC' ? db : 'newsqs.db'} ./CodePush/newsqs.db`;
const pushCode = `code-push release ${CONFIG.platform === 'ios' ? CONFIG.appIos : CONFIG.appAndroid} ./CodePush "${CONFIG.appVersion}" -m --des "${CONFIG.message}" -d ${CONFIG.env}`;
const removeFolder = `${os.type() === 'Windows_NT' ? 'rmdir ./CodePush /s /q' : 'rm -rf ./CodePush'}`;

const buildCodeAndCopyDB = () => {
  console.log('Preparing Resources!');
  const scriptDB = CONFIG.isDeployDB ? ` && ${os.type() === 'Darwin' ? copyDBUnix : copyDBWindows}` : '';
  exec(`${createCodePushFolder} && ${buildCodeAndAssets}${scriptDB}`,
    (error, stdout, stderr) => {
      console.log(stdout);
      console.log(stderr);
      if (error !== null) {
        console.log(`exec error: ${error}`);
        return;
      }
      console.log('Preparing Done!');
      uploadCode();
    });
};

const uploadCode = () => {
  console.log('Ready To Upload!');
  exec(pushCode,
    (error, stdout, stderr) => {
      console.log(stdout);
      console.log(stderr);
      if (error !== null) {
        console.log(`exec error: ${error}`);
      }
      console.log('Upload Done! Cleaning Data!');
      exec(removeFolder,
        (error, stdout, stderr) => {
          console.log(stdout);
          console.log(stderr);
          if (error !== null) {
            console.log(`exec error: ${error}`);
            return;
          }
          console.log('Cleaning Data Done!');
          console.log('Closing Push Update. Bye!');
        });
    });
};

const start = () => {
  console.log('Starting Push Update!');
  buildCodeAndCopyDB();
};

start();
