/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import {
  View, Image, Dimensions,
} from 'react-native';
import PropTypes from 'prop-types';
import Style from '../../styles';

const dimensions = Dimensions.get('window');

class Image21Card extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  render() {
    return (
      <View
        style={[this.props.containerStyle]}
      >
        <Image
          source={this.props.source}
          style={[Style.Main.fullWidth, {
            height: (dimensions.width / 2),
          }, this.props.imageStyle]}
        />
      </View>
    );
  }
}

Image21Card.propTypes = {
  source: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  containerStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  imageStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
};

Image21Card.defaultProps = {
  source: '',
  containerStyle: null,
  imageStyle: null,
};

export default Image21Card;
