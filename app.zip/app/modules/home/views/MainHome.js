/* eslint-disable no-console */
/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import {
  YellowBox, Image, BackHandler, Alert,
} from 'react-native';
import {
  Container, View, Text, Button,
} from 'native-base';
import { connect } from 'react-redux';
import RNExitApp from 'react-native-exit-app';
import { isTablet, wp } from '../../../utilities';
import { SideBarHome } from '../../../components';
import { BgMainPage, RevampMainPage } from '../../../assets/images';
import Style from '../../../styles';
import _ from '../../../lang';

YellowBox.ignoreWarnings(['Warning: ReactNative.createElement']);

const Home = ({ children }) => (
  <Container style={[Style.Main.container, Style.Main.rowDirection]}>
    <Image
      source={BgMainPage}
      style={[Style.Main.setSize({
        bottom: 0, h: '100%', w: '100%', position: 'absolute', zIndex: -1,
      })]}
    />
    <View style={[Style.Main.container, isTablet() ? [Style.Main.padding30, Style.Main.mt20] : Style.Main.padding12]}>
      {children}
    </View>
  </Container>
);
class MainHome extends Component {
  componentDidMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleBack();
      return true;
    });
    // if (this.props.signInDate && moment().diff(this.props.signInDate, 'days') <= 5) {
    //   this.props.navigation.replace('MainDashboard');
    // }
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  handleBack = () => {
    Alert.alert(_('Warning'), _('Apakah anda yakin ingin keluar dari PRUFast?'), [{
      text: _('Ya'),
      onPress: () => RNExitApp.exitApp(), // biar ketika bacl ga jadi background apps
    }, { text: _('Tidak'), onPress: () => {} }]);
  }

  renderInfo = () => (
    <>
      <Text style={[Style.Main.textWhite, Style.Main.fontAlbert, Style.Main.font44, Style.Main.mb20, Style.Main.mt18,
        !isTablet() && Style.Main.textAlignCenter]}
      >PRUFast
      </Text>
      <Text style={[Style.Main.textWhite, Style.Main.fontAlbertBold16]}>{_('Layanan Kesehatan Terbaru Prudential')}</Text>
      <Text
        onPress={() => this.props.navigation.replace('PrivacyPolicyHome')}
        style={[Style.Main.textWhite, Style.Main.fontAlbert12, Style.Main.mt5]}
      >
        {_('Asuransi Prudential kini telah mewujudkan layanan kesehatan terintegrasi baru dengan bekerja sama dengan ')}
        {_('rumah sakit ternama yang lebih memudahkan nasabah...')}
      </Text>
    </>
  )

  renderImg = () => (
    <View style={[isTablet() ? [Style.Main.flex8] : [Style.Main.container, Style.Main.center], Style.Main.justifyBottom]}>
      <Image source={RevampMainPage} style={{ height: wp(isTablet() ? 509 : 244), width: wp(isTablet() ? 566 : 271) }} />
    </View>
  )

  renderButton = () => (
    <>
      <SideBarHome navigation={this.props.navigation} />
      <Button
        block
        style={[Style.Main.btnPrimary, Style.Main.borderRadius10, !isTablet() && Style.Main.mb10]}
        onPress={() => this.props.navigation.replace('SignInHome')}
      ><Text> {_('MASUK')}</Text>
      </Button>
    </>
  )

  render() {
    if (isTablet()) {
      return (
        <Home>
          <View style={[Style.Main.container, Style.Main.rowDirection]}>
            {this.renderImg()}
            <View style={[Style.Main.flex5, Style.Main.justifyBottom]}>
              {this.renderInfo()}
              {this.renderButton()}
            </View>
          </View>
        </Home>
      );
    }
    return (
      <Home>
        {this.renderInfo()}
        {this.renderImg()}
        {this.renderButton()}
      </Home>
    );
  }
}

const mapStateToProps = state => ({
  auth: state.auth.res,
  signInDate: state.auth.signInDate,
});

export default connect(mapStateToProps)(MainHome);
