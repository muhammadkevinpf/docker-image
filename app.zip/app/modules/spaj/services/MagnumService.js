import { MagnumApi } from 'react-native-magnum-plugin';
import { SHA1 } from 'crypto-js';
import RNFB from 'rn-fetch-blob';
import Share from 'react-native-share';
import { Platform, Alert } from 'react-native';
import DeviceInfo from 'react-native-device-info';
import BootstrapStorageService from '../../sqs-spaj/services/BootstrapStorageService';
import { check, checkAndRequest, STORAGE_PERMISSIONS } from '../../../utilities/Permission';
import _ from '../../../lang';
import { saveLog, CONSTANT } from '../../../utilities/Logger';

const DB_KEY = 'prudential-life-assurance-indonesia';
const RULEBASE_PATH = 'magnum-assets/resources/MagnumRuleBase.json';
const LANGUAGE = 'in_ID';

const magnumApi = new MagnumApi();

const writeToFile = async () => {
  try {
    await checkAndRequest(STORAGE_PERMISSIONS[0]);
    await checkAndRequest(STORAGE_PERMISSIONS[1]);
    const checkRead = await check(STORAGE_PERMISSIONS[0]);
    const checkWrite = await check(STORAGE_PERMISSIONS[1]);
    if (!checkRead || !checkWrite) {
      Alert.alert(_('Warning'), _('Download file gagal, tidak mendapatkan akses ke penyimpanan'), [{ text: _('Tutup') }]);
      return;
    }
    const magnumLog = await magnumApi.getLogRecords();
    const {
      createFile, dirs, exists, writeFile,
    } = RNFB.fs;
    const path = `${Platform.OS === 'ios' ? dirs.DocumentDir : dirs.DownloadDir}/magnumLog_${DeviceInfo.getModel()}.txt`;
    if (await exists(path)) {
      await writeFile(path, JSON.stringify(magnumLog), 'utf8');
    } else {
      await createFile(path, JSON.stringify(magnumLog), 'utf8');
    }
    Share.open({
      title: 'magnum log',
      url: `file://${path}`,
      message: 'magnum log',
      subject: 'magnum log',
      failOnCancel: false,
    });
  } catch (error) {
    console.log(error);
  }
};

const magnumCheckVersion = () => new Promise(async (resolve, reject) => {
  try {
    const version = await magnumApi.getVersion();
    if (version.Success) {
      resolve(version);
    } else {
      reject(version.ApiErrorObject);
    }
  } catch (error) {
    reject(error);
  }
});

const magnumStartUp = () => new Promise(async (resolve, reject) => {
  try {
    const res = await magnumApi.startup(DB_KEY);
    if (res.Success) {
      resolve(res);
    } else {
      reject(res.ApiErrorObject);
    }
  } catch (error) {
    reject(error);
  }
});

const magnumSyncRuleBase = () => new Promise(async (resolve, reject) => {
  try {
    const res = await magnumApi.syncRulebaseFromPath(RULEBASE_PATH);
    if (res.Success) {
      resolve(res);
    } else {
      reject(res.ApiErrorObject);
    }
  } catch (error) {
    reject(error);
  }
});

const magnumEraseData = () => new Promise(async (resolve, reject) => {
  try {
    const res = await magnumApi.eraseData();
    if (res.Success) {
      resolve(res);
    } else {
      reject(res.ApiErrorObject);
    }
  } catch (error) {
    reject(error);
  }
});

const magnumGetCases = () => new Promise(async (resolve, reject) => {
  try {
    const cases = await magnumApi.getCases();
    if (cases.Success) {
      resolve(cases);
    } else {
      reject(cases.ApiErrorObject);
    }
  } catch (error) {
    reject(error);
  }
});

const magnumGetCaseStatus = caseId => new Promise(async (resolve, reject) => {
  try {
    const caseStatus = await magnumApi.getCaseStatus(caseId);
    if (caseStatus.Success) {
      resolve(caseStatus);
    } else {
      reject(caseStatus.ApiErrorObject);
    }
  } catch (error) {
    reject(error);
  }
});

const magnumGetNavigationForLife = (caseId, lifeIndex) => new Promise(async (resolve, reject) => {
  try {
    const navigationForLife = await magnumApi.getNavigationForLife(caseId, lifeIndex);
    if (navigationForLife.Success) {
      resolve(navigationForLife);
    } else {
      reject(navigationForLife.ApiErrorObject);
    }
  } catch (error) {
    reject(error);
  }
});

const magnumStartCase = (caseId, bootstrapJson) => new Promise(async (resolve, reject) => {
  try {
    const res = await magnumApi.startCase(bootstrapJson, caseId, LANGUAGE);
    if (res.Success) {
      resolve(res);
    } else {
      reject(res.ApiErrorObject);
    }
    resolve('Case Started!');
  } catch (error) {
    reject(error);
  }
});

const magnumResumeCase = caseId => new Promise(async (resolve, reject) => {
  try {
    const appFormModel = await magnumApi.resumeCase(caseId);
    if (appFormModel.Success) {
      resolve(appFormModel);
    } else {
      reject(appFormModel.ApiErrorObject);
    }
    resolve(appFormModel);
  } catch (error) {
    reject(error);
  }
});

const magnumDeleteCase = caseId => new Promise(async (resolve, reject) => {
  try {
    const res = await magnumApi.deleteCase(caseId);
    if (res.Success) {
      resolve(res);
    } else {
      reject(res.ApiErrorObject);
    }
    resolve('Case Deleted!');
  } catch (error) {
    reject(error);
  }
});

const magnumGetSubmitPackage = caseId => new Promise(async (resolve, reject) => {
  try {
    const submittedPackage = await magnumApi.getSubmitPackage(caseId, true);
    if (submittedPackage.Success) {
      resolve(submittedPackage);
    } else {
      reject(submittedPackage.ApiErrorObject);
    }
    resolve(submittedPackage);
  } catch (error) {
    reject(error);
  }
});

const magnumGetCaseAnswers = caseId => new Promise(async (resolve, reject) => {
  try {
    const caseAnswer = await magnumApi.getCaseAnswers(caseId);
    if (caseAnswer.Success) {
      resolve(caseAnswer);
    } else {
      reject(caseAnswer.ApiErrorObject);
    }
    resolve(caseAnswer);
  } catch (error) {
    reject(error);
  }
});

const magnumImportCase = caseImportJson => new Promise(async (resolve, reject) => {
  try {
    const res = await magnumApi.importCase(caseImportJson, true);
    if (res.Success) {
      resolve(res);
    } else {
      saveLog(CONSTANT.ERROR, `import magnum error | ${JSON.stringify(res.ApiErrorObject)}`);
      reject(res.ApiErrorObject);
    }
    resolve('Import Success!');
  } catch (error) {
    reject(error);
  }
});

const magnumExportCase = caseId => new Promise(async (resolve, reject) => {
  try {
    const caseData = await magnumApi.exportCase(caseId);
    if (caseData.Success) {
      resolve(caseData);
    } else {
      reject(caseData.ApiErrorObject);
    }
    resolve(caseData);
  } catch (error) {
    reject(error);
  }
});

const magnumUpdateCaseBootstrap = (caseId, bootstrapJson) => new Promise(async (resolve, reject) => {
  try {
    const result = await magnumApi.updateCaseBootstrap(caseId, bootstrapJson);
    if (!result.Success) {
      reject(result.ApiErrorObject);
    }
    resolve(result);
  } catch (error) {
    reject(error);
  }
});

// FUNCTION TO GET JSON WF AND HPX FOR SUBMISSION
const getMagnumSubmitData = (caseId, agentCode) => new Promise(async (resolve, reject) => {
  try {
    const magnum = {};
    const caseData = await magnumGetSubmitPackage(caseId);
    magnum.wf = JSON.parse(caseData.Data);
    magnumGetCaseAnswers(caseId)
      .then(async (caseAnswer) => {
        try {
          magnum.hpx = JSON.parse(JSON.stringify(caseAnswer.Data).replace('&lt;', '<'));
          const responseBootstrap = await BootstrapStorageService.getByCode(global.database.pruSmart, { agentCode, proposalCd: caseId });
          if (responseBootstrap) {
            magnum.bootstrap = JSON.parse(JSON.stringify(responseBootstrap));
          } else {
            magnum.bootstrap = {};
          }
          resolve(removeFamilyName(magnum));
        } catch (error) {
          reject(error);
        }
      }, async () => {
        try {
          magnum.hpx = {};
          const responseBootstrap = await BootstrapStorageService.getByCode(global.database.pruSmart, { agentCode, proposalCd: caseId });
          if (responseBootstrap) {
            magnum.bootstrap = JSON.parse(JSON.stringify(responseBootstrap));
          } else {
            magnum.bootstrap = {};
          }
          resolve(removeFamilyName(magnum));
        } catch (error) {
          reject(error);
        }
      });
  } catch (error) {
    reject(error);
  }
});

const removeFamilyName = (magnumObject) => {
  try {
    let wfLength = magnumObject.wf.dataPackages[0].attributes.length;
    let bsLength = magnumObject.bootstrap.attributes.length;
    for (let wfIndex = 0; wfIndex < wfLength; wfIndex += 1) {
      if (magnumObject.wf.dataPackages[0].attributes[wfIndex].attribute.includes('FamilyName')) {
        magnumObject.wf.dataPackages[0].attributes.splice(wfIndex, 1);
        wfLength = magnumObject.wf.dataPackages[0].attributes.length;
      }
    }
    for (let bsIndex = 0; bsIndex < bsLength; bsIndex += 1) {
      if (magnumObject.bootstrap.attributes[bsIndex].attribute.includes('FamilyName')) {
        magnumObject.bootstrap.attributes.splice(bsIndex, 1);
        bsLength = magnumObject.bootstrap.attributes.length;
      }
    }
  } catch (error) {
    console.log(error);
  }
  return (magnumObject);
};

const getMagnumDataForSync = (proposalCd, spajData, agentCode) => new Promise(async (resolve, reject) => {
  try {
    const db = global.database.pruSmart;
    let obj = {};
    const bootstrap = await BootstrapStorageService.getByCode(db, { agentCode, proposalCd });
    const submittedPackage = JSON.parse((await magnumGetSubmitPackage(proposalCd)).Data);
    const getNavigationForLife = spajData.client.lifeAss.map(async (x, i) => {
      const navigationForLife = await magnumGetNavigationForLife(proposalCd, i);
      return navigationForLife;
    });
    const navigationForLife = await Promise.all(getNavigationForLife);
    if (bootstrap) {
      const bootstrapData = {
        bootstrapData: {
          attributes: bootstrap.attributes,
        },
        cisCheckSum: SHA1(JSON.stringify(bootstrap)).toString(),
        basicMapped: true,
        coverageMapped: true,
        magnumData: {
          initUnderwritingForm: true,
          startupSuccess: true,
          initReviewForm: true,
          caseId: proposalCd,
          initLifeSelection: true,
          selectedNavigation: {},
          caseData: {},
          selectedLife: {},
        },
      };
      bootstrapData.magnumData.caseData.LastlifeIndex = spajData.client.lifeAss.length - 1;
      bootstrapData.magnumData.caseData.lifeList = spajData.client.lifeAss.map((x, i) => ({
        NavigationModel: navigationForLife[i].Data,
        FullName: x.customerId,
        Icon: x.sex === 'M' ? 'MALE' : 'FEMALE',
        LifeIndex: i,
      }));
      bootstrapData.magnumData.selectedNavigation = { ...bootstrapData.magnumData.caseData.lifeList[0].NavigationModel.NavigationList[0] };
      bootstrapData.magnumData.caseData.Language = submittedPackage.languageCode;
      bootstrapData.magnumData.caseData.CaseId = proposalCd;
      bootstrapData.magnumData.selectedLife = { ...bootstrapData.magnumData.caseData.lifeList[0] };
      const exportCaseData = await magnumExportCase(proposalCd);
      obj = { bootstrapData, magnum: exportCaseData.Data };
    }
    resolve(obj);
  } catch (error) {
    reject(error);
  }
});


export default {
  magnumStartUp,
  magnumCheckVersion,
  magnumSyncRuleBase,
  magnumEraseData,
  magnumGetCases,
  magnumGetCaseStatus,
  magnumStartCase,
  magnumResumeCase,
  magnumDeleteCase,
  magnumGetSubmitPackage,
  magnumGetCaseAnswers,
  getMagnumSubmitData,
  magnumGetNavigationForLife,
  magnumImportCase,
  magnumExportCase,
  getMagnumDataForSync,
  writeToFile,
  magnumUpdateCaseBootstrap,
};
