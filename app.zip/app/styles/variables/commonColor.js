// @flow

import color from 'color';
import {
  Platform, Dimensions, PixelRatio,
} from 'react-native';
import Style from '..';

const deviceHeight = Dimensions.get('window').height;
const deviceWidth = Dimensions.get('window').width;
const platform = Platform.OS;
const platformStyle = undefined;
const isIphoneX =
  platform === 'ios' && (deviceHeight === 812 || deviceWidth === 812 || deviceHeight === 896 || deviceWidth === 896);

let toolBarHeight = 0;
if (platform === 'ios') {
  toolBarHeight = isIphoneX ? 88 : 64;
} else {
  toolBarHeight = 56;
}

export default {
  platformStyle,
  platform,

  // Accordion
  headerStyle: '#edebed',
  iconStyle: Style.Color.black,
  contentStyle: '#f5f4f5',
  expandedIconStyle: Style.Color.black,
  accordionBorderColor: '#d3d3d3',

  // Android
  androidRipple: true,
  androidRippleColor: 'rgba(256, 256, 256, 0.3)',
  androidRippleColorDark: 'rgba(0, 0, 0, 0.15)',
  btnUppercaseAndroidText: false,

  // Badge
  badgeBg: '#ED1727',
  badgeColor: Style.Color.white,
  badgePadding: platform === 'ios' ? 3 : 0,

  // Button
  btnFontFamily: Style.Font.FSAlbertPro,
  btnDisabledBg: '#b5b5b5',
  buttonPadding: 6,
  get btnPrimaryBg() {
    return this.brandPrimary;
  },
  get btnPrimaryColor() {
    return this.inverseTextColor;
  },
  get btnInfoBg() {
    return this.brandInfo;
  },
  get btnInfoColor() {
    return this.inverseTextColor;
  },
  get btnSuccessBg() {
    return this.brandSuccess;
  },
  get btnSuccessColor() {
    return this.inverseTextColor;
  },
  get btnDangerBg() {
    return this.brandDanger;
  },
  get btnDangerColor() {
    return this.inverseTextColor;
  },
  get btnWarningBg() {
    return this.brandWarning;
  },
  get btnWarningColor() {
    return this.inverseTextColor;
  },
  get btnTextSize() {
    return this.fontSizeBase * 1;
  },
  get btnTextSizeLarge() {
    return this.fontSizeBase * 1.5;
  },
  get btnTextSizeSmall() {
    return this.fontSizeBase * 0.8;
  },
  get borderRadiusLarge() {
    return this.fontSizeBase * 3.8;
  },
  get iconSizeLarge() {
    return this.iconFontSize * 1.5;
  },
  get iconSizeSmall() {
    return this.iconFontSize * 0.6;
  },

  // Card
  cardDefaultBg: Style.Color.white,
  cardBorderColor: '#ccc',
  cardBorderRadius: 3,
  cardItemPadding: platform === 'ios' ? 10 : 12,

  // CheckBox
  CheckboxRadius: platform === 'ios' ? 13 : 3,
  CheckboxBorderWidth: platform === 'ios' ? 1 : 2,
  CheckboxPaddingLeft: platform === 'ios' ? 4 : 2,
  CheckboxPaddingBottom: platform === 'ios' ? 0 : 5,
  CheckboxIconSize: platform === 'ios' ? 21 : 16,
  CheckboxIconMarginTop: platform === 'ios' ? undefined : 1,
  CheckboxFontSize: 14,
  checkboxBgColor: '#039BE5',
  checkboxSize: 20,
  checkboxTickColor: Style.Color.white,
  checkboxDefaultColor: 'transparent',

  // Color
  brandPrimary: platform === 'ios' ? '#007aff' : '#3F51B5',
  brandInfo: '#62B1F6',
  brandSuccess: '#5cb85c',
  brandDanger: '#d9534f',
  brandWarning: '#f0ad4e',
  brandDark: Style.Color.black,
  brandLight: '#f4f4f4',

  // Container
  containerBgColor: Style.Color.white,

  // Date Picker
  datePickerTextColor: Style.Color.black,
  datePickerBg: 'transparent',

  // Font
  DefaultFontSize: 16,
  fontFamily: Style.Font.FSAlbertPro,
  fontSizeBase: 16,
  get fontSizeH1() {
    return this.fontSizeBase * 1.8;
  },
  get fontSizeH2() {
    return this.fontSizeBase * 1.6;
  },
  get fontSizeH3() {
    return this.fontSizeBase * 1.4;
  },

  // Footer
  footerHeight: 55,
  footerDefaultBg: Style.Color.white,
  footerPaddingBottom: 0,

  // FooterTab
  tabBarTextColor: platform === 'ios' ? '#737373' : '#bfc6ea',
  tabBarTextSize: platform === 'ios' ? 14 : 11,
  activeTab: platform === 'ios' ? '#007aff' : Style.Color.white,
  sTabBarActiveTextColor: '#007aff',
  tabBarActiveTextColor: platform === 'ios' ? '#2874F0' : Style.Color.white,
  tabActiveBgColor: platform === 'ios' ? '#cde1f9' : '#3F51B5',

  // Header
  toolbarBtnColor: Style.Color.white,
  toolbarDefaultBg: Style.Color.red,
  toolbarHeight: toolBarHeight,
  toolbarSearchIconSize: platform === 'ios' ? 20 : 23,
  toolbarInputColor: Style.Color.white,
  searchBarHeight: platform === 'ios' ? 30 : 40,
  searchBarInputHeight: platform === 'ios' ? 30 : 50,
  toolbarBtnTextColor: Style.Color.white,
  iosStatusbar: 'light-content',
  toolbarDefaultBorder: Style.Color.red,
  get statusBarColor() {
    return color(this.toolbarDefaultBg)
      .darken(0.2)
      .hex();
  },
  get darkenHeader() {
    return color(this.tabBgColor)
      .darken(0.03)
      .hex();
  },

  // Icon
  iconFamily: 'FontAwesome',
  iconFontSize: platform === 'ios' ? 20 : 18,
  iconHeaderSize: platform === 'ios' ? 33 : 24,

  // InputGroup
  inputFontSize: 14,
  inputBorderColor: '#D9D5DC',
  inputSuccessBorderColor: '#2b8339',
  inputErrorBorderColor: '#ed2f2f',
  inputHeightBase: 50,
  get inputColor() {
    return this.textColor;
  },
  get inputColorPlaceholder() {
    return '#575757';
  },

  // Line Height
  btnLineHeight: 19,
  lineHeightH1: 32,
  lineHeightH2: 27,
  lineHeightH3: 22,
  lineHeight: 22,

  // List
  listBg: 'transparent',
  listBorderColor: '#c9c9c9',
  listDividerBg: '#f4f4f4',
  listBtnUnderlayColor: '#DDD',
  listItemPadding: platform === 'ios' ? 10 : 12,
  listNoteColor: '#808080',
  listNoteSize: 13,
  listItemSelected: platform === 'ios' ? '#007aff' : '#3F51B5',

  // Progress Bar
  defaultProgressColor: '#E4202D',
  inverseProgressColor: '#1A191B',

  // Radio Button
  radioBtnSize: platform === 'ios' ? 25 : 23,
  radioSelectedColorAndroid: '#3F51B5',
  radioBtnLineHeight: platform === 'ios' ? 29 : 24,
  get radioColor() {
    return this.brandPrimary;
  },

  // Segment
  segmentBackgroundColor: platform === 'ios' ? Style.Color.white : Style.Color.white,
  segmentActiveBackgroundColor: platform === 'ios' ? Style.Color.red : Style.Color.red,
  segmentTextColor: platform === 'ios' ? Style.Color.white : Style.Color.white,
  segmentActiveTextColor: platform === 'ios' ? Style.Color.white : Style.Color.white,
  segmentBorderColor: platform === 'ios' ? Style.Color.white : Style.Color.white,
  segmentBorderColorMain: platform === 'ios' ? '#a7a6ab' : '#3F51B5',

  // Spinner
  defaultSpinnerColor: '#45D56E',
  inverseSpinnerColor: '#1A191B',

  // Tab
  tabDefaultBg: platform === 'ios' ? '#F8F8F8' : '#F8F8F8',
  topTabBarTextColor: platform === 'ios' ? Style.Color.lightGray : Style.Color.lightGray,
  topTabBarActiveTextColor: platform === 'ios' ? Style.Color.red : Style.Color.red,
  topTabBarBorderColor: platform === 'ios' ? '#a7a6ab' : '#a7a6ab',
  topTabBarActiveBorderColor: platform === 'ios' ? Style.Color.red : Style.Color.red,

  // Tabs
  tabBgColor: '#F8F8F8',
  tabFontSize: 14,

  // Text
  textColor: Style.Color.lightGray,
  inverseTextColor: Style.Color.white,
  noteFontSize: 14,
  get defaultTextColor() {
    return this.textColor;
  },

  // Title
  titleFontfamily: Style.Font.FSAlbertPro,
  titleFontSize: 16,
  subTitleFontSize: 14,
  subtitleColor: Style.Color.white,
  titleFontColor: Style.Color.white,

  // Other
  borderRadiusBase: 3,
  borderWidth: 1 / PixelRatio.getPixelSizeForLayoutSize(1),
  contentPadding: 10,
  dropdownLinkColor: '#414142',
  inputLineHeight: 24,
  deviceWidth,
  deviceHeight,
  isIphoneX,
  inputGroupRoundedBorderRadius: 30,

  // iPhoneX SafeArea
  Inset: {
    portrait: {
      topInset: 24,
      leftInset: 0,
      rightInset: 0,
      bottomInset: 34,
    },
    landscape: {
      topInset: 0,
      leftInset: 44,
      rightInset: 44,
      bottomInset: 21,
    },
  },
};
