import configs from '../configs/ConfigProductSPAJ';
import {
  UPDATE_SPAJ,
  UPDATE_TOPUP,
  UPDATE_TOPUP_PAYOR,
  RESET_TOPUP_PAYOR,
  UPDATE_CUST_PH,
  UPDATE_CUST_PY,
  UPDATE_CUST_TU,
  UPDATE_CUST_TT1,
  UPDATE_CUST_TT2,
  UPDATE_POLICY,
  UPDATE_BANK,
  UPDATE_AGENT,
  UPDATE_DOCUMENT,
  UPDATE_BENEFIT,
  ADD_BENEFIT,
  DELETE_BENEFIT,
  UPDATE_VALIDATION_TRACKER,
  UPDATE_AMANDEMEN,
  UPDATE_SKA,
  UPDATE_SIGN_PH,
  UPDATE_SIGN_AGENT,
  UPDATE_PAYMENT,
  UPDATE_RECURRING,
  RESET_RECURRING,
  RESET_SPAJ,
  UPDATE_PREMI_PAYMENT,
  UPDATE_UW_QUESTIONAIRE,
  RESET_PREMI_PAYMENT,
  UPDATE_IS_TOPUP,
  UPDATE_TOPUP_FUND,
  UPDATE_TOPUP_AMOUNT,
  UPDATE_TOPUP_CURR,
  RESET_TOPUP,
  UPDATE_TOPUP_PAYOR_NAME,
  UPDATE_TOPUP_PAYOR_TYPE,
  UPDATE_TOPUP_PAYOR_RELATIONSHIP,
  UPDATE_TOPUP_PAYOR_OCCUPATION,
  UPDATE_TOPUP_PAYOR_IS_NON_RUTIN,
  UPDATE_TOPUP_PAYOR_INCOME,
  UPDATE_TOPUP_PAYOR_WHY_TOPUP,
  UPDATE_TOPUP_PAYOR_IS_ENTREPRENEUR,
  UPDATE_TOPUP_PAYOR_ENTREPRENEUR,
  UPDATE_INCOME_TU,
  UPDATE_INCOME_TT1,
  UPDATE_INCOME_TT2,
  UPDATE_NPWP_NO,
  UPDATE_NPWP_FLAG,
  UPDATE_FSC,
  UPDATE_VIDEO_UPLOADER,
  UPDATECOFLAG,
  UPDATE_OJKRIPLAY,
} from '../actions/types';
import { ApiRequestStatus } from '../services/RestClientService';

export function spajReducer(state = configs.getInitialDataSPAJ().spaj, action) {
  const newLA = state.client.lifeAss;
  switch (action.type) {
    case RESET_SPAJ:
      return configs.getInitialDataSPAJ().spaj;

    case UPDATE_VIDEO_UPLOADER: {
      const newState = { ...state, videoSubmission: { ...state.videoSubmission, status: action.status } };
      switch (action.status) {
        case ApiRequestStatus.SUCCEEDED: return { ...newState, videoSubmission: { ...state.videoSubmission, data: action.payload } };
        case ApiRequestStatus.FAILED: return { ...newState, videoSubmission: { ...state.videoSubmission, data: action.payload } };
        case ApiRequestStatus.LOADING: return newState;
        default: return newState;
      }
    }

    case UPDATE_SPAJ:
      return {
        ...state,
        ...action.payload,
      };

    case UPDATE_CUST_PH:
      return {
        ...state,
        client: {
          ...state.client,
          ph: {
            ...state.client.ph,
            ...action.payload,
          },
        },
      };

    case UPDATE_CUST_TU:
      newLA.splice(newLA.findIndex(x => x.role === '01'), 1, action.payload);

      return {
        ...state,
        client: {
          ...state.client,
          lifeAss: newLA,
        },
      };

    case UPDATE_CUST_TT1:
      newLA.splice(newLA.findIndex(x => x.role === '02'), 1, action.payload);

      return {
        ...state,
        client: {
          ...state.client,
          lifeAss: newLA,
        },
      };

    case UPDATE_CUST_TT2:
      newLA.splice(newLA.findIndex(x => x.role === '03'), 1, action.payload);

      return {
        ...state,
        client: {
          ...state.client,
          lifeAss: newLA,
        },
      };

    case UPDATE_NPWP_FLAG:
      return {
        ...state,
        client: {
          ...state.client,
          ph: {
            ...state.client.ph,
            npwp_flag: action.payload,
          },
        },
      };

    case UPDATE_NPWP_NO:
      return {
        ...state,
        client: {
          ...state.client,
          ph: {
            ...state.client.ph,
            npwp: action.payload,
          },
        },
      };

    case UPDATE_INCOME_TU:
      newLA.splice(newLA.findIndex(x => x.role === '01'), 1, {
        ...newLA[0],
        income: action.payload,
      });

      return {
        ...state,
        client: {
          ...state.client,
          lifeAss: newLA,
        },
      };

    case UPDATE_INCOME_TT1:
      newLA.splice(newLA.findIndex(x => x.role === '02'), 1, {
        ...newLA[1],
        income: action.payload,
      });

      return {
        ...state,
        client: {
          ...state.client,
          lifeAss: newLA,
        },
      };

    case UPDATE_INCOME_TT2:
      newLA.splice(newLA.findIndex(x => x.role === '03'), 1, {
        ...newLA[2],
        income: action.payload,
      });

      return {
        ...state,
        client: {
          ...state.client,
          lifeAss: newLA,
        },
      };

    case UPDATE_CUST_PY:
      return {
        ...state,
        policy: {
          ...state.policy,
          payor: {
            ...state.policy.payor,
            ...action.payload,
          },
        },
      };

    case UPDATE_POLICY:
      return {
        ...state,
        policy: {
          ...state.policy,
          ...action.payload,
        },
      };

    case UPDATE_BANK:
      return {
        ...state,
        bank: {
          ...state.bank,
          ...action.payload,
        },
      };

    case UPDATE_AGENT:
      return {
        ...state,
        agent: {
          ...state.agent,
          ...action.payload,
        },
      };

    case UPDATE_SIGN_PH:
      return {
        ...state,
        sqs: {
          ...state.sqs,
          sqs: {
            ...state.sqs.sqs,
            sign: {
              ...state.sqs.sqs.sign,
              ph: {
                ...state.sqs.sqs.sign.ph,
                ...action.payload,
              },
            },
          },
        },
      };

    case UPDATE_SIGN_AGENT:
      return {
        ...state,
        sqs: {
          ...state.sqs,
          sqs: {
            ...state.sqs.sqs,
            sign: {
              ...state.sqs.sqs.sign,
              agent: {
                ...state.sqs.sqs.sign.ph,
                ...action.payload,
              },
            },
          },
        },
      };

      // ================== STEP 4 ==============

    case UPDATE_TOPUP:
      return {
        ...state,
        policy: {
          ...state.policy,
          topUp: {
            ...state.policy.topUp,
            ...action.payload,
          },
        },
      };

    case UPDATE_TOPUP_PAYOR:
      return {
        ...state,
        policy: {
          ...state.policy,
          topUp: {
            ...state.policy.topUp,
            payor: {
              ...state.policy.topUp.payor,
              ...action.payload,
            },
          },
        },
      };

    case RESET_TOPUP_PAYOR:
      return {
        ...state,
        policy: {
          ...state.policy,
          topUp: {
            ...state.policy.topUp,
            payor: configs.getInitialDataSPAJ().spaj.policy.topUp.payor,
          },
        },
      };

      // Smaller Reducer

    case UPDATE_IS_TOPUP:
      return {
        ...state,
        policy: {
          ...state.policy,
          topUp: {
            ...state.policy.topUp,
            is_topup: action.payload,
          },
        },
      };

    case UPDATE_TOPUP_FUND:
      return {
        ...state,
        policy: {
          ...state.policy,
          topUp: {
            ...state.policy.topUp,
            fund: action.payload,
          },
        },
      };

    case UPDATE_TOPUP_AMOUNT:
      return {
        ...state,
        policy: {
          ...state.policy,
          topUp: {
            ...state.policy.topUp,
            amount: action.payload,
          },
        },
      };

    case UPDATE_TOPUP_CURR:
      return {
        ...state,
        policy: {
          ...state.policy,
          topUp: {
            ...state.policy.topUp,
            curr: action.payload,
          },
        },
      };

    case RESET_TOPUP:
      return {
        ...state,
        policy: {
          ...state.policy,
          topUp: {
            ...state.policy.topUp,
            curr: '',
            amount: '',
            fund: [],
          },
        },
      };

    case UPDATE_TOPUP_PAYOR_NAME:
      return {
        ...state,
        policy: {
          ...state.policy,
          topUp: {
            ...state.policy.topUp,
            payor: {
              ...state.policy.topUp.payor,
              name: action.payload,
            },
          },
        },
      };

    case UPDATE_TOPUP_PAYOR_TYPE:
      return {
        ...state,
        policy: {
          ...state.policy,
          topUp: {
            ...state.policy.topUp,
            payor: {
              ...state.policy.topUp.payor,
              type: action.payload,
            },
          },
        },
      };

    case UPDATE_TOPUP_PAYOR_RELATIONSHIP:
      return {
        ...state,
        policy: {
          ...state.policy,
          topUp: {
            ...state.policy.topUp,
            payor: {
              ...state.policy.topUp.payor,
              relationship: action.payload,
              desc_relationship: action.payload,
            },
          },
        },
      };

    case UPDATE_TOPUP_PAYOR_OCCUPATION:
      return {
        ...state,
        policy: {
          ...state.policy,
          topUp: {
            ...state.policy.topUp,
            payor: {
              ...state.policy.topUp.payor,
              occp: action.payload,
            },
          },
        },
      };

    case UPDATE_TOPUP_PAYOR_IS_NON_RUTIN:
      return {
        ...state,
        policy: {
          ...state.policy,
          topUp: {
            ...state.policy.topUp,
            payor: {
              ...state.policy.topUp.payor,
              is_non_rutin: action.payload,
            },
          },
        },
      };

    case UPDATE_TOPUP_PAYOR_INCOME:
      return {
        ...state,
        policy: {
          ...state.policy,
          topUp: {
            ...state.policy.topUp,
            payor: {
              ...state.policy.topUp.payor,
              income: action.payload,
            },
          },
        },
      };

    case UPDATE_TOPUP_PAYOR_WHY_TOPUP:
      return {
        ...state,
        policy: {
          ...state.policy,
          topUp: {
            ...state.policy.topUp,
            payor: {
              ...state.policy.topUp.payor,
              why_topUp: action.payload,
            },
          },
        },
      };

    case UPDATE_TOPUP_PAYOR_IS_ENTREPRENEUR:
      return {
        ...state,
        policy: {
          ...state.policy,
          topUp: {
            ...state.policy.topUp,
            payor: {
              ...state.policy.topUp.payor,
              is_entrepreneur: action.payload,
            },
          },
        },
      };

    case UPDATE_TOPUP_PAYOR_ENTREPRENEUR:
      return {
        ...state,
        policy: {
          ...state.policy,
          topUp: {
            ...state.policy.topUp,
            payor: {
              ...state.policy.topUp.payor,
              entrepreneur: action.payload,
            },
          },
        },
      };


    // ================== STEP 5 ==============
    case UPDATE_BENEFIT: {
      const newBenef = state.client.benef.slice();
      return {
        ...state,
        client: {
          ...state.client,
          benef: newBenef.map((item) => {
            if (item.id === action.payload.id) {
              return {
                ...item,
                ...action.payload,
              };
            }
            return item;
          }),
        },
      };
    }
    case ADD_BENEFIT: {
      const newBenef = state.client.benef.slice();
      newBenef.push(
        {
          ...configs.getInitialDataSPAJ().spaj.client.benef[0],
          id: `form${parseInt(state.client.benef[state.client.benef.length - 1].id.replace('form', ''), 0) + 1}`,
        },
      );
      return {
        ...state,
        client: {
          ...state.client,
          benef: newBenef,
        },
      };
    }

    case DELETE_BENEFIT: {
      let newBenef = state.client.benef.slice();
      newBenef = newBenef.filter(item => item.id !== action.payload);
      return {
        ...state,
        client: {
          ...state.client,
          benef: newBenef,
        },
      };
    }

    // ================== STEP 6 ==============

    case UPDATE_DOCUMENT:
      return {
        ...state,
        policy: {
          ...state.policy,
          doc_upl: action.payload,
        },
      };

      // ================== STEP 7 ==============

    case UPDATE_AMANDEMEN:
      return {
        ...state,
        amend: {
          ...state.amend,
          ...action.payload,
        },
      };


      // ============= SKA ==============
    case UPDATE_SKA:
      return {
        ...state,
        policy: {
          ...state.policy,
          ska: {
            ...state.policy.ska,
            ...action.payload,
          },
        },
      };

      // ================ TRACKER ===============

    case UPDATE_VALIDATION_TRACKER:
      return {
        ...state,
        tracker: {
          ...state.tracker,
          ...action.payload,
        },
      };

      // ================ PAYMENT ===============

    case UPDATE_PAYMENT:
      return {
        ...state,
        policy: {
          ...state.policy,
          payment: action.payload,
          bank: {
            ...state.policy.bank,
            ...action.payload[0],
          },
        },
      };

    case UPDATE_PREMI_PAYMENT: {
      const newPayment = state.policy.payment;
      newPayment.splice(0, 1, { ...state.policy.payment[0], ...action.payload });
      return {
        ...state,
        policy: {
          ...state.policy,
          payment: newPayment,
        },
      };
    }

    case RESET_PREMI_PAYMENT: {
      const newPayment = state.policy.payment;
      newPayment.splice(0, 1, { ...configs.getInitialDataSPAJ().spaj.policy.payment[0], ...action.payload });
      return {
        ...state,
        policy: {
          ...state.policy,
          payment: newPayment,
        },
      };
    }

    // =============== RECURRING ===============

    case UPDATE_RECURRING:
      return {
        ...state,
        policy: {
          ...state.policy,
          recurring: {
            ...state.policy.recurring,
            ...action.payload,
          },
        },
      };

    case RESET_RECURRING:
      return {
        ...state,
        policy: {
          ...state.policy,
          recurring: {
            ...configs.getInitialDataSPAJ().spaj.policy.recurring,
            ...action.payload,
          },
        },
      };

    // STEP2: MEDICAL DATA
    case UPDATE_UW_QUESTIONAIRE:
      return {
        ...state,
        policy: {
          ...state.policy,
          uw_questionnaire: action.payload,
        },
      };

    case UPDATE_FSC:
      return {
        ...state,
        fsc: {
          ...state.fsc,
          ...action.payload,
        },
      };

    case UPDATECOFLAG:
      return {
        ...state,
        counterOfferFlag:
          action.payload,
      };

    case UPDATE_OJKRIPLAY:
      return {
        ...state,
        sqs: {
          ...state.sqs,
          sqs: {
            ...state.sqs.sqs,
            ojkRiplay: action.payload,
          },
        },
      };
    default:
      return state;
  }
}
