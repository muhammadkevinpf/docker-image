/**
 * @author:
 * dwi.setiyadi@gmail.com
 * ahmdichsanb@gmail.com
*/

import React from 'react';
import {
  View, Modal, ActivityIndicator as Spinner, Platform,
} from 'react-native';
import PropTypes from 'prop-types';
import StyleLoadingModal from './StyleLoadingModal';
import Style from '../../styles';
import { isTablet } from '../../utilities';

class LoadingModal extends React.Component {
  render() {
    const { show, size, color } = this.props;
    return (
      Platform.OS === 'android' ?
        <Modal
          animationType="fade"
          transparent
          visible={show}
          onRequestClose={this.props.onRequestClose}
        >
          <View style={[StyleLoadingModal.container, isTablet() && Style.Main.nullMinHeight]}>
            <Spinner size={size} color={color} style={[Style.Main.alignCenter]} />
          </View>
        </Modal>
        :
        show &&
        <View style={[StyleLoadingModal.containerSpinner]}>
          <Spinner size={size} color={color} />
        </View>
    );
  }
}

LoadingModal.propTypes = {
  show: PropTypes.bool.isRequired,
  size: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.oneOf(['small', 'large']),
  ]).isRequired,
  color: PropTypes.string.isRequired,
  onRequestClose: PropTypes.func,
};

LoadingModal.defaultProps = {
  onRequestClose: () => {},
};

export default LoadingModal;
