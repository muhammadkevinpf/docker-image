/**
 * @author: dwi.setiyadi@gmail.com
*/

import { StyleSheet, Platform } from 'react-native';
import Style from '../../styles';

const Font = {
  left: {
    fontWeight: '900',
    fontFamily: Style.Font.frutigerLinotype,
    fontSize: 16,
    marginTop: Platform.OS === 'ios' ? 4 : 0,
  },
  right: {
    fontWeight: 'normal',
    fontFamily: Style.Font.garamond,
    fontSize: 16,
    marginTop: Platform.OS === 'ios' ? 5 : 2,
  },
};

export default StyleSheet.create({
  container: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  leftGray: {
    ...Font.left,
    color: Style.Color.lightGray,
  },
  rightGray: {
    ...Font.right,
    color: Style.Color.lightGray,
  },
  leftWhite: {
    ...Font.left,
    color: Style.Color.white,
  },
  rightWhite: {
    ...Font.right,
    color: Style.Color.white,
  },
  leftRed: {
    ...Font.left,
    color: Style.Color.red,
  },
  rightRed: {
    ...Font.right,
    color: Style.Color.red,
  },
});
