/**
 * @author: dwi.setiyadi@gmail.com
*/

import RouterHome from '../modules/home/RouterHome';
import RouterDashboard from '../modules/dashboard/RouterDashboard';
import RouterSQSNSpaj from '../modules/sqs-spaj/RouterSQSNSpaj';
import RouterNotification from '../modules/notification/RouterNotification';
import RouterSpaj from '../modules/spaj/RouterSpaj';
import RouterTodoList from '../modules/todo-list/RouterTodoList';
import RouterNewsUpdate from '../modules/news-and-update/RouterNews';
import RouterProduction from '../modules/production/RouterProduction';
import RouterPersistency from '../modules/persistency/RouterPersistency';
import RouterProposalPolicy from '../modules/proposal-policy/RouterProposalPolicy';
import RouterClient from '../modules/client/RouterClient';
import RouterCommissionEstimation from '../modules/commission-estimation/RouterCommission';
import RouterIncomeStatement from '../modules/income-statement/RouterIncomeStatement';
import RouterCounterOffer from '../modules/counter-offer/RouterCounterOffer';
import RouterFeedback from '../modules/feedback/RouterFeedback';
import RouterCorrespondence from '../modules/correspondence/RouterCorrespondence';
import RouterActivity from '../modules/activity-management/RouterActivity';
import RouterPruexpert from '../modules/pruexpert/RouterPruexpert';
import RouterPolicyTransaction from '../modules/policy-transaction/RouterPolicyTransaction';
import RouterDictionary from '../modules/dictionary/RouterDictionary';
import RouterResearch from '../modules/research/RouterResearch';

const modules = {
  ...RouterHome,
  ...RouterDashboard,
  ...RouterSQSNSpaj,
  ...RouterNotification,
  ...RouterSpaj,
  ...RouterTodoList,
  ...RouterNewsUpdate,
  ...RouterProduction,
  ...RouterPersistency,
  ...RouterProposalPolicy,
  ...RouterClient,
  ...RouterResearch,
  ...RouterCommissionEstimation,
  ...RouterIncomeStatement,
  ...RouterCounterOffer,
  ...RouterFeedback,
  ...RouterCorrespondence,
  ...RouterActivity,
  ...RouterPruexpert,
  ...RouterPolicyTransaction,
  ...RouterDictionary,
};

const settings = {
  defaultNavigationOptions: {
    header: null,
    headerMode: 'none',
    mode: 'screen',
  },
};

const exitAppWhiteListScreen = [
  'MainHome',
];

export default {
  modules,
  settings,
  exitAppWhiteListScreen,
};
