/* eslint-disable max-len */
/* eslint-disable react/no-array-index-key */
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
// import moment from 'moment';
import { TouchableOpacity } from 'react-native';
import {
  Text, Card, View, Icon,
} from 'native-base';
import Style from '../../../styles';
import { rowLayout, Skeleton } from '../../../components';

export class ProspectListCard extends PureComponent {
  render() {
    const { data, isLoading } = this.props;
    const status = data.logFeedback && data.logFeedback.length ? data.logFeedback[0].reason.feedback[0].description : 'N/A';
    const fontColor = data.logFeedback && data.logFeedback.length ? data.logFeedback[0].reason.feedback[0].fontColor : null;
    return (
      <Card style={this.props.cardStyle}>
        <View
          style={[Style.Main.alignContentCenter, Style.Main.mV10, Style.Main.pb5]}
        >
          <View style={[Style.Main.borderBottomWidth1, Style.Main.borderBottomGray, Style.Main.pb10, Style.Main.mb5]}>
            <Skeleton isLoading={isLoading} layout={[rowLayout({ w: '50%', h: 11 })]} style={[isLoading && Style.Main.ml12, Style.Main.rowDirectionSpaceBetween]}>
              <Text style={[Style.Main.fontAlbertBold14, Style.Main.ph12, Style.Main.justifyCenter]}>{(data.fullname && data.fullname !== 'undefined') ? data.fullname : 'N/A'}</Text>
              <View style={[Style.Main.rowDirectionSpaceBetween]}>
                <TouchableOpacity onPress={this.props.onPhoneClicked}>
                  <Icon name="phone" type="MaterialCommunityIcons" style={[Style.Main.font20, Style.Main.textGray, Style.Main.mr12]} />
                </TouchableOpacity>
                <TouchableOpacity onPress={this.props.onMenuClicked}>
                  <Icon name="dots-vertical" type="MaterialCommunityIcons" style={[Style.Main.font20, Style.Main.textRed, Style.Main.mr10]} />
                </TouchableOpacity>
              </View>
            </Skeleton>
          </View>
          <Skeleton
            isLoading={isLoading}
            layout={[rowLayout({ w: '30%', h: 9 }), rowLayout({ w: '28%', h: 9 }), rowLayout({ w: '25%', h: 9 }),
              rowLayout({ w: '28%', h: 9 }), rowLayout({ w: '15%', h: 9 }), rowLayout({ w: '25%', h: 9 })]}
            style={[Style.Main.ph12]}
          >
            <Text style={[Style.Main.fontAlbert12, Style.Main.textGray, Style.Main.mt5]}>Tanggal Masuk Prospek</Text>
            <Text style={[Style.Main.fontAlbert12, Style.Main.textAlmostBlack, Style.Main.mb10]}>{(data.createdAt && data.createdAt !== 'undefined') ? data.createdAt : 'N/A'}</Text>
            <Text style={[Style.Main.fontAlbert12, Style.Main.textGray]}>Tanggal Aktivitas</Text>
            <Text style={[Style.Main.fontAlbert12, Style.Main.textAlmostBlack, Style.Main.mb10]}>{(data.activityDate && data.activityDate !== 'undefined') ? data.activityDate : 'N/A'}</Text>
            <Text style={[Style.Main.fontAlbert12, Style.Main.textGray]}>Status</Text>
            <Text style={[Style.Main.fontAlbert12, Style.Main.mb10, { color: fontColor }]}>{(status && status !== 'undefined') ? status : 'N/A'}</Text>
          </Skeleton>
        </View>
      </Card>
    );
  }
}

ProspectListCard.propTypes = {
  onPhoneClicked: PropTypes.func,
  onMenuClicked: PropTypes.func,
};

ProspectListCard.defaultProps = {
  onPhoneClicked: () => { },
  onMenuClicked: () => { },
};
