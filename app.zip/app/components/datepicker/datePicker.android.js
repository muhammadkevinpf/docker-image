/* eslint-disable no-console */
/**
 * @author: ahmdichsanb@gmail.com
*/

import React, { Component, Fragment } from 'react';
import {
  DatePickerAndroid,
} from 'react-native';

class AndroidDatePicker extends Component {
  setDate = async () => {
    try {
      const {
        maximumDate, minimumDate, mode, dateValue,
      } = this.props;

      const maxDate = maximumDate;
      const minDate = minimumDate;

      const {
        action, year, month, day,
      } = await DatePickerAndroid.open({
        date: dateValue,
        maxDate,
        minDate,
        mode,
      });

      let newDate = null;
      if (action !== DatePickerAndroid.dismissedAction) {
        newDate = new Date(year, month, day);
        this.props.onDateChange(newDate);
        return;
      }

      this.props.onDateChange(newDate);
    } catch ({ message }) {
      console.warn('Cannot open date picker: ', message);
    }
  };

  render() {
    const { component, isDatePickerOpen } = this.props;

    if (isDatePickerOpen) {
      this.setDate();
    }

    return (
      <Fragment>
        {component}
      </Fragment>
    );
  }
}

export default AndroidDatePicker;
