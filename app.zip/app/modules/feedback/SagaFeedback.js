/* eslint-disable max-len */
/* eslint-disable no-console */
import { takeLatest } from 'redux-saga/effects';
import { feedbackAction } from './ActionFeedback';
import { apiSagaFunction } from '../../utilities/Functions';
import {
  GET_ALL_FEEDBACK, GET_SUB_TRANSACTION_TYPE, GET_DETAIL_FEEDBACK, GET_FILE_BASE64, FIND_TRANSACTION_TYPE, FIND_SUB_TRANSACTION_TYPE, GET_AGENT_DATA, SUBMIT_FEEDBACK,
} from './ConfigFeedback';

const timeout = 20000;
export const watcherFeedback = [
  takeLatest(GET_ALL_FEEDBACK.FETCH, params => apiSagaFunction(params.payload, feedbackAction, GET_ALL_FEEDBACK, { timeout, isResponArray: true })),
  takeLatest(GET_SUB_TRANSACTION_TYPE.FETCH, params => apiSagaFunction(params.payload, feedbackAction, GET_SUB_TRANSACTION_TYPE, { timeout, isResponArray: true })),
  takeLatest(GET_DETAIL_FEEDBACK.FETCH, params => apiSagaFunction(params.payload, feedbackAction, GET_DETAIL_FEEDBACK, { timeout })),
  takeLatest(FIND_TRANSACTION_TYPE.FETCH, params => apiSagaFunction(params.payload, feedbackAction, FIND_TRANSACTION_TYPE, { timeout, isResponArray: true })),
  takeLatest(FIND_SUB_TRANSACTION_TYPE.FETCH, params => apiSagaFunction(params.payload, feedbackAction, FIND_SUB_TRANSACTION_TYPE, { timeout, isResponArray: true })),
  takeLatest(GET_FILE_BASE64.FETCH, params => apiSagaFunction(params.payload, feedbackAction, GET_FILE_BASE64, { timeout })),
  takeLatest(GET_AGENT_DATA.FETCH, params => apiSagaFunction(params.payload, feedbackAction, GET_AGENT_DATA, { timeout })),
  takeLatest(SUBMIT_FEEDBACK.FETCH, params => apiSagaFunction(params.payload, feedbackAction, SUBMIT_FEEDBACK, { timeout })),
];
