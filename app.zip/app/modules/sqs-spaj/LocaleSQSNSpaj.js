/**
 * @author dwi.setiyadi@gmail.com
 */

const translation = [
  {
    id: 'contoh',
    en: 'example',
  },
];

export default translation;
