import {
  ConfigAOB,
} from './config';

const {
  LISTCANDIDATEFETCH,
  LISTCANDIDATESUCCESS,
  LISTCANDIDATEFAILED,
} = ConfigAOB;

const initialState = {
  fetchListCandidate: false,
  send: null,
  res: null,
  err: null,
};

export function ReducerAob(state = initialState, action) {
  switch (action.type) {
    case LISTCANDIDATEFETCH:
      return {
        ...state,
        fetchListCandidate: true,
        send: action.send,
        action: action.type,
      };
    case LISTCANDIDATESUCCESS:
      return {
        ...state,
        fetchSignIn: false,
        res: {
          ...state.res,
          listCandidate: {
            ...action.res,
          },
        },
        err: null,
        action: action.type,
      };
    case LISTCANDIDATEFAILED:
      return {
        ...state,
        fetchListCANDIDATE: false,
        err: action.err,
        action: action.type,
      };
    default:
      return state;
  }
}
