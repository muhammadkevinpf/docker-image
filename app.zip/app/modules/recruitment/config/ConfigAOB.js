const ADAPTERAUTH = 'adapters/HTTPAdapterAuth';
const ADAPTERAUTHFLINK = 'adapters/HTTPAdapterAuthFlink';

// Flink Adapter

const validateDataBeforeGenerateNPA = (phoneNo, email, idCardNo, accessToken) => ({
  adapter: `${ADAPTERAUTHFLINK}/validateDataBeforeGenerateNPA`,
  procedure: 'validateDataBeforeGenerateNPA',
  method: 'post',
  parameters: { params: [phoneNo, email, idCardNo, accessToken] },
});

const createNPA = (leaderofficecode, recruiteragentcode, leadername, leaderagentcode,
  recruitername, idno, phoneno, npaToken, dob, name,
  recruiterofficecode, email, placeofbirth, accessToken, isPruventure,
  pruventureCity, pruventureLevel, pruventureExperience) => ({
  adapter: `${ADAPTERAUTHFLINK}/createNPA`,
  procedure: 'createNPA',
  method: 'post',
  parameters: {
    // eslint-disable-next-line max-len
    params: [leaderofficecode, recruiteragentcode, leadername, leaderagentcode, recruitername, idno, phoneno, npaToken, dob, name, recruiterofficecode, email, placeofbirth, accessToken, isPruventure, pruventureCity, pruventureLevel, pruventureExperience],
  },
});

// Microservice

// Registrasi
const GetEmailExist = (email, phoneNo) => ({
  adapter: `${ADAPTERAUTH}/getEmailExist`,
  procedure: 'getEmailExist',
  method: 'post',
  parameters: { params: [email, phoneNo] },
});

const RequestCancelNPA = {
  adapter: `${ADAPTERAUTH}/requestCancelNPA`,
  procedure: 'requestCancelNPA',
  method: 'post',
};

const GenerateNPA = (Cname, CDOB, CEmail, CIDCardNo, CPhoneNo, CRecuiter, CReqCode,
  CReqOffCode, CLeadName, CLeadCode, CLeadOffCode, npaToken) => ({
  adapter: `${ADAPTERAUTH}/GenerateNPA`,
  procedure: 'GenerateNPA',
  method: 'post',
  parameters: {
    params: [Cname, CDOB, CEmail, CIDCardNo, CPhoneNo, CRecuiter, CReqCode, CReqOffCode, CLeadName, CLeadCode, CLeadOffCode, npaToken],
  },
});

const GetTokenGenerateNPA = {
  adapter: `${ADAPTERAUTH}/getTokenGenerateNPA`,
  procedure: 'getTokenGenerateNPA',
  method: 'post',
  parameters: [],
};

const RecruitmentExam = {
  adapter: `${ADAPTERAUTH}/RecExam`,
  procedure: 'RecExam',
  method: 'post',
};

// Verifikasi
const VerifyCandidate = (npa, nama, idCardNo, checkSalesForceIdFlag) => ({
  adapter: `${ADAPTERAUTH}/verifyCandidate`,
  procedure: 'verifyCandidate',
  method: 'post',
  parameters: { params: [npa, nama, idCardNo, checkSalesForceIdFlag] },
});

const GetPruForceID = (agentCode, npaNumber) => ({
  adapter: `${ADAPTERAUTH}/getIDpruforceid`,
  procedure: 'getIDpruforceid',
  method: 'post',
  parameters: { params: [agentCode, npaNumber] },
});

// Verifikasi
const VerifyTokenAgent = (npa, smsToken) => ({
  adapter: `${ADAPTERAUTH}/verifyTokenAgent`,
  procedure: 'verifyTokenAgent',
  method: 'post',
  parameters: { params: [npa, smsToken] },
});

const VerifyTokenCandidate = (agentCode, smsToken) => ({
  adapter: `${ADAPTERAUTH}/verifyToken`,
  procedure: 'verifyToken',
  method: 'post',
  parameters: { params: [agentCode, smsToken] },
});

// Create
const CreatePruForceId = (username, password, npa, agentCode) => ({
  adapter: `${ADAPTERAUTH}/createpruforceid`,
  procedure: 'createpruforceid',
  method: 'post',
  parameters: { params: [username, password, npa, agentCode] },
});

// Security Question
const GetSecretQuestion = () => ({
  adapter: `${ADAPTERAUTH}/getSecQuest`,
  procedure: 'getSecQuest',
  method: 'post',
  parameters: [],
});

const VerifyInputSecretQuestion = (sq1no, sq1ans, sq2no, sq2ans, pruforceId) => ({
  adapter: `${ADAPTERAUTH}/verifyInputSQ`,
  procedure: 'verifyInputSQ',
  method: 'post',
  parameters: { params: [sq1no, sq1ans, sq2no, sq2ans, pruforceId] },
});

// Candidate List
const LISTCANDIDATEAPI = `${ADAPTERAUTH}/getListCandidate`;
const LISTCANDIDATEFETCH = 'LISTCANDIDATEFETCH';
const LISTCANDIDATESUCCESS = 'LISTCANDIDATESUCCESS';
const LISTCANDIDATEFAILED = 'LISTCANDIDATEFAILED';

// Training

export default {
  // Flink
  createNPA,
  validateDataBeforeGenerateNPA,

  // Existing
  GetEmailExist,
  RequestCancelNPA,
  GenerateNPA,
  GetTokenGenerateNPA,
  RecruitmentExam,
  LISTCANDIDATEAPI,
  LISTCANDIDATEFETCH,
  LISTCANDIDATESUCCESS,
  LISTCANDIDATEFAILED,
  VerifyCandidate,
  GetPruForceID,
  CreatePruForceId,
  GetSecretQuestion,
  VerifyInputSecretQuestion,
  VerifyTokenAgent,
  VerifyTokenCandidate,
};
