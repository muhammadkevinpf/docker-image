import {
  ConfigAOB,
} from './config';

const {
  LISTCANDIDATEFETCH,
  LISTCANDIDATESUCCESS,
  LISTCANDIDATEFAILED,
} = ConfigAOB;

export const listCandidateFetch = value => ({ type: LISTCANDIDATEFETCH, send: value });
export const listCandidateSuccess = value => ({ type: LISTCANDIDATESUCCESS, res: value });
export const listCandidateFailed = value => ({ type: LISTCANDIDATEFAILED, err: value });
