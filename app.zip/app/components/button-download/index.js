import React from 'react';
import { Fab, Icon } from 'native-base';
import { Platform } from 'react-native';
import Share from 'react-native-share';
import PropTypes from 'prop-types';
import { IncomePassword } from '../../modules/income-statement/components/IncomePassword';
import styles from '../../styles';
import { downloadDoc } from '../../utilities';

class ButtonDownload extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      infoShowed: false,
      downloadedFile: '',
    };
  }

  onSuccess = (index, downloadedFile) => {
    let filename = downloadedFile;
    if (index > 0) filename = `${this.state.downloadedFile} & ${downloadedFile}`;
    if (index === (this.props.data.length - 1)) {
      this.setState({ infoShowed: true, downloadedFile: filename });
    }
  }

  handleDownloadPdf = () => {
    const {
      title, data, message, subject,
    } = this.props;
    if (Platform.OS === 'ios') {
      Share.open({
        title,
        urls: data.map(x => `data:application/pdf;base64,${x.base64}`),
        message,
        subject,
        failOnCancel: false,
        filename: data[0].filename,
      });
      return;
    }
    data.forEach((x, i) => {
      downloadDoc({
        content: x.base64,
        fileName: x.filename,
        onSuccess: res => this.onSuccess(i, res),
      });
    });
  }

  render() {
    const { downloadedFile, infoShowed } = this.state;
    return (
      <React.Fragment>
        <Fab
          direction="up"
          position={this.props.position}
          onPress={this.handleDownloadPdf}
          style={styles.Main.backgroundWhite}
        >
          <Icon
            onPress={this.handleDownloadPdf}
            name={Platform.OS === 'ios' ? this.props.shareIcon : this.props.downloadIcon}
            type="FontAwesome5"
            style={styles.Main.fab}
          />
        </Fab>
        <IncomePassword
          downloadedFile={downloadedFile}
          visible={infoShowed}
          onRequestClose={() => this.setState({ infoShowed: false })}
          passwordFormat="ddMmmyyyy"
          passwordExample="01Aug1970"
          showDisclaimer
        />
      </React.Fragment>
    );
  }
}

export default ButtonDownload;

ButtonDownload.propTypes = {
  downloadIcon: PropTypes.string,
  position: PropTypes.string,
  shareIcon: PropTypes.string,
};

ButtonDownload.defaultProps = {
  downloadIcon: 'file-download',
  position: 'bottomRight',
  shareIcon: 'share-alt',
};
