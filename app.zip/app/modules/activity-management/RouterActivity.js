import Views from './views';

export default {
  ProspectList: { screen: Views.ProspectList },
  ActivitySyncContact: { screen: Views.SyncContact },
  ProspectDetail: { screen: Views.ProspectDetail },
  ProspectInputFeedback: { screen: Views.ProspectInputFeedback },
  AddProspect: { screen: Views.AddProspect },
  EditProspect: { screen: Views.EditProspect },
  AMDashboard: { screen: Views.AMDashboard },
  AMCalendar: { screen: Views.AMCalendar },
  DashboardPointDetails: { screen: Views.DashboardPointDetails },
  DashboardConvertionDetails: { screen: Views.DashboardConvertionDetails },
  DashboardHistoryDetails: { screen: Views.DashboardHistoryDetails },
};
