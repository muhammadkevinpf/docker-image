import {
  call, put, takeLatest,
} from 'redux-saga/effects';
import {
  // Branch office
  CITYBRANCHOFFICEAPI,
  CITYBRANCHOFFICEFETCH,

  BRANCHOFFICEAPI,
  BRANCHOFFICEFETCH,

  // Hospital
  CITYHOSPITALAPI,
  CITYHOSPITALFETCH,

  HOSPITALAPI,
  HOSPITALFETCH,
  FORGOT_PASSWORD,
  CHECK_AGENT_VERIFICATION,
  FORGOT_ID_CANDIDATE,
  SMS_VERIFICATION_AGENT,
  SMS_VERIFICATION_CANDIDATE,
  GET_SECURITY_QUESTIONS,
  CHECK_EMAIL_VERIFICATION,
  CHECK_USER_ID,
  FORGOT_CHANGE_PASSWORD,
  GET_USER_ID,
  CHECK_AGENT_BANCA_BY_AGENT_CODE,
  CHECK_AGENT_BANCA_BY_SALES_FORCE_ID,
  VERIFY_AGENT,
  CREATE_PRUFAST_ID,
  VERIFY_SECQUEST,
} from './ConfigHome';
import {
  cityBranchOfficeSuccess,
  cityBranchOfficeFailed,

  branchOfficeSuccess,
  branchOfficeFailed,

  cityHospitalSuccess,
  cityHospitalFailed,

  hospitalSuccess,
  hospitalFailed,
  authAction,

  verifyBancaAction,
} from './ActionHome';
import { resourceRequest } from '../../utilities/StoreApi';
import { sagaWatcherErrorHandling } from '../../utilities/ErrorHandling';
import { apiSagaFunction } from '../../utilities';

function* workerSagaCityBrachOffice(params) {
  try {
    const res = yield call(resourceRequest, CITYBRANCHOFFICEAPI, 'post', params.send);
    // console.log('Success response: ', resTotalToDo); // eslint-disable-line no-console

    if (res.status === '200' || res.status === 200) {
      yield put.resolve(cityBranchOfficeSuccess(res.data.array));
    } else {
      yield put.resolve(cityBranchOfficeFailed(res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(cityBranchOfficeFailed(parseError));
  }
}

function* workerSagaBrachOffice(params) {
  try {
    const res = yield call(resourceRequest, BRANCHOFFICEAPI, 'post', params.send);

    if ((res.status === '200' || res.status === 200)
      && res.data && res.data.array && res.data.array.length) {
      yield put.resolve(branchOfficeSuccess(res.data.array));
    } else {
      yield put.resolve(branchOfficeFailed(res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(branchOfficeFailed(parseError));
  }
}

function* workerSagaCityHospital(params) {
  try {
    const res = yield call(resourceRequest, CITYHOSPITALAPI, 'post', params.send);

    if ((res.status === '200' || res.status === 200)
      && res.data && res.data.array && res.data.array.length) {
      yield put.resolve(cityHospitalSuccess(res.data.array));
    } else {
      yield put.resolve(cityHospitalFailed(res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(cityHospitalFailed(parseError));
  }
}

function* workerSagaHospital(params) {
  try {
    const res = yield call(resourceRequest, HOSPITALAPI, 'post', params.send);

    if ((res.status === '200' || res.status === 200)
      && res.data.hospitalList) {
      yield put.resolve(hospitalSuccess(res.data.hospitalList));
    } else {
      yield put.resolve(hospitalFailed(res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(hospitalFailed(parseError));
  }
}

export const watcherHome = [
  takeLatest(CITYBRANCHOFFICEFETCH, workerSagaCityBrachOffice),
  takeLatest(BRANCHOFFICEFETCH, workerSagaBrachOffice),
  takeLatest(CITYHOSPITALFETCH, workerSagaCityHospital),
  takeLatest(HOSPITALFETCH, workerSagaHospital),
  takeLatest(GET_SECURITY_QUESTIONS.FETCH,
    params => apiSagaFunction(params.payload, authAction, GET_SECURITY_QUESTIONS, { isResponArray: true })),
  takeLatest(FORGOT_PASSWORD.FETCH,
    params => apiSagaFunction(params.payload, authAction, FORGOT_PASSWORD)),
  takeLatest(CHECK_AGENT_VERIFICATION.FETCH,
    params => apiSagaFunction(params.payload, authAction, CHECK_AGENT_VERIFICATION)),
  takeLatest(FORGOT_ID_CANDIDATE.FETCH,
    params => apiSagaFunction(params.payload, authAction, FORGOT_ID_CANDIDATE)),
  takeLatest(SMS_VERIFICATION_AGENT.FETCH,
    params => apiSagaFunction(params.payload, authAction, SMS_VERIFICATION_AGENT)),
  takeLatest(SMS_VERIFICATION_CANDIDATE.FETCH,
    params => apiSagaFunction(params.payload, authAction, SMS_VERIFICATION_CANDIDATE)),
  takeLatest(CHECK_EMAIL_VERIFICATION.FETCH,
    params => apiSagaFunction(params.payload, authAction, CHECK_EMAIL_VERIFICATION)),
  takeLatest(CHECK_USER_ID.FETCH,
    params => apiSagaFunction(params.payload, authAction, CHECK_USER_ID)),
  takeLatest(GET_USER_ID.FETCH,
    params => apiSagaFunction(params.payload, authAction, GET_USER_ID)),
  takeLatest(FORGOT_CHANGE_PASSWORD.FETCH,
    params => apiSagaFunction(params.payload, authAction, FORGOT_CHANGE_PASSWORD)),
  takeLatest(VERIFY_AGENT.FETCH,
    params => apiSagaFunction(params.payload, authAction, VERIFY_AGENT)),
  takeLatest(CREATE_PRUFAST_ID.FETCH,
    params => apiSagaFunction(params.payload, authAction, CREATE_PRUFAST_ID)),
  takeLatest(VERIFY_SECQUEST.FETCH,
    params => apiSagaFunction(params.payload, authAction, VERIFY_SECQUEST)),
  takeLatest(CHECK_AGENT_BANCA_BY_SALES_FORCE_ID.FETCH,
    params => apiSagaFunction(params.payload, verifyBancaAction, CHECK_AGENT_BANCA_BY_SALES_FORCE_ID)),
  takeLatest(CHECK_AGENT_BANCA_BY_AGENT_CODE.FETCH,
    params => apiSagaFunction(params.payload, verifyBancaAction, CHECK_AGENT_BANCA_BY_AGENT_CODE)),
];
