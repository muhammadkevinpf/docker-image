import {
  call, put, takeLatest,
} from 'redux-saga/effects';
import { resourceRequest } from '../../utilities/StoreApi';
import { sagaWatcherErrorHandling } from '../../utilities/ErrorHandling';
import {
  ConfigIntegration,
} from './config';
import {
  listProposalSuccess,
  listProposalFailed,
} from './ActionSQSNSpaj';

const {
  LISTPROPOSALAPI,
  LISTPROPOSALFETCH,
} = ConfigIntegration;

function* workerSagaListProposal(params) {
  try {
    const response = yield call(resourceRequest, LISTPROPOSALAPI, 'post', params.send);
    console.log('response proposal: ', response); // eslint-disable-line no-console

    if (response.status === '200' || response.status === 200) {
      yield put.resolve(listProposalSuccess(response.data));
    } else {
      yield put.resolve(listProposalFailed(response.data.errorMessage));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(listProposalFailed(parseError));
  }
}

export const watcherSQSNSpaj = [
  takeLatest(LISTPROPOSALFETCH, workerSagaListProposal),
];
