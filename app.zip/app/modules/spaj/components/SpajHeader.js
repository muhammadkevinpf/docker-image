import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {
  Modal, TouchableOpacity, Platform, SafeAreaView,
} from 'react-native';
import { Icon, View, Content } from 'native-base';
import { HeaderWithTodo } from '../../../components';
import { ConfigProductSPAJ } from '../configs';
import { dimensions } from '../../../config/Platform';
import { isTablet } from '../../../utilities';
import NavigationSpaj from '../views/navigation-spaj';
import Style from '../../../styles';

const flexRight = 2;

export default class SpajHeader extends Component {
  constructor() {
    super();
    this.state = {
      navigationObject: [],
      showModal: false,
    };
  }

  componentDidMount() {
    const isSyariah = ConfigProductSPAJ.isSyariah(this.props.spaj);
    const navigationObject = ConfigProductSPAJ.navigationData(isSyariah).find(x => x.routing === this.props.navigation.state.routeName);
    this.setState({ navigationObject });
  }

  shouldComponentUpdate(nextProps, nextState) {
    if (JSON.stringify(nextState) !== JSON.stringify(this.state)) return true;
    if (JSON.stringify(nextProps) !== JSON.stringify(this.props)) return true;
    return false;
  }

  subHeader = () => {
    const { navigationObject } = this.state;
    if (this.props.isNotNavigation) return <React.Fragment>{this.props.headerTitle}</React.Fragment>;
    return (
      <React.Fragment>
        {navigationObject.title ? navigationObject.title.toUpperCase() : ''} &nbsp;
        <Icon type="FontAwesome5" name={this.state.showModal ? 'caret-up' : 'caret-down'} style={[Style.Main.textRed]} />
      </React.Fragment>
    );
  }

  header = () => (
    <HeaderWithTodo
      navigation={this.props.navigation}
      onBackClicked={this.props.onBackClicked}
      headerTitle="e-SPAJ"
      subHeader={this.subHeader()}
      subHeaderPress={() => {
        if (this.props.isNotNavigation) return;
        this.setState(prevState => ({ showModal: !prevState.showModal }));
      }}
    />
  )

  render() {
    const headerHeightAndroid = isTablet() ? 108 : 120;
    const headerHeightIos = isTablet() ? 125 : 165;
    const headerHeight = Platform.OS === 'android' ? headerHeightAndroid : headerHeightIos;
    return (
      <React.Fragment>
        {this.header()}
        <Modal transparent visible={this.state.showModal} onRequestClose={() => this.setState({ showModal: false })}>
          {
            !isTablet() ?
              <SafeAreaView>
                { this.header() }
              </SafeAreaView>
              :
              <TouchableOpacity onPress={() => this.setState({ showModal: false })}>
                <View style={{ height: headerHeight }} />
              </TouchableOpacity>
          }
          <View style={[isTablet() ? { height: dimensions.height - headerHeight } : Style.Main.container, Style.Main.rowDirection]}>
            <Content style={[Style.Main.backgroundWhite, Style.Main.container]}>
              <NavigationSpaj navigation={this.props.navigation} syariah={ConfigProductSPAJ.isSyariah(this.props.spaj)} />
            </Content>
            {isTablet() && <View style={[{ flex: flexRight }, Style.Main.backgroundLightGray, Style.Main.halfOpacity]} />}
          </View>
        </Modal>
      </React.Fragment>
    );
  }
}

SpajHeader.propTypes = {
  onBackClicked: PropTypes.func,
  isNotNavigation: PropTypes.bool,
  headerTitle: PropTypes.string,
};

SpajHeader.defaultProps = {
  onBackClicked: () => {},
  isNotNavigation: false,
  headerTitle: '',
};
