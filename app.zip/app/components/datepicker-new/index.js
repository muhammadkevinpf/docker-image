/* eslint-disable react/forbid-prop-types */
/**
*/

import React, { Component } from 'react';
import {
  DatePicker, Label, Item, Text, View,
} from 'native-base';
import PropTypes from 'prop-types';
import { Col, Row } from 'react-native-easy-grid';
import Icon from 'react-native-vector-icons/FontAwesome';
import { Platform } from 'react-native';
import Style from '../../styles';
import StyleDatePicker from './StyleDatePicker';
import _ from '../../lang';
import DatePickerIos from './DatePickerIos';


class DatePickerNativeBase extends Component {
  constructor(props) {
    super(props);
    this.state = {
      // savedDateString: props.defaultDate ?
      //   this.props.defaultDate.toString().substr(4, 12) : null,
      validStatus: true,
      errorMessage: 'Wajib Diisi!',
    };
    this.setDate = this.setDate.bind(this);
  }

  static getDerivedStateFromProps(props) {
    return {
      chosenDate: props.defaultDate,
    };
  }

  componentDidUpdate() {
    this._datePicker.setState({ chosenDate: this.props.defaultDate });
  }

  setDate(newDate) {
    const { onDateChange } = this.props;
    // this.setState({
    //   savedDateString: newDate.toString().substr(4, 11),
    // }, () => {
    if (onDateChange) {
      // onDateChange(newDate.toString().substr(4, 11));
      onDateChange(newDate);
    }
    // });
  }

  openDatePicker = () => {
    if (this._datePicker) {
      this._datePicker.showDatePicker();
    }
  }

  checkSelected = () => {
    const { savedDate } = this.state;
    if (savedDate) {
      this.setState({
        validStatus: true,
      });
    } else {
      this.setState({
        validStatus: false,
      });
    }
  }

  invokeValidation = (_validStatus, _errorMessage) => {
    let { validStatus, errorMessage } = this.state;

    this.checkSelected();

    if (_validStatus) {
      validStatus = _validStatus;
    }
    if (_errorMessage) {
      errorMessage = _errorMessage;
    }

    this.setState({
      validStatus,
      errorMessage,
    });
  }

  render() {
    const {
      minimumDate,
      maximumDate,
      locale,
      timeZoneOffsetInMinutes,
      modalTransparent,
      animationType,
      androidMode,
      placeHolderText,
      textStyle,
      placeHolderTextStyle,
      bottomLabelStyle, // onDateChange,
      disabled,
      style,
      label,
      bottomLabel,
      errorMessageStyle,
      labelStyle,
    } = this.props;

    const {
      // savedDate,
      validStatus,
      errorMessage,
    } = this.state;

    const savedDate = this.props.defaultDate;
    const majorVersionIOS = parseInt(Platform.Version, 10);

    return (
      <View>
        <View style={[StyleDatePicker.formStyle, style]}>
          <Item style={StyleDatePicker.item}>
            <Col size={10} style={StyleDatePicker.labelAndData}>
              <Label style={[StyleDatePicker.styleTextLabel, Style.Main.fontAlbert, labelStyle]}>{_(label)}</Label>
              {(Platform.OS === 'ios' && majorVersionIOS >= 14) ?
                <DatePickerIos
                  defaultDate={savedDate}
                  minimumDate={minimumDate}
                  maximumDate={maximumDate}
                  locale={locale}
                  timeZoneOffsetInMinutes={timeZoneOffsetInMinutes}
                  modalTransparent={modalTransparent}
                  animationType={animationType}
                  androidMode={androidMode}
                  placeHolderText={_(placeHolderText)}
                  textStyle={[
                    StyleDatePicker.pickerTextStyle,
                    disabled ? Style.Main.textDisabled : Style.Main.textAlmostBlack,
                    Style.Main.fontAlbert,
                    textStyle,
                  ]}
                  placeHolderTextStyle={[StyleDatePicker.placeholderTextStyle, placeHolderTextStyle]}
                  onDateChange={this.setDate}
                  disabled={disabled}
                  ref={(ref) => { this._datePicker = ref; }}
                />
                :
                <DatePicker
                  defaultDate={savedDate}
                  minimumDate={minimumDate}
                  maximumDate={maximumDate}
                  locale={locale}
                  timeZoneOffsetInMinutes={timeZoneOffsetInMinutes}
                  modalTransparent={modalTransparent}
                  animationType={animationType}
                  androidMode={androidMode}
                  placeHolderText={_(placeHolderText)}
                  textStyle={[
                    StyleDatePicker.pickerTextStyle,
                    disabled ? Style.Main.textDisabled : Style.Main.textAlmostBlack,
                    Style.Main.fontAlbert,
                    textStyle,
                  ]}
                  placeHolderTextStyle={[StyleDatePicker.placeholderTextStyle, placeHolderTextStyle]}
                  onDateChange={this.setDate}
                  disabled={disabled}
                  ref={(ref) => { this._datePicker = ref; }}
                />
                }
              {/* <Label>Date: {this.state.savedDateString}</Label> */}
            </Col>
            <Row size={1}>
              <Col>
                {
                  this.props.showIcon ? (
                    <Icon
                      name="calendar"
                      style={[StyleDatePicker.iconStyle]}
                      onPress={() => { if (!disabled) { this.openDatePicker(); } }}
                    />
                  ) : <View />
                }
              </Col>
            </Row>
          </Item>
          {!validStatus ? (
            <Text style={[
              StyleDatePicker.styleBottomLabel,
              Style.Main.fontAlbert,
              errorMessageStyle,
            ]}
            >{_(errorMessage)}
            </Text>) : null}
          {bottomLabel.length !== 0 ?
            (
              bottomLabel.map(element => (
                <Text key={element.toString()} style={[StyleDatePicker.styleBottomLabel, Style.Main.fontAlbert, bottomLabelStyle]}>{_(element)}</Text>
              ))
            ) : null}
        </View>
      </View>
    );
  }
}

DatePickerNativeBase.propTypes = {
  defaultDate: PropTypes.oneOfType([PropTypes.object, PropTypes.func]),
  minimumDate: PropTypes.oneOfType([PropTypes.object, PropTypes.func]),
  maximumDate: PropTypes.oneOfType([PropTypes.object, PropTypes.func]),
  locale: PropTypes.string,
  timeZoneOffsetInMinutes: PropTypes.number,
  modalTransparent: PropTypes.bool,
  animationType: PropTypes.string,
  androidMode: PropTypes.string,
  placeHolderText: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
  textStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  bottomLabelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  placeHolderTextStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  onDateChange: PropTypes.func,
  disabled: PropTypes.bool,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  label: PropTypes.string,
  // isRequired: PropTypes.bool,
  bottomLabel: PropTypes.arrayOf(PropTypes.string),
  errorMessageStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  labelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  showIcon: PropTypes.bool,
};

DatePickerNativeBase.defaultProps = {
  defaultDate: null,
  minimumDate: new Date(new Date().getFullYear() - 70, 0, 1),
  maximumDate: new Date(),
  locale: 'id',
  timeZoneOffsetInMinutes: undefined,
  modalTransparent: false,
  animationType: 'fade', // 'fade','slide','none'
  androidMode: 'spinner', // 'default','calendar','spinner'
  placeHolderText: null,
  textStyle: null,
  bottomLabelStyle: null,
  placeHolderTextStyle: { color: Style.Color.lightGray },
  onDateChange: () => { },
  disabled: false,
  style: null,
  label: null,
  bottomLabel: [],
  // isRequired: false,
  errorMessageStyle: null,
  labelStyle: null,
  showIcon: true,
};

export default DatePickerNativeBase;
