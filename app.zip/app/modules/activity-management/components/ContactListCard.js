/* eslint-disable max-len */
/* eslint-disable react/no-array-index-key */
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
// import moment from 'moment';
import { TouchableOpacity } from 'react-native';
import {
  Text, Card, View, Icon,
} from 'native-base';
import Style from '../../../styles';

export class ContactListCard extends PureComponent {
  render() {
    const { data } = this.props;
    return (
      <Card style={[Style.Main.container, Style.Main.mb5, Style.Main.padding10, Style.Main.rowDirection, Style.Main.fullWidth, this.props.cardStyle]}>
        <TouchableOpacity style={[Style.Main.alignCenter, Style.Main.fullHeight, Style.Main.center]} onPress={this.props.onSelect}>
          <Icon
            name={data.isChecked ? 'checkbox-marked' : 'checkbox-blank-outline'}
            type="MaterialCommunityIcons"
            style={[data.isChecked && !data.isProspect ? Style.Main.textRed : Style.Main.textGray, Style.Main.font18, Style.Main.alignCenter, Style.Main.mr10]}
          />
        </TouchableOpacity>
        <View style={[Style.Main.flex15]}>
          <Text style={[Style.Main.fontAlbert12, Style.Main.textAlmostBlack]}>{data.fullName || 'N/A'}</Text>
          <Text style={[Style.Main.fontAlbert12, Style.Main.textGray]}>{data.phoneNumber || 'N/A'}</Text>
        </View>
        <View style={[Style.Main.justifyCenter, Style.Main.alignCenter]}>
          <Text style={[Style.Main.fontAlbert12, data.isProspect ? Style.Main.textGray : Style.Main.textRed]}>{data.isProspect ? 'Prospek' : 'Baru'}</Text>
        </View>
      </Card>
    );
  }
}

ContactListCard.propTypes = {
  onSelect: PropTypes.func,
};

ContactListCard.defaultProps = {
  onSelect: () => { },
};
