import {
// Branch office
  CITYBRANCHOFFICEFETCH,
  CITYBRANCHOFFICESUCCESS,
  CITYBRANCHOFFICEFAILED,

  BRANCHOFFICEFETCH,
  BRANCHOFFICESUCCESS,
  BRANCHOFFICEFAILED,

  // Hospital
  CITYHOSPITALFETCH,
  CITYHOSPITALSUCCESS,
  CITYHOSPITALFAILED,

  HOSPITALFETCH,
  HOSPITALSUCCESS,
  HOSPITALFAILED,

  CLEARHOSPITALANDOFFICELIST,
} from './ConfigHome';

export const cityBranchOfficeFetch = value => ({ type: CITYBRANCHOFFICEFETCH, send: value });
export const cityBranchOfficeSuccess = value => ({ type: CITYBRANCHOFFICESUCCESS, res: value });
export const cityBranchOfficeFailed = value => ({ type: CITYBRANCHOFFICEFAILED, err: value });

export const branchOfficeFetch = value => ({ type: BRANCHOFFICEFETCH, send: value });
export const branchOfficeSuccess = value => ({ type: BRANCHOFFICESUCCESS, res: value });
export const branchOfficeFailed = value => ({ type: BRANCHOFFICEFAILED, err: value });

export const cityHospitalFetch = value => ({ type: CITYHOSPITALFETCH, send: value });
export const cityHospitalSuccess = value => ({ type: CITYHOSPITALSUCCESS, res: value });
export const cityHospitalFailed = value => ({ type: CITYHOSPITALFAILED, err: value });

export const hospitalFetch = value => ({ type: HOSPITALFETCH, send: value });
export const hospitalSuccess = value => ({ type: HOSPITALSUCCESS, res: value });
export const hospitalFailed = value => ({ type: HOSPITALFAILED, err: value });

export const authAction = (action, value) => ({ type: action, payload: value });

export const verifyBancaAction = (action, value) => ({ type: action, payload: value });

export const clearHospitalAndOfficeList = () => ({ type: CLEARHOSPITALANDOFFICELIST });
