import Views from './views';

// Please update Screen in Sub-Menu Components too
export default {
  MainProposalPolicy: { screen: Views.MainProposalPolicy },
  ProposalPolicyList: { screen: Views.ProposalPolicyList },
  ProposalPolicyListByUnit: { screen: Views.ProposalPolicyListByUnit },
};
