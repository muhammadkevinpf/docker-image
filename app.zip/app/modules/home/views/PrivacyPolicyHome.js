/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import {
  Container,
  Content, Body, View,
  Card, CardItem, Text, List, ListItem,
} from 'native-base';
import { BackHandler } from 'react-native';
import Communications from 'react-native-communications';
import { Grid, Row, Col } from 'react-native-easy-grid';
import Icon from 'react-native-vector-icons/FontAwesome';
import _ from '../../../lang';

import Style from '../../../styles';
import { HeaderWithTodo } from '../../../components';

class PrivacyPolicyHome extends Component {
  componentDidMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleBack();
      return true;
    });
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  handleBack = () => {
    this.props.navigation.replace('MainHome');
  }

  renderContactCenter = () => {
    const dataContact = [
      {
        label: '(021) - 29958585 ext 5 ',
        onPress: () => Communications.phonecall('021 29958585', true),
        icon: 'phone',
      },
      {
        label: 'www.prudential.co.id ',
        onPress: () => Communications.web('https://prudential.co.id/'),
        icon: 'globe',
      },
      {
        label: 'prudigitalfriend@prudential.co.id ',
        onPress: () => Communications.email(['prudigitalfriend@prudential.co.id'], null, null, '', ''),
        icon: 'envelope',
      },
      {
        label: 'Customer Care Centre,  Prudential Tower',
        onPress: () => Communications.web('https://goo.gl/maps/MufkfuAt9zwiDwj9A'),
        icon: 'building',
      },
    ];
    return dataContact.map((x, i) => (
      <ListItem key={i.toString()} style={[Style.Main.noBorderBottom, Style.Main.pt0]}>
        <Grid>
          <Row>
            <Col size={10}>
              <Icon name={x.icon} style={[Style.Main.font20, Style.Main.mt4]} />
            </Col>
            <Col size={90}>
              <View style={Style.Main.textWrap}>
                <Text
                  style={[Style.Main.textBlue]}
                  onPress={x.onPress}
                >
                  {_(x.label)}
                </Text>
              </View>
            </Col>
          </Row>
        </Grid>
      </ListItem>
    ));
  }

  render() {
    return (
      <Container>

        <HeaderWithTodo
          {...this.props}
          headerTitle="Kebijakan Privasi"
          isShowBackButton
          isShowRightButton={false}
          onBackClicked={() => this.props.navigation.replace('MainHome')}
        />

        <Content keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
          <Grid>
            <Row>
              <Col>
                <Card style={[Style.Main.mt15, Style.Main.ml15, Style.Main.mr15, Style.Main.mb10]}>
                  <CardItem bordered>
                    <Body>
                      <View style={Style.Main.textWrap}>
                        <Text style={[Style.Main.mt0]}>
                          {/* eslint-disable max-len */}
                          {_('PT Prudential Life Assurance sangat memperhatikan privasi anda dan juga privasi nasabahnya. Silakan membaca kebijakan privasi ini secara hati-hati untuk dapat memahami kebijakan privasi PT Prudential Life Assurance.')}
                          {/* eslint-enable max-len */}
                        </Text>
                      </View>
                    </Body>
                  </CardItem>
                </Card>
              </Col>
            </Row>

            <Row>
              <Col>
                <Card style={[Style.Main.ml15, Style.Main.mr15, Style.Main.mb10]}>
                  <CardItem
                    header
                    bordered
                  >
                    <Text style={[Style.Main.textRed]}>
                      {_('CAKUPAN KEBIJAKAN PRIVASI PT PRUDENTIAL LIFE ASSURANCE')}
                    </Text>
                  </CardItem>
                  <CardItem>
                    <Body>
                      <View style={Style.Main.textWrap}>
                        <Text style={[Style.Main.mt0]}>
                          {/* eslint-disable max-len */}
                          {_('Kebijakan ini berlaku bagi PT Prudential Life Assurance dan juga setiap pihak lain yang berafiliasi dan bekerja sama dengan PT Prudential Life Assurance.')}
                          {/* eslint-enable max-len */}
                        </Text>
                      </View>
                    </Body>
                  </CardItem>
                </Card>
              </Col>
            </Row>

            <Row>
              <Col>
                <Card style={[Style.Main.ml15, Style.Main.mr15, Style.Main.mb10]}>
                  <CardItem
                    header
                    bordered
                  >
                    <Text style={[Style.Main.textRed]}>
                      {_('PENGAMANAN INFORMASI PRIBADI')}
                    </Text>
                  </CardItem>
                  <CardItem>
                    <Body>
                      <View style={Style.Main.textWrap}>
                        <Text style={[Style.Main.mt0, Style.Main.mb10]}>
                          {/* eslint-disable max-len */}
                          {_('PT Prudential Life Assurance memiliki komitmen untuk selalu mengamankan informasi pribadi anda dan data pribadi nasabah yang diperoleh atau dikumpulkan melalui media website, aplikasi online ataupun berbagai bentuk media lainnya. PT Prudential Life Assurance tidak akan menjual atau menyewakan informasi anda kepada siapapun, namun PT Prudential Life Assurance dapat menggunakan, mengolah, metransfer maupun mengungkapkan informasi pribadi anda atau nasabahnya kepada pihak ketiga atau afiliasinya sebagaimana')}
                          {/* eslint-enable max-len */}
                        </Text>
                        <Text style={[Style.Main.mt0]}>
                          {/* eslint-disable max-len */}
                          {_('Setiap pihak yang berafiliasi dan/atau bekerja sama dengan PT Prudential Life Assurance wajib memahami dan mengetahui bahwa setiap proses penggunaan, pengolahan, transfer atau pengungkapan informasi pribadi nasabah ataupun informasi pribadi lainnya dengan alasan apapun tidak diperkenankan untuk dilakukan. Kecuali hal tersebut telah secara tegas mendapatkan persetujuan dari nasabah atau pemilik data pribadi atau PT Prudential Life Assurance ataupun apabila dibutuhkan oleh hukum dan peraturan yang berlaku. Setiap pihak yang berafiliasi dan/atau bekerja sama dengan PT Prudential Life Assurance yang telah memperoleh persetujuan untuk menggunakan ataupun mengelola informasi pribadi lainnya juga wajib menjaga kerahasiaannya dan menggunakan sesuai kebutuhan. Kegagalan pelaksanaan ketentuan ini dapat mengakibatkan pengenaan sanksi sesuai dengan ketentuan yang tercantum didalam perjanjian kerja sama, hukum dan/atau peraturan perundang-undangan yang berlaku.')}
                          {/* eslint-enable max-len */}
                        </Text>
                      </View>
                    </Body>
                  </CardItem>
                </Card>
              </Col>
            </Row>

            <Row>
              <Col>
                <Card style={[Style.Main.ml15, Style.Main.mr15, Style.Main.mb10]}>
                  <CardItem
                    header
                    bordered
                  >
                    <Text style={[
                      Style.Main.textRed,
                    ]}
                    >
                      {_('PEROLEHAN DAN PENGUMPULAN INFORMASI PRIBADI ANDA')}
                    </Text>
                  </CardItem>
                  <CardItem>
                    <Body>
                      <View style={Style.Main.textWrap}>
                        <Text style={[Style.Main.mt0]}>
                          {/* eslint-disable max-len */}
                          {_('PT Prudential Life Assurance dapat memperoleh dan mengumpulkan informasi pribadi anda yang bersifat sensitif pada saat anda menyampaikan informasi tersebut melalui website, melalui aplikasi online ataupun melalui berbagai bentuk media lainnya. Data pribadi tersebut dapat mencakup tetapi tidak terbatas kepada beberapa informasi seperti: nama, alamat, tanggal lahir, no telepon, alamat email, nama ibu kandung dan juga no identitas (KTP/paspor) anda. PT Prudential Life Assurance juga dapat menyimpan informasi yang berasal dari komputer atau perangkat elektronik anda seperti ip address, informasi hardware dan software ataupun berbagai bentuk informasi lainnya. Perlu anda pahami, jika anda menyampaikan informasi pribadi terkait pihak ketiga ke dalam website, aplikasi online ataupun media lain milik PT Prudential Life Assurance, berarti anda telah mewakili PT Prudential Life Assurance dalam mendapatkan persetujuan pemilik informasi untuk menyediakan informasi tersebut bagi PT Prudential Life Assurance sesuai dengan tujuan masing-masing. Adapun tujuan dari pengumpulan informasi pribadi anda dapat meliputi tetapi tidak terbatas sebagai berikut:')}
                          {/* eslint-enable max-len */}
                        </Text>
                      </View>
                    </Body>
                  </CardItem>

                  <List>

                    <ListItem style={[Style.Main.noBorderBottom, Style.Main.pt0]}>
                      <Row>
                        <Col size={10}>
                          <Text style={Style.Main.mt0}>1.</Text>
                        </Col>
                        <Col size={90}>
                          <View style={Style.Main.textWrap}>
                            <Text style={[Style.Main.mt0]}>
                              {_('Penyediaan dan desain asuransi, jasa keuangan atau produk terkait.')}
                            </Text>
                          </View>
                        </Col>
                      </Row>
                    </ListItem>

                    <ListItem style={[Style.Main.noBorderBottom, Style.Main.pt0]}>
                      <Row>
                        <Col size={10}>
                          <Text style={Style.Main.mt0}>2.</Text>
                        </Col>
                        <Col size={90}>
                          <View style={Style.Main.textWrap}>
                            <Text style={[Style.Main.mt0]}>
                              {/* eslint-disable max-len */}
                              {_('Pengolahan setiap kredit, medis, keamanan dan pengecekan underwriting serta klaim asuransi.')}
                              {/* eslint-enable max-len */}
                            </Text>
                          </View>
                        </Col>
                      </Row>
                    </ListItem>

                    <ListItem style={[Style.Main.noBorderBottom, Style.Main.pt0]}>
                      <Row>
                        <Col size={10}>
                          <Text style={Style.Main.mt0}>3.</Text>
                        </Col>
                        <Col size={90}>
                          <View style={Style.Main.textWrap}>
                            <Text style={[Style.Main.mt0]}>
                              {_('Statistik dan penelitian.')}
                            </Text>
                          </View>
                        </Col>
                      </Row>
                    </ListItem>

                    <ListItem style={[Style.Main.noBorderBottom, Style.Main.pt0]}>
                      <Row>
                        <Col size={10}>
                          <Text style={Style.Main.mt0}>4.</Text>
                        </Col>
                        <Col size={90}>
                          <View style={Style.Main.textWrap}>
                            <Text style={[Style.Main.mt0]}>
                              {/* eslint-disable max-len */}
                              {_('keuangan atau produk wealth management terkait dengan PT Prudential Life Assurance, afiliasinya ataupun mitra lembaga keuangan.')}
                              {/* eslint-enable max-len */}
                            </Text>
                          </View>
                        </Col>
                      </Row>
                    </ListItem>

                    <ListItem style={[Style.Main.noBorderBottom, Style.Main.pt0]}>
                      <Row>
                        <Col size={10}>
                          <Text style={Style.Main.mt0}>5.</Text>
                        </Col>
                        <Col size={90}>
                          <View style={Style.Main.textWrap}>
                            <Text style={[Style.Main.mt0]}>
                              {_('Komunikasi dengan pelanggan dan/atau pengguna website maupun aplikasi online PT Prudential Life Assurance.')}
                            </Text>
                          </View>
                        </Col>
                      </Row>
                    </ListItem>

                    <ListItem style={[Style.Main.noBorderBottom, Style.Main.pt0]}>
                      <Row>
                        <Col size={10}>
                          <Text style={Style.Main.mt0}>6.</Text>
                        </Col>
                        <Col size={90}>
                          <View style={Style.Main.textWrap}>
                            <Text style={[Style.Main.mt0]}>
                              {/* eslint-disable max-len */}
                              {_('Kebutuhan pengungkapan sebagaimana diperlukan oleh hukum, peraturan perundang undangan yang berlaku dan/atau kebutuhan bagian yang berwenang di PT Prudential Life Assurance termasuk kepada afiliasinya ataupun mitra lembaga keuangan lainnya.')}
                              {/* eslint-enable max-len */}
                            </Text>
                          </View>
                        </Col>
                      </Row>
                    </ListItem>

                  </List>
                </Card>
              </Col>
            </Row>

            <Row>
              <Col>
                <Card style={[Style.Main.ml15, Style.Main.mr15, Style.Main.mb10]}>
                  <CardItem
                    header
                    bordered
                  >
                    <Text style={[Style.Main.textRed]}>
                      {_('PENGGUNAAN, PENGELOLAAN, TRANSFER DAN PENGUNGKAPAN INFORMASI PRIBADI ANDA')}
                    </Text>
                  </CardItem>
                  <CardItem>
                    <Body>
                      <View style={Style.Main.textWrap}>
                        <Text style={[Style.Main.mt0]}>
                          {/* eslint-disable max-len */}
                          {_('Dengan menyampaikan informasi pribadi anda kepada PT Prudential Life Assurance, berarti anda telah menyetujui dan mengizinkan PT Prudential Life Assurance untuk dapat menggunakan, mengelola, mentransfer atau mengungkapkan informasi pribadi anda untuk memenuhi kebutuhan anda dan/atau PT Prudential Life Assurance sebagaimana tercantum pada bagian "perolehan dan pengumpulan informasi pribadi anda" kepada salah satu pihak berikut (baik yang berada di dalam ataupun di luar negeri), antara lain:')}
                          {/* eslint-enable max-len */}
                        </Text>
                      </View>
                    </Body>

                  </CardItem>
                  <List>

                    <ListItem style={[Style.Main.noBorderBottom, Style.Main.pt0]}>
                      <Row>
                        <Col size={10}>
                          <Text style={Style.Main.mt0}>1.</Text>
                        </Col>
                        <Col size={90}>
                          <View style={Style.Main.textWrap}>
                            <Text style={[Style.Main.mt0]}>
                              {_('Setiap perusahaan terkait dengan PT Prudential Life Assurance.')}
                            </Text>
                          </View>
                        </Col>
                      </Row>
                    </ListItem>

                    <ListItem style={[Style.Main.noBorderBottom, Style.Main.pt0]}>
                      <Row>
                        <Col size={10}>
                          <Text style={Style.Main.mt0}>2.</Text>
                        </Col>
                        <Col size={90}>
                          <View style={Style.Main.textWrap}>
                            <Text style={[Style.Main.mt0]}>
                              {_('Setiap perusahaan pembawa asuransi dan/atau bisnis reasuransi terkait.')}
                            </Text>
                          </View>
                        </Col>
                      </Row>
                    </ListItem>

                    <ListItem style={[Style.Main.noBorderBottom, Style.Main.pt0]}>
                      <Row>
                        <Col size={10}>
                          <Text style={Style.Main.mt0}>3.</Text>
                        </Col>
                        <Col size={90}>
                          <View style={Style.Main.textWrap}>
                            <Text style={[Style.Main.mt0]}>
                              {/* eslint-disable max-len */}
                              {_('Setiap perantara asuransi yang memiliki perjanjian keagenan atau broker dengan PT Prudential Life Assurance.')}
                              {/* eslint-enable max-len */}
                            </Text>
                          </View>
                        </Col>
                      </Row>
                    </ListItem>

                    <ListItem style={[Style.Main.noBorderBottom, Style.Main.pt0]}>
                      <Row>
                        <Col size={10}>
                          <Text style={Style.Main.mt0}>4.</Text>
                        </Col>
                        <Col size={90}>
                          <View style={Style.Main.textWrap}>
                            <Text style={[Style.Main.mt0]}>{_('Setiap penyelidik klaim asuransi.')}</Text>
                          </View>
                        </Col>
                      </Row>
                    </ListItem>

                    <ListItem style={[Style.Main.noBorderBottom, Style.Main.pt0]}>
                      <Row>
                        <Col size={10}>
                          <Text style={Style.Main.mt0}>5.</Text>
                        </Col>
                        <Col size={90}>
                          <View style={Style.Main.textWrap}>
                            <Text style={[Style.Main.mt0]}>
                              {_('Setiap asosiasi dan federasi industri asuransi yang ada dari waktu ke waktu.')}
                            </Text>
                          </View>
                        </Col>
                      </Row>
                    </ListItem>

                    <ListItem style={[Style.Main.noBorderBottom, Style.Main.pt0]}>
                      <Row>
                        <Col size={10}>
                          <Text style={Style.Main.mt0}>6.</Text>
                        </Col>
                        <Col size={90}>
                          <View style={Style.Main.textWrap}>
                            <Text style={[Style.Main.mt0]}>
                              {_('Setiap penyedia layanan lain yang menyediakan asuransi dan/atau bisnis reasuransi terkait.')}
                            </Text>
                          </View>
                        </Col>
                      </Row>
                    </ListItem>

                    <ListItem style={[Style.Main.noBorderBottom, Style.Main.pt0]}>
                      <Row>
                        <Col size={10}>
                          <Text style={Style.Main.mt0}>7.</Text>
                        </Col>
                        <Col size={90}>
                          <View style={Style.Main.textWrap}>
                            <Text style={[Style.Main.mt0]}>
                              {/* eslint-disable max-len */}
                              {_('Setiap agen, afiliasi, kontraktor atau penyedia layanan pihak ketiga yang menyediakan administrasi, telekomunikasi, computer, pembayaran atau jasa lainnya kepada PT Prudential Life Assurance dalam kaitannya dengan operasi bisnis PT Prudential Life Assurance')}
                              {/* eslint-enable max-len */}
                            </Text>
                          </View>
                        </Col>
                      </Row>
                    </ListItem>

                    <ListItem style={[Style.Main.noBorderBottom, Style.Main.pt0]}>
                      <Row>
                        <Col size={10}>
                          <Text style={Style.Main.mt0}>8.</Text>
                        </Col>
                        <Col size={90}>
                          <View style={Style.Main.textWrap}>
                            <Text style={[Style.Main.mt0]}>
                              {_('Setiap instansi referensi kredit.')}
                            </Text>
                          </View>
                        </Col>
                      </Row>
                    </ListItem>

                    <ListItem style={[Style.Main.noBorderBottom, Style.Main.pt0]}>
                      <Row>
                        <Col size={10}>
                          <Text style={Style.Main.mt0}>9.</Text>
                        </Col>
                        <Col size={90}>
                          <View style={Style.Main.textWrap}>
                            <Text style={[Style.Main.mt0]}>
                              {_('Setiap agen penagihan hutang.')}
                            </Text>
                          </View>
                        </Col>
                      </Row>
                    </ListItem>

                    <ListItem style={[Style.Main.noBorderBottom, Style.Main.pt0]}>
                      <Row>
                        <Col size={10}>
                          <Text style={Style.Main.mt0}>10.</Text>
                        </Col>
                        <Col size={90}>
                          <View style={Style.Main.textWrap}>
                            <Text style={[Style.Main.mt0]}>
                              {/* eslint-disable max-len */}
                              {_('Setiap orang atau badan perusahaan atau instansi pemerintah atau regulator kepada siapa PT Prudential Life Assurance wajib mengungkapkan informasi pribadi tersebut di dalam rangka untuk memenuhi persyaratan hukum dan/atau peraturan perundang-undangan yang berlaku terkait dengan PT Prudential Life Assurance atau afiliasinya atau mitra bisnisnya.')}
                              {/* eslint-enable max-len */}
                            </Text>
                          </View>
                        </Col>
                      </Row>
                    </ListItem>

                  </List>
                </Card>
              </Col>
            </Row>

            <Row>
              <Col>
                <Card style={[Style.Main.ml15, Style.Main.mr15, Style.Main.mb15]}>
                  <CardItem
                    header
                    bordered
                  >
                    <Text style={[Style.Main.textRed]}>
                      {_('INFORMASI PENTING LAINNYA')}
                    </Text>
                  </CardItem>
                  <CardItem>
                    <Body>
                      <View style={Style.Main.textWrap}>
                        <Text style={[Style.Main.mt0, Style.Main.mb10]}>
                          {/* eslint-disable max-len */}
                          {_('Anda berhak untuk melakukan perubahan, pembaharuan, penambahan ataupun perbaikan terhadap informasi pribadi anda. Di samping itu anda juga dapat memperoleh akses terhadap informasi pribadi anda melalui media-media yang telah disediakan oleh PT Prudential Life Assurance.')}
                          {/* eslint-enable max-len */}
                        </Text>
                        <Text style={[Style.Main.mt0, Style.Main.mb10]}>
                          {/* eslint-disable max-len */}
                          {_('Anda berhak untuk tidak menyetujui atau menarik kembali persetujuan terhadap penggunaan, pengelolaan, transfer dan pengungkapan informasi pribadi anda oleh PT Prudential Life Assurance Indonesia sepanjang hal tersebut sesuai dan/ atau tidak dibatasi oleh hukum dan peraturan perundang-undangan yang berlaku. Namun perlu diingat bahwa dengan menarik persetujuan terkait informasi pribadi anda, PT Prudential Life Assurance mungkin tidak dapat menghubungi anda dan/atau memberikan layanan yang anda butuhkan.')}
                          {/* eslint-enable max-len */}
                        </Text>
                        <Text style={[Style.Main.mt0]}>
                          {/* eslint-disable max-len */}
                          {_('Jika anda memiliki pertanyaan berkaitan dengan kebijakan privasi PT Prudential Life Assurance, silakan menghubungi PT Prudential Life Assurance di:')}
                          {/* eslint-enable max-len */}
                        </Text>
                      </View>
                    </Body>
                  </CardItem>
                  <List>
                    <this.renderContactCenter />
                  </List>
                </Card>
              </Col>
            </Row>

          </Grid>
        </Content>
      </Container>
    );
  }
}

export default PrivacyPolicyHome;
