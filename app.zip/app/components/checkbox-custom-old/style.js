/**
 * @author: ahmdichsanb@gmail.com
*/

import { StyleSheet } from 'react-native';
// import Styles from '../../styles';

const Style = StyleSheet.create({
  container: {
    width: '100%',
  },
  iconStyle: {
    textAlign: 'center',
  },
  colIconStyle: {
    padding: 5,
  },
  colLabelStyle: {
    textAlign: 'left',
    padding: 5,
  },
  colInputStyle: {
    paddingHorizontal: 5,
  },
  fontStyle: {
    fontSize: 14,
  },
});

export default Style;
