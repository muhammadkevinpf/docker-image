/* eslint-disable no-console */
import { takeLatest } from 'redux-saga/effects';
import { apiSagaFunction } from '../../utilities/Functions';
import {
  INCOME_STATEMENT, incomeStatementAction, INCOME_EARNING_EXCEL, INCOME_EARNING_PDF, SEND_INCOME_STATEMENT,
  INCOME_HISTORY, INCOME_COMMISSION, INCOME_COMMISSION_FILTER, INCOME_STATEMENT_HISTORY,
  INCOME_EARNING_EXCEL_HISTORY, INCOME_EARNING_PDF_HISTORY, SEND_INCOME_STATEMENT_HISTORY, INCOME_LANDING, TAX_SLIP_LANDING,
  TAX_SLIP_LIST, GET_TAX_SLIP, SEND_TAX_SLIP,
} from './ConfigIncomeStatement';

export const watcherIncomeStatement = [
  // CPS Landing Page
  takeLatest(INCOME_LANDING.FETCH, params => apiSagaFunction(
    params.payload, incomeStatementAction, INCOME_LANDING, { resAttribute: 'summarygross' },
  )),
  takeLatest(TAX_SLIP_LANDING.FETCH, params => apiSagaFunction(params.payload, incomeStatementAction, TAX_SLIP_LANDING, { isResponArray: true })),

  // Income Statement
  takeLatest(INCOME_STATEMENT.FETCH, params => apiSagaFunction(params.payload, incomeStatementAction, INCOME_STATEMENT)),
  takeLatest(INCOME_EARNING_EXCEL.FETCH, params => apiSagaFunction(params.payload, incomeStatementAction, INCOME_EARNING_EXCEL)),
  takeLatest(INCOME_EARNING_PDF.FETCH, params => apiSagaFunction(params.payload, incomeStatementAction, INCOME_EARNING_PDF)),
  takeLatest(SEND_INCOME_STATEMENT.FETCH, params => apiSagaFunction(params.payload, incomeStatementAction, SEND_INCOME_STATEMENT)),
  takeLatest(INCOME_HISTORY.FETCH, params => apiSagaFunction(params.payload, incomeStatementAction, INCOME_HISTORY)),

  // Income Statement from History
  takeLatest(INCOME_STATEMENT_HISTORY.FETCH, params => apiSagaFunction(params.payload, incomeStatementAction, INCOME_STATEMENT_HISTORY)),
  takeLatest(INCOME_EARNING_EXCEL_HISTORY.FETCH, params => apiSagaFunction(params.payload, incomeStatementAction, INCOME_EARNING_EXCEL_HISTORY)),
  takeLatest(INCOME_EARNING_PDF_HISTORY.FETCH, params => apiSagaFunction(params.payload, incomeStatementAction, INCOME_EARNING_PDF_HISTORY)),
  takeLatest(SEND_INCOME_STATEMENT_HISTORY.FETCH, params => apiSagaFunction(params.payload, incomeStatementAction, SEND_INCOME_STATEMENT_HISTORY)),

  // Income Detail
  takeLatest(INCOME_COMMISSION.FETCH, params => apiSagaFunction(params.payload, incomeStatementAction, INCOME_COMMISSION)),
  takeLatest(INCOME_COMMISSION_FILTER.FETCH,
    params => apiSagaFunction(params.payload, incomeStatementAction, INCOME_COMMISSION_FILTER, { isResponArray: true })),

  // Tax Slip
  takeLatest(TAX_SLIP_LIST.FETCH, params => apiSagaFunction(params.payload, incomeStatementAction, TAX_SLIP_LIST, { isResponArray: true })),
  takeLatest(GET_TAX_SLIP.FETCH, params => apiSagaFunction(params.payload, incomeStatementAction, GET_TAX_SLIP)),
  takeLatest(SEND_TAX_SLIP.FETCH, params => apiSagaFunction(params.payload, incomeStatementAction, SEND_TAX_SLIP)),
];
