import moment from 'moment';
import { requestStatus } from '../../utilities/ApiConnection';
import { RESET_ALL_STATE } from '../dashboard/ConfigDashboard';
import {
  INCOME_STATEMENT, INCOME_EARNING_EXCEL, INCOME_EARNING_PDF, SEND_INCOME_STATEMENT,
  INCOME_HISTORY, INCOME_COMMISSION, INCOME_COMMISSION_FILTER, INCOME_STATEMENT_HISTORY,
  INCOME_EARNING_EXCEL_HISTORY, INCOME_EARNING_PDF_HISTORY, SEND_INCOME_STATEMENT_HISTORY,
  RESET_INCOME_DETAIL, INCOME_LANDING, TAX_SLIP_LANDING, TAX_SLIP_LIST, GET_TAX_SLIP, SEND_TAX_SLIP,
} from './ConfigIncomeStatement';
import { isEmpty } from '../../utilities';
import _ from '../../lang';

const initialIncome = {
  mainIncomeStatus: requestStatus.IDLE,
  incomeExcelStatus: requestStatus.IDLE,
  incomePdfStatus: requestStatus.IDLE,
  sendStatementStatus: requestStatus.IDLE,
  incomeHistoryStatus: requestStatus.IDLE,

  mainIncome: {},
  incomeExcel: null,
  incomePdf: null,
  sendStatement: null,
  incomeHistory: [],

  error: null,
  send: null,
};

const initialState = {
  ...initialIncome,

  landingStatus: requestStatus.IDLE,
  taxLandingStatus: requestStatus.IDLE,
  landingData: {},
  taxLanding: [],

  lastUpdateIncomeLanding: null,
  lastUpdateTaxLanding: null,
};

export function ReducerIncomeStatement(state = initialState, action) {
  switch (action.type) {
    case RESET_ALL_STATE: return initialState;

      // CPS LANDING

    case INCOME_LANDING.FETCH: return { ...state, landingStatus: requestStatus.FETCH, send: action.payload };
    case INCOME_LANDING.FAILED: return { ...state, landingStatus: requestStatus.FAILED, error: action.payload };
    case INCOME_LANDING.SUCCESS: return {
      ...state, landingStatus: requestStatus.SUCCESS, landingData: action.payload, lastUpdateIncomeLanding: moment(new Date()).format('LLL'),
    };

    case TAX_SLIP_LANDING.FETCH: return { ...state, taxLandingStatus: requestStatus.FETCH, send: action.payload };
    case TAX_SLIP_LANDING.FAILED: return { ...state, taxLandingStatus: requestStatus.FAILED, error: action.payload };
    case TAX_SLIP_LANDING.SUCCESS: return {
      ...state,
      taxLandingStatus: requestStatus.SUCCESS,
      taxLanding: isEmpty(action.payload) ? [] : action.payload.map(x => moment(new Date(x)).format('DD MMM YYYY')),
      lastUpdateTaxLanding: moment(new Date()).format('LLL'),
    };

      // INCOME STATEMENT

    case INCOME_STATEMENT.RESET: return { ...initialState, ...initialIncome };
    case INCOME_STATEMENT.FETCH: return { ...state, mainIncomeStatus: requestStatus.FETCH, send: action.payload };
    case INCOME_STATEMENT.FAILED: return { ...state, mainIncomeStatus: requestStatus.FAILED, error: action.payload };
    case INCOME_STATEMENT.SUCCESS: return { ...state, mainIncomeStatus: requestStatus.SUCCESS, mainIncome: action.payload };

    case INCOME_EARNING_EXCEL.FETCH: return { ...state, incomeExcelStatus: requestStatus.FETCH, send: action.payload };
    case INCOME_EARNING_EXCEL.FAILED: return { ...state, incomeExcelStatus: requestStatus.FAILED, error: action.payload };
    case INCOME_EARNING_EXCEL.SUCCESS: return { ...state, incomeExcelStatus: requestStatus.SUCCESS, incomeExcel: action.payload };

    case INCOME_EARNING_PDF.FETCH: return { ...state, incomePdfStatus: requestStatus.FETCH, send: action.payload };
    case INCOME_EARNING_PDF.FAILED: return { ...state, incomePdfStatus: requestStatus.FAILED, error: action.payload };
    case INCOME_EARNING_PDF.SUCCESS: return { ...state, incomePdfStatus: requestStatus.SUCCESS, incomePdf: action.payload };

    case SEND_INCOME_STATEMENT.FETCH: return { ...state, sendStatementStatus: requestStatus.FETCH, send: action.payload };
    case SEND_INCOME_STATEMENT.FAILED: return { ...state, sendStatementStatus: requestStatus.FAILED, error: action.payload };
    case SEND_INCOME_STATEMENT.SUCCESS: return { ...state, sendStatementStatus: requestStatus.SUCCESS, sendStatement: action.payload };

    case INCOME_HISTORY.FETCH: return { ...state, incomeHistoryStatus: requestStatus.FETCH, send: action.payload };
    case INCOME_HISTORY.FAILED: return { ...state, incomeHistoryStatus: requestStatus.FAILED, error: action.payload };
    case INCOME_HISTORY.SUCCESS: return {
      ...state,
      incomeHistoryStatus: requestStatus.SUCCESS,
      incomeHistory: state.incomeHistory.length ?
        [...state.incomeHistory, ...action.payload.filter(x => !state.incomeHistory.some(item => item === x))]
        : action.payload,
    };

    default: return state;
  }
}

// INCOME DETAIL

const detailInitialState = {
  commissionStatus: requestStatus.IDLE,
  commissionFilterStatus: requestStatus.IDLE,
  mainIncomeStatus: requestStatus.IDLE,
  incomeExcelStatus: requestStatus.IDLE,
  incomePdfStatus: requestStatus.IDLE,
  sendStatementStatus: requestStatus.IDLE,

  mainIncome: {},
  incomeExcel: null,
  incomePdf: null,
  sendStatement: null,
  commissionList: [],
  totalCommission: 0,
  commissionFilter: [],

  error: null,
  send: null,
};

export function ReducerIncomeDetail(state = detailInitialState, action) {
  switch (action.type) {
    case RESET_ALL_STATE: return detailInitialState;

    case RESET_INCOME_DETAIL: return detailInitialState;

    case INCOME_STATEMENT_HISTORY.FETCH: return { ...state, mainIncomeStatus: requestStatus.FETCH, send: action.payload };
    case INCOME_STATEMENT_HISTORY.FAILED: return { ...state, mainIncomeStatus: requestStatus.FAILED, error: action.payload };
    case INCOME_STATEMENT_HISTORY.SUCCESS: return { ...state, mainIncomeStatus: requestStatus.SUCCESS, mainIncome: action.payload };

    case INCOME_EARNING_EXCEL_HISTORY.FETCH: return { ...state, incomeExcelStatus: requestStatus.FETCH, send: action.payload };
    case INCOME_EARNING_EXCEL_HISTORY.FAILED: return { ...state, incomeExcelStatus: requestStatus.FAILED, error: action.payload };
    case INCOME_EARNING_EXCEL_HISTORY.SUCCESS: return { ...state, incomeExcelStatus: requestStatus.SUCCESS, incomeExcel: action.payload };

    case INCOME_EARNING_PDF_HISTORY.FETCH: return { ...state, incomePdfStatus: requestStatus.FETCH, send: action.payload };
    case INCOME_EARNING_PDF_HISTORY.FAILED: return { ...state, incomePdfStatus: requestStatus.FAILED, error: action.payload };
    case INCOME_EARNING_PDF_HISTORY.SUCCESS: return { ...state, incomePdfStatus: requestStatus.SUCCESS, incomePdf: action.payload };

    case SEND_INCOME_STATEMENT_HISTORY.FETCH: return { ...state, sendStatementStatus: requestStatus.FETCH, send: action.payload };
    case SEND_INCOME_STATEMENT_HISTORY.FAILED: return { ...state, sendStatementStatus: requestStatus.FAILED, error: action.payload };
    case SEND_INCOME_STATEMENT_HISTORY.SUCCESS: return { ...state, sendStatementStatus: requestStatus.SUCCESS, sendStatement: action.payload };

    case INCOME_COMMISSION.RESET: return {
      ...state, commissionStatus: requestStatus.IDLE, commissionList: [], totalCommission: 0,
    };
    case INCOME_COMMISSION.FETCH: return { ...state, commissionStatus: requestStatus.FETCH, send: action.payload };
    case INCOME_COMMISSION.FAILED: return { ...state, commissionStatus: requestStatus.FAILED, error: action.payload };
    case INCOME_COMMISSION.SUCCESS: return {
      ...state,
      commissionStatus:
      requestStatus.SUCCESS,
      totalCommission: action.payload && action.payload.totalCommission,
      commissionList: state.commissionList.length ?
        [...state.commissionList, ...action.payload.detail.filter(x => !state.commissionList.some(item => item.policyNumber === x.policyNumber))]
        : action.payload.detail,
    };

    case INCOME_COMMISSION_FILTER.RESET: return { ...state, commissionFilterStatus: requestStatus.IDLE, commissionFilter: [] };
    case INCOME_COMMISSION_FILTER.FETCH: return { ...state, commissionFilterStatus: requestStatus.FETCH, send: action.payload };
    case INCOME_COMMISSION_FILTER.FAILED: return { ...state, commissionFilterStatus: requestStatus.FAILED, error: action.payload };
    case INCOME_COMMISSION_FILTER.SUCCESS: return { ...state, commissionFilterStatus: requestStatus.SUCCESS, commissionFilter: action.payload };

    default: return state;
  }
}

// TAX DETAIL

const initialTaxState = {
  statusList: requestStatus.IDLE,
  statusPdf: requestStatus.IDLE,
  statusSend: requestStatus.IDLE,

  list: [],
  pdf: null,
  email: null,
  pwd: null,
  sendEmail: null,

  send: null,
  error: null,
};

export function ReducerTaxSlip(state = initialTaxState, action) {
  switch (action.type) {
    case RESET_ALL_STATE: return initialTaxState;

    case TAX_SLIP_LIST.RESET: return initialTaxState;
    case TAX_SLIP_LIST.FETCH: return { ...state, statusList: requestStatus.FETCH, send: action.payload };
    case TAX_SLIP_LIST.FAILED: return {
      ...state, statusList: requestStatus.FAILED, error: action.payload,
    };
    case TAX_SLIP_LIST.SUCCESS: return {
      ...state,
      statusList: requestStatus.SUCCESS,
      list: state.list.length ?
        [...state.commissionList, ...action.list.filter(x => !state.list.some(item => item.taxDate === x.taxDate))]
        : action.payload,
    };

    case GET_TAX_SLIP.RESET: return { ...initialTaxState, ...state.list, ...state.statusList };
    case GET_TAX_SLIP.FETCH: return { ...state, statusPdf: requestStatus.FETCH, send: action.payload };
    case GET_TAX_SLIP.FAILED: return { ...state, statusPdf: requestStatus.FAILED, error: action.payload };
    case GET_TAX_SLIP.SUCCESS: {
      if (!isEmpty(action.payload)) {
        return {
          ...state,
          statusPdf: requestStatus.SUCCESS,
          pdf: action.payload.base64Attachment,
          email: action.payload.email,
          pwd: action.payload.password,
        };
      }
      return { ...state, statusPdf: requestStatus.SUCCESS };
    }

    case SEND_TAX_SLIP.FETCH: return { ...state, statusSend: requestStatus.FETCH, send: action.payload };
    case SEND_TAX_SLIP.FAILED: return { ...state, statusSend: requestStatus.FAILED, error: action.payload };
    case SEND_TAX_SLIP.SUCCESS: {
      if (!isEmpty(action.payload) && Number(action.payload.body.httpCode) === 200) {
        // return { ...state, statusSend: requestStatus.SUCCESS, sendEmail: action.payload.body.response.descriptionStatus };
        return { ...state, statusSend: requestStatus.SUCCESS, sendEmail: _('Email telah dikirimkan ke server') };
      }
      return { ...state, statusSend: requestStatus.FAILED, sendEmail: _('Email tidak berhasil dikirimkan!') };
    }

    default: return state;
  }
}
