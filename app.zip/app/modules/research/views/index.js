import OcrResearch from './OcrResearch';

export default {
  OcrResearch,
};
