
import React from 'react';
import { Text } from 'native-base';
import Style from '../../styles';
import { coverageStartText } from '../../config';
import { isEmpty } from '../../utilities';

const splitDesc = (desc) => {
  const startText = coverageStartText.find(type => desc.startsWith(type));
  let restText = desc;
  if (!isEmpty(startText)) {
    const temp = desc.slice(startText.length);
    restText = `${temp.split(' ').map(word => word.substr(0, 1).toUpperCase() + word.substr(1, word.length)).join(' ')}`;
  }
  return { startText, restText };
};

export const CoverageHTML = (desc) => {
  const { startText, restText } = splitDesc(desc);
  if (!isEmpty(startText)) {
    if (startText.includes('USave') || startText.includes('Usave')) {
      return 'USave <b>PRU</b>Star';
    }
    return `<b>${startText}</b>${restText}`;
  } return desc;
};

export const CoverageText = ({
  desc, pruStyle, labelStyle, style = [],
}) => {
  const { startText, restText } = splitDesc(desc);
  if (!isEmpty(startText)) {
    if (startText.includes('USave') || startText.includes('Usave')) {
      return (
        <Text style={[Style.Main.fontAlbert14, ...style]}>
          <Text style={[Style.Main.fontAlbert14, ...style, pruStyle]}>USave </Text>
          <Text style={[Style.Main.fontAlbertBold14, ...style, pruStyle]}>PRU</Text>
          <Text style={[Style.Main.fontAlbert14, ...style, pruStyle]}>Star</Text>
        </Text>
      );
    }
    return (
      <Text style={[Style.Main.fontAlbert14, ...style]}>
        <Text style={[Style.Main.fontAlbertBold14, ...style, pruStyle]}>{startText}</Text>
        {!isEmpty(restText) && <Text style={[Style.Main.fontAlbert14, ...style, labelStyle]}>{restText}</Text>}
      </Text>
    );
  }
  return <Text style={[Style.Main.fontAlbert14, ...style, labelStyle]}>{desc}</Text>;
};
