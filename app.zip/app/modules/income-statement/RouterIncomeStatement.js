import Views from './views';

// Please update Screen in Sub-Menu Components too
export default {
  MainIncomeStatement: { screen: Views.MainIncomeStatement },
  IncomeStatement: { screen: Views.IncomeStatement },
  CommissionDetail: { screen: Views.CommissionDetail },
  IncomeHistoryDetail: { screen: Views.IncomeHistoryDetail },
  TaxSlipPreview: { screen: Views.TaxSlipPreview },
  TaxSlipList: { screen: Views.TaxSlipList },
};
