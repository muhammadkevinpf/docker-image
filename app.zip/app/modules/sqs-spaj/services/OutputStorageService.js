import moment from 'moment';
// import Analytics from 'appcenter-analytics';
import CryptoJS from 'crypto-js';
import SQLiteUtils from '../../../utilities/SQLiteUtils';
import Database from '../../../config/Database';

const { output } = Database.pruSmart.tables;

const querySelect = `SELECT * FROM ${output.name} WHERE method = ? and agentCode = ?`;
const querySelectByKey = `SELECT * FROM ${output.name} WHERE method = ? and agentCode = ? and outputCode = ?`;
const queryDelete = `DELETE FROM ${output.name} WHERE method = ? and agentCode = ? and outputCode = ?`;
const queryUpdateByKey = `UPDATE ${output.name} SET data = ?, createDate = ? where method = ? and agentCode = ? and outputCode = ?`;
const queryInsert = `INSERT INTO ${output.name} VALUES (?,?,?,?,?)`;
const serviceName = 'OutputStorageService';

const openDatabase = () => new Promise(async (resolve, reject) => {
  try {
    const dbName = Database.pruSmart.name;
    const db = await SQLiteUtils.openDatabase(dbName, 'default');
    resolve(db);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const getAll = (db, agentCode) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(db, querySelect, [output.method, agentCode]);
    const data = [];
    for (let i = 0; i < res.rows.length; i += 1) {
      data.push(JSON.parse(CryptoJS.AES.decrypt(res.rows.item(i).data, SQLiteUtils.DBKEY).toString(CryptoJS.enc.Utf8)));
    }
    resolve(data);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const getByCode = (db, param) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(
      db,
      querySelectByKey,
      [output.method, param.agentCode, param.outputId],
    );
    if (res.rows.length > 0) {
      resolve(JSON.parse(CryptoJS.AES.decrypt(res.rows.item(0).data, SQLiteUtils.DBKEY).toString(CryptoJS.enc.Utf8)).invocationResult);
    } else {
      resolve(res.rows.length);
    }
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const deleteByCode = (db, param) => new Promise(async (resolve, reject) => {
  try {
    // const checkData = await getByCode(db, param);
    // if (!checkData) { reject(new Error(`${serviceName} Data not found`)); }
    const res = await SQLiteUtils.executeTransaction(
      db,
      queryDelete,
      [output.method, param.agentCode, param.outputId],
    );
    resolve(res);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const upsert = (db, param) => new Promise(async (resolve, reject) => {
  try {
    let data = {};
    data.invocationResult = param.data;
    data.agentId = param.agentCode;
    data.outputId = param.outputId;
    data.retrieveDate = new Date();

    let queryToProcess = queryInsert;

    let parameterToInput = [
      param.agentCode,
      output.method,
      param.outputId,
      CryptoJS.AES.encrypt(JSON.stringify(data), SQLiteUtils.DBKEY).toString(),
      moment().format('DD/MM/YYYY hh:mm'),
    ];

    const res = await SQLiteUtils.executeQuery(
      db,
      querySelectByKey,
      [output.method, param.agentCode, param.outputId],
    );

    if (res.rows.length > 0) {
      data = JSON.parse(CryptoJS.AES.decrypt(res.rows.item(0).data, SQLiteUtils.DBKEY).toString(CryptoJS.enc.Utf8));
      data.invocationResult = param.data;
      data.outputId = param.outputId;
      queryToProcess = queryUpdateByKey;
      parameterToInput = [
        CryptoJS.AES.encrypt(JSON.stringify(data), SQLiteUtils.DBKEY).toString(),
        moment().format('DD/MM/YYYY hh:mm'),
        output.method,
        param.agentCode,
        param.outputId,
      ];
    }

    const resUpsert = await SQLiteUtils.executeTransaction(
      db,
      queryToProcess,
      parameterToInput,
    );
    resolve(`UPSERT ${resUpsert}`);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

export default {
  openDatabase,
  getByCode,
  deleteByCode,
  upsert,
  getAll,
};
