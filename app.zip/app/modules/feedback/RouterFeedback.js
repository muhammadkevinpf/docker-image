import Views from './views';

export default {
  FeedbackHistoryList: { screen: Views.FeedbackHistoryList },
  FeedbackHistoryDetail: { screen: Views.FeedbackHistoryDetail },
  AttachmentPreview: { screen: Views.AttachmentPreview },
};
