/* eslint-disable react/no-array-index-key */
import React from 'react';
import Animated from 'react-native-reanimated';
import {
  Tabs, Tab, TabHeading, Text,
} from 'native-base';
import { connect } from 'react-redux';
import { View, Dimensions } from 'react-native';
import PropTypes from 'prop-types';
import Style from '../../styles';
import _ from '../../lang';
import { isText, isTablet } from '../../utilities';

const noHeight = { height: 0 };

class NativeTabs extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      scrollValue: new Animated.Value(0),
      activeTab: 0,
    };
  }

  renderHeading = (x, isActive) => {
    if (isTablet()) {
      const underlineWidth = (Dimensions.get('window').width - this.props.sideBarWidth) / this.props.tabs.length;
      const tabUnderlineStyle = {
        position: 'absolute',
        width: underlineWidth,
        height: 4,
        backgroundColor: isActive ? Style.Color.red : Style.Color.transparent,
        bottom: 0,
      };
      const leftPosition = this.state.scrollValue.interpolate({
        inputRange: [0, 1],
        outputRange: [0, underlineWidth],
      });
      return (
        <TabHeading>
          <Animated.View style={[tabUnderlineStyle, { left: leftPosition }]} />
          <Text>{isText(x.title) ? _(x.title).toUpperCase() : x.title}</Text>
        </TabHeading>
      );
    } return <TabHeading><Text>{isText(x.title) ? _(x.title).toUpperCase() : x.title}</Text></TabHeading>;
  }

  renderTabs = () => {
    if (this.props.tabs && this.props.tabs.length > 0) {
      return (
        <Tabs
          locked={isTablet()}
          onChangeTab={({ i }) => this.setState({ activeTab: i })}
          tabBarUnderlineStyle={isTablet() ? noHeight : null}
          style={isTablet() ? { paddingRight: this.props.sideBarWidth } : null}
        >
          {
            this.props.tabs.map((x, i) => (
              <Tab
                {...this.props}
                key={i}
                textStyle={[Style.Main.fontAlbert14]}
                activeTextStyle={[Style.Main.fontAlbert14]}
                heading={this.renderHeading(x, this.state.activeTab === i)}
                locked={Number(i) === 0}
              >
                <View style={[Style.Main.container, isTablet() && { paddingRight: this.props.sideBarWidth }]}>
                  {x.screen}
                </View>
              </Tab>
            ))
          }
        </Tabs>
      );
    } return null;
  }

  render() {
    if (isTablet()) {
      return (
        <View style={[Style.Main.container, { width: Dimensions.get('window').width }]}>
          {this.renderTabs()}
        </View>
      );
    }
    return this.renderTabs();
  }
}

NativeTabs.propTypes = {
  tabs: PropTypes.arrayOf(PropTypes.object).isRequired,
};

const mapStateToProps = state => ({
  sideBarWidth: state.bootstrap.sideBarWidth,
});

export default connect(mapStateToProps, null)(NativeTabs);
