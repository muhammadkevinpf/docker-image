import {
  NEWS_LIST_FETCH,
  NEWS_LIST_SUCCESS,
  NEWS_LIST_FAILED,
  NEWS_DETAIL_FETCH,
  NEWS_DETAIL_SUCCESS,
  NEWS_DETAIL_FAILED,
  FILE_BASE_64_FETCH,
  FILE_BASE_64_SUCCESS,
  FILE_BASE_64_FAILED,
  FILE_BASE_64_RESET,
  NEWS_LIST_RESET,
  NEWS_DETAIL_RESET,
} from './ConfigNews';

export const newsListFetch = value => ({ type: NEWS_LIST_FETCH, send: value });
export const newsListSuccess = value => ({ type: NEWS_LIST_SUCCESS, res: value });
export const newsListFailed = value => ({ type: NEWS_LIST_FAILED, err: value });
export const newsListReset = () => ({ type: NEWS_LIST_RESET });

export const newsDetailFetch = value => ({ type: NEWS_DETAIL_FETCH, send: value });
export const newsDetailSuccess = value => ({ type: NEWS_DETAIL_SUCCESS, res: value });
export const newsDetailFailed = value => ({ type: NEWS_DETAIL_FAILED, err: value });
export const newsDetailReset = () => ({ type: NEWS_DETAIL_RESET });

export const fileBase64Fetch = value => ({ type: FILE_BASE_64_FETCH, send: value });
export const fileBase64Success = value => ({ type: FILE_BASE_64_SUCCESS, res: value });
export const fileBase64Failed = value => ({ type: FILE_BASE_64_FAILED, err: value });
export const fileBase64Reset = () => ({ type: FILE_BASE_64_RESET });
