/* eslint-disable consistent-return */
/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import {
  View,
  Button, Segment, Content, Text,
} from 'native-base';
import { Row, Col } from 'react-native-easy-grid';
import Icon from 'react-native-vector-icons/FontAwesome';
import _ from '../../../lang';

import Style from '../../../styles';
import StyleDashboard from '../StyleDashboard';

class SegmentAccorProduction extends Component {
  constructor(props) {
    super(props);
    this.firstpage = this.firstpage.bind(this);
    this.secondpage = this.secondpage.bind(this);
    this.state = {
      page: 1,
      firstpageactive: true,
      secondpageactive: false,

    };
  }

  firstpage() {
    this.setState({
      page: 1,
      firstpageactive: true,
      secondpageactive: false,
    });
  }

  secondpage() {
    this.setState({
      page: 2,
      firstpageactive: false,
      secondpageactive: true,
    });
  }

  render() {
    const { page } = this.state;
    let shows = null;
    if (page === 1) {
      shows =
        <View>
          <Row style={[Style.Main.textWrap, Style.Main.mt15]}>
            <Col>
              <Text>Ape Net MTD</Text>
            </Col>
          </Row>
          <View style={[Style.Main.textWrap, Style.Main.mt15]}>
            <Row>
              <Col size={10}>
                <Icon name="male" style={Style.Main.textRed} />
              </Col>
              <Col size={35}>
                <Text>Individu</Text>
              </Col>
              <Col size={30}>
                <Text>Rp.</Text>
              </Col>
              <Col size={20}>
                <Text>0.00</Text>
              </Col>
              <Col size={5}>
                <Icon name="angle-right" />
              </Col>
            </Row>
          </View>
        </View>;
    } else if (page === 2) {
      shows =
        <View>
          <Row style={[Style.Main.textWrap, Style.Main.mt15]}>
            <Col>
              <Text>Ape Net YTD</Text>
            </Col>
          </Row>
          <View style={[Style.Main.textWrap, Style.Main.mt15]}>
            <Row>
              <Col size={10}>
                <Icon name="male" style={Style.Main.textRed} />
              </Col>
              <Col size={35}>
                <Text>Individu</Text>
              </Col>
              <Col size={30}>
                <Text>Rp.</Text>
              </Col>
              <Col size={20}>
                <Text>0.00</Text>
              </Col>
              <Col size={5}>
                <Icon name="angle-right" />
              </Col>
            </Row>
          </View>
        </View>;
    }

    return (
      <View>
        <Segment style={[Style.Main.pt15, Style.Main.pb5]}>
          <Button
            first
            active={this.state.firstpageactive}
            onPress={this.firstpage}
            style={StyleDashboard.SegmentAccordion}
          >
            <Text style={Style.Main.textCenter}>
              {_('MTD')}
            </Text>
          </Button>
          <Button
            last
            active={this.state.secondpageactive}
            onPress={this.secondpage}
            style={StyleDashboard.SegmentAccordion}
          >
            <Text style={Style.Main.textCenter}>
              {_('YTD')}
            </Text>
          </Button>
        </Segment>

        <Content padder style={Style.Main.pb15} keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
          {shows}
        </Content>
      </View>
    );
  }
}

export default SegmentAccorProduction;
