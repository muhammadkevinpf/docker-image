/* eslint-disable react/no-array-index-key */
/* eslint-disable no-console */
/* eslint-disable camelcase */
/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import {
  TouchableOpacity, Alert, BackHandler, ActivityIndicator,
  // Image,
} from 'react-native';
import { connect } from 'react-redux';
import {
  Container, Content, Card, Text, View,
} from 'native-base';
import { NavigationEvents } from 'react-navigation';
import Icon from 'react-native-vector-icons/FontAwesome';
import _ from '../../../lang';
import Style from '../../../styles';
import UserProfileService from '../services/UserProfileService';
import FatcaModal from './FatcaModal';
import LoadingModal from '../../../components/loading_modal';
import { HeaderWithTodo, SideBarMenu } from '../../../components';
import { isTablet } from '../../../utilities';

class MyAccountDetail extends Component {
  constructor(props) {
    super(props);
    this.state = {
      cpdCode: '',
      showModal: false,
      fatcaFlag: false,
      isLoading: false,
      emergencyContact: {},
      isChangedToOnline: false,
    };
  }

  componentDidMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleOnBack();
      return true;
    });
    // this.setState({ isLoading: true });
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  handleBack = () => {
    this.props.navigation.replace('MyAccount');
  }

  initialLoad = async () => {
    try {
      const { access_token, userProfile } = this.props.resAuth || {};
      if (access_token && userProfile) {
        const fatcaData = await UserProfileService.getFatcaStatus(access_token, userProfile.agentCode);
        const emergencyData = await UserProfileService.showEmergency(access_token, userProfile.agentCode);
        const agentCPDSummary = await UserProfileService.getAgentCPDSummary(access_token, userProfile.agentCode);
        if (fatcaData && fatcaData.responseDescription === 'Y') {
          this.setState({ fatcaFlag: true });
        }
        this.setState({
          emergencyContact: emergencyData ? emergencyData.array[0] || {} : {},
          cpdCode: agentCPDSummary ? agentCPDSummary.data.data[0].lastAgentCpdCode : '',
          isChangedToOnline: !!emergencyData,
        });
      } else { this.setState({ isChangedToOnline: true }); }
    } catch (e) {
      this.setState({ isChangedToOnline: true });
      console.log('error at initialLoad with error: ', e);
    }
    this.setState({ isLoading: false });
  }

  componentDidUpdate = (prevProps, prevState) => {
    console.log('prevState: ', prevState);
    if (this.props.connectionStatus.isOnline !== prevProps.connectionStatus.isOnline && this.props.connectionStatus.isOnline) {
      this.initialLoad();
      // this.isChangedToOnline();
    }
  }

  // isChangedToOnline = () => this.setState({ isChangedToOnline: true })

  handleModal = () => {
    this.setState({ showModal: true });
  }

  handleOnClose = () => {
    this.setState({ showModal: false });
  }

  handleOnAgree = async () => {
    // this.setState({ isLoading: true });
    const { access_token, userProfile } = this.props.resAuth || {};
    if (this.props.connectionStatus.isOnline) {
      if (access_token && userProfile) {
        await UserProfileService.fatcaApproval(access_token, userProfile.agentCode)
          .then(() => {
            this.setState({ showModal: false }, () => {
              Alert.alert(
                '', 'Terima Kasih telah menyetujui ketentuan FATCA',
                [
                  {
                    text: 'Ok',
                    onPress: () => {
                      this.setState({ fatcaFlag: true });
                    },
                  },
                ],
              );
            });
          });
      }
    } else { this.setState({ showModal: false }, () => Alert.alert('', 'Jaringan tidak tersedia. Silakan ulangi kembali')); }
  }

  handleOnBack = () => {
    if (isTablet()) this.props.navigation.replace('MainDashboard');
    else this.props.navigation.replace('MyAccount');
    this.backHandler.remove();
  }

  handleOnProceed = (goto) => {
    if (this.props.connectionStatus.isOnline) {
      this.props.navigation.replace(goto);
    } else {
      Alert.alert('Please check your connection!');
    }
  }

  renderTextValue = value => <Text style={[Style.Main.fontAlbert11]}>{_(`${value}`)}</Text>

  renderActivityIndicator = () => (
    <View style={[Style.Main.textLeft, Style.Main.mt2]}>
      <ActivityIndicator color="red" size="small" />
    </View>
  );

  renderHeader = (iconName, title, editButton) => (
    <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.noBorder, Style.Main.backgroundRed, Style.Main.padding10]}>
      <View style={[Style.Main.rowDirectionFlexStart, Style.Main.fullHeight, Style.Main.justifyCenter]}>
        <Icon name={iconName} style={[Style.Main.textWhite, Style.Main.font18, Style.Main.width30]} />
        <Text style={[Style.Main.fontAlbert14, Style.Main.textWhite]}>{title}</Text>
      </View>
      {
        editButton && (
          <TouchableOpacity style={[Style.Main.alignCenter]} onPress={() => { this.handleOnProceed('EditEmergencyContact'); }}>
            <Icon name="edit" style={[Style.Main.textWhite, Style.Main.font14, Style.Main.justifyCenter, Style.Main.alignCenter]} />
          </TouchableOpacity>
        )
      }
    </View>
  )

  render() {
    const {
      // userAvatar,
      userProfile,
    } = this.props.resAuth || [];
    const {
      idNumber, licenseNumber, joinDate, licenseExpiryDate, agentNumber,
      dateOfBirth, marital, address1, address2, address3, address4, address5,
      agentEmailAddress, agentMobilephone1, agentMobilephone2, agentMobilephone3,
      office, leaderNumber, leaderName, currentYearSanction, overallSanction,
    } = userProfile || {};


    const { contactName, relation, phoneNumber } = this.state.emergencyContact || {};

    const personalInfo = [
      { icon: 'id-card', label: 'Nomor Identitas', value: idNumber || 'N/A' },
      { icon: 'id-card', label: 'Kode Lisensi', value: licenseNumber || 'N/A' },
      { icon: 'calendar', label: 'Tanggal Bergabung', value: joinDate || 'N/A' },
      { icon: 'file', label: 'Tanggal Berakhirnya Lisensi', value: licenseExpiryDate || 'N/A' },
      { icon: 'id-card', label: 'Kode Agen', value: agentNumber || 'N/A' },
      { icon: 'id-card', label: 'CPD Code', value: this.state.cpdCode || 'N/A' },
      { icon: 'calendar', label: 'Tanggal Lahir', value: dateOfBirth || 'N/A' },
      { icon: 'file', label: 'Status Pernikahan', value: marital || 'N/A' },
      { icon: 'home', label: 'Alamat Rumah', value: `${address1 || ''}\n${address2 || ''}\n${address3 || ''}\n${address4 || ''}\n${address5 || ''}` },
      { icon: 'envelope', label: 'Email', value: agentEmailAddress || 'N/A' },
      { icon: 'phone', label: 'Nomor Telepon' },
      { icon: 'mobile', label: 'Handphone', value: agentMobilephone1 || 'N/A' },
      { icon: 'home', label: 'Rumah', value: agentMobilephone2 || 'N/A' },
      { icon: 'building', label: 'Kantor', value: agentMobilephone3 || 'N/A' },
      { icon: 'building', label: 'Kantor', value: office || 'N/A' },
      { icon: 'key', label: 'Kode Manajer Keagenan', value: leaderNumber || 'N/A' },
      { icon: 'users', label: 'Nama Manajer Keagenan', value: leaderName || 'N/A' },
    ];

    const emergencyContact = [
      { icon: 'user', label: 'Nama', value: contactName || 'N/A' },
      { icon: 'users', label: 'Hubungan', value: relation || 'N/A' },
      { icon: 'phone', label: 'Nomor Telepon', value: phoneNumber || 'N/A' },
      {
        icon: 'home',
        label: 'Alamat',
        value: this.state.emergencyContact.address1
          ? `${this.state.emergencyContact.address1 || ''}\n${this.state.emergencyContact.address2
          || ''}\n${this.state.emergencyContact.address3 || ''}` : 'N/A',
      },
    ];

    return (
      <React.Fragment>
        <NavigationEvents
          onDidFocus={() => this.initialLoad()}
        />
        <Container style={[isTablet() && Style.Main.rowDirection]}>
          <SideBarMenu visible={isTablet()} navigation={this.props.navigation} />
          <View style={[Style.Main.container]}>
            <HeaderWithTodo
              {...this.props}
              onBackClicked={this.handleOnBack}
              headerTitle="PROFIL SAYA"
            // subHeader="PROFIL SAYA"
            />
            <Content
              style={[isTablet() ? Style.Main.containerWithPaddingTablet : Style.Main.padding10]}
              keyboardDismissMode="on-drag"
              enableResetScrollToCoords={false}
            >
              <View style={[Style.Main.mb35]}>
                <Card style={[Style.Main.pb15]}>
                  {this.renderHeader('user', 'DATA PRIBADI')}
                  <View style={[Style.Main.px10, Style.Main.noBorder, Style.Main.textAlmostBlack, Style.Main.fontAlbert, this.props.contentStyle]}>
                    {personalInfo && personalInfo.length > 0 && personalInfo.map((val, i) => {
                      const renderValue = i === 5 && !this.state.isChangedToOnline ? this.renderActivityIndicator() : this.renderTextValue(val.value);

                      return (
                        <View style={[
                          i !== 11 && Style.Main.mt10,
                          Style.Main.pb15,
                          // val.value !== undefined && Style.Main.mb10,
                          val.value !== undefined && Style.Main.borderBottomNativeBase,
                          (i === 11 || i === 12 || i === 13) && Style.Main.ml35,
                        ]}
                        >
                          <View style={[Style.Main.rowDirectionFlexStart]}>
                            <Icon
                              name={val.icon}
                              style={[Style.Main.textGray, Style.Main.font16, Style.Main.container, Style.Main.alignCenter]}
                            />
                            <View style={[Style.Main.flex8]}>
                              <Text style={[Style.Main.fontAlbert11]}>{_(`${val.label}`)}</Text>
                              {/* {(!val.value) ? renderValue : null} */}
                              {val.value !== undefined && renderValue}
                            </View>
                            {
                              i === 5 && (
                                <TouchableOpacity
                                  style={[Style.Main.rowDirection]}
                                  onPress={() => { this.handleOnProceed('CPDDetail'); }}
                                >
                                  <Icon
                                    name="angle-right"
                                    style={[Style.Main.textGray, Style.Main.font16, Style.Main.ml12, Style.Main.alignCenter]}
                                  />
                                </TouchableOpacity>
                              )
                            }
                          </View>
                        </View>
                      );
                    })}
                  </View>
                </Card>

                <Card style={[Style.Main.pb15]}>
                  {this.renderHeader('exclamation-circle', 'JUMLAH SANKSI')}
                  <View style={[Style.Main.px10, Style.Main.noBorder, Style.Main.textAlmostBlack, Style.Main.fontAlbert]}>
                    <View style={[Style.Main.mt10, Style.Main.pb5, Style.Main.borderBottomNativeBase]}>
                      <View style={[Style.Main.rowDirectionFlexStart]}>
                        <View style={[Style.Main.flex8]}>
                          <Text style={[Style.Main.fontAlbert11]}>{_('Tahun Ini')}</Text>
                          <Text style={[Style.Main.fontAlbert11]}>{!currentYearSanction ? 'N/A' : _(`${currentYearSanction}`)}</Text>
                        </View>
                      </View>
                    </View>
                    <View style={[Style.Main.mt10, Style.Main.pb5, Style.Main.borderBottomNativeBase]}>
                      <View style={[Style.Main.rowDirectionFlexStart]}>
                        <View style={[Style.Main.flex8]}>
                          <Text style={[Style.Main.fontAlbert11]}>{_('Keseluruhan')}</Text>
                          <Text style={[Style.Main.fontAlbert11]}>{!overallSanction ? 'N/A' : _(`${overallSanction}`)}</Text>
                        </View>
                      </View>
                    </View>
                  </View>
                </Card>

                <Card style={[Style.Main.pb15]}>
                  {this.renderHeader('exclamation-circle', 'PERSETUJUAN FATCA')}
                  <View style={[Style.Main.px10, Style.Main.noBorder, Style.Main.textAlmostBlack, Style.Main.fontAlbert]}>
                    <View style={[Style.Main.mt10]}>
                      <View style={[Style.Main.rowDirectionFlexStart]}>
                        <Icon name="file" style={[Style.Main.textGray, Style.Main.font16, Style.Main.container, Style.Main.alignCenter]} />
                        <View style={[Style.Main.flex8]}>
                          <Text style={[Style.Main.fontAlbert12]}>{_('Status FATCA')}</Text>
                        </View>
                        <View style={[Style.Main.rowDirection]}>
                          <TouchableOpacity onPress={this.handleModal} style={[Style.Main.rowDirection, Style.Main.alignCenter]}>
                            <Text style={[Style.Main.fontAlbert11]}>
                              {_('Setuju')}
                            </Text>
                            <Icon name="angle-right" style={[Style.Main.textGray, Style.Main.ml5, Style.Main.alignRight]} />
                          </TouchableOpacity>
                        </View>
                      </View>
                    </View>
                  </View>
                </Card>

                <Card style={[Style.Main.pb15]}>
                  {this.renderHeader('exclamation-circle', 'KONTAK DARURAT', true)}
                  {
                    emergencyContact && (emergencyContact.map(val => (
                      <View style={[Style.Main.px10, Style.Main.noBorder, Style.Main.textAlmostBlack, Style.Main.fontAlbert]}>
                        <View style={[Style.Main.mt10, Style.Main.pb15, Style.Main.borderBottomNativeBase]}>
                          <View style={[Style.Main.rowDirectionFlexStart]}>
                            <Icon
                              name={val.icon}
                              style={[Style.Main.textGray, Style.Main.font16, Style.Main.container, Style.Main.alignCenter]}
                            />
                            <View style={[Style.Main.flex8]}>
                              <Text style={[Style.Main.fontAlbert11]}>{val.label && _(`${val.label}`)}</Text>
                              {
                                !this.state.isChangedToOnline
                                  ? this.renderActivityIndicator()
                                  : this.renderTextValue(val.value)
                              }
                            </View>
                          </View>
                        </View>
                      </View>
                    )))
                  }
                </Card>
              </View>
            </Content>
          </View>
        </Container>
        <FatcaModal
          {...this.props}
          visible={this.state.showModal}
          onClose={this.handleOnClose}
          fatcaFlag={this.state.fatcaFlag}
          onAgree={this.handleOnAgree}
        />
        <LoadingModal show={this.state.isLoading} size="large" color="white" />
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  resAuth: state.auth.res,
  connectionStatus: state.connectionStatus,
});

export default connect(mapStateToProps, null)(MyAccountDetail);
