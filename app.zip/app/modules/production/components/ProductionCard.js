import React, { PureComponent } from 'react';
import {
  Text, Button, Card, View,
} from 'native-base';
import moment from 'moment';
import {
  isEmpty, toFixedCurrency, toStringTwoDigit, toTitleCase,
} from '../../../utilities';
import {
  Collapsible, Skeleton, StyledText, UpdateDate,
} from '../../../components';
import LoadingModal from '../../../components/loading_modal';
import Colors from '../../../styles/Colors';
import Style from '../../../styles';
import _ from '../../../lang';

class ProdValueView extends PureComponent {
  render() {
    return (
      <View style={[Style.Main.fullWidth]}>
        <View style={[Style.Main.fullWidth, Style.Main.rowDirectionSpaceBetween, Style.Main.mt5]}>
          <Text style={[Style.Main.flex8, Style.Main.fontAlbert14]}>{_('APE')}</Text>
          <View style={[Style.Main.flex7, Style.Main.rowDirectionSpaceBetween]}>
            <Text style={[Style.Main.fontAlbert14]}>Rp. </Text>
            <Text style={[Style.Main.fontAlbert14]}>{this.props.data ? toFixedCurrency(this.props.data.api || 0, 2) : '0.00'}</Text>
          </View>
        </View>
        <View style={[Style.Main.fullWidth, Style.Main.rowDirectionSpaceBetween, Style.Main.mt5]}>
          <Text style={[Style.Main.flex8, Style.Main.fontAlbert14]}>{_('SAVER')}</Text>
          <View style={[Style.Main.flex7, Style.Main.rowDirectionSpaceBetween]}>
            <Text style={[Style.Main.fontAlbert14]}>Rp. </Text>
            <Text style={[Style.Main.fontAlbert14]}>{this.props.data ? toFixedCurrency(this.props.data.saver || 0, 2) : '0.00'}</Text>
          </View>
        </View>
        <View style={[Style.Main.fullWidth, Style.Main.rowDirectionSpaceBetween, Style.Main.mt5]}>
          <Text style={[Style.Main.flex8, Style.Main.fontAlbert14]}>{_('TOP UP')}</Text>
          <View style={[Style.Main.flex7, Style.Main.rowDirectionSpaceBetween]}>
            <Text style={[Style.Main.fontAlbert14]}>Rp. </Text>
            <Text style={[Style.Main.fontAlbert14]}>{this.props.data ? toFixedCurrency(this.props.data.topUp || 0, 2) : '0.00'}</Text>
          </View>
        </View>
        <View style={[Style.Main.fullWidth, Style.Main.rowDirectionSpaceBetween, Style.Main.mt5]}>
          <Text style={[Style.Main.flex8, Style.Main.fontAlbert14]}>{_('SPI')}</Text>
          <View style={[Style.Main.flex7, Style.Main.rowDirectionSpaceBetween]}>
            <Text style={[Style.Main.fontAlbert14]}>Rp. </Text>
            <Text style={[Style.Main.fontAlbert14]}>{this.props.data ? toFixedCurrency(this.props.data.spi || 0, 2) : '0.00'}</Text>
          </View>
        </View>
      </View>
    );
  }
}

const skeletonLayout = [{
  flexDirection: 'row',
  justifyContent: 'space-between',
  width: '100%',
  height: 9,
  marginVertical: 3,
  children: [
    { width: '30%', height: '100%', borderRadius: 1 },
    { width: '40%', height: '100%', borderRadius: 1 },
  ],
}, {
  flexDirection: 'row',
  justifyContent: 'space-between',
  width: '100%',
  height: 7,
  marginVertical: 3,
  children: [
    { width: '10%', height: '100%', borderRadius: 1 },
    { width: '25%', height: '100%', borderRadius: 1 },
  ],
}];

class ProductionCard extends PureComponent {
  ProductionItem = ({
    type, value, diff, color, style,
  }) => (
    <View style={[Style.Main.container, Style.Main.rowDirection, color ? Style.Main.mtMin1 : Style.Main.padding10,
      Style.Main.setBorder({ borderRadius: color ? 0 : 5 }), style]}
    >
      {!isEmpty(color) && <View style={[Style.Main.setSize({ w: 5, h: '100%', backgroundColor: color })]} />}
      <View style={[Style.Main.container, color && Style.Main.padding10]}>
        <Skeleton isLoading={this.props.isLoading} layout={skeletonLayout}>
          <View style={[Style.Main.rowDirectionSpaceBetween]}>
            <StyledText bold>{type}</StyledText>
            <StyledText bold>{toFixedCurrency(value || 0, 2)}</StyledText>
          </View>
          <View style={[Style.Main.rowDirectionSpaceBetween]}>
            <StyledText font={10} color={Colors.gray83}>{Number(moment(new Date()).format('YYYY')) - 1}</StyledText>
            <StyledText font={10} color={Colors.greenPruexpert}>{toFixedCurrency(diff || 0, 2)}</StyledText>
          </View>
        </Skeleton>
      </View>
    </View>
  );

  render() {
    const {
      type = '', data = {}, label = '', lastUpdate, isLoading,
    } = this.props;
    return (
      <Collapsible
        title={_(type)}
        content={
          <>
            <StyledText>{toTitleCase(_(label))}</StyledText>
            <UpdateDate isLoading={isLoading} date={lastUpdate ? moment(lastUpdate).format('LLLL') : null} />
            <this.ProductionItem type="APE NET" value={data.ape} diff={data.apeDiff} style={[Style.Main.mt10]} />
          </>
        }
        expandedContent={
          <>
            <this.ProductionItem type="REGULAR PREMI" value={data.rp} diff={data.rpDiff} color={Colors.red} />
            <this.ProductionItem type="SAVER" value={data.saver} diff={data.saverDiff} color={Colors.yellowPruexpert} />
            <this.ProductionItem type="SINGLE PREMI" value={data.spi} diff={data.spiDiff} color={Colors.bluePruexpert} />
            <this.ProductionItem type="SINGLE TOP UP" value={data.topUp} diff={data.topUpDiff} color={Colors.greenPruexpert} />
          </>
        }
        onDetail={this.props.onPress || (() => {})}
      />
    );
  }
}

class HistoryProductionCard extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    };
  }

  render() {
    return (
      <Card style={[Style.Main.padding12, Style.Main.mb12]}>
        <View style={[Style.Main.padding2, Style.Main.pt0]}>
          {
            this.props.data !== undefined && !!this.props.data.periodMonth &&
            <Text style={[Style.Main.fontAlbertBold16, Style.Main.mb5]}>
              {moment(toStringTwoDigit(this.props.data.periodMonth), 'MM').format('MMMM')} {Number(this.props.data.periodYear)}
            </Text>
          }
          <ProdValueView {...this.props} />
        </View>
        <Button
          block
          style={[Style.Main.btnPrimary, Style.Main.mt15]}
          onPress={this.props.onPress || (() => {})}
        >
          <Text style={[Style.Main.fontAlbert14]}>{_('LIHAT RINCIAN')}</Text>
        </Button>
        <LoadingModal show={this.state.isLoading} size="large" color="white" />
      </Card>
    );
  }
}

export {
  ProductionCard,
  HistoryProductionCard,
};
