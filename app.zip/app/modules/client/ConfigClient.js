import { defaultTo } from 'lodash';
import { API_ACTION_TYPES } from '../../utilities';
import { adapter } from '../../config';
import { BackgroundHNWI } from '../../assets/images';

export const vipIndicator = {
  Y: 'Y',
  N: 'N',
};

export const vipType = {
  HNWI: 'HNWI',
  VIP: 'VIP',
  VIP1: 'VIP1',
  VIP2: 'VIP2',
};

export const hnwiType = {
  BASIC: 'Basic',
  PRESITGE: 'Prestige',
  POTENTIAL: 'Potential',
};

export const hnwiStyle = {
  BASIC: {
    bgImg: BackgroundHNWI.BASIC,
    statusColor: '#E6BC14',
    cardColor: '#ED1B2E',
    headerColor: '#942E2E',
    status: hnwiType.BASIC,
    labelColor: '#9B7E6B',
    subCardColor: '#BE6262',
  },
  POTENTIAL: {
    bgImg: BackgroundHNWI.POTENTIAL,
    statusColor: '#3F3F3F',
    cardColor: '#143EE6',
    headerColor: '#DEB513',
    status: hnwiType.POTENTIAL,
    labelColor: '#838383',
    subCardColor: '#C1A741',
  },
  PRESTIGE: {
    bgImg: BackgroundHNWI.PRESTIGE,
    statusColor: '#E6BC14',
    cardColor: '#E6BC14',
    headerColor: '#16253B',
    status: hnwiType.PRESITGE,
    labelColor: '#3F3F3F',
    subCardColor: '#43597B',
  },
};

export const nonHNWI = ['BUOI'];

export const showHNWI = channel => !nonHNWI.includes(channel);

export const clientDetailConfig = (indicator = '', type = '') => {
  const style = hnwiStyle.BASIC;
  switch (`${defaultTo(indicator, '').toUpperCase()}|${defaultTo(type, '').toUpperCase()}`) {
    case `${vipIndicator.Y}|${vipType.HNWI}`: return hnwiStyle.PRESTIGE;
    default: return style;
  }
};

export const hnwiConfig = (data = {}) => {
  const sumAssured = Number(data.SUMINS || 0) / 100;
  const targetSumAssured = 10000000000;
  const requiredSumAssured = targetSumAssured - sumAssured;
  const premiNTopup = (Number(data.ANNPREM || 0) / 100) + (Number(data.ZRTOPUSUM || 0) / 100);
  const targetPremiNTopup = 500000000;
  const percentage = 0.5;

  const config = {
    data: {
      sumAssured, targetSumAssured, requiredSumAssured, premiNTopup, targetPremiNTopup,
    },
    styles: hnwiStyle.BASIC,
  };

  if (data.TAGHNWI === vipIndicator.Y) return { ...config, styles: hnwiStyle.PRESTIGE };

  const minPremiNTopup = targetPremiNTopup * percentage;
  const minSumAssured = targetSumAssured * percentage;

  if ((sumAssured > 0 && sumAssured >= minSumAssured) || (premiNTopup > 0 && premiNTopup >= minPremiNTopup)) {
    return { ...config, styles: hnwiStyle.POTENTIAL };
  }
  return config;
};

export const clientListAction = (action, value) => ({ type: action, payload: value });

export const CLIENT_LIST = API_ACTION_TYPES('CLIENT_LIST', `${adapter.INQUIRY}/findListClientByAgentNumber`);

export const CLIENT_VIP_INFO_LIST = API_ACTION_TYPES('CLIENT_VIP_INFO_LIST', `${adapter.PMN}/getClientVipInfoByListId`);
