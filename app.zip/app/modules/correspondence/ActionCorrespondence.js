export const correspondenceAction = (action, value) => ({ type: action, payload: value });
