import Views from './views';

// Please update Screen in Sub-Menu Components too
export default {
  MainProduction: { screen: Views.MainProduction },
  ProductionHistoryDetail: { screen: Views.ProductionHistoryDetail },
  ProductionUnitList: { screen: Views.ProductionUnitList },
  ProductionIndividuList: { screen: Views.ProductionIndividuList },
};
