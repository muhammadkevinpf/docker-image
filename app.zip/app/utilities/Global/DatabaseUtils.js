import { isEmpty } from '../Functions';
import { coverageStartText } from '../../config';
import { toTitleCase, ucFirst } from '../String';
import Caches from '../Caches';


const productCategory = {
  UL: 'UL',
  TRD: 'TRD',
};

const database = () => {
  // if (global && global.database) return global.database;
  if (global && global.database) return Caches.dumpCache();
  return {};
};

const formattedTelCodes = () => Caches.dumpCache()
  .allCountry.ALL_COUNTRY.map(obj => ({ ...obj, descCountry: `${obj.telephoneCode} (${obj.description})` }));

const coverage = () => {
  if (!isEmpty(Caches.dumpCache())
  && !isEmpty(Caches.dumpCache().coverage)
  && Caches.dumpCache().coverage.COVERAGE) return Caches.dumpCache().coverage.COVERAGE;
  return {};
};

const getCoverage = (productCode, ignoreLastDigit) => {
  if (!isEmpty(coverage())) {
    if (ignoreLastDigit) {
      const defaultCoverage = coverage()[`${productCode}R`] || coverage()[`${productCode}1`]
        || coverage()[`${productCode}U`] || coverage()[`${productCode}3`] || coverage()[`${productCode}D`]
        || coverage()[`${productCode}2`] || coverage()[`${productCode}4`] || coverage()[`${productCode}5`]
        || coverage()[`${productCode}6`] || coverage()[`${productCode}7`] || coverage()[`${productCode}8`]
        || coverage()[`${productCode}9`];
      return defaultCoverage;
    }
    return coverage()[productCode];
  }
  return {};
};

const getCoverageDesc = (productCode, ignoreLastDigit, returnDefaultByDB) => {
  if (!isEmpty(getCoverage(productCode, ignoreLastDigit))) {
    const desc = getCoverage(productCode, ignoreLastDigit).longDescription;
    if (!returnDefaultByDB) return toCoverageFormat(desc);
    return desc;
  }
  return '';
};

const toCoverageFormat = (desc) => {
  if (!isEmpty(desc)) {
    const newDesc = toTitleCase(desc);
    const startsWith = coverageStartText.find(type => newDesc.toUpperCase().startsWith(type));
    if (!isEmpty(startsWith)) return startsWith + ucFirst(newDesc.slice(startsWith.length));
    return newDesc;
  }
  return desc;
};

const getFSCLabel = (productCd, isLongDesc, isHTMLFormat, channel) => {
  const staffBankProduct = ['E2E', 'L2O', 'H2I'];
  let label = isLongDesc ? 'Financial Services Consultant (FSC)' : 'FSC';
  if (staffBankProduct.includes(productCd) || channel === 'BUOI') {
    label = 'Staf Bank';
  } else if (isLongDesc && isHTMLFormat) {
    label = '<i>Financial Services Consultant</i> (FSC)';
  }
  return label;
};

const getCategoryFromCode = (agentChannel, productCode) => {
  if (isEmpty(agentChannel) || isEmpty(productCategory)) return null;
  if (Caches.get('channel').CHANNEL[agentChannel].PRODUCT_CATEGORY
    .find(item => item.code === productCategory.UL).PRODUCT
    .find(item => item.code === productCode)) return productCategory.UL;
  return productCategory.TRD;
};

const getFundDesc = (code) => {
  const cache = Caches.dumpCache();
  if (!isEmpty(cache) && !isEmpty(cache.fund) && !isEmpty(cache.fund.FUND) && !isEmpty(cache.fund.FUND[code])) {
    return cache.fund.FUND[code].descriptionInd;
  } return '';
};

export default {
  productCategory,
  database,
  coverage,
  getCoverage,
  getCoverageDesc,
  toCoverageFormat,
  formattedTelCodes,
  getFSCLabel,
  getCategoryFromCode,
  getFundDesc,
};
