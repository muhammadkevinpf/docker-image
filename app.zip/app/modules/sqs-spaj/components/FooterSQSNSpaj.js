/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { PureComponent } from 'react';
import {
  Footer, FooterTab, Button, Text, View, Grid,
} from 'native-base';
import { Row, Col } from 'react-native-easy-grid';
import Icon from 'react-native-vector-icons/FontAwesome';
import _ from '../../../lang';
import Style from '../../../styles';
import StyleSQSNSpaj from '../StyleSQSNSpaj';

class FooterSQSNSpaj extends PureComponent {
  render() {
    return (
      <Footer>
        <FooterTab>
          <Grid>
            <Row>

              <Col style={Style.Main.mr1}>
                <Button
                  vertical
                  style={Style.Main.backgroundRed}
                  onPress={this.props.subsequentDocuments}
                >
                  <Row>
                    <View style={Style.Main.textWrap}>
                      <Col size={20} style={StyleSQSNSpaj.leftIconFooter}>
                        <Icon name="plus-circle" style={[Style.Main.textWhite, Style.Main.alignCenter]} />
                      </Col>
                      <Col size={80} style={StyleSQSNSpaj.rightTitleFooter}>
                        <Text style={[Style.Main.textWhite]}>{_('Dokumen Susulan')}</Text>
                      </Col>
                    </View>
                  </Row>
                </Button>
              </Col>

              <Col style={Style.Main.ml1}>
                <Button
                  vertical
                  style={Style.Main.backgroundRed}
                  onPress={this.props.newProposal}
                >
                  <Row>
                    <View style={Style.Main.textWrap}>
                      <Col size={20} style={StyleSQSNSpaj.leftIconFooter}>
                        <Icon name="plus-circle" style={[Style.Main.textWhite, Style.Main.alignCenter]} />
                      </Col>
                      <Col size={80} style={StyleSQSNSpaj.rightTitleFooter}>
                        <Text style={[Style.Main.textWhite]}>{_('Proposal Baru')}</Text>
                      </Col>
                    </View>
                  </Row>
                </Button>
              </Col>

            </Row>
          </Grid>
        </FooterTab>
      </Footer>
    );
  }
}

export default FooterSQSNSpaj;
