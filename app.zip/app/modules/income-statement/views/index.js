import MainIncomeStatement from './main-income-statement';
import IncomeStatement from './income-statement-summary';
import CommissionDetail from './detail-commission';
import IncomeHistoryDetail from './detail-history';
import { TaxSlipPreview, TaxSlipList } from './tax-slip';

export default {
  MainIncomeStatement,
  IncomeStatement,
  CommissionDetail,
  IncomeHistoryDetail,
  TaxSlipPreview,
  TaxSlipList,
};
