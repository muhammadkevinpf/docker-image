/**
 * @author: dwi.setiyadi@gmail.com
*/

import { SETSCREEN, SET_SIDEBAR_WIDTH } from '../../config/Constants';

const initialState = {
  action: null,
  prevScreen: null,
  thisScreen: null,
  sideBarWidth: null,
};

export function ReducerContainer(state = initialState, action) {
  switch (action.type) {
    case SETSCREEN:
      return {
        ...state,
        action: action.screen.action,
        prevScreen: action.screen.prevScreen,
        thisScreen: action.screen.thisScreen,
      };

    case SET_SIDEBAR_WIDTH: return { ...state, sideBarWidth: action.payload };

    default:
      return state;
  }
}
