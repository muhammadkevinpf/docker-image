
import React from 'react';
import CodePush from 'react-native-code-push';
import { View, Text } from 'native-base';
import ProgressBar from 'react-native-progress/Bar';
import { Alert, Platform, Dimensions } from 'react-native';
import RNFS from 'react-native-fs';
import RNExitApp from 'react-native-exit-app';
import { ModalCustom } from '../../components';
import Styles from '../../styles';
import _ from '../../lang';
import SplashScreen from 'react-native-splash-screen';
import Database from '../../config/Database';
import { saveLog, CONSTANT } from '../Logger';
import { trackEvent } from 'appcenter-analytics';

export class PushUpdateUtils {
  downloading = false;

  copyDB = isUpdating => new Promise(async (resolve, reject) => {
    try {
      const destPath = `${RNFS.DocumentDirectoryPath}/${Database.newSqs.name}`;
      const CodePushPath = Platform.OS === 'android' ? `${RNFS.DocumentDirectoryPath}/CodePush` : `${RNFS.LibraryDirectoryPath}/Application Support/CodePush`;
      const sourceAssetsPath = Platform.OS === 'android' ? 'www/newsqs.db' : `${RNFS.MainBundlePath}/www/newsqs.db`;
      const isDBExist = await RNFS.exists(destPath);
      if (!isUpdating) {
        if (!isDBExist) {
          const documents = await RNFS.readDir(RNFS.DocumentDirectoryPath);
          for (let documentIndex = 0; documentIndex < documents.length; documentIndex += 1) {
            if (documents[documentIndex].name.includes('newsqs')) {
              await RNFS.unlink(documents[documentIndex].path)
            }
          }
          if (Platform.OS === 'android') {
            await RNFS.copyFileAssets(sourceAssetsPath, destPath);
          } else {
            await RNFS.copyFile(sourceAssetsPath, destPath);
          }
        }
      } else {
        CodePush.disallowRestart();
        let checkCodePushPath = [];
        try {
          checkCodePushPath = await RNFS.readDir(CodePushPath);
        } catch (error) {
          // saveLog(CONSTANT.ERROR, JSON.stringify(error));
          trackEvent('DB_UPDATE', { message: error.message });
          checkCodePushPath = [];
        }
        for (let dirIndex = 0; dirIndex < checkCodePushPath.length; dirIndex++) {
          if (await RNFS.exists(`${CodePushPath}/${checkCodePushPath[dirIndex].name}/CodePush/newsqs.db`)) {
            if (isDBExist) {
              await RNFS.unlink(destPath);
            }
            await RNFS.copyFile(`${CodePushPath}/${checkCodePushPath[dirIndex].name}/CodePush/newsqs.db`, destPath);
            break;
          }
        }
        CodePush.allowRestart();
      }
      resolve('success');
    } catch (error) {
      trackEvent('DB_UPDATE', { message: error.message });
      reject(error);
    }
  });

  checkUpdate = (showUpdateModal = () => { }, downloadProgress = () => { }) => {
    CodePush.sync(
      {
        updateDialog: {
          title: 'Pembaruan',
          optionalInstallButtonLabel: 'Perbarui',
          optionalUpdateMessage: 'Pembaruan Tersedia',
          optionalIgnoreButtonLabel: 'Nanti',
          mandatoryContinueButtonLabel: 'Perbarui',
          mandatoryUpdateMessage: 'Pembaruan Tersedia',
          appendReleaseDescription: true,
          descriptionPrefix: '\n\nPerubahan:\n',
        },
        installMode: CodePush.InstallMode.IMMEDIATE,
        mandatoryInstallMode: CodePush.InstallMode.IMMEDIATE,
      },
      (status) => {
        switch (status) {
          case CodePush.SyncStatus.DOWNLOADING_PACKAGE:
            this.downloading = true;
            showUpdateModal(true);
            break;
          case CodePush.SyncStatus.INSTALLING_UPDATE:
            this.downloading = false;
            this.copyDB(true);
            break;
          case CodePush.SyncStatus.UPDATE_IGNORED:
            // BackHandler.exitApp();
            break;
          case CodePush.SyncStatus.UPDATE_INSTALLED:
            showUpdateModal(false);
            SplashScreen.show();
            break;
          case CodePush.SyncStatus.UNKNOWN_ERROR:
            showUpdateModal(false);
            this.handleCodePushError();
            break;
          default:
            break;
        }
      },
      ({ receivedBytes, totalBytes }) => {
        downloadProgress(receivedBytes, totalBytes);
      },
    );
  }

  handleCodePushError = () => {
    if (!this.downloading) return;
    Alert.alert(
      'Kesalahan',
      'Terjadi kesalahan ketika pembaruan, pastikan koneksi internet anda dalam kondisi baik.'
      [{
        text: 'OK', onPress: () => {
          RNExitApp.exitApp();
        }
      }],
      { cancelable: false },
    );
  }
}

export class PushUpdateModal extends React.PureComponent {
  render() {
    return (
      <ModalCustom
        isVisible={this.props.showUpdateModal}
        content={
          <View style={[Styles.Main.backgroundWhiteSmoke, Styles.Main.width70, Styles.Main.height90, Styles.Main.borderRadius10]}>
            <View style={[Styles.Main.mt15, Styles.Main.mb10, Styles.Main.alignCenter]}>
              <Text style={[Styles.Main.textRed, Styles.Main.fontAlbert]}>Memperbarui</Text>
            </View>
            <View style={[Styles.Main.alignCenter, Styles.Main.mb10]}>
              <View>
                <ProgressBar
                  progress={this.props.receivedBytes / this.props.totalBytes}
                  borderWidth={0}
                  borderRadius={4}
                  height={10}
                  color="#ed1b2e"
                  unfilledColor="#ededed"
                  width={Dimensions.get('window').width * 0.6}
                />
                <Text style={[Styles.Main.font12, Styles.Main.alignRight]}>{this.props.receivedBytes}/{this.props.totalBytes}</Text>
              </View>
            </View>
          </View>
        }
        onPress={() => { }}
        animationType="fade"
      />
    );
  }
}
