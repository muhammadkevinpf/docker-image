import React, { Component } from 'react';
import CryptoJS from 'crypto-js';
import { BackHandler, TextInput, Alert } from 'react-native';
import {
  Button, Text, View, Icon,
} from 'native-base';
import { connect } from 'react-redux';
import _ from '../../../lang';
import Style from '../../../styles';
import HomeScreen from '../components/HomeScreen';
import { authAction } from '../ActionHome';
import { FORGOT_CHANGE_PASSWORD, pageType as page, CREATE_PRUFAST_ID } from '../ConfigHome';
import { requestStatus } from '../../../utilities';
import LoadingModal from '../../../components/loading_modal';
import { hashingPassword } from '../../auth/ActionAuth';

const headers = [
  {
    keyHeader: 'X-CSRF-Token',
    valueHeader: 'Bearer undefined',
  },
];
class SignUpAgent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isSecure: true,
      isSecureConfirm: true,
      prufastId: '',
      password: '',
      confirmPassword: '',
      isLoading: false,
      isSignUp: false,
      pageType: '',
    };
  }

  componentDidMount() {
    const pageType = this.props.navigation.getParam('pageType', '');
    const isSignUp = pageType === page.createPRUFastID || pageType === page.createPRUFastIDNoSFA;
    this.setState({ isSignUp, pageType });
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleBack();
      return true;
    });
  }

  componentDidUpdate(prevProps) {
    if (this.props !== prevProps) {
      if ((this.props.status !== prevProps.status && this.props.status === requestStatus.FETCH)
        || (this.props.createIdStatus !== prevProps.createIdStatus && this.props.createIdStatus === requestStatus.FETCH)) {
        this.handleLoading(true);
      }

      if (this.props.status !== prevProps.status && this.props.status === requestStatus.SUCCESS) {
        this.handleLoading(false, () => {
          if (this.props.changePasswordData.errorCode === '000000') {
            this.props.hashingUserPassword(CryptoJS.SHA1(JSON.stringify(this.state.password)).toString());
            Alert.alert('', 'Password berhasil diganti!', [{
              text: 'OK',
              onPress: () => this.props.navigation.replace('SignInHome', { agentData: this.props.changePasswordData.agent }),
            }]);
          } else {
            Alert.alert('', this.props.changePasswordData.errorMessage, [{ text: 'Ok', onPress: () => { } }]);
          }
        });
      }

      if (this.props.createIdStatus !== prevProps.createIdStatus && this.props.createIdStatus === requestStatus.SUCCESS) {
        this.handleLoading(false, () => {
          if (this.props.createId.errorCode === '000000') {
            this.props.hashingUserPassword(CryptoJS.SHA1(JSON.stringify(this.state.password)).toString());
            Alert.alert('', 'PRUFast ID berhasil didaftarkan', [{
              text: 'OK',
              onPress: () => this.props.navigation.replace('SecurityQuestions',
                { pageType: this.state.pageType, agentData: this.props.createId.agent }),
            }]);
          } else {
            Alert.alert('', this.props.createId.errorMessage, [{ text: 'Ok', onPress: () => { } }]);
          }
        });
      }

      if ((this.props.status !== prevProps.status && this.props.status === requestStatus.FAILED)
        || (this.props.createIdStatus !== prevProps.createIdStatus && this.props.createIdStatus === requestStatus.FAILED)) {
        this.handleLoading(false, () => {
          Alert.alert('', 'Gagal memanggil service', [{ text: 'Ok', onPress: () => { } }]);
        });
      }
    }
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  handleLoading = (val, func) => {
    const callbackFunc = func || (() => { });
    this.setState({ isLoading: val }, callbackFunc);
  }

  handleBack = () => {
    const route = this.props.navigation.getParam('route', 'SecurityQuestions');
    this.props.navigation.replace(route, { pageType: this.state.pageType });
  }

  onVerify = () => {
    // eslint-disable-next-line no-useless-escape
    const passwordFormat = /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
    const username = this.props.navigation.getParam('username', '');
    const dataParam = this.props.navigation.getParam('data', {});
    const {
      prufastId, password, isSignUp, pageType,
    } = this.state;
    const agentCode = pageType === page.createPRUFastIDNoSFA ? dataParam.agentId : this.props.agentData.body.result.agentId;
    const npa = '0';

    if (passwordFormat.test(password)) {
      Alert.alert('', 'Format Password belum sesuai!', [{ text: 'Ok', onPress: () => { } }]);
    } else if (isSignUp) {
      const data = { headers, params: `["${prufastId}", "${password}", "${npa}", "${agentCode}"]` };
      this.props.signUp(data);
    } else {
      this.props.changePassword({ headers, params: `["${username}", "${password}"]` });
    }
  }

  buttonDisabled = () => {
    const {
      password, confirmPassword, isSignUp, prufastId,
    } = this.state;

    if (this.checkPassword().length > 0 || confirmPassword !== password
      || password === '' || confirmPassword === '' || (isSignUp && prufastId === '')) {
      return true;
    }
    return false;
  }

  checkPassword = () => {
    const {
      password, confirmPassword, prufastId, isSignUp,
    } = this.state;
    const errorMessage = [];
    if (isSignUp && prufastId.length < 5) {
      errorMessage.push('PRUFast ID terdiri dari 5-15 karakter');
    } if (password.length < 8) {
      errorMessage.push('Password kurang dari minimum karakter');
    } if (password.search(/\d/) === -1 || password.search(/[A-Z]/) === -1 || password.search(/[a-z]/) === -1) {
      errorMessage.push('Password harus memiliki minimum 1 angka dan 1 huruf kapital');
    } if (password.length && confirmPassword.length && password !== confirmPassword) {
      errorMessage.push('Password tidak sama');
    }

    return errorMessage;
  }

  render() {
    const { isSignUp } = this.state;
    const changePassLabel = !isSignUp ? ' Baru' : '';
    // eslint-disable-next-line no-useless-escape
    const regex = /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
    return (
      <HomeScreen
        title={isSignUp ? 'Daftar PRUFast ID' : 'Set Ulang Password'}
        onBackClicked={this.handleBack}
        content={
          <React.Fragment>
            {isSignUp && (
              <View style={[Style.Main.container, Style.Main.fontAlbert, Style.Main.grayBorderBottom,
                Style.Main.alignCenter, Style.Main.width200, Style.Main.rowDirection, Style.Main.mt15]}
              >
                <TextInput
                  style={[Style.Main.container, Style.Main.fontAlbert,
                    Style.Main.pb5, Style.Main.alignCenter]}
                  keyboardAppearance="default"
                  keyboardType="default"
                  returnKeyType="done"
                  maxLength={15}
                  placeholder={_('Masukkan PRUFast ID')}
                  onChangeText={text => this.setState({ prufastId: text.trim().replace(regex, '') })}
                  value={this.state.prufastId}
                />
              </View>
            )}
            <View style={[Style.Main.container, Style.Main.fontAlbert, Style.Main.grayBorderBottom,
              Style.Main.alignCenter, Style.Main.width200, Style.Main.rowDirection, Style.Main.mt15]}
            >
              <TextInput
                style={[Style.Main.container, Style.Main.fontAlbert,
                  Style.Main.pb5, Style.Main.alignCenter]}
                keyboardAppearance="default"
                keyboardType="default"
                returnKeyType="done"
                maxLength={15}
                placeholder={_(`Password${changePassLabel}`)}
                onChangeText={text => this.setState({ password: text.trim().replace(regex, '') })}
                value={this.state.password}
                autoCompleteType="password"
                secureTextEntry={this.state.isSecure}
              />
              <Icon
                style={[Style.Main.alignRight, Style.Main.mb8, Style.Main.textGray]}
                type="Ionicons"
                name={this.state.isSecure ? 'eye-off' : 'eye'}
                onPress={() => this.setState(prevState => ({ isSecure: !prevState.isSecure }))}
              />
            </View>
            <View style={[Style.Main.container, Style.Main.fontAlbert, Style.Main.grayBorderBottom,
              Style.Main.alignCenter, Style.Main.width200, Style.Main.rowDirection, Style.Main.mt15]}
            >
              <TextInput
                style={[Style.Main.container, Style.Main.fontAlbert,
                  Style.Main.pb5, Style.Main.alignCenter]}
                keyboardAppearance="default"
                keyboardType="default"
                returnKeyType="done"
                maxLength={15}
                placeholder={_(`Ulangi Password${changePassLabel}`)}
                onChangeText={text => this.setState({ confirmPassword: text.trim().replace(regex, '') })}
                value={this.state.confirmPassword}
                autoCompleteType="password"
                secureTextEntry={this.state.isSecureConfirm}
              />
              <Icon
                style={[Style.Main.alignRight, Style.Main.mb8, Style.Main.textGray]}
                type="Ionicons"
                name={this.state.isSecure ? 'eye-off' : 'eye'}
                onPress={() => this.setState(prevState => ({ isSecureConfirm: !prevState.isSecureConfirm }))}
              />
            </View>
            <Button
              disabled={this.buttonDisabled()}
              rounded
              danger
              style={[Style.Main.mt35, Style.Main.buttonRed, this.buttonDisabled() && Style.Main.halfOpacity]}
              onPress={this.onVerify}
            >
              <Text style={[Style.Main.fontAlbert14, Style.Main.textWhite]}>{_(isSignUp ? 'DAFTAR' : 'LANJUT')}</Text>
            </Button>
            {
              this.checkPassword() && this.checkPassword().map(value => (
                <View style={[Style.Main.container, Style.Main.fontAlbert, Style.Main.width200, Style.Main.alignCenter]}>
                  <Text style={[Style.Main.textRed, Style.Main.font8, Style.Main.textCenter]}>
                    {value}
                  </Text>
                </View>
              ))
            }
            <LoadingModal
              show={this.state.isLoading}
              size="large"
              color="white"
            />
          </React.Fragment>
        }
      />
    );
  }
}

const mapStateToProps = state => ({
  isOnline: state.connectionStatus.isOnline,
  changePasswordData: state.home.changePassword,
  status: state.home.changePasswordStatus,
  createId: state.home.createId,
  createIdStatus: state.home.createIdStatus,
  agentData: state.home.checkAgent,
});

const mapDispatchToProps = dispatch => ({
  changePassword: value => dispatch(authAction(FORGOT_CHANGE_PASSWORD.FETCH, value)),
  hashingUserPassword: value => dispatch(hashingPassword(value)),
  signUp: value => dispatch(authAction(CREATE_PRUFAST_ID.FETCH, value)),
});

export default connect(mapStateToProps, mapDispatchToProps)(SignUpAgent);
