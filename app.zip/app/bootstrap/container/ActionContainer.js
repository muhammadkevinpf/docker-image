/**
 * @author: dwi.setiyadi@gmail.com
*/

import { SETSCREEN, SET_SIDEBAR_WIDTH } from '../../config/Constants';

export const setScreen = value => ({ type: SETSCREEN, screen: value });
export const setSidebarWidth = value => ({ type: SET_SIDEBAR_WIDTH, payload: value });
