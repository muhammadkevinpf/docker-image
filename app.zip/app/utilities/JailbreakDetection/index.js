import JailBreak from 'jail-monkey';
import { Alert, Platform } from 'react-native';
import RNExitApp from 'react-native-exit-app';
import _ from '../../lang';
import { displayName as appName } from '../../../app.json';

const jailBreakCheck = () => new Promise(async (resolve, reject) => {
  try {
    const jailbroken = await JailBreak.isJailBroken();
    if (jailbroken) {
      Alert.alert(
        _('Kesalahan'),
        _(`${appName} tidak dapat berjalan di perangkat yang telah di ${Platform.os === 'android' ? 'root' : 'JailBreak'}.`),
        [{ text: _('Tutup'), onPress: () => RNExitApp.exitApp() }],
        { cancelable: false },
      );
    }
    resolve(jailbroken);
  } catch (error) {
    reject(error);
  }
});

export { jailBreakCheck };
