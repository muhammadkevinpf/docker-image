/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import {
  TextInput, View, KeyboardAvoidingView, Image, BackHandler,
} from 'react-native';
import {
  Container,
  Content, Button, Text, Icon, Footer,
} from 'native-base';
import _ from '../../../lang';
import Style from '../../../styles';
import bg from '../../../assets/images/bg.png';


class SignUpAgentHome extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dislayFooter: true,
    };
  }

  componentDidMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleBack();
      return true;
    });
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  handleBack = () => {
    this.props.navigation.replace('SignUpHome');
  }

  render() {
    return (
      <Container>
        <Image source={bg} style={Style.Main.bgImage} />
        <View>
          <Button
            transparent
            iconLeft
            onPress={() => this.props.navigation.replace('SignUpHome')}
          >
            <Icon name="angle-left" type="FontAwesome" style={[Style.Main.textRed]} />
            <Text style={[Style.Main.textRed]}>{_('Back')}</Text>
          </Button>
        </View>
        <Content keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
          <Text
            style={[Style.Main.font44, Style.Main.textRed, Style.Main.mt64, Style.Main.textAlignCenter, Style.Main.fontBold, Style.Main.mb55]}
          >PRUFast
          </Text>
          <Text
            style={[Style.Main.font18, Style.Main.textColor3f3, Style.Main.textAlignCenter]}
          >{_('Daftar PRUFast untuk Agen')}
          </Text>
          <View
            style={[Style.Main.container, Style.Main.mt30]}
          >
            <KeyboardAvoidingView>
              <TextInput
                style={[Style.Main.container, Style.Main.grayBorderBottom, Style.Main.pb5, Style.Main.alignCenter, Style.Main.width187]}
                keyboardAppearance="default"
                keyboardType="default"
                returnKeyType="done"
                maxLength={15}
                placeholder={_('SFA ID/Kode Agen')}
                onFocus={() => {
                  this.setState({
                    dislayFooter: false,
                  });
                }}
                onEndEditing={() => {
                  this.setState({
                    dislayFooter: true,
                  });
                }}
              />
            </KeyboardAvoidingView>
          </View>
          <View
            style={[Style.Main.container, Style.Main.mt30]}
          >
            <KeyboardAvoidingView>
              <TextInput
                style={[Style.Main.container, Style.Main.grayBorderBottom, Style.Main.pb5, Style.Main.alignCenter, Style.Main.width187]}
                keyboardAppearance="default"
                keyboardType="default"
                returnKeyType="done"
                maxLength={15}
                placeholder={_('SFA Password')}
                secureTextEntry
                onFocus={() => {
                  this.setState({
                    dislayFooter: false,
                  });
                }}
                onEndEditing={() => {
                  this.setState({
                    dislayFooter: true,
                  });
                }}
              />
            </KeyboardAvoidingView>
          </View>
          <View
            style={[Style.Main.container]}
          >
            <Button
              rounded
              danger
              style={[Style.Main.alignCenter, Style.Main.backgroundRed, Style.Main.mt20,
                Style.Main.width187, Style.Main.dialogBtnCnt, Style.Main.itemCenter]}
              // onPress={this.handleNavigation}
            >
              <Text
                style={[Style.Main.textWhite]}
              >{_('Masuk')}
              </Text>
            </Button>
          </View>

        </Content>
        <Footer
          style={[Style.Main.backgroundF9,
            (this.state.dislayFooter)
              ? Style.Main.displayFlex
              : Style.Main.displayNone,
          ]}
        >
          <View
            style={[Style.Main.container, Style.Main.dialogBtnCnt, Style.Main.itemCenter]}
          >
            <Text
              style={[Style.Main.textCenter, Style.Main.container,
                Style.Main.font12]}
            >
              {_('Tidak Memiliki SFA ID? ')}
              <Text
                style={[Style.Main.font12, Style.Main.textRed]}
                onPress={() => this.props.navigation.replace('SignUpAgentSFARegHome')}
              >{_('Verifikasi data')}
              </Text>
            </Text>
          </View>
        </Footer>
      </Container>
    );
  }
}

export default SignUpAgentHome;
