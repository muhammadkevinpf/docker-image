const ADAPTERNEWSQS = 'adapters/HTTPAdapterNewSQS';
const HTTPAdapterCommonJava = 'adapters/HTTPAdapterCommonJava';

const LISTPROPOSALAPI = `${ADAPTERNEWSQS}/syncListDraft2`;
const LISTPROPOSALFETCH = 'LISTPROPOSALFETCH';
const LISTPROPOSALSUCCESS = 'LISTPROPOSALSUCCESS';
const LISTPROPOSALFAILED = 'LISTPROPOSALFAILED';

const GETDETAILPROPOSALAPI = `${ADAPTERNEWSQS}/syncDraftDetail`;

const SyncSqsPost = tmpQuote => ({
  adapter: `${ADAPTERNEWSQS}/syncSqsPost2`,
  procedure: 'syncSqsPost2',
  method: 'post',
  parameters: { params: tmpQuote },
});

const DoEncrypt = param => ({
  adapter: `${ADAPTERNEWSQS}/doEncrypt`,
  procedure: 'doEncrypt',
  method: 'post',
  parameters: { params: param },
});

const Upload = param => ({
  adapter: `${HTTPAdapterCommonJava}/doEncrypt`,
  procedure: 'resource/upload"',
  method: 'post',
  parameters: { params: param },
});

const STOREILLUSTRATIONDATA = 'STORE_ILLUSTRATION_DATA';

export default {
  LISTPROPOSALAPI,
  LISTPROPOSALFAILED,
  LISTPROPOSALFETCH,
  LISTPROPOSALSUCCESS,
  GETDETAILPROPOSALAPI,
  SyncSqsPost,
  DoEncrypt,
  Upload,
  STOREILLUSTRATIONDATA,
};
