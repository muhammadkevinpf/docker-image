/**
 * @author: ahmdichsanb@gmail.com
*/

import { StyleSheet } from 'react-native';
import Styles from '../../styles';

const Style = StyleSheet.create({
  indicatorStyle: {
    backgroundColor: Styles.Color.red,
  },
  tabBarStyle: {
    backgroundColor: Styles.Color.white,
  },
});

export default Style;
