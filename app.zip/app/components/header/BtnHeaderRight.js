/**
 * @author
 * Dwi Setiyadi
 * ahmdichsanb@gmail.com
 */

import React from 'react';
import { View } from 'react-native';
import { Col } from 'react-native-easy-grid';
import { connect } from 'react-redux';
import ButtonCustom from '../button-custom';

import Style from '../../styles';
import StyleHeader from './StyleHeader';

import { totalToDoFetch } from '../../modules/todo-list/ActionTodoList';
import { TOTALTODOSUCCESS } from '../../modules/todo-list/ConfigTodoList';

import { totalNotificationFetch } from '../../modules/notification/ActionNotification';
import { TOTALNOTIFICATIONSUCCESS } from '../../modules/notification/ConfigNotification';

class BtnHeaderRight extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      totalToDo: null,
      totalNotification: null,
    };
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.actionToDo !== prevState.actionToDo && nextProps.actionToDo === TOTALTODOSUCCESS) {
      return {
        totalToDo: nextProps.resTodo.totalToDo,
      };
    }

    if (nextProps.actionNotification !== prevState.actionNotification && nextProps.actionNotification === TOTALNOTIFICATIONSUCCESS) {
      return {
        totalNotification: nextProps.resNotification.totalNotification,
      };
    }

    return null;
  }

  componentDidMount = () => {
    if (this.props.resAuth !== null && this.props.resAuth.userProfile !== undefined) {
      // Total Todo
      const dataTotalTodo = {
        headers: [
          {
            keyHeader: 'X-CSRF-Token',
            valueHeader: `Bearer ${this.props.resAuth.access_token}`,
          },
        ],
        params: `["${this.props.resAuth.userProfile.agentCode}", "${this.props.resAuth.username}"]`,
      };
      this.props.dispatchTotalToDo(dataTotalTodo);

      // Total Notification
      const dataTotalNotification = {
        headers: [
          {
            keyHeader: 'X-CSRF-Token',
            valueHeader: `Bearer ${this.props.resAuth.access_token}`,
          },
        ],
        params: `["${this.props.resAuth.userProfile.agentCode}", "All"]`,
      };
      this.props.dispatchTotalNotification(dataTotalNotification);
    }
  }


  render() {
    return (
      <React.Fragment>
        <View style={[Style.Main.textWrap, Style.Main.mt2]}>
          <Col>
            <ButtonCustom
              badge
              badgeValue={this.state.totalToDo}
              badgeType="default"
              badgeWrapper={[StyleHeader.buttonBadgeWrapper]}
              iconName="check-circle"
              iconSize={30}
              iconColor="white"
              iconStyle={[StyleHeader.buttonRight]}
              onPress={this.props.taskLink}
            />
          </Col>
          <Col>
            <ButtonCustom
              badge
              badgeValue={this.state.totalNotification}
              badgeType="default"
              badgeWrapper={[StyleHeader.buttonBadgeWrapper]}
              iconName="bell"
              iconSize={30}
              iconColor="white"
              iconStyle={[StyleHeader.buttonRight]}
              onPress={this.props.notifLink}
            />
          </Col>
        </View>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  actionAuth: state.auth.action,
  actionToDo: state.todo.action,
  actionNotification: state.notification.action,
  resAuth: state.auth.res,
  resTodo: state.todo.res,
  resNotification: state.notification.res,
});

const mapDispatchToProps = dispatch => ({
  dispatchTotalToDo: value => dispatch(totalToDoFetch(value)),
  dispatchTotalNotification: value => dispatch(totalNotificationFetch(value)),
});

export default connect(mapStateToProps, mapDispatchToProps)(BtnHeaderRight);
