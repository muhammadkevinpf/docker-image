export const persistencyAction = (action, value) => ({ type: action, payload: value });
