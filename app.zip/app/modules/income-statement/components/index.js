import IncomeStatement from './IncomeStatement';
import CommissionCard from './CommissionCard';
import { IncomeComponent, IncomeComponent2 } from './IncomeCards';

export {
  IncomeComponent,
  IncomeStatement,
  CommissionCard,
  IncomeComponent2,
};
