/* eslint-disable max-len */
/* eslint-disable no-console */
import { takeLatest } from 'redux-saga/effects';
import { activityAction } from './ActionActivity';
import { apiSagaFunction, apiTakeLatest } from '../../utilities';
import {
  GET_PROSPECT_LIST, POST_PROSPECT, GET_CONTACT, POST_CONTACT,
  PROSPECT_DETAIL, INPUT_FEEDBACK_LIST, FEEDBACK_POINT, ADD_FEEDBACK_AM,
  GET_POINT_INDIVIDU, GET_CONVERTION_INDIVIDU, GET_HISTORY_INDIVIDU, AM_DASHBOARD, AM_CALENDAR_DATA, EDIT_PROSPECT,
} from './ConfigActivity';

const timeout = 20000;
export const watcherActivity = [
  takeLatest(GET_PROSPECT_LIST.FETCH, params => apiSagaFunction(params.payload, activityAction, GET_PROSPECT_LIST, { timeout, resAttribute: 'data' })),
  takeLatest(POST_PROSPECT.FETCH, params => apiSagaFunction(params.payload, activityAction, POST_PROSPECT, { timeout, resAttribute: 'data' })),
  takeLatest(EDIT_PROSPECT.FETCH, params => apiSagaFunction(params.payload, activityAction, EDIT_PROSPECT, { timeout, resAttribute: 'data' })),
  takeLatest(GET_CONTACT.FETCH, params => apiSagaFunction(params.payload, activityAction, GET_CONTACT, { timeout })),
  takeLatest(POST_CONTACT.FETCH, params => apiSagaFunction(params.payload, activityAction, POST_CONTACT, { timeout })),
  takeLatest(FEEDBACK_POINT.FETCH, params => apiSagaFunction(params.payload, activityAction, FEEDBACK_POINT, { timeout: 5000 })),
  takeLatest(GET_POINT_INDIVIDU.FETCH, params => apiSagaFunction(params.payload, activityAction, GET_POINT_INDIVIDU, { timeout })),
  takeLatest(GET_CONVERTION_INDIVIDU.FETCH, params => apiSagaFunction(params.payload, activityAction, GET_CONVERTION_INDIVIDU, { timeout, resAttribute: 'data' })),
  takeLatest(GET_HISTORY_INDIVIDU.FETCH, params => apiSagaFunction(params.payload, activityAction, GET_HISTORY_INDIVIDU, { timeout, resAttribute: 'data' })),

  apiTakeLatest(ADD_FEEDBACK_AM),
  apiTakeLatest(PROSPECT_DETAIL, { timeout: 8000, resAttribute: 'data' }),
  apiTakeLatest(FEEDBACK_POINT, { resAttribute: 'body' }),
  apiTakeLatest(INPUT_FEEDBACK_LIST, { resAttribute: 'data' }),
  apiTakeLatest(AM_DASHBOARD, { timeout: 30000, resAttribute: 'data' }),
  apiTakeLatest(AM_CALENDAR_DATA, { resAttribute: 'data' }),
];
