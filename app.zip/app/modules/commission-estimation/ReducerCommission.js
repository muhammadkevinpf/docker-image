import { requestStatus } from '../../utilities/ApiConnection';
import { RESET_ALL_STATE } from '../dashboard/ConfigDashboard';
import { COMMISSION_ESTIMATION } from './ConfigCommission';
import { isEmpty } from '../../utilities';

const initialState = {
  data: {},
  status: requestStatus.IDLE,
  error: null,
  send: null,
};

export function ReducerCommissionEstimation(state = initialState, action) {
  switch (action.type) {
    case RESET_ALL_STATE: return initialState;

    case COMMISSION_ESTIMATION.FETCH: return { ...state, status: requestStatus.FETCH, send: action.payload };
    case COMMISSION_ESTIMATION.FAILED: return { ...state, status: requestStatus.FAILED, error: action.payload };
    case COMMISSION_ESTIMATION.SUCCESS: {
      let idr = 0;
      let usd = 0;
      if (!isEmpty(action.payload)) {
        const { GROSSCOMM, TOTCOMM } = action.payload;
        if (!isEmpty(GROSSCOMM) && !isEmpty(TOTCOMM)) {
          const comissionDot = '.';
          const insertPosition = 15;
          const GROSSCOMM2 = [GROSSCOMM.slice(0, insertPosition), comissionDot, GROSSCOMM.slice(insertPosition)].join('');
          const TOTCOMM2 = [TOTCOMM.slice(0, insertPosition), comissionDot, TOTCOMM.slice(insertPosition)].join('');
          idr = GROSSCOMM2.endsWith('+') ? GROSSCOMM2.substring(0, 18) : -(GROSSCOMM2.substring(0, 18));
          usd = TOTCOMM2.endsWith('+') ? TOTCOMM2.substring(0, 18) : -TOTCOMM2.substring(0, 18);
        }
      }
      return {
        ...state,
        status: requestStatus.SUCCESS,
        data: { idr, usd },
      };
    }

    default: return state;
  }
}
