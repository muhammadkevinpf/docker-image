import MainCommissionEstimation from './main-commission-estimation';

export default {
  MainCommissionEstimation,
};
