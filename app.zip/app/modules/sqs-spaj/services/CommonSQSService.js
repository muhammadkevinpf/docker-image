/* eslint-disable import/no-cycle */
/* eslint-disable no-console */
/* eslint-disable guard-for-in */
/* eslint-disable no-restricted-syntax */
// import Analytics from 'appcenter-analytics';
import NewQuotationStorageService from './NewQuotationStorageService';
import NewSPAJStorageService from './NewSPAJStorageService';

// const serviceName = 'CommonSQSService';

const upsertSQSLocalDB = async (pruSmartDB, sqsData, agentCode, lastState, coStatus, quotationCode) => new Promise(async (resolve, reject) => {
  try {
    // save to NewQuotationStorage
    const { sqs } = sqsData;
    const param = {
      agentCode,
      data: sqsData,
      quotationCode,
    };
    const resultNewQuotation = await NewQuotationStorageService.upsert(pruSmartDB, param);
    console.log(resultNewQuotation);
    if (coStatus !== '') {
      const paramNewSPAJStorage = {
        agentCode,
        spajCode: sqs.proposalCode,
      };
      let resultNewSPAJStorageGet = await NewSPAJStorageService.getByCode(pruSmartDB, paramNewSPAJStorage);
      if (resultNewSPAJStorageGet === 0) {
        resultNewSPAJStorageGet = {};
        resultNewSPAJStorageGet = JSON.parse(JSON.stringify(sqsData));
        if (resultNewSPAJStorageGet.sqs.policy === undefined) {
          resultNewSPAJStorageGet.sqs.policy = {};
        }
        resultNewSPAJStorageGet.sqs.policy.lastState = lastState;
      }

      const paramNewSPAJStorageAdd = {
        agentCode,
        data: resultNewSPAJStorageGet,
        spajCode: sqs.proposalCd,
      };
      const resultNewSPAJStorageAdd = await NewSPAJStorageService.upsert(pruSmartDB, paramNewSPAJStorageAdd);
      console.log(resultNewSPAJStorageAdd);
    }
    resolve('oke');
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(error);
  }
});

const getQueueId = (quotId) => {
  const id = `Queue${quotId}`;
  return id;
};

const distinctCustomer = (data) => {
  const unique = {};
  const distinct = [];
  for (let i = 0; i < data.length; i += 1) {
    unique[data[i].customerId] = data[i];
  }

  for (const key in unique) {
    distinct.push(unique[key]);
  }

  return distinct;
};

const isEmpty = (obj) => {
  // null and undefined are "empty"
  if (obj === null) return true;
  if (obj === undefined) return true;

  // Assume if it has a length property with a non-zero value
  // that that property is correct.
  if (obj.constructor === Array) {
    if (obj.length > 0) return false;
    if (obj.length === 0) return true;
  } else {
    if (obj > 0) return false;
    if (obj === 0) return true;
  }

  // If it isn't an object at this point
  // it is empty, but it can't be anything *but* empty
  // Is it empty?  Depends on your application.
  if (typeof obj !== 'object') return true;

  // Otherwise, does it have any properties of its own?
  // Note that this doesn't handle
  // toString and valueOf enumeration bugs in IE < 9
  for (const key in obj) {
    if (hasOwnProperty.call(obj, key)) return false;
  }

  return true;
};

export default {
  upsertSQSLocalDB,
  getQueueId,
  distinctCustomer,
  isEmpty,
};
