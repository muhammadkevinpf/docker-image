/* eslint-disable react/jsx-indent */
/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { View, Text, Image } from 'react-native';
import PropTypes from 'prop-types';
import Style from '../../styles';

class CarouselCard extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  render() {
    return (
      <TouchableOpacity
        activeOpacity={this.props.activeOpacity || 1}
        onPress={this.props.onPress}
        style={[Style.Main.justifySpaceBetween, this.props.containerStyle]}
      >
        <View style={[Style.Main.container]}>
          {(this.props.imageSource && this.props.imageSource !== '')
            ? <Image
                source={this.props.imageSource}
                style={[this.props.imageStyle]}
            />
            : null
          }
          {(this.props.upperContent !== null
            ? <View style={[this.props.upperContentStyle]}>
              {this.props.upperContent}
              </View>
            : null
          )}
          {(this.props.title !== '')
            ? <Text numberOfLines={this.props.titleNumberOfLines} style={[Style.Main.fullWidth, Style.Main.mt12, this.props.titleStyle]}>
              {this.props.title}
              </Text>
            : null
          }
          {(this.props.content !== null
            ? <View style={[this.props.contentStyle]}>
              {this.props.content}
              </View>
            : null
          )}
        </View>
        {this.props.buttonText !== '' &&
          <View style={[Style.Main.backgroundWhite, Style.Main.borderRadius8]}>
            <Text style={[Style.Main.mb12, this.props.buttonStyle]}>{this.props.buttonText}</Text>
          </View>
        }
      </TouchableOpacity>
    );
  }
}

CarouselCard.propTypes = {
  contentStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  containerStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  imageStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  imageSource: PropTypes.oneOfType([PropTypes.string, PropTypes.number, PropTypes.object]),
  title: PropTypes.string,
  titleStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  buttonText: PropTypes.string,
  buttonStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  content: PropTypes.element,
  upperContent: PropTypes.element,
  onPress: PropTypes.func,
  titleNumberOfLines: PropTypes.number,
};

CarouselCard.defaultProps = {
  contentStyle: {},
  containerStyle: {},
  imageStyle: {},
  imageSource: '',
  title: '',
  titleStyle: {},
  buttonText: '',
  buttonStyle: {},
  content: null,
  upperContent: null,
  onPress: () => { },
  titleNumberOfLines: 2,
};

export default CarouselCard;
