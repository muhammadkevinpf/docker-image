// Please change this values based on API References

export const newsType = {
  ANNOUNCEMENT: 6,
  TRAINING: 3, // unchecked
  ARTICLE: 2, // unchecked
  CONTEST: 1,
  REGULATION: 4, // unchecked
  AWARDS: 5,
};

export const newsTypeLabel = {
  ANNOUNCEMENT: 'ANNOUNCEMENT',
  TRAINING: 'TRAINING',
  ARTICLE: 'ARTICLE',
  CONTEST: 'CONTEST',
  REGULATION: 'REGULATION',
  AWARDS: 'AWARDS',
};

export const newsSortOption = [ // checked
  { value: 'publishDateAsc', label: 'Tanggal Publish ASC' },
  { value: 'publishDateDesc', label: 'Tanggal Publish DESC' },
  { value: 'subjectAsc', label: 'Judul ASC' },
  { value: 'subjectDesc', label: 'Judul DESC' },
];

export const newsFilterOption = [
  { value: `${newsType.ANNOUNCEMENT}`, label: newsTypeLabel.ANNOUNCEMENT }, // checked
  { value: `${newsType.AWARDS}`, label: newsTypeLabel.AWARDS }, // checked
  { value: `${newsType.TRAINING}`, label: newsTypeLabel.TRAINING },
  { value: `${newsType.ARTICLE}`, label: newsTypeLabel.ARTICLE },
  { value: `${newsType.CONTEST}`, label: newsTypeLabel.CONTEST }, // checked
  { value: `${newsType.REGULATION}`, label: newsTypeLabel.REGULATION },
];

export const NEWS_LIST_API = 'adapters/HTTPAdapterNewsUpdate/newsListMobile';
export const NEWS_LIST_FETCH = 'NEWS_LIST_FETCH';
export const NEWS_LIST_SUCCESS = 'NEWS_LIST_SUCCESS';
export const NEWS_LIST_FAILED = 'NEWS_LIST_FAILED';
export const NEWS_LIST_RESET = 'NEWS_LIST_RESET';

export const NEWS_DETAIL_API = 'adapters/HTTPAdapterNewsUpdate/getDetailNewsById';
export const NEWS_DETAIL_FETCH = 'NEWS_DETAIL_FETCH';
export const NEWS_DETAIL_SUCCESS = 'NEWS_DETAIL_SUCCESS';
export const NEWS_DETAIL_FAILED = 'NEWS_DETAIL_FAILED';
export const NEWS_DETAIL_RESET = 'NEWS_DETAIL_RESET';

export const FILE_BASE_64_API = 'adapters/HTTPAdapterNewsUpdate/getFileBase64';
export const FILE_BASE_64_FETCH = 'FILE_BASE_64_FETCH';
export const FILE_BASE_64_SUCCESS = 'FILE_BASE_64_SUCCESS';
export const FILE_BASE_64_FAILED = 'FILE_BASE_64_FAILED';
export const FILE_BASE_64_RESET = 'FILE_BASE_64_RESET';
