import axios from 'axios';

export const ApiRequestStatus = {
  IDLE: 'IDLE',
  LOADING: 'LOADING',
  SUCCEEDED: 'SUCCEEDED',
  FAILED: 'FAILED',
};

function startedApiAction(type) {
  return { type, status: ApiRequestStatus.LOADING };
}

function succeededApiAction(type) {
  return { type, status: ApiRequestStatus.SUCCEEDED };
}

function failedApiAction(type) {
  return { type, status: ApiRequestStatus.SUCCEEDED };
}

function callApi(type, config) {
  return async (dispatch) => {
    dispatch(startedApiAction(type));
    try {
      const payload = await axios(config);
      dispatch(succeededApiAction(type, payload.data));
    } catch (err) {
      dispatch(failedApiAction(type, err));
    }
  };
}

export default {
  callApi,
};
