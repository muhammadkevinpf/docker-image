/* eslint-disable no-console */
/* eslint-disable react/no-array-index-key */
/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import {
  Image, ActivityIndicator,
} from 'react-native';
import { View, Text } from 'native-base';
// import Swiper from 'react-native-web-swiper';
import Swiper from 'react-native-swiper';
import { connect } from 'react-redux';
import { newsListReset } from '../../news-and-update/ActionNews';
import { requestStatus } from '../../../utilities';
import {
  campaignBannerFetch, firstCampaignFetch, secondCampaignFetch, thirdCampaignFetch,
} from '../ActionDashboard';
import {
  CAMPAIGN_BANNER_FETCH, FIRST_CAMPAIGN_FETCH, SECOND_CAMPAIGN_FETCH, THIRD_CAMPAIGN_FETCH,
} from '../ConfigDashboard';
import { iconEmptyImage } from '../../../assets/images';
import Style from '../../../styles';
import _ from '../../../lang';

class CampaignBanner extends Component {
  cardStyle = [Style.Main.cardShadow, Style.Main.container, Style.Main.mV10, Style.Main.mr12,
    Style.Main.ml12, Style.Main.alignContentCenter, Style.Main.justifyCenter, Style.Main.swiperHeight, this.props.style];

  constructor(props) {
    super(props);
    this.state = {
      timePassed: false,
    };
  }

  componentDidMount() {
    if (this.shoudFetch()) this.getCampaignBanner();

    setTimeout(() => { this.setState({ timePassed: true }); }, 1000);
  }

  componentDidUpdate = (prevProps) => {
    if (this.props.resAuth && this.props.resAuth.userProfile && this.shoudFetch() && (this.props.resAuth !== prevProps.resAuth
      || (this.props.isOnline !== prevProps.isOnline && this.props.isOnline && !this.props.dashboard.campaignList.length))) {
      this.getCampaignBanner();
    }
    if (this.props.dashboard.campaignList.length && !this.props.dashboard.campaignImages.length && this.props.isOnline &&
      (this.props.isOnline !== prevProps.isOnline || (this.props.dashboard.campaignListStatus !== prevProps.dashboard.campaignListStatus &&
        this.props.dashboard.campaignListStatus === requestStatus.SUCCESS))) {
      this.props.dashboard.campaignList.map((item, i) => this.getCampaignImage(item, i));
    }
  }

  // shoudFetch = () => isDataOutdated(this.props.lastFetch)
  shoudFetch = () => true

  getCampaignBanner = () => {
    if (this.props.resAuth && this.props.resAuth.userProfile && this.props.isOnline) {
      const { resAuth } = this.props;
      const data = {
        headers: [
          {
            keyHeader: 'X-CSRF-Token',
            valueHeader: `Bearer ${this.props.resAuth.access_token}`,
          },
          {
            keyHeader: 'X-Requested-Url',
            // valueHeader: '/resource/campaign/getDataBannerCampaign',
            valueHeader: '/corp/getBannerListPriority',
          },
        ],
        // eslint-disable-next-line max-len
        params: `["${resAuth.username}", "${resAuth.userProfile.agentCode}", "${resAuth.agent_channelType}"]`,
      };
      this.props.getCampaignList(data);
    }
  }

  getCampaignImage = (item, i) => {
    if (this.props.resAuth !== null && this.props.resAuth.userProfile !== undefined) {
      const data = {
        headers: [
          {
            keyHeader: 'X-CSRF-Token',
            valueHeader: `Bearer ${this.props.resAuth.access_token}`,
          },
        ],
        params: `["${item.imageName.split('|')[1]}", "corporatebanner"]`,
      };
      if (i === 0) return this.props.getFirstCampaign(data);
      if (i === 1) return this.props.getSecondCampaign(data);
      return this.props.getThirdCampaign(data);
    }
    return {};
  }

  renderLoadingData = () => (
    <View style={this.cardStyle}>
      <ActivityIndicator color="red" size="large" style={[Style.Main.alignCenter]} />
    </View>
  )

  renderFailedData = () => (
    <View style={this.cardStyle}>
      <Image source={iconEmptyImage} style={[Style.Main.height85, Style.Main.alignCenter]} resizeMode="contain" />
      <Text style={[Style.Main.fontAlbert11, Style.Main.alignCenter, Style.Main.mt15]}>{_('Gagal Mengambil Data')}</Text>
    </View>
  )

  render() {
    const {
      campaignImages, campaignListStatus, firstCampaignStatus, secondCampaignStatus, thirdCampaignStatus,
    } = this.props.dashboard;
    const reverseCampaign = campaignImages;
    const showImage = (this.props.isOnline && this.state.timePassed) || !this.props.isOnline;
    // const reverseCampaign = campaignImages && campaignImages.length > 0 ? campaignImages.reverse() : campaignImages;
    if (!reverseCampaign || (reverseCampaign.length < 1
      && (campaignListStatus === requestStatus.FETCH || firstCampaignStatus === requestStatus.FETCH
        || secondCampaignStatus === requestStatus.FETCH || thirdCampaignStatus === requestStatus.FETCH
      ))
    ) return this.renderLoadingData();
    if (reverseCampaign && reverseCampaign.length > 0) {
      return (
        <View style={[Style.Main.fullWidth, Style.Main.swiperHeight, Style.Main.mV10, this.props.style]}>
          <Swiper
            loop
            autoplay
            activeDotColor="red"
            autoplayTimeout={6}
            showsPagination={showImage}
          >
            {
              reverseCampaign.map((image, i) => (
                <View
                  style={[Style.Main.radius8, Style.Main.my5, Style.Main.mr12,
                    Style.Main.ml12, Style.Main.cardShadow]}
                  key={i}
                >
                  {
                    showImage && (
                      <Image
                        source={{ uri: `data:image/jpeg;base64,${image}` }}
                        style={[Style.Main.fullWidth, Style.Main.swiperImage, Style.Main.fullHeight]}
                      />
                    )
                  }
                </View>
              ))
            }
          </Swiper>
        </View>
      );
    }
    return this.renderFailedData();
  }
}

const mapStateToProps = state => ({
  resAuth: state.auth.res,
  action: state.auth.action,
  dashboard: state.dashboard,
  isOnline: state.connectionStatus.isOnline,
  lastFetch: state.dashboard.lastFetchCampaign,
});

const mapDispatchToProps = dispatch => ({
  resetNewsList: () => dispatch(newsListReset()),
  getCampaignList: value => dispatch(campaignBannerFetch(CAMPAIGN_BANNER_FETCH, value)),
  getFirstCampaign: value => dispatch(firstCampaignFetch(FIRST_CAMPAIGN_FETCH, value)),
  getSecondCampaign: value => dispatch(secondCampaignFetch(SECOND_CAMPAIGN_FETCH, value)),
  getThirdCampaign: value => dispatch(thirdCampaignFetch(THIRD_CAMPAIGN_FETCH, value)),
});

export default connect(mapStateToProps, mapDispatchToProps)(CampaignBanner);
