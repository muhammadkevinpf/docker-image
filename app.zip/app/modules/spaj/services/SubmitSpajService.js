/* eslint-disable import/no-cycle */
/* eslint-disable max-len */
/* eslint-disable no-console */
import JSZip from 'jszip';
import Axios from 'axios';
import { WLClient } from 'react-native-ibm-mobilefirst';
import { Platform } from 'react-native';
import { getVersion, getModel } from 'react-native-device-info';
import { trackEvent } from 'appcenter-analytics';
import { ApiRequestStatus } from './RestClientService';
import MappingService from './MappingService';
import MagnumService from './MagnumService';
import { componentCodeUuid } from '../views/magnum-medical-data/mappers/newMappers';
import { version } from '../../../../package.json';
import ContentStorageService from '../../sqs-spaj/services/ContentStorageService';
import Caches from '../../../utilities/Caches';

const templateSqsCO = {
  doc: [],
  data: {
    product_code: '',
    product_type: '',
    desc_product: '',
    prod_prefix: '',
    coverage: [],
    substandard: [],
    refund: {
      bank_name: '',
      bank_branch: '',
      bank_account: '',
      currency: '',
      name: '',
    },
    period_plan: '',
    total_prem: '',
  },
  prop_no: '',
  agent_code: '',
  fund: [
    {
      type_fund: '',
      type: '',
      desc_fund: '',
      percent: '',
    },
  ],
  fundTopup: [],
  back_date: '',
  timestamp: '',
  sign: [
    {
      loc: '',
      date: '',
      role: '',
      value: '',
      name: '',
    },
  ],
  budget: '',
  budgetTerm: '',
  isFundRp: true,
  fixVersion: '',
  countPdf: 0,
};

const magnumRemapping = (redux, agentCode, counterOffer, sqsCO) => new Promise(async (resolve, reject) => {
  try {
    let caseId = redux.sqs.sqs.proposalCd;
    if (counterOffer && !sqsCO) {
      caseId = redux.policy.originProposalCd;
    }
    let magnum = {};
    let isSIOFullUW = false;
    if (!redux.policy.isInputManual) {
      magnum = await MagnumService.getMagnumSubmitData(caseId, agentCode);
      // inject data salary to magnum
      console.log('before inject', magnum);
      for (let i = 0; i < redux.client.lifeAss.length; i += 1) {
        const client = redux.client.lifeAss[i];
        const salary = client.income[0].type === 'monthly' ? Number(client.income[0].amount || 0) * 12 : Number(client.income[0].amount || 0);
        const magnumAnnualIncome = magnum.bootstrap.attributes.find(attribute => attribute.attribute === `case.life[${i}].Financial.AnnualIncome`);
        const magnumAnnualIncomeWF = magnum.wf.dataPackages[0].attributes.find(attribute => attribute.attribute === `case.life[${i}].Financial.AnnualIncome`);
        const prefix = magnumAnnualIncome ? i : `extID=${i}`;
        const prefixWF = magnumAnnualIncomeWF ? i : `extID=${i}`;
        magnum.bootstrap.attributes.find(attribute => attribute.attribute === `case.life[${prefix}].Financial.AnnualIncome`).valueAsString = salary.toString();
        magnum.wf.dataPackages[0].attributes.find(attribute => attribute.attribute === `case.life[${prefixWF}].Financial.AnnualIncome`).value.decimalValue = salary;
      }
      const payorAnnualIncome = redux.policy.payor.income[0].type === 'monthly' ? (Number(redux.policy.payor.income[0].amount || 0) * 12).toString() : Number(redux.policy.payor.income[0].amount || 0);
      magnum.bootstrap.attributes.find(attribute => attribute.attribute === 'case.PayorAnnualIncome').valueAsString = payorAnnualIncome.toString();
      magnum.wf.dataPackages[0].attributes.find(attribute => attribute.attribute === 'case.PayorAnnualIncome').value.decimalValue = payorAnnualIncome;
      console.log('after inject', magnum);
      // inject data salary to magnum

      // switch SIO to FullUW
      console.log('temp_field_9 before', redux.flag.find(x => x.bo_mapping.includes('temp_field_9')));
      const quickQuote = redux.sqs.sqs.quickQuote.find(x => x.isMainQuotation);
      const magnumSIO = componentCodeUuid[quickQuote.mainCoverage.GIO] ? componentCodeUuid[quickQuote.mainCoverage.GIO].type === 'SIO' : false;
      const magnumGIO = componentCodeUuid[quickQuote.mainCoverage.GIO] ? componentCodeUuid[quickQuote.mainCoverage.GIO].type === 'GIO' : false;
      if (quickQuote.mainCoverage.main === 'E2ER') {
        for (let i = 0; i < redux.client.lifeAss.length; i += 1) {
          const client = redux.client.lifeAss[i];
          const { height } = redux.policy.uw_questionnaire.bmiheight.find(x => x.role === client.role);
          const { weight } = redux.policy.uw_questionnaire.bmiweight.find(x => x.role === client.role);
          client.bmiHeight = `${height} cm`;
          client.bmiWeight = `${weight} kg`;
        }
      }
      if (magnumGIO || magnumSIO) {
        if (magnum.hpx.LifeList.some(x => x.Forms.length > 1)) {
          if (redux.flag.find(x => x.bo_mapping.includes('temp_field_9'))) {
            const tempField9Index = redux.flag.findIndex(x => x.bo_mapping.includes('temp_field_9'));
            // eslint-disable-next-line no-param-reassign
            redux.flag[tempField9Index] = {
              desc: 'Full UW',
              value: 'N',
              bo_mapping: 'temp_field_9',
            };
          }
          if (magnumSIO) {
            isSIOFullUW = true; // open this code when pruhub ready for using the latest magnum,
          }
          for (let i = 0; i < redux.client.lifeAss.length; i += 1) {
            const client = redux.client.lifeAss[i];
            delete client.bmiHeight;
            delete client.bmiWeight;
          }
        } else {
          for (let i = 0; i < redux.client.lifeAss.length; i += 1) {
            const client = redux.client.lifeAss[i];
            const { height } = redux.policy.uw_questionnaire.bmiheight.find(x => x.role === client.role);
            const { weight } = redux.policy.uw_questionnaire.bmiweight.find(x => x.role === client.role);
            client.bmiHeight = `${height} cm`;
            client.bmiWeight = `${weight} kg`;
          }
        }
      }
      console.log('temp_field_9 after', redux.flag.find(x => x.bo_mapping.includes('temp_field_9')));
    }
    // switch SIO to FullUW
    resolve({ magnum, isSIOFullUW });
  } catch (error) {
    trackEvent('[SUBMISSION]', { error: `${redux.policy.prop_no}_999_${error.message}_magnumRemapping` });
    reject(error);
  }
});

const reformSpaj = (redux, userProfile, counterOffer, sqsCO, outputCO) => new Promise(async (resolve, reject) => {
  try {
    const { magnum, isSIOFullUW } = await magnumRemapping(redux, userProfile.agentCode, counterOffer, sqsCO);
    const { sqs, sqsPdf, sqsReport } = await MappingService.mapping(redux, userProfile.agentCode, userProfile.clientName, isSIOFullUW, counterOffer, sqsCO, outputCO);
    console.log('hasil mappingan sqs: ', { sqs, sqsPdf, sqsReport });

    if (sqsPdf.some(x => !x)) {
      trackEvent('[SUBMISSION]', { error: `${redux.policy.prop_no}_999_Reforming Spaj Error: some of sqsPdf is null` });
      reject(new Error('Reforming Spaj Error: some of sqsPdf is null'));
      return;
    }

    let base64 = '';
    const spaj = redux;
    spaj.magnum = magnum;
    spaj.sqs = sqs;
    spaj.sqsReport = sqsReport;
    spaj.sqsPdf = counterOffer ? [] : sqsPdf;
    spaj.jsonVer = `Platform: ${Platform.OS}_${getModel()} | App: ${getVersion()} | DB: ${Caches.get('dbVersion').version} | Code: ${version}`;
    console.log('hasil mappingan spaj: ', spaj);
    const data = JSON.stringify(spaj);
    if (!counterOffer) {
      const zip = new JSZip();
      zip.file('data.txt', data);
      await zip.generateAsync({ type: 'base64' }).then((content) => {
        base64 = content;
      });
      const apiBody = {
        stringBase64: base64,
        propNo: redux.policy.prop_no !== '' ? redux.policy.prop_no : '',
      };
      resolve(apiBody);
    } else {
      console.log('payloadCO:', data);
      resolve(data);
    }
  } catch (err) {
    trackEvent('[SUBMISSION]', { error: `${redux.policy.prop_no}_999_${err.message}` });
    reject(new Error('Reforming Spaj Error: ', err));
  }
});

const uploadNonf2fVideo = async (spajPolicy, token, actions, { onProgress, onSuccess, onFailed }) => {
  try {
    const serverUrl = await WLClient.getServerUrl();
    const docVid = await ContentStorageService.getByCode(global.database.pruSmart, spajPolicy.proposalCd);
    const config = {
      method: 'POST',
      data: {
        stringBase64: docVid,
        propNo: spajPolicy.prop_no,
      },
      url: `${serverUrl}/adapters/HTTPAdapterCommonJavaPDNF2F/resource/uploadVideo`,
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': `Bearer ${token}`,
      },
      timeout: 10000,
      onUploadProgress: onProgress,
    };
    Axios.defaults.timeout = setTimeout || 10000;
    const res = await Axios(config);
    if (res.data.responseCode === '00') { actions(ApiRequestStatus.SUCCEEDED, res.data.responseMessage); return onSuccess(); }
    actions(ApiRequestStatus.FAILED, res.data.responseMessage, res.data.responseCode); return onFailed();
  } catch (err) { actions(ApiRequestStatus.FAILED, err.message, '999'); return onFailed(); }
};

const submitSpaj = async (payload, token, actions/* , isNonF2F */) => {
  actions(ApiRequestStatus.LOADING);
  const serverUrl = await WLClient.getServerUrl();
  const config = {
    method: 'POST',
    data: payload,
    // url: `${serverUrl}${isNonF2F ? '/adapters/HTTPAdapterCommonJavaPDNF2F/resource/upload' : '/adapters/HTTPAdapterCommonJavaPD/resource/upload'}`,
    url: `${serverUrl}/adapters/HTTPAdapterCommonJavaPDNF2F/resource/upload`,
    headers: {
      'Content-Type': 'application/json',
      'X-CSRF-Token': `Bearer ${token}`,
    },
    timeout,
  };
  try {
    Axios.defaults.timeout = timeout;
    const startCount = new Date().getTime();
    const res = await Axios(config);
    const finishCount = (new Date().getTime() - startCount);
    trackEvent('[SUBMIT_TIME]', { count: `${payload.propNo}_${finishCount}ms` });
    if (res.data.responseCode === '00') actions(ApiRequestStatus.SUCCEEDED, res.data);
    else {
      trackEvent('[SUBMISSION]', { error: `${payload.propNo}_${res.data.responseCode}_${res.data.responseMessage}` });
      actions(ApiRequestStatus.FAILED, res.data.responseMessage, res.data.responseCode);
    }
  } catch (err) {
    trackEvent('[SUBMISSION]', { error: `${payload.propNo}_999_${err.message}` });
    actions(ApiRequestStatus.FAILED, err.message, '999');
  }
};

const submitCounterOffer = async (payload, token, actions /* , isNonF2F */) => {
  actions(ApiRequestStatus.LOADING);
  const serverUrl = await WLClient.getServerUrl();
  const config = {
    method: 'POST',
    data: payload,
    // url: `${serverUrl}${isNonF2F ? '/adapters/HTTPAdapterCommonJavaPDNF2F/resource/upload' : '/adapters/HTTPAdapterCommonJavaPD/resource/upload'}`,
    url: `${serverUrl}/adapters/HTTPAdapterCommonJavaPDNF2F/resource/submitCounterOffer`,
    headers: {
      'Content-Type': 'application/json',
      'X-CSRF-Token': `Bearer ${token}`,
    },
    timeout,
  };
  try {
    Axios.defaults.timeout = timeout;
    const startCount = new Date().getTime();
    const res = await Axios(config);
    const finishCount = (new Date().getTime() - startCount);
    trackEvent('[SUBMIT_TIME]', { count: `${payload.propNo}_${finishCount}ms` });
    if (res.data.responseCode === '00') actions(ApiRequestStatus.SUCCEEDED, res.data);
    else {
      trackEvent('[SUBMISSION_CO]', { error: `${payload.propNo}_${res.data.responseCode}_${res.data.responseMessage}` });
      actions(ApiRequestStatus.FAILED, res.data.responseMessage, res.data.responseCode);
    }
  } catch (err) {
    trackEvent('[SUBMISSION_CO]', { error: `${payload.propNo}_999_${err.message}` });
    actions(ApiRequestStatus.FAILED, err.message, '999');
  }
};

const reformCounterOffer = (redux, userProfile, counterOffer, sqsCO, outputCO) => new Promise(async (resolve, reject) => {
  try {
    // const { magnum, isSIOFullUW } = await magnumRemapping(redux, userProfile.agentCode, counterOffer, sqsCO);
    const spaj = redux;
    if (sqsCO && outputCO) {
      const mapping = await MappingService.mapping(redux, userProfile.agentCode, userProfile.clientName, false, counterOffer, sqsCO, outputCO);
      if (mapping.sqsPdf.some(x => !x)) {
        reject(new Error('Reforming Spaj Error: some of sqsPdf is null'));
        return;
      }
      spaj.sqs = mapping.sqs;
      spaj.sqsReport = mapping.sqsReport;
      spaj.sqsPdf = mapping.sqsPdf;
    } else {
      spaj.sqs = templateSqsCO;
      spaj.sqsReport = {};
      spaj.sqsPdf = [];
    }
    spaj.magnum = null;
    if (spaj.amend.flag_loosemail === 'Y') {
      spaj.amend.sign = spaj.policy.sign;
    }
    // if (!redux.policy.isInputManual) {
    //   spaj.magnum = magnum;
    // } else {
    // }
    spaj.jsonVer = `Platform: ${Platform.OS}_${getModel()} | App: ${getVersion()} | DB: ${Caches.get('dbVersion').version} | Code: ${version}`;
    console.log('hasil mappingan spaj: ', spaj);
    const data = JSON.stringify(spaj);
    console.log('payloadCO:', data);
    resolve(data);
  } catch (err) {
    reject(new Error('Reforming Spaj Error: ', err));
  }
});

const timeout = 25000;

export default {
  reformSpaj,
  submitSpaj,
  uploadNonf2fVideo,
  submitCounterOffer,
  reformCounterOffer,
};
