import moment from 'moment';
// import Analytics from 'appcenter-analytics';
import SQLiteUtils from '../../../utilities/SQLiteUtils';
import Database from '../../../config/Database';
import ApiService from './ApiService';
import { ConfigProduct } from '../config';
import { saveLog, CONSTANT } from '../../../utilities/Logger';

/**
 * API SERVICE
 */

const { migrates } = Database.pruSmart.tables;

const querySelect = `SELECT * FROM ${migrates.name} WHERE agentCode = ? AND method = ?`;
const queryInsert = `INSERT INTO ${migrates.name} ${migrates.column} VALUES (?, ?, ?, ?)`;
const queryUpdate = `UPDATE ${migrates.name} SET date = ?, updatedDate = ? WHERE method = ? AND agentCode = ?`;
const queryDelete = `DELETE FROM ${migrates.name} WHERE agentCode = ? AND method = ?`;
const serviceName = 'SyncService';

const postDataToAPI = request => new Promise(async (resolve, reject) => {
  try {
    const responseApi = await ApiService.requestToApi(request);
    console.log(responseApi);
    saveLog(CONSTANT.DEBUG, `error sync nih ${JSON.stringify(responseApi)}`);
    resolve(responseApi);
  } catch (error) {
    // Analytics.trackEvent(serviceName, JSON.stringify(error));
    console.log(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const getLastCheckedDate = agentCode => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(global.database.pruSmart, querySelect, [agentCode, migrates.method]);
    if (res.rows.length > 0) {
      resolve(res.rows.item(0).date);
    } else {
      resolve(ConfigProduct.oldDate);
    }
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const upsert = (agentCode, date) => new Promise(async (resolve, reject) => {
  try {
    let queryToProcess = queryInsert;
    let param = [migrates.method, agentCode, date, moment().format('DD/MM/YYYY HH:mm')];
    const check = await SQLiteUtils.executeQuery(global.database.pruSmart, querySelect, [agentCode, migrates.method]);
    if (check.rows.length > 0) {
      queryToProcess = queryUpdate;
      param = [date, moment().format('DD/MM/YYYY HH:mm'), migrates.method, agentCode];
    }
    const res = await SQLiteUtils.executeTransaction(global.database.pruSmart, queryToProcess, param);
    resolve(`res upsert migrates ${res}`);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const remove = agentCode => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeTransaction(global.database.pruSmart, queryDelete, [agentCode, migrates.method]);
    resolve(`res delete migrates ${res}`);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});


export default {
  postDataToAPI,
  getLastCheckedDate,
  upsert,
  remove,
};
