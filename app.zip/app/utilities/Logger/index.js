import DeviceInfo from 'react-native-device-info';
import { Alert, Platform } from 'react-native';
import RNFB from 'rn-fetch-blob';
import Share from 'react-native-share';
import uuid from 'uuid';
import moment from 'moment';
import SQLite from '../SQLiteUtils';
import { check, checkAndRequest, STORAGE_PERMISSIONS } from '../Permission';
import _ from '../../lang';
import Database from '../../config/Database';
import { resourceRequest } from '../StoreApi';
import { adapter } from '../../config';

const { log } = Database.log.tables;

/**
 * @param level: define for log level (ERROR, INFO, DEBUG, WARNING) if empty get all level
 * @param date: define for timestamp with getTime() method, default 1991-01-01 (under Construction)
 */
const getLogRecords = (
  level = '',
  // date = new Date('1990-01-01').getTime(),
) => new Promise(async (resolve, reject) => {
  try {
    const result = [];
    const queryResult = await SQLite.executeQuery(
      global.database.log,
      `SELECT * FROM ${log.name} WHERE (level = ? OR ? = "") AND processed = "false"`,
      [level, level],
    );
    for (let i = 0; i < queryResult.rows.length; i += 1) {
      result.push(queryResult.rows.item(i));
    }
    resolve(result);
  } catch (error) {
    reject(error);
  }
});

/**
 * @param level: define for log level (ERROR, INFO, DEBUG, WARNING) default ERROR
 * @param message: message for log, if object it will be stringify
 */
const saveLog = (level = CONSTANT.ERROR, message = '') => new Promise(async (resolve, reject) => {
  try {
    const stringifyMessage = message instanceof Object ? JSON.stringify(message) : message;
    const { getModel, getSystemName, getSystemVersion } = DeviceInfo;
    await SQLite.executeTransaction(
      global.database.log,
      // eslint-disable-next-line max-len
      `INSERT INTO ${log.name} (ID, level, model, os, os_version, timestamp, message, processed, processedDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        uuid.v4(),
        level, getModel(),
        getSystemName(),
        getSystemVersion(),
        moment(new Date()).format('YYYY-MM-DD HH:mm:ss'),
        stringifyMessage,
        'false',
        null,
      ],
    );
    resolve('INSERT SUCCEED');
  } catch (error) {
    reject(error);
  }
});

/**
 * Get log data from DB and mapping the data as base64
 */
const createLogData = () => new Promise(async (resolve, reject) => {
  try {
    const appLog = await getLogRecords();
    if (!appLog.length) {
      reject(new Error('No Data'));
      return;
    }
    const datas = appLog.map((x) => {
      const dataToWrite = `${x.timestamp}|${x.level}|${x.message}`;
      return dataToWrite;
    });
    const IDs = appLog.map(x => x.ID);
    resolve({ datas, IDs });
  } catch (error) {
    reject(error);
  }
});

/**
 * create log file
 */
const createLogFile = () => new Promise(async (resolve, reject) => {
  try {
    await checkAndRequest(STORAGE_PERMISSIONS[0]);
    await checkAndRequest(STORAGE_PERMISSIONS[1]);
    const checkRead = await check(STORAGE_PERMISSIONS[0]);
    const checkWrite = await check(STORAGE_PERMISSIONS[1]);
    if (!checkRead || !checkWrite) {
      Alert.alert(_('Warning'), _('Download file gagal, tidak mendapatkan akses ke penyimpanan'), [{ text: _('Tutup') }]);
      return;
    }
    const { datas, IDs } = await createLogData();
    const {
      createFile, dirs, exists, appendFile,
    } = RNFB.fs;
    const path = `${Platform.OS === 'ios' ? dirs.DocumentDir : dirs.DownloadDir}/PRUFastLog_${DeviceInfo.getModel()}.txt`;
    const pathExist = await exists(path);
    await Promise.all(datas.map(async (x) => {
      if (pathExist) {
        await appendFile(path, `\n${x}`, 'utf8');
      } else {
        await createFile(path, x, 'utf8');
      }
    }));
    resolve({ path, IDs });
  } catch (error) {
    reject(error);
  }
});

/**
 * share log file from social media
 */
const shareLogFile = () => new Promise(async (resolve, reject) => {
  try {
    const { path } = await createLogFile();
    await Share.open({
      title: 'PRUFast Log',
      url: `file://${path}`,
      message: _(`PRUFast Log from ${DeviceInfo.getModel()} ${DeviceInfo.getSystemName()} ${DeviceInfo.getSystemVersion()}`),
      subject: 'PRUFast Log',
      failOnCancel: false,
    });
    resolve('Succeed');
  } catch (error) {
    reject(error);
  }
});

/**
 * @param agentCode: agent code
 * @param token: API Token
 */
const sendLogFileToApi = (agentCode, token) => new Promise(async (resolve, reject) => {
  try {
    const { path, IDs } = await createLogFile();
    let base64 = '';
    try {
      base64 = await RNFB.fs.readFile(path, 'base64');
    } catch (error) {
      console.log(error);
    }
    if (base64) return;
    const parameter = {
      agentCode,
      deviceType: DeviceInfo.getSystemName(),
      deviceVersion: DeviceInfo.getModel(),
      OSVersion: DeviceInfo.getSystemVersion(),
      logFile: base64,
    };
    const config = {
      params: `['${JSON.stringify(parameter)}']`,
      headers: [
        {
          keyHeader: 'X-CSRF-Token',
          valueHeader: `Bearer ${token}`,
        },
      ],
    };
    console.log(config);
    const response = await resourceRequest(`${adapter.COMMON}/sendLogFile`, 'post', config);
    if (response.data.responseCode === '00') {
      await updateLog(IDs);
    }
    await RNFB.fs.unlink(path);
    resolve('Succeed');
  } catch (error) {
    console.log(error);
    reject(error);
  }
});

/**
 * @param IDs: IDs that have been sent to the API
 */
const updateLog = (IDs = []) => new Promise(async (resolve, reject) => {
  try {
    const stringIDs = JSON.stringify(IDs).replace('[', '(').replace(']', ')');
    await SQLite.executeTransaction(
      global.database.log,
      `UPDATE ${log.name} SET processed = ?, processedDate = ? WHERE ID IN ${stringIDs}`,
      ['true', moment(new Date()).format('YYYY-MM-DD HH:mm:ss')],
    );
    resolve('Succeed');
  } catch (error) {
    reject(error);
  }
});

let schedulerRunning = false;
const scheduler = (agentCode, token) => {
  if (schedulerRunning) return;
  schedulerRunning = true;
  setInterval(() => {
    sendLogFileToApi(agentCode, token);
  }, 60 * 1000);
};

const CONSTANT = {
  DEBUG: 'DEBUG',
  ERROR: 'ERROR',
  WARNING: 'WARNING',
  INFO: 'INFO',
};

/**
 * Example
 */
// const example = () => {
//   try {
//     saveLog(CONSTANT.DEBUG, `This is ${CONSTANT.DEBUG} message.`);
//     saveLog(CONSTANT.WARNING, `This is ${CONSTANT.WARNING} message.`);
//     saveLog(CONSTANT.INFO, `This is ${CONSTANT.INFO} message.`);
//   } catch (error) {
//     saveLog(CONSTANT.ERROR, `This is ${CONSTANT.ERROR} message.`);
//   }
// };

export {
  scheduler,
  shareLogFile,
  saveLog,
  sendLogFileToApi,
  CONSTANT,
};
