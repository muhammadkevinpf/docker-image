/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { PureComponent } from 'react';
import { View, Text } from 'react-native';
import PropTypes from 'prop-types';
import UnCheckIcon from 'react-native-vector-icons/Feather';
import CheckIcon from 'react-native-vector-icons/AntDesign';
import Style from '../../styles';

class OutlineCheckbox extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  render() {
    const unCheck = <UnCheckIcon name="square" type="Feather" style={[Style.Main.font20, Style.Main.gray83]} onPress={this.props.onPress} />;
    const check = <CheckIcon
      name="checksquareo"
      type="AntDesign"
      style={[Style.Main.font20, Style.Main.textRed]}
      onPress={this.props.onPress}
    />;
    return (
      <View style={[Style.Main.rowDirectionFlexStart, this.props.style]}>
        <View>
          {(this.props.checked)
            ? check
            : unCheck }
        </View>
        {
          this.props.sideLabel && (
            <View style={[Style.Main.pl10, ...this.props.style]}>
              <Text style={[Style.Main.fontAlbert, Style.Main.font14, Style.Main.textJustify, ...this.props.styleLabel]}>
                {this.props.sideLabel}
              </Text>
            </View>
          )
        }
        <View style={[Style.Main.pl10, ...this.props.style]}>
          <Text
            onPress={this.props.onPressLabel || this.props.onPress}
            style={[Style.Main.fontAlbert, Style.Main.font14, Style.Main.textJustify, ...this.props.styleLabel]}
          >
            {this.props.label}
          </Text>
        </View>
      </View>
    );
  }
}

OutlineCheckbox.propTypes = {
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.func, PropTypes.object]),
  checked: PropTypes.bool,
  onPress: PropTypes.func,
  style: PropTypes.arrayOf(PropTypes.object),
  styleLabel: PropTypes.arrayOf(PropTypes.object),
};

OutlineCheckbox.defaultProps = {
  label: '',
  checked: false,
  onPress: () => {},
  style: [],
  styleLabel: [],
};

export default OutlineCheckbox;
