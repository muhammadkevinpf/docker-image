/**
 * @author: ahmdichsanb@gmail.com
*/

import { StyleSheet, Dimensions } from 'react-native';
import Styles from '../../styles';

const deviceWidth = Dimensions.get('window').width;
let fontSize = 12;
if (deviceWidth > 450) fontSize = 16;

const Style = StyleSheet.create({
  container: {
    width: '49%',
    aspectRatio: 2,
    padding: 5,
    margin: 2,
    justifyContent: 'center',
    alignContent: 'center',
    borderRadius: 20,
  },
  backgroundSelected: {
    backgroundColor: Styles.Color.red,
  },
  backgroundUnSelected: {
    backgroundColor: Styles.Color.gray,
  },
  image: {
    width: '100%',
    height: '100%',
    borderRadius: 20,
    position: 'absolute',
    marginLeft: 5,
  },
  svgIconWrapper: {
    width: '100%',
    height: '80%',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 5,
    transform: [{ rotate: '40deg' }],
    bottom: '10%',
  },
  labelWrapper: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    marginLeft: 5,
  },
  label: {
    zIndex: 99,
    textAlign: 'center',
    color: Styles.Color.white,
    fontFamily: 'Roboto',
    fontSize,
  },
  columnWrapperStyle: {
    flex: 1,
    justifyContent: 'space-around',
  },
});

export default Style;
