import { iconLeader, iconSoftSkill, iconVideo } from '../../assets/images';

/* eslint-disable max-len */
export const trainingProgress = {
  DONE: 'done',
  UNDONE: 'undone',
  LAST: 'last',
};

export const trainingType = {
  CLASSROOM: 'CLASSROOM',
  ONLINE: 'ONLINE',
  AFM: 'AFM',
};

export const postTestInstruction = [
  'Test ini merupakan test akhir yang bertujuan untuk mengetahui tingkat pemahaman yang anda dapatkan terhadap materi pelajaran yang telah dipelajari.',
  'Terdiri dari 20 soal, dengan jangka waktu 20 menit',
  'Batas minimal kelulusan adalah 80',
];
export const cpd = {
  AAJI: 'AAJI',
  AASI: 'AASI',
};

export const periodTabs = {
  ongoing: 'ongoing',
  upcoming: 'upcoming',
  finish: 'finish',
};

export const scheduleTabs = {
  MYSCHEDULE: 'MYSCHEDULE',
  ALLSCHEDULE: 'ALLSCHEDULE',
};

export const catalogType = {
  LEADER: 'LEADER_TRAINING',
  SOFT_SKILL: 'SOFT_SKILL_TRAINING',
  VIDEO: 'PODCAST_AND_VIDEO',
};

export const getCatalogIcon = (type) => {
  switch (type) {
    case catalogType.VIDEO: return iconVideo;
    case catalogType.SOFT_SKILL: return iconSoftSkill;
    case catalogType.LEADER: default: return iconLeader;
  }
};
