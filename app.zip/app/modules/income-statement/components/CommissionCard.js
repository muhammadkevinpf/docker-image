/* eslint-disable max-len */

import React, { PureComponent } from 'react';
import {
  Text, View, Card, Icon,
} from 'native-base';
import { TouchableOpacity } from 'react-native';
import { CoverageText } from '../../../components';
import { DatabaseUtils, toFixedCurrency } from '../../../utilities';
import LoadingModal from '../../../components/loading_modal';
import Style from '../../../styles';
import _ from '../../../lang';

class CommissionCard extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    };
  }

  render() {
    const {
      data, onPress, detailShowed, onExpand,
    } = this.props;
    const Tag = this.props.onPress ? TouchableOpacity : View;
    return (
      <Tag style={[Style.Main.fullWidth]} onPress={onPress || (() => {})}>
        <LoadingModal show={this.state.isLoading} size="large" color="white" />
        <Card style={[detailShowed ? Style.Main.mb0 : Style.Main.mb2]}>
          <View style={[Style.Main.fullWidth, Style.Main.padding10,
            Style.Main.center, Style.Main.rowDirectionSpaceBetween, Style.Main.borderBottomWhiteSmoke]}
          >
            <View style={[Style.Main.container]}>
              <View style={[Style.Main.rowDirectionSpaceBetween]}>
                <Text style={[Style.Main.textBlack, Style.Main.fontAlbert14]}>{data.name}</Text>
                <Text style={[Style.Main.fontAlbert14, Style.Main.textRight]}>Contract Issue</Text>
                <TouchableOpacity
                  activeOpacity={1}
                  style={[Style.Main.pl15, Style.Main.pr0]}
                  onPress={onExpand || (() => { })}
                >
                  <Text style={[Style.Main.font26, Style.Main.textBlack, Style]}>
                    {detailShowed
                      ? <Icon name="angle-up" type="FontAwesome" style={[Style.Main.gray83, Style.Main.font21]} />
                      : <Icon name="angle-down" type="FontAwesome" style={[Style.Main.gray83, Style.Main.font21]} />}
                  </Text>
                </TouchableOpacity>
              </View>
              <View>
                <Text style={[Style.Main.fontAlbert14]}>{data.policyNumber}</Text>
              </View>
            </View>
          </View>
          <View style={[Style.Main.fullWidth, Style.Main.padding10]}>
            <View style={[Style.Main.borderBottomGray]}>
              <Text style={[Style.Main.textBlack, Style.Main.fontAlbert14]}>{_('Komisi')}</Text>
              <Text style={[Style.Main.textRed, Style.Main.fontAlbert14, Style.Main.mb15]}>IDR {toFixedCurrency(data.commissionIdr, 2)}</Text>
            </View>
          </View>

          {detailShowed &&
            <View style={[Style.Main.padding20, Style.Main.mt0, Style.Main.mb2]}>
              <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.mb20]}>
                <View style={[Style.Main.container]}>
                  <Text style={[Style.Main.fontAlbert11]}>{_('FREKUENSI PEMBAYARAN')}</Text>
                  <Text style={[Style.Main.textBlack, Style.Main.fontAlbert14]}>{data.paymentFreq}</Text>
                </View>
                <View style={[Style.Main.container]}>
                  <Text style={[Style.Main.fontAlbert11]}>{_('PRODUK MANFAAT')}</Text>
                  {/* <Text style={[Style.Main.textBlack, Style.Main.fontAlbert14]}>{data.productName}</Text> */}
                  <CoverageText style={[Style.Main.textBlack]} desc={DatabaseUtils.toCoverageFormat(data.productName)} />
                </View>
              </View>
              <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.mb20]}>
                <View style={[Style.Main.container]}>
                  <Text style={[Style.Main.fontAlbert11, Style.Main.pr5]}>{_('KEAGENAN SAAT PREMI DIBUAT')}</Text>
                  <Text style={[Style.Main.textBlack, Style.Main.fontAlbert14]}>{data.issueLevel}</Text>
                </View>
                <View style={[Style.Main.container]}>
                  <Text style={[Style.Main.fontAlbert11]}>{_('TAHUN KE-')}</Text>
                  <Text style={[Style.Main.textBlack, Style.Main.fontAlbert14]}>{data.year}</Text>
                </View>
              </View>
              <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.mb20]}>
                <View style={[Style.Main.container]}>
                  <Text style={[Style.Main.fontAlbert11]}>{_('POLICY INCEPTION DATE')}</Text>
                  <Text style={[Style.Main.textBlack, Style.Main.fontAlbert14]}>{data.inceptionDate}</Text>
                </View>
                <View style={[Style.Main.container]}>
                  <Text style={[Style.Main.fontAlbert11]}>{_('JATUH TEMPO')}</Text>
                  <Text style={[Style.Main.textBlack, Style.Main.fontAlbert14]}>{data.dueDate}</Text>
                </View>
              </View>
              <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.mb20]}>
                <View style={[Style.Main.container]}>
                  <Text style={[Style.Main.textBlack, Style.Main.fontAlbert11]}>{_('PREMI')}</Text>
                  <Text style={[Style.Main.textBlack, Style.Main.fontAlbert14]}>IDR {toFixedCurrency(data.premium, 2)}</Text>
                </View>
                <View style={[Style.Main.container]}>
                  <Text style={[Style.Main.textBlack, Style.Main.fontAlbert11]}>{_('KOMISI')}</Text>
                  <Text style={[Style.Main.textBlack, Style.Main.fontAlbert14]}>IDR {toFixedCurrency(data.commissionOriginal, 2)}</Text>
                </View>
              </View>
            </View>
          }
        </Card>
      </Tag>
    );
  }
}

export default CommissionCard;
