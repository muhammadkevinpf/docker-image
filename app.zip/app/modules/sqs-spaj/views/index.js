/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import LandingPage_ from './landing-page';
import ExistingPolicy_ from './existing-policy';
import Questionnaire_ from './questionnaire';
import MainInsured_ from './main-insured';
import InvestmentGoals_ from './investment-goals';
import Benefits_ from './benefits';
import CustomerData_ from './customer-data';
import Withdrawal_ from './withdrawal';
import Substandard_ from './substandard';
import QuickQuote_ from './quick-quote';
import AdditionalCustomerData_ from './additional-customer-data';
import Calculation_ from './calculation';
import Illustration_ from './illustration';
import Signature_ from './signature';

const LandingPage = LandingPage_;
const ExistingPolicy = ExistingPolicy_;
const Questionnaire = Questionnaire_;
const MainInsured = MainInsured_;
const InvestmentGoals = InvestmentGoals_;
const CustomerData = CustomerData_;
const Withdrawal = Withdrawal_;
const Substandard = Substandard_;
const AdditionalCustomerData = AdditionalCustomerData_;
const Benefits = Benefits_;
const Calculation = Calculation_;
const QuickQuote = QuickQuote_;
const Illustration = Illustration_;
const Signature = Signature_;

export default {
  LandingPage,
  ExistingPolicy,
  Questionnaire,
  MainInsured,
  InvestmentGoals,
  CustomerData,
  Withdrawal,
  Substandard,
  AdditionalCustomerData,
  Benefits,
  Calculation,
  QuickQuote,
  Illustration,
  Signature,
};
