/* eslint-disable max-len */
import moment from 'moment';
import _ from '../../lang';
import { API_ACTION_TYPES } from '../../utilities';
import Caches from '../../utilities/Caches';
import { SqsSpajService } from '../spaj/services';


export const sortProspectList = [
  {
    value: '01', orderBy: 'fullname', direction: 'asc', label: 'Nama Prospek A-Z',
  },
  {
    value: '02', orderBy: 'fullname', direction: 'desc', label: 'Nama Prospek Z-A',
  },
  {
    value: '03', orderBy: 'activity_date', direction: 'asc', label: 'Tanggal Aktivitas Terlama',
  },
  {
    value: '04', orderBy: 'activity_date', direction: 'desc', label: 'Tanggal Aktivitas Terbaru',
  },
  {
    value: '05', orderBy: 'created_date', direction: 'asc', label: 'Tanggal Masuk Prospek Terlama',
  },
  {
    value: '06', orderBy: 'created_date', direction: 'desc', label: 'Tanggal Masuk Prospek Terbaru',
  },
];

export const sortDashboardDetails = [
  {
    value: '01', orderBy: 'fullname', direction: 'asc', label: 'Nama A-Z', isDefault: true,
  },
  {
    value: '02', orderBy: 'fullname', direction: 'desc', label: 'Nama Z-A', isDefault: true,
  },
  {
    value: '03', orderBy: 'activity_date', direction: 'asc', label: 'Tanggal Aktivitas Terlama', isDefault: true,
  },
  {
    value: '04', orderBy: 'activity_date', direction: 'desc', label: 'Tanggal Aktivitas Terbaru', isDefault: true,
  },
  {
    value: '05', orderBy: 'point', direction: 'asc', label: 'Jumlah Poin Terkecil - Terbesar', isDefault: false,
  },
  {
    value: '06', orderBy: 'point', direction: 'desc', label: 'Jumlah Poin Terbesar - Terkecil', isDefault: false,
  },
];

export const sortContactList = [
  {
    value: '01', orderBy: 'full_name', direction: 'asc', label: 'Berdasarkan Abjad A-Z',
  },
  {
    value: '02', orderBy: 'full_name', direction: 'desc', label: 'Berdasarkan Abjad Z-A',
  },
];

export const segmentList = [
  { value: 'PV', label: 'PV' },
  { value: 'BB', label: 'BB' },
  { value: 'CB', label: 'CB' },
  { value: 'NFT', label: 'NFT' },
  { value: 'BB-NFT', label: 'BB-NFT' },
];

export const filterContactList = [
  { value: true, label: 'Prospek' },
  { value: false, label: 'Baru' },
];

export const GET_PROSPECT_LIST = {
  API: 'adapters/PDActivityManagementAdapter/getProspectList',
  FETCH: 'GET_PROSPECT_LIST_FETCH',
  SUCCESS: 'GET_PROSPECT_LIST_SUCCESS',
  FAILED: 'GET_PROSPECT_LIST_FAILED',
};

export const POST_PROSPECT = {
  API: 'adapters/PDActivityManagementAdapter/addProspect',
  FETCH: 'POST_PROSPECT_FETCH',
  SUCCESS: 'POST_PROSPECT_SUCCESS',
  FAILED: 'POST_PROSPECT_FAILED',
};

export const EDIT_PROSPECT = API_ACTION_TYPES('EDIT_PROSPECT', 'adapters/PDActivityManagementAdapter/editProspect');

export const GET_CONTACT = {
  API: 'adapters/HTTPAdapterAMContact/getContact',
  FETCH: 'GET_CONTACT_FETCH',
  SUCCESS: 'GET_CONTACT_SUCCESS',
  FAILED: 'GET_CONTACT_FAILED',
};

export const POST_CONTACT = {
  API: 'adapters/HTTPAdapterAMContact/addContact',
  FETCH: 'POST_CONTACT_FETCH',
  SUCCESS: 'POST_CONTACT_SUCCESS',
  FAILED: 'POST_CONTACT_FAILED',
};

export const CLEAR_PROSPECT = {
  LIST: 'CLEAR_PROSPECT_LIST',
  CONTACT: 'CLEAR_PROSPECT_CONTACT',
};

export const UPDATE_CONTACT_CHECK = 'UPDATE_CONTACT_CHECK';

export const PROSPECT_DETAIL = {
  ...API_ACTION_TYPES('PROSPECT_DETAIL', 'adapters/PDActivityManagementAdapter/getProspect'),
  RESET: 'PROSPECT_DETAIL_RESET',
  SET: 'PROSPECT_DETAIL_SET',
};

export const INPUT_FEEDBACK_LIST = API_ACTION_TYPES('INPUT_FEEDBACK_LIST', 'adapters/PDActivityManagementAdapter/getAllFeedback');
export const FEEDBACK_POINT = API_ACTION_TYPES('FEEDBACK_POINT', 'adapters/HTTPAdapterAMProspect/getFeedbackPoint');
export const ADD_FEEDBACK_AM = API_ACTION_TYPES('ADD_FEEDBACK_AM', 'adapters/PDActivityManagementAdapter/addLogFeedback');
export const AM_DASHBOARD = API_ACTION_TYPES('AM_DASHBOARD', 'adapters/PDActivityManagementAdapter/getDashboard');
export const AM_CALENDAR_DATA = API_ACTION_TYPES('AM_CALENDAR_DATA', 'adapters/PDActivityManagementAdapter/getSchedule');

export const GET_POINT_INDIVIDU = {
  API: 'adapters/HTTPAdapterAMDashboard/getPointIndividu',
  FETCH: 'GET_POINT_INDIVIDU_FETCH',
  SUCCESS: 'GET_POINT_INDIVIDU_SUCCESS',
  FAILED: 'GET_POINT_INDIVIDU_FAILED',
};

export const GET_CONVERTION_INDIVIDU = {
  API: 'adapters/PDActivityManagementAdapter/getConversionIndividu',
  FETCH: 'GET_CONVERTION_INDIVIDU_FETCH',
  SUCCESS: 'GET_CONVERTION_INDIVIDU_SUCCESS',
  FAILED: 'GET_CONVERTION_INDIVIDU_FAILED',
};

export const GET_HISTORY_INDIVIDU = {
  API: 'adapters/PDActivityManagementAdapter/getHistoryIndividu',
  FETCH: 'GET_HISTORY_INDIVIDU_FETCH',
  SUCCESS: 'GET_HISTORY_INDIVIDU_SUCCESS',
  FAILED: 'GET_HISTORY_INDIVIDU_FAILED',
};

export const CLEAR_DASHBOARD = {
  POINT: 'CLEAR_DASHBOARD_POINT',
  CONVERTION: 'CLEAR_DASHBOARD_CONVERTION',
  HISTORY: 'CLEAR_DASHBOARD_HISTORY',
};

export const newProspectDisclaimer = bankName => [
  `${_('Saya dengan ini memberikan persetujuan kepada')} ${bankName} ${_(`untuk mereferensikan Saya kepada Financial Services Consultant ("FSC") selaku pihak yang ditunjuk oleh PT Prudential Life Assurance untuk memberikan penjelasan lebih detail kepada Saya mengenai produk-produk asuransi dalam kaitanya dengan kerjasama antara ${bankName} dan PT Prudential Life Assurance ("Produk Asuransi").`)}`,
  `${_('Saya setuju dan memahami bahwa seluruh informasi yang Saya sampaikan dalam interaksi Saya dengan FSC adalah atas kesadaran dan risiko Saya tanpa tekanan dari pihak manapun.')}`,
  `${_('FSC dan PT Prudential Life Assurance mempunyai hak sepenuhnya untuk mencatat dan menyimpan informasi mengenai Saya semata-mata hanya untuk keperluan proses pengajuan Produk Asuransi yang ditawarkan.')}`,
];

export const dataProposal = (data) => {
  const dob = data.dob ? data.dob.split('-') : null;
  const newDob = dob ? `${dob[2]}/${dob[1]}/${dob[0]}` : '';
  const age = SqsSpajService.calculateAgeTMP(moment(data.dob, 'YYYY-MM-DD').toDate());

  console.log('age: ', age);
  console.log('new dob: ', newDob);
  const country = Caches.get('allCountry').ALL_COUNTRY || [];
  let number = data.phoneNumber.replace(/^0+/, '');
  let code = 'RI';

  country.forEach((item) => {
    if (number.includes(item.telephoneCode)) {
      number = number.replace(item.telephoneCode, '');
      code = item.countryCd;
    }
  });

  return {
    Dob: newDob || '',
    mobile: number || '',
    // customerId: '',
    MaritalStatus: data.maritalStatus || '',
    // pekerjaanCode: '',
    codeTelp: code || '',
    age: age.year,
    anb: age.anb,
    custAge: age.year,
    custAgeDay: age.day,
    custAgeMonth: age.month,
    name: data.customerName || '',
    sex: data.gender || '',
    // smokeStatus: '',
    // clazz: '',
    // Departement: '',
    // isExisting: '',
    // Business: '',
    prospectId: data.id,
    masterNumber: data.masterNumber,
    prodAccountNumber: data.prodAccountNumber,
  };
};
