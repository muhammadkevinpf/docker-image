import { StyleSheet, PixelRatio } from 'react-native';
import Styles from '../../styles';

const Style = StyleSheet.create({
  stylePickerView: {
    borderBottomColor: Styles.Color.gray,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  stylePickerBody: {
    width: '100%',
  },
  styleTextLabel: {
    margin: 0,
    padding: 0,
    flex: 1,
    fontSize: 11,
    color: Styles.Color.gray,
    // marginTop: 10,
  },
  suggestionList: {
    padding: 13,
    fontSize: 16,
    // borderBottomColor: Styles.Color.black,
    // borderBottomWidth: 0.5,
  },
  flatList: {
    borderTopColor: Styles.Color.black,
    borderRightColor: Styles.Color.black,
    borderLeftColor: Styles.Color.black,
    borderBottomColor: Styles.Color.black,
    borderTopWidth: 0.5,
    borderRightWidth: 0.5,
    borderLeftWidth: 0.5,
    borderBottomWidth: 0.5,
    maxHeight: 170,
  },
  styleTextInput: {
    height: 30,
    padding: 0,
    paddingBottom: 6,
    margin: 0,
    fontSize: 14,
  },
  // eslint-disable-next-line react-native/no-color-literals
  outerItem: {
    // maxHeight: 50,
    // backgroundColor: Styles.Color.mediumGray,
    paddingLeft: 1,
    marginTop: 15,
    borderColor: '#D9D5DC',
    borderBottomWidth: 1 / PixelRatio.getPixelSizeForLayoutSize(1) * 2,
    flexDirection: 'column',
  },
  innerItem: {
    padding: 0,
    margin: 0,
    // maxHeight: 40,
    // borderBottomWidth: 0,
    // backgroundColor: Styles.Color.yellow,
    flexDirection: 'row',
    alignItems: 'center',
    alignContent: 'flex-start',
  },
  iconStyle: {
    fontSize: 18,
    color: Styles.Color.brightGray,
    marginRight: 6,
    // marginBottom: 20,
    // backgroundColor: Styles.Color.blue,
  },
  styleBottomLabel: {
    // marginBottom: 15,
    color: Styles.Color.red,
    fontSize: 10,
    marginLeft: 15,
  },
});

export default Style;
