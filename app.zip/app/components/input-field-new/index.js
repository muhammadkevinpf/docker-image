/**
 * @author: ahmdichsanb@gmail.com
*/

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {
  Item, Input, Label, Text, View,
} from 'native-base';
import { Platform } from 'react-native';
import { stringToFloat } from '../../utilities';
import Style from '../../styles';
import StyleInput from './StyleInputField';
import _ from '../../lang';

class InputField extends Component {
  constructor(props) {
    super(props);
    this.state = {
      errorMessage: '',
      isOnEdit: false,
      itemHeight: 45,
      // value: '',
    };
  }

  // shouldComponentUpdate = (prevProps, prevState) => {
  //   console.log(this.props.isInsideCheckbox);
  //   if (!this.props.isInsideCheckbox && JSON.stringify(this.props) === JSON.stringify(prevProps) &&
  //   !this.state.isOnEdit && prevState.isOnEdit === this.state.isOnEdit) return false;
  //   return true;
  // }

  componentDidMount = () => {
    const { invoke } = this.props;
    if (invoke) { this.invokeChecker(); }
  }

  componentDidUpdate = (prevProps) => {
    if (this.props.invoke !== prevProps.invoke) { this.invokeChecker(); }
  }

  onFocusValidation = (input) => {
    const { onFocus, type } = this.props;
    if (type === 'currency') {
      // eslint-disable-next-line no-param-reassign
      input = input.replace(/,/g, '');// eslint-disable-line no-useless-escape
    }
    this.setState({ isOnEdit: true });
    this.inputCheck(input, false);
    if (onFocus) {
      onFocus(input);
    }
  }

  onChangeValidation = (input) => {
    // const { type } = this.props;

    // if (type === 'currency') {
    //   // eslint-disable-next-line no-param-reassign
    //   input = input.replace(/,/g, '');// eslint-disable-line no-useless-escape
    // }
    if (this.props.setValueToParent) {
      this.props.setValueToParent(this.props.index, input);
    }
    this.inputCheck(input, true);
  }

  onBlurValidation = (string) => {
    const { onBlur, type } = this.props;
    let input = string;
    // if (type === 'currency') {
    //   // eslint-disable-next-line no-param-reassign
    //   input = input.replace(/,/g, '');// eslint-disable-line no-useless-escape
    // }
    if (type === 'float') input = stringToFloat(input, { invokeBlur: true });
    this.setState({ isOnEdit: false });
    this.inputCheck(input ? input.trim() : '', true);
    if (onBlur) {
      onBlur(input);
    }
  }

  convertToCurrency = val => val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');

  numberValidation = (string, isOnChange) => {
    const {
      minVal,
      maxVal,
      onChangeText,
      fractionDigit,
      type,
    } = this.props;
    // Cannot Contain other than Number

    let input = string;
    const regex = type === 'float' ? /[^0-9.]/gi : /[^0-9]/gi;
    if (regex.test(input)) {
      return;
    }

    if (type !== 'postCode' && type !== 'float' && input.length > 1) {
      const regex2 = /^0+/;
      if (regex2.test(input)) {
        input = input.replace(regex2, '');
      }
    }

    if (type === 'float') input = stringToFloat(input, { maxFractionDigit: fractionDigit });
    const inputValue = type === 'float' ? parseFloat(input, 2) : parseInt(input, 0);
    if (inputValue > 0) {
      if (minVal) {
        if (inputValue < minVal) {
          this.setState({
            errorMessage: `Minimal masukkan ${type === 'currency' ? this.convertToCurrency(minVal) : minVal}`,
          });
          if (isOnChange) {
            onChangeText(input);
          }
          return;
        }
      }

      if (maxVal) {
        if (inputValue > maxVal) {
          this.setState({
            errorMessage: `Maksimal masukkan ${type === 'currency' ? this.convertToCurrency(maxVal) : maxVal}`,
          });
          if (isOnChange) {
            onChangeText(input);
          }
          return;
        }
      }
    }

    if (isOnChange) {
      onChangeText(input);
    }
  }

  mobileValidation = (input, isOnChange) => {
    const { onChangeText, countryCd } = this.props;
    let isValid = false;
    // Cannot Contain other than Number
    const regexJustWithNumber = /[^0-9]/gi;
    const regexNotStartWithZero = /^0+/;
    if (regexJustWithNumber.test(input) || regexNotStartWithZero.test(input)) {
      return;
    }

    if (countryCd === '+62') {
      const regexMustMobileNumber = /^8[1-9][0-9]{5,11}$/;
      const regexMustNotRepetitive = /^(?!(((?!8)[0-9]*))\1+$)\d{9}/;
      const regexMustNotSeq = /^(?=.*(?:1(?![02])|2(?![13])|3(?![24])|4(?![35])|5(?![46])|6(?![57])|7(?![68])|8(?![79])|9(?!8)|0(?!1))(?!$))\d+$/;
      if (!regexMustMobileNumber.test(input) || !regexMustNotRepetitive.test(input) || !regexMustNotSeq.test(input)) {
        this.setState({
          errorMessage: 'Format No. Handphone tidak sesuai',
        });
      } else {
        this.setState({
          errorMessage: '',
        });
        isValid = true;
      }
    } else {
      this.setState({
        errorMessage: '',
      });
      isValid = true;
    }

    if (isOnChange) {
      onChangeText(input, isValid);
    }
  }

  phoneValidation = (input, isOnChange) => {
    const { onChangeText } = this.props;
    // Cannot Contain other than Number
    const regex = /[^0-9]/gi;
    const regex2 = /^0+/;
    if (regex.test(input) || regex2.test(input)) {
      return;
    }

    if (isOnChange) {
      onChangeText(input);
    }
  }

  emailValidation = (input, isOnChange) => {
    const { onChangeText } = this.props;
    let isValid = false;
    // For Email Address
    const regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/gi; // eslint-disable-line no-useless-escape
    if (!regex.test(input)) {
      this.setState({
        errorMessage: 'Alamat email tidak valid!',
      });
    } else {
      this.setState({
        errorMessage: '',
      });
      isValid = true;
    }
    if (isOnChange) {
      onChangeText(input, isValid);
    }
  }

  alphaNumericValidation = (input, isOnChange) => {
    const { onChangeText, capitalize } = this.props;

    if (capitalize) {
      const regex = /^[A-Z0-9 $]*$/;
      const regex2 = /^\S+$/;
      const isValid = !regex.test(input) || !regex2.test(input);
      if (isValid) return;
    }

    const regex = /^[0-9a-zA-Z $]*$/;
    const isValid = regex.test(input);
    if (!isValid) return;
    if (isOnChange) {
      onChangeText(input, isValid);
    }
  }

  alphabetValidation = (input, isOnChange) => {
    const { onChangeText } = this.props;
    const regex = /^[a-zA-Z $]*$/;
    const isValid = regex.test(input);
    if (!isValid) return;
    if (isOnChange) {
      onChangeText(input, isValid);
    }
  }

  nameValidation = (input, isOnChange) => {
    const { onChangeText } = this.props;
    const regex = /[^a-zA-Z, ,.,',]/g;
    if (regex.test(input)) {
      return;
    }

    if (isOnChange) {
      onChangeText(input);
    }
  }

  companyValidation = (input, isOnChange) => {
    const { onChangeText } = this.props;
    let isValid = false;
    const regex = /^[A-Za-z]([a-zA-Z0-9]|[\W])*[a-zA-Z0-9]$/g;
    const regex2 = /\s{2}|(.)\1{3,}/g;
    if (!regex.test(input) || regex2.test(input)) {
      this.setState({
        errorMessage: this.props.errorMessage ? this.props.errorMessage : 'Nama perusahaan/organisasi tidak valid!',
      });
    } else {
      isValid = true;
    }

    if (isOnChange) {
      onChangeText(input, isValid);
    }
  }

  addressValidation = (input, isOnChange) => {
    const { onChangeText } = this.props;
    let isValid = false;
    const regex = /^[A-Za-z]([a-zA-Z0-9]|[\s,,,.,\-,/])*[a-zA-Z0-9]$/g;
    const regex2 = /\s{2}|(.)\1{3,}/g;
    if (!regex.test(input) || regex2.test(input)) {
      this.setState({
        errorMessage: this.props.errorMessage ? this.props.errorMessage : 'Alamat tidak valid!',
      });
    } else {
      isValid = true;
    }

    if (isOnChange) {
      onChangeText(input, isValid);
    }
  }

  inputCheck = (input, isOnChange) => {
    const {
      isRequired, type, onChangeText, minLength,
    } = this.props;
    let errorMessage = '';
    let isValid = false;

    // console.log('state in input value: ', this.state.value);

    // Wajib diisi Check
    if (!input || input.length <= 0) {
      if (isRequired) {
        errorMessage = 'Wajib diisi!';
      } else {
        errorMessage = '';
        isValid = true;
      }
      if (isOnChange) {
        onChangeText(input, isValid);
      }
      this.setState({
        errorMessage,
      });
    } else {
      if (minLength) {
        if (input.length < minLength) {
          errorMessage = `minimal panjang karakter ${minLength}`;
          isValid = false;
          // if (isOnChange) {
          //   onChangeText(input, isValid);
          // }
          this.setState({
            errorMessage,
          });
        } else {
          errorMessage = '';
          isValid = true;
        }
      }
      this.setState({
        errorMessage,
      });
      // for Validation
      // Number and Phone Number
      switch (type) {
        case 'currency':
        case 'number':
        case 'float':
          this.numberValidation(input, isOnChange);
          break;
        case 'postCode':
          this.numberValidation(input, isOnChange);
          break;
        case 'phone':
          this.phoneValidation(input, isOnChange);
          break;
        case 'mobile':
          this.mobileValidation(input, isOnChange);
          break;
        case 'email':
          this.emailValidation(input, isOnChange);
          break;
        case 'name':
          this.nameValidation(input, isOnChange);
          break;
        case 'company':
          this.companyValidation(input, isOnChange);
          break;
        case 'address':
          this.addressValidation(input, isOnChange);
          break;
        case 'alphanumeric':
          this.alphaNumericValidation(input, isOnChange);
          break;
        case 'alphabet':
          this.alphabetValidation(input, isOnChange);
          break;
        default:
          if (isOnChange) {
            onChangeText(input, isValid);
          }
          break;
      }
    }
  }

  invokeChecker = () => {
    let keyboardType = 'default';
    if (keyboardType === 'default') {
      switch (this.props.type) {
        case 'currency':
        case 'number':
        case 'float':
          keyboardType = 'numeric';
          break;
        case 'email':
          keyboardType = 'email-address';
          break;
        case 'phone':
          keyboardType = 'phone-pad';
          break;
        case 'mobile':
          keyboardType = 'phone-pad';
          break;
        default:
          break;
      }
    }
    if (this.props.keyboardType) {
      // eslint-disable-next-line prefer-destructuring
      keyboardType = this.props.keyboardType;
    }
    // eslint-disable-next-line no-nested-ternary
    const value = keyboardType === 'numeric' ? this.props.value.toString() : this.props.value;
    this.inputCheck(value);
  }

  // getRefsData = () => this._input;

  render() {
    // console.log('ini ref: ', this._input);
    // console.log('this input field being rendered');
    const {
      allowFontScaling,
      autoFocus,
      editable,
      multiline,
      numberOfLines,
      placeholder,
      placeholderTextColor,
      secureTextEntry,
      style,
      labelStyle,
      textInputStyle,
      bottomLabelStyle,
      errorLabelStyle,
      textAlignVertical,
      label,
      bottomLabel,
      type,
      formStyle,
      maxLength,
      // add
      itemStyle,
      setHeight,
    } = this.props;
    const {
      errorMessage,
      isOnEdit,
      itemHeight,
    } = this.state;
    let keyboardType = 'default';
    if (keyboardType === 'default') {
      switch (type) {
        case 'currency':
        case 'number':
        case 'float':
          keyboardType = 'numeric';
          break;
        case 'email':
          keyboardType = 'email-address';
          break;
        case 'phone':
          keyboardType = 'phone-pad';
          break;
        case 'mobile':
          keyboardType = 'phone-pad';
          break;
        default:
          break;
      }
    }
    if (this.props.keyboardType) {
      // eslint-disable-next-line prefer-destructuring
      keyboardType = this.props.keyboardType;
    }
    // eslint-disable-next-line no-nested-ternary
    const value = keyboardType === 'numeric' ? this.props.value.toString() : this.props.value;
    const itemStyleOnEdit = label ? StyleInput.item : StyleInput.withoutLabel;
    return (
      <View style={[style]}>
        <View style={[StyleInput.formStyle, formStyle]}>
          <Item
            floatingLabel={!!label}
            style={[
              value || isOnEdit ? itemStyleOnEdit : null,
              itemHeight > 45 ? StyleInput.pb0 : null,
              label ? { height: itemHeight } : StyleInput.withoutLabel,
              itemStyle,
            ]}
          >
            {
              label && (
                <Label
                  numberOfLines={1}
                  style={[value || isOnEdit ? StyleInput.styleTextLabel : StyleInput.styleTextLabelValEmpty, Style.Main.fontAlbert, labelStyle]}
                >{_(label)}
                </Label>
              )
            }
            <Input
              // getRef={(ref) => { this._input = ref; }}
              blurOnSubmit
              allowFontScaling={allowFontScaling}
              autoFocus={autoFocus}
              editable={editable}
              keyboardType={keyboardType}
              maxLength={maxLength}
              multiline={multiline}
              numberOfLines={numberOfLines}
              onFocus={() => this.onFocusValidation(value)}
              onChangeText={e => this.onChangeValidation(e)}
              onBlur={() => this.onBlurValidation(value)}
              onContentSizeChange={() => { this.setState({ itemHeight: setHeight !== null ? setHeight : 45 }); }}
              placeholder={placeholder}
              placeholderTextColor={placeholderTextColor}
              secureTextEntry={secureTextEntry}
              style={[
                StyleInput.input, editable ? Style.Main.textAlmostBlack : Style.Main.textDisabled,
                Style.Main.fontAlbert,
                !label && [Style.Main.pb5],
                Platform.OS === 'ios' ? Style.Main.mt20 : '',
                textInputStyle,
              ]}
              textAlignVertical={textAlignVertical}
              value={type === 'currency' && !isOnEdit ? this.convertToCurrency(value) : value}
            />
          </Item>
        </View>
        {errorMessage ? (<Text style={[StyleInput.styleBottomLabel, Style.Main.fontAlbert, errorLabelStyle]}>{_(errorMessage)}</Text>) : null}
        {bottomLabel.length !== 0 ?
          (
            bottomLabel.map(element => (
              <Text key={element.toString()} style={[StyleInput.styleBottomLabel, Style.Main.fontAlbert, bottomLabelStyle]}>{_(element)}</Text>
            ))
          ) : null}
      </View>
    );
  }
}

InputField.propTypes = {
  allowFontScaling: PropTypes.bool,
  autoFocus: PropTypes.bool,
  maxLength: PropTypes.number,
  minLength: PropTypes.number,
  multiline: PropTypes.bool,
  numberOfLines: PropTypes.number,
  isRequired: PropTypes.bool,
  minVal: PropTypes.number,
  maxVal: PropTypes.number,
  placeholder: PropTypes.string,
  value: PropTypes.string.isRequired,
  placeholderTextColor: PropTypes.string,
  secureTextEntry: PropTypes.bool,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  formStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  labelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  textInputStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  bottomLabelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  errorLabelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  textAlignVertical: PropTypes.string,
  editable: PropTypes.bool,
  onChangeText: PropTypes.func,
  onFocus: PropTypes.func,
  onBlur: PropTypes.func,
  label: PropTypes.string,
  bottomLabel: PropTypes.arrayOf(PropTypes.string),
  type: PropTypes.string,
  keyboardType: PropTypes.string,
  // add
  itemStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  invoke: PropTypes.bool,
  // isInsideCheckbox: PropTypes.bool,
  errorMessage: PropTypes.string,
  setHeight: PropTypes.number,
  fractionDigit: PropTypes.number,
  countryCd: PropTypes.string,
};

InputField.defaultProps = {
  allowFontScaling: false,
  autoFocus: false,
  maxLength: null,
  minLength: null,
  multiline: true,
  numberOfLines: null,
  isRequired: true,
  placeholder: '',
  textAlignVertical: 'bottom',
  secureTextEntry: false,
  editable: true,
  style: null,
  formStyle: null,
  labelStyle: null,
  textInputStyle: null,
  bottomLabelStyle: null,
  errorLabelStyle: null,
  maxVal: null,
  minVal: null,
  placeholderTextColor: Style.Color.gray,
  onChangeText: () => { },
  onFocus: () => { },
  onBlur: () => { },
  label: null,
  bottomLabel: [],
  type: 'default', // default, name, email, number, currency, phone, float
  keyboardType: null,
  // add
  itemStyle: null,
  // isInsideCheckbox: false,
  invoke: false,
  errorMessage: '',
  setHeight: null,
  fractionDigit: 2,
  countryCd: '',
};

export default InputField;

/**
keyboardType =

Cross platforms:
-default
-number-pad
-decimal-pad
-numeric
-email-address
-phone-pad

No yet Added for Validation
add this on Validation Condition
iOS only:
-ascii-capable
-numbers-and-punctuation
-url
-name-phone-pad
-twitter
-web-search

Android only:
-visible-password
 */
