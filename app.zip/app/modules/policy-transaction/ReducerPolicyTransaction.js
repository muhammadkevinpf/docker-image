import { requestStatus } from '../../utilities';
import { RESET_ALL_STATE } from '../dashboard/ConfigDashboard';
import Configs, { SUBMIT_PHS } from './ConfigPolicyTransaction';

export const PHSPaymentInObj = {
  proses: '',
  policy: {
    pol_no: '',
    pol_type: '', // corporate/personal???
    spaj_no: '', // madatory if polno not filled
    ow_name: '',
    scan_time_stamp: '', // YYYYMMDDHHMMSS
    scan_date: '', // YYYYMMDD // same as sub_date
    sub_date: '', // YYYYMMDD
    sub_type: '', // TUP/SWI/RED/SNR
    vendor: 'PRUFAST',
    corp_pic: '',
  },
  tup: {
    ref_code: '',
    ref_name: '',
    cur: '',
    amount: '',
    fund: [
      // { name: '', percentage: 100 }, // name === fundCode of fundName???
    ],
    contri_role: '',
    contri_role_desc: '', // if contri_role === 'other'???
    contri_occup_new: '', // Y/N
    contri_occup: {
      main: '', // mandatory if contri_occup_new = Y
      company: '', // mandatory if contri_occup.main = Z
      position: '', // mandatory if contri_occup.main = Z
      desc: '', // mandatory if contri_occup.main = Z
    },
    contri_income: [
      // { type: '', source: [], total: 0 }, // obj properties in source array???
    ],
    purpose: [
      // { value: '' }, // is it okay to add "desc" property?
    ],
    enterprise: {
      status: '', // value??? // mandatory if AMOUNT TUP > 250mio IDR / 25k USD
      type: '', // value???
      name: '',
      sector: '',
      address: '',
    },
    ow_sign: null,
    py_sign: null, // mandatory if KONTRIBUTOR_ADALAH != OW
    ver: '', // value??
    sub_time: '', // format???
    company_income: [
      // { type: '', source: '', total: '' },
    ],
    company_sector: '',
    percent: 0, // added // is it okay???
  },
  swi: {
    pau: '',
    syariah_flag: null,
    fund: [{
      name: '', type: null, value: '', convert_to_unit: '', convert_to_amount: '', desc: '', // desc was added for UI need
    }],
    fund_target: [{
      name: '', percentage: 0, type: null, desc: '', // desc was added for UI need
    }],
    total_amount: '',
  },
  red: {
    fund: [
      { type: '', name: '', percentage: '' },
    ],
  },
  snr: {
    doc_id: '',
    ver: '',
    ow_sign: '',
    ow_sign_loc: '', // added for UI need
    ow_sign_date: '', // added for UI need
    cur: '',
    offshore_fund: '', // offshore === Y, onshore === N
    sub_time: '', // time > 4p.m === Y, time <= 4p.m === N
  },

  // not included in PHS
  productCode: '',
  topupFundMaster: [],
  owSignLoc: '',
  owSignDate: null,
  pySignLoc: '',
  pySignDate: null,
  document: {
    file_name: '',
    doc_id: '',
  },
  submission: {
    status: requestStatus.IDLE,
  },
};

export function ReducerPolicyTransaction(state = PHSPaymentInObj, action) {
  switch (action.type) {
    case RESET_ALL_STATE: case Configs.UPDATE_REDUCER.RESET: return PHSPaymentInObj;

    case Configs.UPDATE_REDUCER.ALL: return { ...state, ...action.payload };
    case Configs.UPDATE_REDUCER.POLICY: return { ...state, policy: { ...state.policy, ...action.payload } };
    case Configs.UPDATE_REDUCER.TOPUP: return { ...state, tup: { ...state.tup, ...action.payload } };
    case Configs.UPDATE_REDUCER.SNR: return { ...state, snr: { ...state.snr, ...action.payload } };
    case Configs.UPDATE_REDUCER.SWI: return { ...state, swi: { ...state.swi, ...action.payload } };

    case SUBMIT_PHS.FETCH: return { ...state, submission: { status: requestStatus.FETCH, send: action.payload } };
    case SUBMIT_PHS.SUCCESS: return { ...state, submission: { status: requestStatus.SUCCESS, res: action.payload } };
    case SUBMIT_PHS.FAILED: return { ...state, submission: { status: requestStatus.FAILED, err: action.payload } };
    default: return state;
  }
}
