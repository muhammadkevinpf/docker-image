/**
 * @author: ahmdichsanb@gmail.com
*/

import { StyleSheet, Dimensions } from 'react-native';
import Styles from '../../styles';

const deviceWidth = Dimensions.get('window').width;
let defaultContainerWidth = (70 / 100) * deviceWidth;
if (deviceWidth > 800) {
  defaultContainerWidth = (60 / 100) * deviceWidth;
}
const Style = StyleSheet.create({
  container: {
    width: defaultContainerWidth,
    height: 350,
    backgroundColor: Styles.Color.white,
    padding: 10,
    borderRadius: 10,
  },
  headerContent: {
    width: '100%',
    backgroundColor: Styles.Color.red,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    height: 50,
  },
  bodyContent: {
    width: '100%',
    padding: 10,
    backgroundColor: Styles.Color.white,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    height: 240,
    overflow: 'hidden',
  },
  footertContent: {
    alignItems: 'flex-end',
    height: 40,
    backgroundColor: Styles.Color.white,
  },
});

export default Style;
