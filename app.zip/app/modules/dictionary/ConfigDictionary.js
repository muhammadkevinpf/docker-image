/* eslint-disable max-len */

import React from 'react';
import { Linking } from 'react-native';
import { StyledText } from '../../components';
import Colors from '../../styles/Colors';
import { API_ACTION_TYPES } from '../../utilities';

export const GET_DICTIONARY = API_ACTION_TYPES('GET_DICTIONARY', 'adapters/HTTPAdapterDictionary/keywordDictionary');

const links = {
  ojk: 'www.ojk.go.id',
  aaji: 'www.aaji.co.id',
  pajak: 'www.pajak.co.id',
};

export const disclaimerDictionary = [
  <StyledText>Kamus Asuransi ini dibuat oleh PT Prudential Life Assurance (“<StyledText bold>Prudential</StyledText>”) semata-mata bertujuan untuk memberikan pemahaman kepada para Tenaga Pemasar Prudential mengenai istilah-istilah yang secara umum digunakan dalam bidang asuransi jiwa.</StyledText>,
  <StyledText>Kamus Asuransi ini bukan merupakan bagian dari Polis sehingga tidak dimaksudkan sebagai rujukan atau menggantikan makna yang terdapat dalam Polis, serta tidak dapat digunakan sebagai rujukan terkait proses penerbitan polis, proses klaim, serta proses hukum/persidangan.</StyledText>,
  <StyledText>Prudential beserta seluruh direksi, komisaris dan karyawannya tidak bertanggung jawab terhadap dan dibebaskan dari segala klaim, tuntutan dan/atau kerugian yang mungkin timbul dari penggunaan Kamus Asuransi ini dari pihak manapun.</StyledText>,
  <StyledText>
    Istilah-istilah dalam Kamus Asuransi ini diambil dari berbagai sumber antara lain <StyledText color={Colors.blue} onPress={() => Linking.openURL(`https://${links.ojk}`)}>{links.ojk}</StyledText>
    , <StyledText color={Colors.blue} onPress={() => Linking.openURL(`https://${links.aaji}`)}>{links.aaji}</StyledText>
    , <StyledText color={Colors.blue} onPress={() => Linking.openURL(`https://${links.pajak}`)}>{links.pajak}</StyledText>
    , ketentuan polis dan beberapa sumber lainnya sesuai dengan kebijakan Prudential. Prudential berhak untuk meninjau, memperbaharui dan mengubah Kamus Asuransi ini sewaktu-waktu dan dengan tanpa pemberitahuan sebelumnya.
  </StyledText>,
];
