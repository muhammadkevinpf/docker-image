/* eslint-disable max-len */
/* eslint-disable no-console */
import { takeLatest } from 'redux-saga/effects';
import { persistencyAction } from './ActionPersistency';
import { apiSagaFunction } from '../../utilities/Functions';
import {
  PERSISTENCY_MAIN_CURRENT, PERSISTENCY_MAIN_HISTORY, PERSISTENCY_GROUPUNIT_LIST, PERSISTENCY_GROUPUNIT_FILTER,
  PERSISTENCY_INDIVIDU_CURRENT_LIST, PERSISTENCY_INDIVIDU_ROLLING_LIST,
  PERSISTENCY_INDIVIDU_CURRENT_FILTER, PERSISTENCY_INDIVIDU_ROLLING_FILTER,
  PERSISTENCY_HISTORY_DETAIL,
} from './ConfigPersistency';

const timeout = 20000;
export const watcherPersistency = [
  takeLatest(PERSISTENCY_MAIN_CURRENT.FETCH, params => apiSagaFunction(params.payload, persistencyAction, PERSISTENCY_MAIN_CURRENT, { timeout })),
  takeLatest(PERSISTENCY_MAIN_HISTORY.FETCH, params => apiSagaFunction(params.payload, persistencyAction, PERSISTENCY_MAIN_HISTORY, { timeout })),

  takeLatest(PERSISTENCY_GROUPUNIT_LIST.FETCH, params => apiSagaFunction(params.payload, persistencyAction, PERSISTENCY_GROUPUNIT_LIST, { timeout })),
  takeLatest(PERSISTENCY_INDIVIDU_CURRENT_LIST.FETCH, params => apiSagaFunction(params.payload, persistencyAction, PERSISTENCY_INDIVIDU_CURRENT_LIST, { timeout })),
  takeLatest(PERSISTENCY_INDIVIDU_ROLLING_LIST.FETCH, params => apiSagaFunction(params.payload, persistencyAction, PERSISTENCY_INDIVIDU_ROLLING_LIST, { timeout })),
  takeLatest(PERSISTENCY_GROUPUNIT_FILTER.FETCH, params => apiSagaFunction(params.payload, persistencyAction, PERSISTENCY_GROUPUNIT_FILTER, { timeout })),
  takeLatest(PERSISTENCY_INDIVIDU_CURRENT_FILTER.FETCH, params => apiSagaFunction(params.payload, persistencyAction, PERSISTENCY_INDIVIDU_CURRENT_FILTER, { timeout })),
  takeLatest(PERSISTENCY_INDIVIDU_ROLLING_FILTER.FETCH, params => apiSagaFunction(params.payload, persistencyAction, PERSISTENCY_INDIVIDU_ROLLING_FILTER, { timeout })),

  takeLatest(PERSISTENCY_HISTORY_DETAIL.FETCH, params => apiSagaFunction(params.payload, persistencyAction, PERSISTENCY_HISTORY_DETAIL)),
];
