import Dictionary from './Dictionary';

export default {
  Dictionary,
};
