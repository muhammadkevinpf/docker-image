import Views from './views';

// Please update Screen in Sub-Menu Components too
export default {
  MainPersistency: { screen: Views.MainPersistency },
  PersistencyGroupUnit: { screen: Views.PersistencyGroupUnit },
  PersistencyIndividu: { screen: Views.PersistencyIndividu },
  PersistencyHistoryScreen: { screen: Views.PersistencyHistoryScreen },
};
