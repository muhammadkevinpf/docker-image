import React from 'react';
import { createBottomTabNavigator, createStackNavigator } from 'react-navigation';
import { StyleSheet, Image } from 'react-native';
import { iconPruexpert } from '../../assets/images';
import Styles from '../../styles';
import * as Views from './views';
import _ from '../../lang';

const ICON_SIZE = 25;

const DashboardStack = createStackNavigator({
  DashboardPruexpert: { screen: Views.DashboardPruexpert },
  CPDPruexpert: { screen: Views.CPDPruexpert },
}, { headerMode: 'none', initialRouteName: 'DashboardPruexpert' });

const TrainingStack = createStackNavigator({
  MyTraining: { screen: Views.MyTraining },
}, { headerMode: 'none', initialRouteName: 'MyTraining' });

const CatalogStack = createStackNavigator({
  Catalog: { screen: Views.MainCatalog },
  VideoPruexpert: { screen: Views.VideoPruexpert },
  CatalogList: { screen: Views.CatalogList },
}, { headerMode: 'none', initialRouteName: 'Catalog' });

const ScheduleStack = createStackNavigator({
  Schedule: { screen: Views.Schedule },
}, { headerMode: 'none', initialRouteName: 'Schedule' });

DashboardStack.navigationOptions = { tabBarLabel: _('Beranda') };
TrainingStack.navigationOptions = { tabBarLabel: _('Training Saya') };
CatalogStack.navigationOptions = { tabBarLabel: _('Katalog') };
ScheduleStack.navigationOptions = { tabBarLabel: _('Jadwal') };

const TabNavigationPruexpert = createBottomTabNavigator({
  PruexpertDashboard: DashboardStack,
  PruexpertTraining: TrainingStack,
  PruexpertCatalog: CatalogStack,
  PruexpertSchedule: ScheduleStack,
}, {
  initialRouteName: 'PruexpertDashboard',
  tabBarOptions: {
    labelStyle: Styles.Main.fontAlbert11,
    activeTintColor: Styles.Color.red,
    inactiveTintColor: Styles.Color.gray83,
    style: {
      borderTopWidth: 0,
      elevation: 10,
      padding: 10,
      shadowOpacity: 1,
      shadowColor: Styles.Color.nativeBaseBorderGray,
      shadowRadius: StyleSheet.hairlineWidth,
      shadowOffset: {
        height: StyleSheet.hairlineWidth,
        width: 0,
      },
      zIndex: 1,
    },
  },
  defaultNavigationOptions: ({ navigation }) => ({
    tabBarOnPress: () => {
      navigation.popToTop();
      navigation.navigate(navigation.state.routeName);
    },
    tabBarIcon: ({ focused }) => {
      const { routeName } = navigation.state;
      if (routeName === 'PruexpertTraining') {
        return <Image source={focused ? iconPruexpert.TrainingEnable : iconPruexpert.TrainingDisable} style={style.icon} />;
      } if (routeName === 'PruexpertCatalog') {
        return <Image source={focused ? iconPruexpert.CatalogEnable : iconPruexpert.CatalogDisable} style={style.icon} />;
      } if (routeName === 'PruexpertSchedule') {
        return <Image source={focused ? iconPruexpert.ScheduleEnable : iconPruexpert.ScheduleDisable} style={style.icon} />;
      } return <Image source={focused ? iconPruexpert.HomeEnable : iconPruexpert.HomeDisable} style={style.icon} />;
    },
  }),
});

const style = StyleSheet.create({
  icon: {
    width: ICON_SIZE,
    height: ICON_SIZE,
  },
});

export default {
  MainPruexpert: TabNavigationPruexpert,
  MyTrainingPDF: { screen: Views.MyTrainingPDFViewer },
  MyTrainingDetails: { screen: Views.MyTrainingDetails },
  PostTestInstruction: { screen: Views.PostTestInstruction },
  PostTest: { screen: Views.PostTest },
  PostTestResult: { screen: Views.PostTestResult },
  CatalogDetails: { screen: Views.CatalogDetails },
};
