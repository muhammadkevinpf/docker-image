/* eslint-disable max-len */
/* eslint-disable react/default-props-match-prop-types */
/**
 * @author: ahmdichsanb@gmail.com
 * Note:
*/

import React, { Component } from 'react';
import {
  Text, FlatList, TouchableHighlight, ScrollView,
} from 'react-native';
import {
  Label, Input, View,
} from 'native-base';
import filter from 'lodash/filter';
import PropTypes from 'prop-types';
import StyleAutocomplete from './StyleAutocomplete';
import Icons from '../icon-native-base';
import Style from '../../styles';
import _ from '../../lang';

class Autocomplete extends Component {
  constructor(props) {
    super(props);
    this.state = {
      inputFieldText: '',
      // eslint-disable-next-line react/no-unused-state
      selectedRow: {},
      errorMessage: this.props.errorMessage,

      // Ichsan
      suggestionList: [],
      isSuggestionOpen: false,
      isOnEdit: false,
      itemHeight: 30,
    };
  }

  // shouldComponentUpdate = (prevProps, prevState) => {
  //   // console.log('autocomplete prev props', prevState.inputFieldText);
  //   // console.log('autocomplete this props', this.state.inputFieldText);
  //   // console.log(prevState.isOnEdit);
  //   let isRender = true;
  //   if (!prevState.isOnEdit && prevState.isOnEdit === this.state.isOnEdit) { isRender = false; }
  //   if (this.props.isProvince && this.props.zipCode !== prevProps.zipCode) { isRender = true; }
  //   if (this.props.selectedValue !== prevProps.selectedValue) { isRender = true; }
  //   return isRender;
  // }

  componentDidMount = () => {
    const { invoke } = this.props;
    if (invoke && !this.props.selectedValue && this.props.isRequired) {
      this.setState({ errorMessage: 'Wajib Diisi!' });
    }
  }

  componentDidUpdate = (prevProps) => {
    if (this.props.invoke !== prevProps.invoke) {
      const errorMessage = this.props.selectedValue === '' ? 'Wajib Diisi!' : '';
      this.handleErrorMessage(errorMessage);
    }
  }

  handleErrorMessage = message => this.setState({ errorMessage: message });

  handleOnPress = (item) => {
    const {
      valueProp, labelProp, onPress,
    } = this.props;
    if (!item[valueProp]) {
      return;
    }

    if (onPress) {
      onPress(item, item[valueProp], item[labelProp]);
    }

    this.setState({
      isSuggestionOpen: false,
      inputFieldText: item[labelProp],
      // eslint-disable-next-line react/no-unused-state
      selectedRow: item,
      errorMessage: '',
    });
  }

  handleOnFocus = (inputText) => {
    const {
      onFocus, dropdownData, valueProp, selectedValue, isDropdown,
    } = this.props;
    const inputFieldText = isDropdown ? inputText : '';
    const selectedRow = (selectedValue ? dropdownData.find(element => element[valueProp] === selectedValue)
      : {});
    this.setState({
      isSuggestionOpen: true,
      suggestionList: dropdownData,
      isOnEdit: true,
      inputFieldText,
      selectedRow,
    }, () => {
      if (onFocus) {
        onFocus(inputFieldText, this.state.suggestionList);
      }
    });
  }

  handleOnBlur = () => {
    const { onBlur, labelProp, isRequired } = this.props;
    const { selectedRow } = this.state;
    let errorMessage = '';
    let inputFieldText;
    if (selectedRow[labelProp]) {
      inputFieldText = selectedRow[labelProp];
    } else if (isRequired) {
      errorMessage = 'Wajib Diisi!';
    }

    this.setState({
      isSuggestionOpen: false, inputFieldText, isOnEdit: false, errorMessage,
    },
    () => {
      if (onBlur) {
        onBlur(this.state.inputFieldText, this.state.suggestionList);
      }
    });
  }

  handleOnChangeText = (inputFieldText) => {
    const {
      dropdownData, valueProp, labelProp, onChangeText,
    } = this.props;

    let suggestionList = filter(dropdownData, item => item[labelProp].toLowerCase().indexOf(inputFieldText.toLowerCase()) > -1);

    if (inputFieldText.length < 1) {
      this.setState({
        inputFieldText, suggestionList: dropdownData, isSuggestionOpen: true, isOnEdit: true,
      });
      return;
    }

    if (suggestionList.length < 1) {
      suggestionList = [{}];
      suggestionList[0][labelProp] = 'Data Tidak Ditemukan';
      suggestionList[0][valueProp] = null;
      this.setState({ inputFieldText, suggestionList, isSuggestionOpen: true },
        () => {
          if (onChangeText) {
            onChangeText(this.state.inputFieldText, this.state.suggestionList);
          }
        });
      return;
    }

    this.setState({ inputFieldText, suggestionList, isSuggestionOpen: true });
  }

  invokeValidation = (_errorMessage) => {
    let { errorMessage } = this.state;

    if (_errorMessage) {
      errorMessage = _errorMessage;
    }
    this.setState({
      errorMessage,
    });
  }

  render() {
    console.log('this autocomplete being rendered');
    const {
      allowFontScaling,
      editable,
      placeholder,
      iosIcon,
      labelStyle,
      bottomLabelStyle,
      errorLabelStyle,
      valueProp,
      labelProp,
      bottomLabel,
      label,
      autoFocus,
      numberOfLines,
      placeholderTextColor,
      style,
      textInputStyle,
      textAlignVertical,
      multiline,
      keyboardType,
      underlayColor,
      selectedValue,
      dropdownData,
      isDropdown,
      styleTextInput,
    } = this.props;
    const {
      errorMessage,
      isSuggestionOpen,
      isOnEdit,
      itemHeight,
    } = this.state;
    let _selectedRow;
    if (selectedValue && dropdownData.length && !isOnEdit) {
      _selectedRow = this.props.dropdownData.find(element => element[valueProp] === selectedValue);
    } else {
      _selectedRow = {};
    }
    const suggestionList = this.state.suggestionList || this.props.dropdownData;
    // eslint-disable-next-line no-nested-ternary
    const inputFieldText = ((isOnEdit) ? this.state.inputFieldText : (_selectedRow ? _selectedRow[labelProp] : ''));

    return (
      <View onTouchStart={isDropdown ? () => this.handleOnFocus(inputFieldText) : null}>
        <View style={[StyleAutocomplete.outerItem, style]}>
          <Label numberOfLines={1} style={[StyleAutocomplete.styleTextLabel, Style.Main.fontAlbert, labelStyle]}>{_(label)}</Label>
          <View style={[StyleAutocomplete.innerItem]}>
            <Input
              // disabled={isDropdown || !editable}
              blurOnSubmit
              allowFontScaling={allowFontScaling}
              autoFocus={autoFocus}
              editable={!isDropdown && editable}
              keyboardType={keyboardType}
              onChangeText={e => this.handleOnChangeText(e)}
              onFocus={() => this.handleOnFocus(inputFieldText)}
              onBlur={() => this.handleOnBlur()}
              value={inputFieldText}
              placeholder={placeholder}
              placeholderTextColor={placeholderTextColor}
              styleTextInput={[StyleAutocomplete.styleTextInput, styleTextInput]}
              numberOfLines={numberOfLines}
              style={[
                selectedValue ? Style.Main.textAlmostBlack : Style.Main.textBrightGray,
                StyleAutocomplete.styleTextInput,
                !editable ? Style.Main.textBrightGray : null,
                { height: itemHeight },
                Style.Main.fontAlbert,
                textInputStyle,
              ]}
              // selection={{ start: 0, end: 0 }}
              textAlignVertical={textAlignVertical}
              multiline={multiline}
              onContentSizeChange={(event) => {
                this.setState({ itemHeight: Math.max(30, event.nativeEvent.contentSize.height) });
              }}
            />
            <Icons name={iosIcon} style={StyleAutocomplete.iconStyle} />
          </View>
        </View>
        {
          isSuggestionOpen && (
            <ScrollView
              keyboardShouldPersistTaps="handled"
              nestedScrollEnabled
            >
              <FlatList
                style={[StyleAutocomplete.flatList]}
                data={suggestionList}
                keyboardShouldPersistTaps="handled"
                keyExtractor={item => item[valueProp]}
                nestedScrollEnabled
                renderItem={({ item, index }) => (
                  <TouchableHighlight
                    onPress={() => this.handleOnPress(item)}
                    underlayColor={underlayColor}
                    key={index}
                  // onBlur={() => this.handleOnBlur()}
                  >
                    <View style={[StyleAutocomplete.suggestionList]}>
                      <Text style={[Style.Main.fontAlbert]}>{item[labelProp]}</Text>
                    </View>
                  </TouchableHighlight>
                )}
              />
            </ScrollView>
          )
        }
        {errorMessage !== '' && !isSuggestionOpen ?
          (<Text style={[StyleAutocomplete.styleBottomLabel, Style.Main.fontAlbert, errorLabelStyle]}>{_(errorMessage)}</Text>) :
          null}
        {bottomLabel.length !== 0 ?
          (
            bottomLabel.map(element => (
              <Text key={element.toString()} style={[StyleAutocomplete.styleBottomLabel, Style.Main.fontAlbert, bottomLabelStyle]}>{_(element)}</Text>
            ))
          )
          : null}
      </View>
    );
  }
}

Autocomplete.propTypes = {
  placeholder: PropTypes.string,
  iosIcon: PropTypes.string,
  // inputFieldText: PropTypes.string,
  dropdownData: PropTypes.arrayOf(PropTypes.object).isRequired,
  labelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  bottomLabelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  errorLabelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  labelProp: PropTypes.string,
  valueProp: PropTypes.string,
  isRequired: PropTypes.bool,
  errorMessage: PropTypes.string,
  bottomLabel: PropTypes.arrayOf(PropTypes.string),
  label: PropTypes.string,

  // forInputField
  allowFontScaling: PropTypes.bool,
  autoFocus: PropTypes.bool,
  numberOfLines: PropTypes.number,
  placeholderTextColor: PropTypes.string,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  styleTextInput: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  textAlignVertical: PropTypes.string,
  // editable: PropTypes.bool,
  onChangeText: PropTypes.func,
  onFocus: PropTypes.func,
  onBlur: PropTypes.func,

  // from Ichsan
  underlayColor: PropTypes.string,
  onPress: PropTypes.func,
  multiline: PropTypes.bool,
  keyboardType: PropTypes.string,
  isDropdown: PropTypes.bool,
  invoke: PropTypes.bool,
};

Autocomplete.defaultProps = {
  placeholder: 'Select',
  iosIcon: 'caret-down',
  // inputFieldText: null,
  labelStyle: null,
  bottomLabelStyle: Style.Main.textRed,
  errorLabelStyle: Style.Main.textRed,
  labelProp: 'label',
  valueProp: 'value',
  isRequired: true,
  errorMessage: '',
  bottomLabel: [],
  label: null,
  zipCode: '',
  isProvince: false,

  // forInputField
  allowFontScaling: false,
  autoFocus: false,
  numberOfLines: 1,
  textAlignVertical: 'bottom',
  editable: true,
  style: null,
  placeholderTextColor: Style.Main.textBrightGray.color,
  onChangeText: () => { },
  onFocus: () => { },
  onBlur: () => { },

  // from Ichsan
  underlayColor: '#E0E0E0',
  onPress: () => { },
  styleTextInput: null,
  multiline: false,
  keyboardType: 'default',
  isDropdown: false,
  invoke: false,
};

export default Autocomplete;
