import React, { Component } from 'react';
import { Button, Text } from 'native-base';
import Icon from 'react-native-vector-icons/FontAwesome';
import PropTypes from 'prop-types';
import Style from '../../../styles';
import _ from '../../../lang';

class CustomButton extends Component {
  shouldComponentUpdate(nextProps) {
    if (JSON.stringify(nextProps) !== JSON.stringify(this.props)) return true;
    return false;
  }

  render() {
    return (
      <Button
        androidRippleColor="red"
        transparent={this.props.transparent}
        block={this.props.block}
        badge={this.props.badge}
        danger={this.props.danger}
        disabled={this.props.disabled}
        style={[
          Style.Main.btnPrimary,
          Style.Main.fullWidth,
          Style.Main.justifyCenter,
          Style.Main.alignContentCenter,
          this.props.style,
          this.props.disabled && Style.Main.halfOpacity,
        ]}
        onPress={this.props.onPress}
      >
        {
          this.props.iconName &&
          <Icon
            size={this.props.iconSize}
            color={this.props.iconColor}
            name={this.props.iconName}
            style={[Style.Main.textAlignCenter, this.props.iconStyle]}
            onPress={this.props.onPress}
          />
        }
        {
          this.props.label &&
          <Text style={[Style.Main.textCenter, this.props.labelStyle]}>
            {_(this.props.label)}
          </Text>
        }
      </Button>
    );
  }
}

CustomButton.propTypes = {
  transparent: PropTypes.bool,
  block: PropTypes.bool,
  badge: PropTypes.bool,
  danger: PropTypes.bool,
  disabled: PropTypes.bool,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  iconName: PropTypes.string,
  iconColor: PropTypes.string,
  iconSize: PropTypes.number,
  label: PropTypes.string,
  onPress: PropTypes.func,
};

CustomButton.defaultProps = {
  transparent: false,
  block: false,
  badge: false,
  danger: false,
  disabled: false,
  style: null,
  iconName: null,
  iconColor: '#000000',
  iconSize: 18,
  label: null,
  onPress: () => {},
};

export default CustomButton;
