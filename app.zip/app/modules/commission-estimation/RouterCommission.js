import Views from './views';

// Please update Screen in Sub-Menu Components too
export default {
  MainCommissionEstimation: { screen: Views.MainCommissionEstimation },
};
