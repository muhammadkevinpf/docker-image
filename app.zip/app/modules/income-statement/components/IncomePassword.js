import React from 'react';
import { Modal, TouchableOpacity } from 'react-native';
import { View, Text } from 'native-base';
import { isEmpty, isTablet } from '../../../utilities';
import Style from '../../../styles';
import _ from '../../../lang';

export const IncomePassword = ({
  visible, onRequestClose, downloadedFile, passwordFormat, passwordExample, showDisclaimer,
}) => (
  <Modal transparent visible={visible} onRequestClose={onRequestClose}>
    <View
      style={[
        Style.Main.center,
        Style.Main.container,
        Style.Main.backgroundLightSmoke]}
    >
      <View
        style={[Style.Main.backgroundWhiteSmoke, isTablet() ? Style.Main.width25pr : Style.Main.width90pr, Style.Main.padding15,
          Style.Main.borderRadius5, Style.Main.justifySpaceBetween]}
      >
        {
          !isEmpty(downloadedFile) &&
          <>
            <Text style={[Style.Main.setFontAlbertBold(16, Style.Color.black)]}>Download</Text>
            <Text style={[Style.Main.setFontAlbert(14, Style.Color.black), Style.Main.mb15]}>
              {_('Download File Berhasil tersimpan di folder:')} {downloadedFile}
            </Text>
          </>
        }
        <Text style={[Style.Main.setFontAlbert(14, Style.Color.black), !downloadedFile && Style.Main.textAlignCenter]}>
          {_('Format password untuk membuka File anda adalah ')}
          <Text style={[Style.Main.fontAlbertBold14, Style.Main.textBlack]}>{passwordFormat} </Text>
          ({_('contoh')}: <Text style={[Style.Main.fontAlbertBold14, Style.Main.textBlack]}>{passwordExample} </Text>), {_('dimana')} :
        </Text>
        <View style={[Style.Main.fullWidth]}>
          <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.mt10]}>
            <Text style={[Style.Main.textBlack, Style.Main.fontAlbertBold14, Style.Main.width60]}>dd</Text>
            <Text style={[Style.Main.textBlack, Style.Main.fontAlbert14, Style.Main.mr10]}>:</Text>
            <Text style={[Style.Main.textBlack, Style.Main.fontAlbert14, Style.Main.container, Style.Main.textJustify]}>
              {_('Dua digit tanggal lahir Anda, contoh: 01')}
            </Text>
          </View>
          <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.mt10]}>
            <Text style={[Style.Main.textBlack, Style.Main.fontAlbertBold14, Style.Main.width60]}>Mmm</Text>
            <Text style={[Style.Main.textBlack, Style.Main.fontAlbert14, Style.Main.mr10]}>:</Text>
            <Text style={[Style.Main.textBlack, Style.Main.fontAlbert14, Style.Main.container, Style.Main.textJustify]}>
              {
                // eslint-disable-next-line max-len
                _('Tiga huruf pertama bulan lahir Anda dalam bahasa Inggris diawali dengan huruf besar, contoh: Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec')
              }
            </Text>
          </View>
          <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.mt10]}>
            <Text style={[Style.Main.textBlack, Style.Main.fontAlbertBold14, Style.Main.width60]}>yyyy</Text>
            <Text style={[Style.Main.textBlack, Style.Main.fontAlbert14, Style.Main.mr10]}>:</Text>
            <Text style={[Style.Main.textBlack, Style.Main.fontAlbert14, Style.Main.container, Style.Main.textJustify]}>
              {_('Tahun lahir Anda, contoh: 1970')}
            </Text>
          </View>
        </View>
        {
          showDisclaimer && (
            <React.Fragment>
              <View style={[Style.Main.rowDirection, Style.Main.mt30]}>
                <Text style={[Style.Main.textBlack, Style.Main.fontAlbert14, Style.Main.container, Style.Main.textAlignLeft, Style.Main.italic]}>
                  {_(
                    // eslint-disable-next-line max-len
                    '1. Segala data dan/atau informasi terkait Nasabah yang diperoleh melalui sistem PRUFast, termasuk namun tidak terbatas pada informasi polis, transaksi polis, dll merupakan data dan/atau informasi terkini yang bersifat rahasia milik PT Prudential Life Assurance dan digunakan hanya untuk keperluan penjualan produk PT Prudential Life Assurance dalam kaitannya dengan kerja sama penjualan produk asuransi dengan bank rekanan.',
                  )}
                </Text>
              </View>
              <View style={[Style.Main.rowDirection, Style.Main.mt5]}>
                <Text style={[Style.Main.textBlack, Style.Main.fontAlbert14, Style.Main.container, Style.Main.textAlignLeft, Style.Main.italic]}>
                  {_(
                    // eslint-disable-next-line max-len
                    '2. PT Prudential Life Assurance tidak bertanggungjawab terhadap penyalahgunaan data dan informasi terkait Nasabah oleh Tenaga Pemasar. Ketentuan tentang kerahasiaan data diatur dan tunduk pada Kode Etik dan kontrak kerja Tenaga Pemasar.',
                  )}
                </Text>
              </View>
            </React.Fragment>
          )
        }
        {
          isEmpty(downloadedFile) ?
            <TouchableOpacity
              activeOpacity={1}
              style={[Style.Main.backgroundRed, Style.Main.justifyCenter, Style.Main.borderRadius5, Style.Main.mt30]}
              onPress={onRequestClose}
            >
              <Text style={[Style.Main.font16, Style.Main.mV10, Style.Main.textWhite, Style.Main.fontAlbert, Style.Main.textAlignCenter]}>
                {_('OK')}
              </Text>
            </TouchableOpacity> :
            <Text onPress={onRequestClose} style={[Style.Main.setFontAlbertBold(16, Style.Color.black), Style.Main.alignRight, Style.Main.mt30]}>
              {_('Tutup')}
            </Text>
        }
      </View>
    </View>
  </Modal>
);
