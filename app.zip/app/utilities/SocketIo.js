import { Alert } from 'react-native';
import io from 'socket.io-client';

import _ from '../lang';


// CONFIGURATION
// const SERVER_URL = 'http://192.168.43.190:3000';
const SERVER_URL = 'http://10.170.49.21:9080';
const MAX_RETRY_ATTEMPT = 3;
// in millisecond
const RETRY_ATTEMPT_TIMEOUT = 3000;

const RECONNECTION_CONFIG = {
  reconnection: true,
  reconnectionDelay: RETRY_ATTEMPT_TIMEOUT,
  reconnectionAttempts: MAX_RETRY_ATTEMPT,
};

export const startSocketIO = async (onConnected, onDisconnected) => {
  const socket = io(SERVER_URL, {
    autoConnect: true,
    ...RECONNECTION_CONFIG,
  });
  // const { sockets } = socket;
  socket.connect();

  // if (socket.connected) {
  //   console.log('connected to server.');
  //   if (onConnected) {
  //     onConnected(socket);
  //   }
  // }

  socket.on('connecting', () => {
    console.log('connecting to server.');
  });

  socket.on('connect', () => {
    console.log('connected to server.');
    if (onConnected) {
      onConnected(socket);
    }
  });

  socket.on('disconnect', (reason) => {
    console.log('connection to server lost.', reason);
    if (onDisconnected) {
      onDisconnected(socket);
    }
  });


  // return socket;
};

export const getConnectionStatus = socket => socket.status;

export const stopSocketIO = (socket, onDisconnected) => {
  // const { sockets } = socket;
  if (socket.connected) {
    socket.disconnect();
  }
  if (onDisconnected) {
    onDisconnected();
  }
};

export const sendDataToAPI = (socket, action) => {
  const { status } = socket;
  if (status) {
    action();
  } else {
    Alert.alert(
      _('Connection is Offline'),
      _('Your device is not connected to server.'),
      [
        {
          text: _('Oke'),
        },
        {
          text: _('Retry'),
          onPress: () => {
            this.startSocketIO(this.sendDataToAPI(socket, action));
          },
        },
      ],
    );
  }
};
