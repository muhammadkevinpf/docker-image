/**
 * @author: dwi.setiyadi@gmail.com
*/


import LocaleGlobal from '../lang/LocaleGlobal';
import LocaleNotification from '../modules/notification/LocaleNotification';

export const Locale = [
  ...LocaleGlobal,
  ...LocaleNotification,
];

export const Availability = [
  'id',
  'en',
];
