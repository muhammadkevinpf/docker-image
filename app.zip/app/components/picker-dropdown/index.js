/* eslint-disable no-console */
/**
 * improve component dropdown picker from ahmdichsanb@gmail.com
 * use picker from native base
 * on Android one item picker is added in the first value to be used as a placeholder
*/

import React, { PureComponent, Fragment } from 'react';
import {
  Platform,
} from 'react-native';
import {
  Content, Picker,
} from 'native-base';
import PropTypes from 'prop-types';
import StylePicker from './StylePicker';
import Icons from '../icon-native-base';

class PickerDropdown extends PureComponent {
  render() {
    const {
      mode,
      enabled,
      placeholder,
      iosIcon,
      stylePickerBody,
      stylePickerView,
      dropdownData,
      selectedValue,
      textColor,
      valueProperty,
      labelProperty,
    } = this.props;

    const dropdown = dropdownData.map((item, index) => {
      const label = item[labelProperty];
      const value = item[valueProperty];
      const order = index;
      return (
        <Picker.Item key={order} label={label} value={value} color={textColor} />
      );
    });

    const androidPicker = (
      <Content style={stylePickerView} keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
        <Picker
          mode={mode}
          style={stylePickerBody}
          iosIcon={<Icons name={iosIcon} />}
          selectedValue={selectedValue}
          value={value}
          onValueChange={e => (this.props.handleDropdownValue ? this.props.handleDropdownValue(e) : console.log('nothing'))}
          enabled={enabled}
          placeholder={placeholder}
        >
          {<Picker.Item label={placeholder} value="" color={textColor} />}
          {dropdown}
        </Picker>
      </Content>
    );

    const iosPicker = (
      <Content style={stylePickerView} keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
        <Picker
          mode={mode}
          iosIcon={<Icons name={iosIcon} />}
          selectedValue={selectedValue}
          value={value}
          style={stylePickerBody}
          onValueChange={e => this.props.handleDropdownValue(e)}
          enabled={enabled}
          placeholder={placeholder}
        >
          {dropdown}
        </Picker>
      </Content>
    );

    const value = dropdownData.find(e => e[valueProperty] === selectedValue);

    return (
      <Fragment>
        {
          Platform.OS === 'ios' ? iosPicker : androidPicker
        }
      </Fragment>
    );
  }
}

PickerDropdown.propTypes = {
  enabled: PropTypes.bool,
  placeholder: PropTypes.string,
  mode: PropTypes.string,
  iosIcon: PropTypes.string,
  selectedValue: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
  ]).isRequired,
  dropdownData: PropTypes.arrayOf(PropTypes.object).isRequired,
  stylePickerBody: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  stylePickerView: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  labelProperty: PropTypes.string,
  valueProperty: PropTypes.string,
};

PickerDropdown.defaultProps = {
  enabled: true,
  placeholder: 'Enter',
  mode: 'dropdown',
  iosIcon: 'caret-down',
  stylePickerBody: StylePicker.stylePickerBody, // default picker width is 100%
  stylePickerView: StylePicker.stylePickerView, // default picker use border bottom
  labelProperty: 'label',
  valueProperty: 'value',
};

export default PickerDropdown;
