import React from 'react';
import WebView from 'react-native-webview';
import PropTypes from 'prop-types';
import {
  Button, Footer, FooterTab, Text, View,
} from 'native-base';
import { Modal } from 'react-native';
import { isTablet, isText } from '../../utilities';
import OutlineCheckbox from '../outline-checkbox';
import Style from '../../styles';
import _ from '../../lang';

class DisclaimerCheckbox extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      wasRead: false,
      showModal: false,
      isModalButtonDisabled: true,
    };
  }

  closeModal = (endReached) => {
    this.setState(prevState => ({ showModal: false, wasRead: endReached === undefined ? prevState.wasRead : endReached }),
      () => this.props.onPress(this.state.wasRead));
  }

  onMessage = (data) => { if (data.nativeEvent.data === 'setButtonOn') this.setState({ isModalButtonDisabled: false }); }

  render() {
    const { wasRead, showModal, isModalButtonDisabled } = this.state;
    const {
      label, labelStyle, style, modalLabel, modalHtmlContent, modalHeaderStyle, modalLabelStyle,
    } = this.props;
    // eslint-disable-next-line max-len
    const JavaScript = "window.onload=function(){ console.log(this);console.log(document.body.clientHeight + ' + ' + document.body.scrollTop + ' = ' + ((document.body.clientHeight + 1) + document.body.scrollTop) + '/' + document.body.scrollHeight); if((document.body.clientHeight + 1) + document.body.scrollTop >= document.body.scrollHeight){window.ReactNativeWebView.postMessage('setButtonOn');}}; window.onscroll=window.onload; var ready = function ( fn ) {if ( typeof fn !== 'function' ) return;if ( document.readyState === 'complete'  ) {return fn();}document.addEventListener( 'interactive', fn, false );}; ready(window.onload); true;";
    return (
      <View style={[Style.Main.container, Style.Main.mV2, style]}>
        <OutlineCheckbox
          checked={wasRead}
          onPress={() => this.setState({ showModal: true })}
          onPressLabel={() => this.setState({ showModal: true })}
          label={isText(label) ? _(label) : label}
          style={[Style.Main.container]}
          styleLabel={[Style.Main.setFontAlbert(14, Style.Color.blue), labelStyle]}
        />
        <Modal
          animated
          animationType="slide"
          onRequestClose={this.closeModal}
          presentationStyle="fullScreen"
          visible={showModal}
        >
          <View style={[Style.Main.backgroundRed, Style.Main.ph15, Style.Main.height100, modalHeaderStyle]}>
            <Text style={[isTablet() ? [Style.Main.font20, Style.Main.fontAlbert] : Style.Main.fontAlbert14, Style.Main.textWhite,
              Style.Main.textCenter, Style.Main.textAlignVerticalCenter, modalLabelStyle]}
            >{_(modalLabel || label)}
            </Text>
          </View>
          <WebView
            source={{ baseUrl: '', html: modalHtmlContent }}
            originWhitelist={['*']}
            javaScriptEnabled
            onMessage={this.onMessage}
            injectedJavaScript={JavaScript}
          />
          <Footer style={[Style.Main.footerHeight]}>
            <FooterTab>
              <Button
                disabled={isModalButtonDisabled}
                style={[Style.Main.btnPrimary, Style.Main.mH12, isModalButtonDisabled && Style.Main.halfOpacity]}
                onPress={() => this.closeModal(true)}
              ><Text style={[Style.Main.fontAlbert16, Style.Main.textWhite]}>{_('SELESAI')}</Text>
              </Button>
            </FooterTab>
          </Footer>
        </Modal>
      </View>
    );
  }
}

DisclaimerCheckbox.propTypes = {
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.func, PropTypes.object]),
  modalLabel: PropTypes.oneOfType([PropTypes.string, PropTypes.func, PropTypes.object]),
  modalHtmlContent: PropTypes.oneOfType([PropTypes.string, PropTypes.func, PropTypes.object]),
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  labelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  modalLabelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  modalHeaderStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  onPress: PropTypes.func,
};

DisclaimerCheckbox.defaultProps = {
  label: '',
  modalLabel: '',
  modalHtmlContent: '',
  style: null,
  labelStyle: null,
  modalLabelStyle: null,
  modalHeaderStyle: null,
  onPress: () => {},
};

export default DisclaimerCheckbox;
