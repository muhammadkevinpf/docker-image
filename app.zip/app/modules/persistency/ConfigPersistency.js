export const persistencyCard = {
  individu: 'I',
  unit: 'U',
  group: 'G',
};

export const persistencyGroupUnitSort = [
  { value: ['PrsctyDesc', 'current'], label: 'Persistensi Lama Tertinggi', type: 'current' },
  { value: ['PrsctyAsc', 'current'], label: 'Persistensi Lama Terendah', type: 'current' },
  { value: ['LapsedApi', 'current'], label: 'Lapsed API Persistensi Lama Tertinggi', type: 'current' },
  { value: ['DecreasedApi', 'current'], label: 'Penurunan API Persistensi Lama Tertinggi', type: 'current' },
  { value: ['PrsctyDesc', 'rolling'], label: 'Rolling Persistensi Tertinggi', type: 'rolling' },
  { value: ['PrsctyAsc', 'rolling'], label: 'Rolling Persistensi Terendah', type: 'rolling' },
  { value: ['LapsedApi', 'rolling'], label: 'Lapsed API Rolling Persistensi Tertinggi', type: 'rolling' },
  { value: ['DecreasedApi', 'rolling'], label: 'Penurunan API Rolling Persistensi Tertinggi', type: 'rolling' },
];

export const persistencyIndividuSort = [
  { value: 'policyHolderName', label: 'Nama Pemegang Polis' },
  { value: 'policyNumber', label: 'Nomor Pemegang Polis' },
  { value: 'lapsedApi', label: 'Lapsed API Tertinggi' },
  { value: 'decreasedApi', label: 'Penurunan API Tertinggi' },
];

// MAIN PERSISTENCY
export const PERSISTENCY_MAIN_CURRENT = {
  API: 'adapters/HTTPAdapterInquiry/findPersistencyGraphCR',
  FETCH: 'PERSISTENCY_MAIN_CURRENT_FETCH',
  SUCCESS: 'PERSISTENCY_MAIN_CURRENT_SUCCESS',
  FAILED: 'PERSISTENCY_MAIN_CURRENT_FAILED',
};

export const PERSISTENCY_MAIN_HISTORY = {
  API: 'adapters/HTTPAdapterInquiry/findAllPersistencyHistory',
  FETCH: 'PERSISTENCY_MAIN_HISTORY_FETCH',
  SUCCESS: 'PERSISTENCY_MAIN_HISTORY_SUCCESS',
  FAILED: 'PERSISTENCY_MAIN_HISTORY_FAILED',
};

// PERSISTENCY DETAILS
export const PERSISTENCY_GROUPUNIT_LIST = {
  API: 'adapters/HTTPAdapterInquiry/findAllPersistencyCR',
  FETCH: 'PERSISTENCY_GROUPUNIT_LIST_FETCH',
  SUCCESS: 'PERSISTENCY_GROUPUNIT_LIST_SUCCESS',
  FAILED: 'PERSISTENCY_GROUPUNIT_LIST_FAILED',
};

export const PERSISTENCY_INDIVIDU_CURRENT_LIST = {
  API: 'adapters/HTTPAdapterInquiry/findAllPolicyCurrent',
  FETCH: 'PERSISTENCY_INDIVIDU_CURRENT_LIST_FETCH',
  SUCCESS: 'PERSISTENCY_INDIVIDU_CURRENT_LIST_SUCCESS',
  FAILED: 'PERSISTENCY_INDIVIDU_CURRENT_LIST_FAILED',
};

export const PERSISTENCY_INDIVIDU_ROLLING_LIST = {
  API: 'adapters/HTTPAdapterInquiry/findAllPolicyRolling',
  FETCH: 'PERSISTENCY_INDIVIDU_ROLLING_LIST_FETCH',
  SUCCESS: 'PERSISTENCY_INDIVIDU_ROLLING_LIST_SUCCESS',
  FAILED: 'PERSISTENCY_INDIVIDU_ROLLING_LIST_FAILED',
};

export const PERSISTENCY_GROUPUNIT_FILTER = {
  API: 'adapters/HTTPAdapterInquiry/findAllAgentTypeCR',
  FETCH: 'PERSISTENCY_GROUPUNIT_FILTER_FETCH',
  SUCCESS: 'PERSISTENCY_GROUPUNIT_FILTER_SUCCESS',
  FAILED: 'PERSISTENCY_GROUPUNIT_FILTER_FAILED',
};

export const PERSISTENCY_INDIVIDU_CURRENT_FILTER = {
  API: 'adapters/HTTPAdapterInquiry/findAllPolicyStatusCurrent',
  FETCH: 'PERSISTENCY_INDIVIDU_CURRENT_FILTER_FETCH',
  SUCCESS: 'PERSISTENCY_INDIVIDU_CURRENT_FILTER_SUCCESS',
  FAILED: 'PERSISTENCY_INDIVIDU_CURRENT_FILTER_FAILED',
};

export const PERSISTENCY_INDIVIDU_ROLLING_FILTER = {
  API: 'adapters/HTTPAdapterInquiry/findAllPolicyStatusRolling',
  FETCH: 'PERSISTENCY_INDIVIDU_ROLLING_FILTER_FETCH',
  SUCCESS: 'PERSISTENCY_INDIVIDU_ROLLING_FILTER_SUCCESS',
  FAILED: 'PERSISTENCY_INDIVIDU_ROLLING_FILTER_FAILED',
};

export const PERSISTENCY_HISTORY_DETAIL = {
  API: 'adapters/HTTPAdapterInquiry/findAllPersistencyHistoryDetail',
  FETCH: 'PERSISTENCY_HISTORY_DETAIL_FETCH',
  SUCCESS: 'PERSISTENCY_HISTORY_DETAIL_SUCCESS',
  FAILED: 'PERSISTENCY_HISTORY_DETAIL_FAILED',
};

export const CLEAR_PERSISTENCY_GROUPUNIT_LIST = 'CLEAR_PERSISTENCY_GROUPUNIT_LIST';
export const CLEAR_PERSISTENCY_INDIVIDU_CURRENT_LIST = 'CLEAR_PERSISTENCY_INDIVIDU_CURRENT_LIST';
export const CLEAR_PERSISTENCY_INDIVIDU_ROLLING_LIST = 'CLEAR_PERSISTENCY_INDIVIDU_ROLLING_LIST';
export const CLEAR_PERSISTENCY_GROUPUNIT_FILTER = 'CLEAR_PERSISTENCY_GROUPUNIT_FILTER';
export const CLEAR_PERSISTENCY_INDIVIDU_CURRENT_FILTER = 'CLEAR_PERSISTENCY_INDIVIDU_CURRENT_FILTER';
export const CLEAR_PERSISTENCY_INDIVIDU_ROLLING_FILTER = 'CLEAR_PERSISTENCY_INDIVIDU_ROLLING_FILTER';
export const CLEAR_PERSISTENCY_HISTORY_DETAILS = 'CLEAR_PERSISTENCY_HISTORY_DETAILS';
