/**
 * @author Dwi Setiyadi
 */

import { StyleSheet } from 'react-native';
import Styles from '../../styles';

const Style = StyleSheet.create({
  MainContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  offline: {
    fontSize: 20,
    textAlign: 'center',
    backgroundColor: Styles.Color.red,
  },
  online: {
    fontSize: 20,
    textAlign: 'center',
    backgroundColor: Styles.Color.green,
  },
});

export default Style;
