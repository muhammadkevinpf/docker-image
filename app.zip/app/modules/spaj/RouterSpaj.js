import ViewsSpaj from './views';

export default {
  IntroSpaj: { screen: ViewsSpaj.IntroSpaj },
  CustomerDataSpaj: { screen: ViewsSpaj.CustomerDataSpaj },
  BMISpaj: { screen: ViewsSpaj.BMISpaj },
  PayorDataSpaj: { screen: ViewsSpaj.PayorDataSpaj },
  LandingTest: { screen: ViewsSpaj.LandingTest },
  SpajTopup: { screen: ViewsSpaj.SpajTopup },
  SpajTopupDetail: { screen: ViewsSpaj.SpajTopupDetail },
  SpajDocument: { screen: ViewsSpaj.SpajDocument },
  ProspectiveBeneficiaries: { screen: ViewsSpaj.ProspectiveBeneficiaries },
  SpajMagnumMedicalData: { screen: ViewsSpaj.MagnumMedicalData },
  SpajAmandemen: { screen: ViewsSpaj.SpajAmandemen },
  SignatureSqs: { screen: ViewsSpaj.SignatureSqs },
  SignatureSpaj: { screen: ViewsSpaj.SignatureSpaj },
  SpajEula: { screen: ViewsSpaj.SpajEula },
  SpajPembayaran: { screen: ViewsSpaj.SpajPembayaran },
  PaymentConfirmation: { screen: ViewsSpaj.PaymentConfirmation },
  SubmitSpaj: { screen: ViewsSpaj.SubmitSpaj },
  NavigationSpaj: { screen: ViewsSpaj.NavigationsSpaj },
  SuratKeterikatanAsuransi: { screen: ViewsSpaj.SuratKeterikatanAsuransi },
};
