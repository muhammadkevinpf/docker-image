/* eslint-disable max-len */
import { requestStatus } from '../../utilities/ApiConnection';
import {
  GET_CORRESPONDENCE, GET_LETTER_TYPE, GET_DOCUMENT_CATEGORY, CLEAR_CORRESPONDENCE, GET_PASSWORD_INFO, GET_PDF_DOCUMENT, GET_DOC_CATEGORY, GET_DOC_BY_ID, GET_DOC_BASE64, SEND_DOC_BY_EMAIL,
} from './ConfigCorrespondence';

const initialStateCorrespondence = {
  // status
  correspondenceListStatus: requestStatus.IDLE,
  letterTypeStatus: requestStatus.IDLE,
  docCategoryStatus: requestStatus.IDLE,
  passwordInfoStatus: requestStatus.IDLE,
  pdfDocStatus: requestStatus.IDLE,

  // result
  correspondenceList: [],
  letterType: [],
  docCategory: [],
  passwordInfo: [],
  pdfDoc: [],

  // download file
  downloadFile: {
    status: requestStatus.IDLE, statusFilter: requestStatus.IDLE, data: [], filter: [],
  },
  document: { status: requestStatus.IDLE, data: {} },
  sendEmail: { status: requestStatus.IDLE, data: {} },

  error: null,
  send: null,
};

export function ReducerCorrespondence(state = initialStateCorrespondence, action) {
  switch (action.type) {
    case GET_CORRESPONDENCE.FETCH: return { ...state, correspondenceListStatus: requestStatus.FETCH, send: action.payload };
    case GET_CORRESPONDENCE.SUCCESS: return {
      ...state,
      correspondenceListStatus: requestStatus.SUCCESS,
      correspondenceList: action.payload,
    };
    case GET_CORRESPONDENCE.FAILED: return { ...state, correspondenceListStatus: requestStatus.FAILED, error: action.payload };

    case GET_LETTER_TYPE.FETCH: return { ...state, letterTypeStatus: requestStatus.FETCH, send: action.payload };
    case GET_LETTER_TYPE.SUCCESS: return {
      ...state,
      letterTypeStatus: requestStatus.SUCCESS,
      letterType: action.payload,
    };
    case GET_LETTER_TYPE.FAILED: return { ...state, letterTypeStatus: requestStatus.FAILED, error: action.payload };

    case GET_DOCUMENT_CATEGORY.FETCH: return { ...state, docCategoryStatus: requestStatus.FETCH, send: action.payload };
    case GET_DOCUMENT_CATEGORY.SUCCESS: return {
      ...state,
      docCategoryStatus: requestStatus.SUCCESS,
      docCategory: action.payload,
    };
    case GET_DOCUMENT_CATEGORY.FAILED: return { ...state, docCategoryStatus: requestStatus.FAILED, error: action.payload };

    case GET_PASSWORD_INFO.FETCH: return { ...state, passwordInfoStatus: requestStatus.FETCH, send: action.payload };
    case GET_PASSWORD_INFO.SUCCESS: return {
      ...state,
      passwordInfoStatus: requestStatus.SUCCESS,
      passwordInfo: action.payload,
    };
    case GET_PASSWORD_INFO.FAILED: return { ...state, passwordInfoStatus: requestStatus.FAILED, error: action.payload };

    case GET_PDF_DOCUMENT.FETCH: return { ...state, pdfDocStatus: requestStatus.FETCH, send: action.payload };
    case GET_PDF_DOCUMENT.SUCCESS: return {
      ...state,
      pdfDocStatus: requestStatus.SUCCESS,
      pdfDoc: action.payload,
    };
    case GET_PDF_DOCUMENT.FAILED: return { ...state, pdfDocStatus: requestStatus.FAILED, error: action.payload };

    case GET_DOC_CATEGORY.FETCH: return { ...state, downloadFile: { ...state.downloadFile, statusFilter: requestStatus.FETCH } };
    case GET_DOC_CATEGORY.SUCCESS: return {
      ...state,
      downloadFile: {
        ...state.downloadFile,
        statusFilter: requestStatus.SUCCESS,
        filter: action.payload,
      },
    };
    case GET_DOC_CATEGORY.FAILED: return { ...state, error: action.payload, downloadFile: { ...state.downloadFile, statusFilter: requestStatus.FAILED } };

    case GET_DOC_BY_ID.FETCH: return { ...state, downloadFile: { ...state.downloadFile, status: requestStatus.FETCH } };
    case GET_DOC_BY_ID.SUCCESS: return {
      ...state,
      downloadFile: {
        ...state.downloadFile,
        status: requestStatus.SUCCESS,
        data: state.downloadFile.data.length ? [...state.downloadFile.data, ...action.payload.filter(x => !state.downloadFile.data.some(item => item.document_id === x.id))]
          : action.payload,
      },
    };
    case GET_DOC_BY_ID.FAILED: return { ...state, error: action.payload, downloadFile: { ...state.downloadFile, status: requestStatus.FAILED } };

    case GET_DOC_BASE64.FETCH: return { ...state, document: { ...state.document, status: requestStatus.FETCH } };
    case GET_DOC_BASE64.SUCCESS: return { ...state, document: { status: requestStatus.SUCCESS, data: action.payload } };
    case GET_DOC_BASE64.FAILED: return { ...state, error: action.payload, document: { ...state.document, status: requestStatus.FAILED } };

    case SEND_DOC_BY_EMAIL.FETCH: return { ...state, sendEmail: { ...state.sendEmail, status: requestStatus.FETCH } };
    case SEND_DOC_BY_EMAIL.SUCCESS: return { ...state, sendEmail: { status: requestStatus.SUCCESS, data: action.payload } };
    case SEND_DOC_BY_EMAIL.FAILED: return { ...state, error: action.payload, sendEmail: { ...state.sendEmail, status: requestStatus.FAILED } };

    case CLEAR_CORRESPONDENCE.LIST: return { ...state, correspondenceListStatus: requestStatus.IDLE, correspondenceList: [] };
    case CLEAR_CORRESPONDENCE.LETTER_TYPE: return { ...state, letterTypeStatus: requestStatus.IDLE, letterType: [] };
    case CLEAR_CORRESPONDENCE.DOC_CATEGORY: return { ...state, docCategoryStatus: requestStatus.IDLE, docCategory: [] };
    case CLEAR_CORRESPONDENCE.PASS_INFO: return { ...state, passwordInfoStatus: requestStatus.IDLE, passwordInfo: [] };
    case CLEAR_CORRESPONDENCE.PDF_DOC: return { ...state, pdfDocStatus: requestStatus.IDLE, pdfDoc: [] };
    case CLEAR_CORRESPONDENCE.DOWNLOAD_LIST: return { ...state, downloadFile: { ...state.downloadFile, status: requestStatus.IDLE, data: [] } };

    default:
      return state;
  }
}
