/**
 * @author: dwi.setiyadi@gmail.com
*/

import { StyleSheet } from 'react-native';
import color from 'color';
import Styles from '../../styles';

export default StyleSheet.create({
  searchPrimary: {
    backgroundColor: color(Styles.Color.lightGray).lighten(0.99).hex(),
    borderRadius: 30,
    shadowColor: Styles.Color.black,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    marginTop: 10,
    marginLeft: 10,
    marginRight: 10,
  },
});
