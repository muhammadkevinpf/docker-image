/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import {
  Content, View, Button, Text,
} from 'native-base';
import { Row, Col } from 'react-native-easy-grid';
import {
  VictoryChart,
  VictoryGroup,
  VictoryLine,
  VictoryTheme,
} from 'victory-native';

import _ from '../../../lang';

import Style from '../../../styles';
// import StyleDashboard from '../StyleDashboard';

class LineChartDashboard extends Component {
  // constructor(props) {
  //   super(props);
  //   this.state = {
  //     data: [],
  //   };
  // }

  render() {
    return (
      <Content keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
        {/* <Grid> */}
        <View>
          <Row>
            <Col size={50}>
              <Button transparent>
                <Text style={[Style.Main.textGray]}>
                  {_('Persistensi Saat Ini')}
                </Text>
              </Button>
            </Col>
            <Col size={50}>
              <Button transparent>
                <Text style={[Style.Main.textGray]}>
                  {_('Rolling Persistensi')}
                </Text>
              </Button>
            </Col>
          </Row>
          <Row>
            <VictoryChart
              width={375}
              height={300}
              style={[Style.Main.ml15, Style.Main.mt0]}
              theme={VictoryTheme.material}
            >
              <VictoryGroup
                offset={20}
              >
                <VictoryLine
                  data={[
                    { x: 'Sep 2018', y: 3 },
                    { x: 'Okt 2018', y: 2 },
                    { x: 'Nov 2018', y: 4 },
                    { x: 'Des 2018', y: 1 },
                    { x: 'Jan 2019', y: 8 },
                  ]}
                />
                <VictoryLine
                  style={{
                    data: { stroke: '#0b6623' },
                    parent: { border: '1px solid #ccc' },
                  }}
                  data={[
                    { x: 'Sep 2018', y: 2 },
                    { x: 'Okt 2018', y: 3 },
                    { x: 'Nov 2018', y: 5 },
                    { x: 'Des 2018', y: 4 },
                    { x: 'Jan 2019', y: 7 },
                  ]}
                />
              </VictoryGroup>
            </VictoryChart>
          </Row>
        </View>
        {/* </Grid> */}
      </Content>
    );
  }
}

export default LineChartDashboard;
