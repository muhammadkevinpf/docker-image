/* eslint-disable max-len */
/* eslint-disable no-console */
import ApiService from '../../sqs-spaj/services/ApiService';

const adapterEmergencyContact = 'adapters/HTTPAdapterEmergencyContact';
const adapterFatca = 'adapters/HTTPAdapterInquiry';

const postDataToAPI = request => new Promise(async (resolve, reject) => {
  try {
    const responseApi = await ApiService.requestToApi(request);
    console.log(responseApi);
    resolve(responseApi);
  } catch (error) {
    reject(new Error(`UserProfileService ${error.message}`));
  }
});

const getRelation = token => new Promise(async (resolve, reject) => {
  try {
    const requestObject = {
      adapter: `${adapterEmergencyContact}/getRelation`,
      method: 'post',
      parameters: { params: "['']" },
    };
    const headerToken = [{
      keyHeader: 'X-CSRF-Token',
      valueHeader: `Bearer ${token}`,
    }];
    requestObject.data = {
      headers: headerToken,
      params: requestObject.parameters.params,
    };
    const res = await postDataToAPI(requestObject);
    resolve(res);
  } catch (error) {
    reject(error);
  }
});

const insertEmergency = (token, agentNumber, contactName, relation, phoneNumber, address1, address2, address3) => new Promise(async (resolve, reject) => {
  try {
    const requestObject = {
      adapter: `${adapterEmergencyContact}/addEmergencycontact`,
      method: 'post',
      parameters: { params: `['${agentNumber}','${contactName}','${relation}','${phoneNumber}','${address1}','${address2}','${address3}']` },
    };
    const headerToken = [{
      keyHeader: 'X-CSRF-Token',
      valueHeader: `Bearer ${token}`,
    }];
    requestObject.data = {
      headers: headerToken,
      params: requestObject.parameters.params,
    };
    const res = await postDataToAPI(requestObject);
    resolve(res);
  } catch (error) {
    reject(error);
  }
});

const updateEmergency = (token, agentNumber, contactName, relation, phoneNumber, address1, address2, address3) => new Promise(async (resolve, reject) => {
  try {
    const requestObject = {
      adapter: `${adapterEmergencyContact}/updateEmergencycontact`,
      method: 'post',
      parameters: { params: `['${agentNumber}','${contactName}','${relation}','${phoneNumber}','${address1}','${address2}','${address3}']` },
    };
    const headerToken = [{
      keyHeader: 'X-CSRF-Token',
      valueHeader: `Bearer ${token}`,
    }];
    requestObject.data = {
      headers: headerToken,
      params: requestObject.parameters.params,
    };
    const res = await postDataToAPI(requestObject);
    resolve(res);
  } catch (error) {
    reject(error);
  }
});

const checkEmergency = (token, agentCode) => new Promise(async (resolve, reject) => {
  try {
    const requestObject = {
      adapter: `${adapterEmergencyContact}/checkEmergencyContact`,
      method: 'post',
      parameters: { params: `['${agentCode}']` },
    };
    const headerToken = [{
      keyHeader: 'X-CSRF-Token',
      valueHeader: `Bearer ${token}`,
    }];
    requestObject.data = {
      headers: headerToken,
      params: requestObject.parameters.params,
    };
    const res = await postDataToAPI(requestObject);
    resolve(res);
  } catch (error) {
    reject(error);
  }
});

const showEmergency = (token, agentCode) => new Promise(async (resolve, reject) => {
  try {
    const requestObject = {
      adapter: `${adapterEmergencyContact}/showEmergencyContact`,
      method: 'post',
      parameters: { params: `['${agentCode}']` },
    };
    const headerToken = [{
      keyHeader: 'X-CSRF-Token',
      valueHeader: `Bearer ${token}`,
    }];
    requestObject.data = {
      headers: headerToken,
      params: requestObject.parameters.params,
    };
    const res = await postDataToAPI(requestObject);
    resolve(res);
  } catch (error) {
    reject(error);
  }
});

const getFatcaStatus = (token, agentCode) => new Promise(async (resolve, reject) => {
  try {
    const requestObject = {
      adapter: `${adapterFatca}/getFatcaStatus`,
      method: 'post',
      cache: false,
      parameters: { params: `['${agentCode}']` },
    };

    const headerToken = [{
      keyHeader: 'X-CSRF-Token',
      valueHeader: `Bearer ${token}`,
    }];
    requestObject.data = {
      headers: headerToken,
      params: requestObject.parameters,
    };
    const res = await postDataToAPI(requestObject);
    resolve(res);
  } catch (error) {
    reject(error);
  }
});

const fatcaApproval = (token, agentCode) => new Promise(async (resolve, reject) => {
  try {
    const requestObject = {
      adapter: `${adapterFatca}/fatcaRegisterApproval`,
      method: 'post',
      cache: false,
      parameters: { params: `['${agentCode}']` },
    };

    const headerToken = [{
      keyHeader: 'X-CSRF-Token',
      valueHeader: `Bearer ${token}`,
    }];
    requestObject.data = {
      headers: headerToken,
      params: requestObject.parameters.params,
    };
    const res = await postDataToAPI(requestObject);
    resolve(res);
  } catch (error) {
    reject(error);
  }
});

const getAgentCPD = (token, agentCode) => new Promise(async (resolve, reject) => {
  try {
    const requestObject = {
      adapter: 'adapters/HTTPAdapterLMS2/getAgentCPD',
      method: 'post',
      parameters: { params: `['${agentCode}']` },
    };

    const headerToken = [{
      keyHeader: 'X-CSRF-Token',
      valueHeader: `Bearer ${token}`,
    }];
    requestObject.data = {
      headers: headerToken,
      params: requestObject.parameters.params,
    };
    const res = await postDataToAPI(requestObject);
    resolve(res);
  } catch (error) {
    reject(error);
  }
});

const getAgentCPDSummary = (token, agentCode) => new Promise(async (resolve, reject) => {
  try {
    const requestObject = {
      adapter: 'adapters/HTTPAdapterLMS2/getAgentCPDSummary',
      method: 'post',
      parameters: { params: `['${agentCode}']` },
    };

    const headerToken = [{
      keyHeader: 'X-CSRF-Token',
      valueHeader: `Bearer ${token}`,
    }];
    requestObject.data = {
      headers: headerToken,
      params: requestObject.parameters.params,
    };
    const res = await postDataToAPI(requestObject);
    resolve(res);
  } catch (error) {
    reject(error);
  }
});

export default {
  getRelation,
  insertEmergency,
  updateEmergency,
  checkEmergency,
  showEmergency,
  getFatcaStatus,
  fatcaApproval,
  getAgentCPD,
  getAgentCPDSummary,
};
