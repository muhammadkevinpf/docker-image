/**
 * @author: ahmdichsanb@gmail.com
*/

import { StyleSheet } from 'react-native';
import Styles from '../../styles';

const Style = StyleSheet.create({
  styleTextLabel: {
    // flex: 1,
    // marginTop: 4,
    fontSize: 14,
    color: Styles.Color.f3f,
    fontFamily: Styles.Main.fontAlbert.fontFamily,
  },
  styleTextLabelValEmpty: {
    color: Styles.Color.gray,
  },
  styleBottomLabel: {
    color: Styles.Color.red,
    fontSize: 10,
    marginLeft: 15,
  },
  item: {
    marginLeft: 0,
    paddingLeft: 0,
    height: 45,
  },
  pb0: {
    paddingBottom: 0,
  },
  formStyle: {
    marginLeft: 0,
    paddingLeft: 0,
    marginTop: 15,
  },
  // add
  styleTextPlaceholder: {
    color: Styles.Main.textColor3f3.color,
  },
  styleTextValue: {
    fontSize: 14,
    color: Styles.Main.textColor3f3.color,
    fontFamily: Styles.Main.fontAlbert.fontFamily,
  },
});

export default Style;
