/* eslint-disable no-console */
/* eslint-disable react/no-array-index-key */

import React, { PureComponent } from 'react';
import moment from 'moment';
import PropTypes from 'prop-types';
import { Alert } from 'react-native';
import {
  View, Text, Row, Col,
} from 'native-base';
import MonthYearPicker from './MonthYearPicker';
import Style from '../../styles';
import _ from '../../lang';

export const setDateByMonthRange = range => new Date(new Date().setMonth(new Date().getMonth() - range));
export const setDateByThisMonth = new Date(new Date().setMonth(new Date().getMonth()));

const defaultFormat = 'YYYY-MM-DD';

class RangePicker extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      minRangeYear: Number(moment(setDateByMonthRange(this.props.rangeMonth)).format('YYYY')),
      minRangeMonth: moment(setDateByMonthRange(this.props.rangeMonth)).format('MM'),
      startYear: Number(moment(this.props.startDate, this.props.formatDate).format('YYYY')),
      startMonth: moment(this.props.startDate, this.props.formatDate).format('MM'),
      endYear: Number(moment(this.props.endDate, this.props.formatDate).format('YYYY')),
      endMonth: moment(this.props.endDate, this.props.formatDate).format('MM'),
      startDate: this.props.startDate,
      endDate: this.props.endDate,
    };
  }

  checkValidation = (selected, type) => {
    const startMonth = type === 'start' ? selected.selectedMonth : this.state.startMonth;
    const startYear = type === 'start' ? selected.selectedYear : this.state.startYear;
    const endMonth = type === 'end' ? selected.selectedMonth : this.state.endMonth;
    const endYear = type === 'end' ? selected.selectedYear : this.state.endYear;
    const checkingDate = (endYear - startYear) * 12 + (endMonth - startMonth);
    let checkValid = true;

    if (checkingDate < 0) {
      checkValid = false;
      Alert.alert('', 'Tanggal awal tidak boleh melebihi tanggal akhir');
    }

    return checkValid;
  }

  onChangeStartRange = (val) => {
    if (this.checkValidation(val, 'start')) {
      let date = `${val.selectedYear}-${val.selectedMonth}-01`;
      if (this.props.formatDate !== defaultFormat) date = moment(date, defaultFormat).format(this.props.formatDate);
      this.setState({ startYear: val.selectedYear, startMonth: val.selectedMonth, startDate: date },
        () => { this.props.onConfirm(this.state.startDate, this.state.endDate); });
    }
  }

  onChangeEndRange = (val) => {
    if (this.checkValidation(val, 'end')) {
      let date = `${val.selectedYear}-${val.selectedMonth}-31`;
      if (this.props.formatDate !== defaultFormat) date = moment(date, defaultFormat).format(this.props.formatDate);
      this.setState({ endYear: val.selectedYear, endMonth: val.selectedMonth, endDate: date },
        () => { this.props.onConfirm(this.state.startDate, this.state.endDate); });
    }
  }

  // endMonth = (year) => {
  //   if (year === (new Date()).getFullYear()) {
  //     return (new Date()).getMonth() + 1;
  //   } return 12;
  // }

  // getMinRange = () => {
  //   const month = (new Date()).getMonth() + 1;
  //   const year = (new Date()).getFullYear() - 1;

  //   const totalMonth = ((year * 12) + month) - this.props.rangeMonth;
  //   const minRangeYear = Math.floor(totalMonth / 12);
  //   const minRangeMonth = totalMonth % 12 !== 0 ? totalMonth % 12 : 12;

  //   this.setState({ minRangeYear, minRangeMonth });
  // }

  render() {
    return (
      <View style={[Style.Main.fullWidth]}>
        <Text style={[Style.Main.fontAlbert14, Style.Main.textBlack]}>{_(this.props.label)}</Text>
        <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.pb10, Style.Main.mb10]}>
          <Row>
            <Col>
              <Text style={[Style.Main.font12]}>Tanggal Awal</Text>
              <MonthYearPicker
                startMonth={this.state.minRangeMonth}
                startYear={Number(this.state.minRangeYear)}
                endMonthByYear
                selectedYear={Number(this.state.startYear)}
                selectedMonth={this.state.startMonth}
                onConfirm={this.onChangeStartRange}
              />
            </Col>
            <Text style={[Style.Main.font26, Style.Main.textAlignVerticalCenter, Style.Main.margin30]}>-</Text>
            <Col>
              <Text style={[Style.Main.font12]}>Tanggal Akhir</Text>
              <MonthYearPicker
                startMonth={this.state.minRangeMonth}
                startYear={Number(this.state.minRangeYear)}
                endMonthByYear
                selectedYear={Number(this.state.endYear)}
                selectedMonth={this.state.endMonth}
                onConfirm={this.onChangeEndRange}
              />
            </Col>
          </Row>
        </View>
      </View>
    );
  }
}

RangePicker.propTypes = {
  label: PropTypes.string,
  formatDate: PropTypes.string,
  rangeMonth: PropTypes.number,
  onConfirm: PropTypes.func,
};

RangePicker.defaultProps = {
  label: 'Periode',
  formatDate: defaultFormat,
  rangeMonth: 24,
  onConfirm: () => {},
};

export default RangePicker;
