import { getVersion } from 'react-native-device-info';

const newSqs = {
  name: `newsqs_${getVersion()}.db`,
  tables: {
    allCountry: 'all_country',
    allRiderRecommendation: 'all_rider_recomendation',
    attributWithdrawalTopUp: 'attribut',
    business: 'business',
    channel: 'channel',
    coverage: 'coverage',
    coverageGroup: 'coverage_group',
    // coveragePAA: 'coverage_paa',
    coverageTerm: 'coverage_term',
    // disclaimer: 'disclaimer',
    formula: 'formula',
    // formulaPAA: 'formula_paa',
    fund: 'fund',
    fundGroup: 'fund_group',
    // fundPAA: 'fund_paa',
    income: 'income',
    input: 'input',
    load: 'load',
    loadDetail: 'load_detail',
    // magnum: 'magnum',
    medicalOption: 'medical_option',
    medicalOptionPphPlus: 'medical_option_pphplus',
    newSqsRate: 'newsqsrate',
    occupation: 'occupation',
    paymentFrequency: 'payment_frequensi',
    position: 'position',
    publish: 'publish',
    // questionnaire: 'questionare',
    rateDetail: 'rate_detail',
    reffMaster: 'REFFMASTER',
    rule: 'rule',
    // rulePAA: 'rule_paa',
    zipCode: 'zipcode',
    dbVersion: 'version',
  },
};

const pruSmart = {
  name: 'prusmart.db',
  tables: {
    customer: {
      name: 'CustomerStorage',
      method: 'customer_storage',
    },
    quotation: {
      name: 'NewQuotationStorage',
      method: 'new_quotation_storage',
    },
    spaj: {
      name: 'NewSpajStorage',
      method: 'new_spaj_storage',
    },
    output: {
      name: 'OutputStorage',
      method: 'output_storage',
    },
    paymentCredential: {
      name: 'PaymentCredential',
      method: 'payment_credential',
    },
    queue: {
      name: 'QueueList',
      method: 'queue_list',
    },
    bootstrapMagnum: {
      name: 'bootstrapMagnum',
      method: 'bootstrap_magnum',
    },
    migrates: {
      name: 'SyncMigrates',
      method: 'sync_migrates',
      column: '(method, agentCode, date, updatedDate)',
    },
    headerProposal: {
      name: 'HeaderProposal',
      method: 'header_proposal',
      column: '(method, agentCode, data, updatedDate, draftId)',
    },
    content: {
      name: 'ContentSqsSpaj',
      column: '(ID TEXT NOT NULL PRIMARY KEY, CONTENT BLOB NOT NULL)',
    },
    branch: {
      name: 'Branch',
      column: '(OFFICE_CODE TEXT NOT NULL, OFFICE_NAME TEXT NOT NULL)',
    },
    referral: {
      name: 'Referral',
      column: '(REFERRAL_CODE TEXT NOT NULL, REFERALL_NAME TEXT, CHANNEL TEXT NOT NULL, RM_PSID TEXT, BRANCH_OFFICE_CODE TEXT)',
    },
  },
};

const inquiries = {
  name: 'inquiries.db',
  tables: {
    clientSync: 'clientSync',
    clientSIO: 'clientSIO',
  },
};

const pruForce = {
  name: 'pruforce.db',
  tables: {
    recruitmentDetail: {
      name: 'recruitment_detail',
      AllListCandidate: {
        name: 'AllListCandidate',
        method: 'all_list_candidate',
      },
      getListCandidate: {
        name: 'recruitment_detail',
        method: 'getListCandidate',
      },
    },
    recruitment: {
      name: 'recruitment',
      AplicationPackData: {
        name: 'AplicationPackData',
        method: 'application_pack_data',
      },
    },
    aob: {
      name: 'aob',
      getIDpruforceid: {
        name: 'getIDpruforceid',
        method: 'id_pruforce',
      },
      createpruforceid: {
        name: 'createpruforceid',
        method: 'create_pf_id',
      },
      getSecQuest: {
        name: 'SecretQuestions',
        method: 'get_sec_quest',
      },
      verifyInputSQ: {
        name: 'verifyInputSQ',
        method: 'verify_input_sq',
      },
      verifyTokenAgent: {
        name: 'verifyTokenAgent',
        method: 'verify_token_agent',
      },
      verifyToken: {
        name: 'verifyToken',
        method: 'verify_token',
      },
      requestCancelNPA: {
        name: 'requestCancelNPA',
        method: 'req_cancel_npa',
      },
      generateNPA: {
        name: 'generateNPA',
        method: 'generate_npa',
      },
      RecExam: {
        name: 'RecExam',
        method: 'rec_exam',
      },
    },
  },
};

const general = {
  name: 'general.db',
  tables: {
    candidate: {
      name: 'candidate',
      verifyCandidate: {
        name: 'verifyCandidate',
        method: 'verify_candidate',
      },
    },
  },
};

const log = {
  name: 'log.db',
  tables: {
    log: {
      name: 'log',
      column: '(ID, level, model, os, os_version, timestamp, message, processed, processedDate)',
    },
  },
};

export default {
  newSqs, pruSmart, inquiries, general, pruForce, log,
};
