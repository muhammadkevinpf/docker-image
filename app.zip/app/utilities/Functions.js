/* eslint-disable func-names */
/* eslint-disable prefer-arrow-callback */
/* eslint-disable no-unused-vars */
/* eslint-disable no-param-reassign */
/* eslint-disable no-return-assign */
/* eslint-disable no-console */
import RNFetchBlob from 'rn-fetch-blob';
import Share from 'react-native-share';
import DeviceInfo from 'react-native-device-info';
import lodash from 'lodash';
import moment from 'moment';
import { call, put } from 'redux-saga/effects';
import {
  Alert, Platform, Dimensions, PixelRatio,
} from 'react-native';
import RNFS from 'react-native-fs';
import { resourceRequest } from './StoreApi';
import { sagaWatcherErrorHandling } from './ErrorHandling';
import { check, checkAndRequest, STORAGE_PERMISSIONS } from './Permission';
import { toStringTwoDigit } from './String';
import _ from '../lang';
import AppJson from '../../app.json';

export const defaultAction = (type, payload) => ({ type, payload });

export function* apiSagaFunction(payload, action, actionConfig, {
  isResponArray, resAttribute, timeout, method, errAttribute,
} = {}) {
  try {
    console.log('payload: ', payload);
    const res = yield call(resourceRequest, actionConfig.API, method || 'post', payload, timeout || 10000);
    console.log(`API ${actionConfig.API} RES: `, res);
    if (res.data
      && Number(res.status) === 200
      && Number(res.data.statusCode) === 200
      && (res.data.responseCode ? (Number(res.data.responseCode) === 200) : true)
    ) {
      if (isResponArray) {
        if (res.data.array && res.data.array.length) yield put.resolve(action(actionConfig.SUCCESS, res.data.array));
        else yield put.resolve(action(actionConfig.FAILED, errAttribute || res.data.errorMessage || res.data.error || res.data.statusReason));
      } else yield put.resolve(action(actionConfig.SUCCESS, resAttribute ? res.data[resAttribute] : res.data));
    } else {
      yield put.resolve(action(actionConfig.FAILED, errAttribute || res.data.responseMessage || res.data.statusReason || 'Unknown Error'));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(action(actionConfig.FAILED, parseError));
    console.log(`API ${actionConfig.API} ERROR: `, parseError);
  }
}

export function isDataOutdated(lastUpdatedDate, updateHour) {
  const hour = updateHour || 15;
  if (!lastUpdatedDate) return true;
  if (new Date(lastUpdatedDate).getDate() !== new Date().getDate() || (
    new Date(lastUpdatedDate).getHours() < hour && new Date().getHours() >= hour
  )) return true;
  return false;
}

export const encodingType = {
  BASE64: 'base64',
  URI: 'uri',
};

export const downloadDoc = async ({
  content, fileName, share, encoding, shareBody, shareSubject, onSuccess, onCloseAlert = () => {},
}) => {
  const { dirs } = RNFetchBlob.fs;
  const path = `${Platform.OS === 'ios' ? dirs.DocumentDir : dirs.DownloadDir}/${fileName}`;
  const url = `file://${path}`;
  const exist = await RNFetchBlob.fs.exists(path);
  try {
    if (!exist) {
      await checkAndRequest(STORAGE_PERMISSIONS[0]);
      await checkAndRequest(STORAGE_PERMISSIONS[1]);
      const checkRead = await check(STORAGE_PERMISSIONS[0]);
      const checkWrite = await check(STORAGE_PERMISSIONS[1]);
      if (!checkRead || !checkWrite) {
        const type = share ? 'Download' : 'Share';
        Alert.alert(_('Warning'), _(`${type} file gagal, tidak mendapatkan akses ke penyimpanan`),
          [{ text: _('Tutup'), onPress: () => onCloseAlert() }]);
      } else {
        const downloadPath = path;
        RNFetchBlob.fs.createFile(downloadPath, content, encoding || encodingType.BASE64).then((res) => {
          if (!share) {
            if (onSuccess) onSuccess(res);
            else Alert.alert(_('Download'), `${_('Download File Berhasil')} ${res}`, [{ text: _('Tutup'), onPress: () => onCloseAlert(res) }]);
          } else {
            Share.open({
              title: _('Bagikan'),
              url,
              message: shareBody || '',
              subject: shareSubject || '',
              failOnCancel: false,
            });
          }
        }, e => Alert.alert('', _('Download File Gagal'), [{ text: _('Tutup'), onPress: () => onCloseAlert(e) }]));
      }
    } else if (!share) {
      Alert.alert(_('Download'), _('File sudah tersimpan'), [{ text: _('Tutup'), onPress: () => onCloseAlert() }]);
    } else {
      Share.open({
        title: _('Bagikan'),
        url,
        message: shareBody || '',
        subject: shareSubject || '',
        failOnCancel: false,
      });
    }
  } catch (error) {
    console.log(error);
  }
};

export const isTablet = () => DeviceInfo.isTablet();
// export const isTablet = () => DeviceInfo.isLandscape();

export const isIos = () => Platform.OS === 'ios';

export const isText = content => (lodash.isString(content) || lodash.isNumber(content));

export const isStringEmpty = content => (!content || content === '');

export const isArrayEmpty = content => !(content && content.length);

// This can check if the string, array or object is empty
// Use this isEmpty function instead of isStringEmpty or isArrayEmpty
export const isEmpty = content => lodash.isEmpty(content);

export const isMenuActive = (mobileMenu, moduleName) => {
  const menu = mobileMenu.find(x => x.name === moduleName);
  if (menu) return menu.active;
  return false;
};

export const paramsToJSON = (value) => {
  let data = JSON.stringify(value);
  data = data.replace(/'/g, function (val) { return val = '##PTK##'; });
  data = data.replace(/\\n/g, '');
  data = data.replace(/\\r/g, '');
  data = data.replace(/%/g, '%25');
  data = data.replace(/[+]/g, '%2B');

  return `['${data}']`;
};

export const tempArray = (total = 8) => Array(total).fill({});

/**
 * @param data: data json that will be written to csv file (must be Array of Object)
 * @param fileName: name for the file (string)
 */
export const createCsv = (data = [{}], fileName = '') => new Promise(async (resolve) => {
  try {
    let errMessage = '';
    if (!fileName) errMessage += '| filename cannot be blank |';
    if (!data || !data.length || !(data[0] instanceof Object) || !(Object.keys(data[0]).length)) errMessage += '| Wrong Object |';
    if (errMessage) {
      console.log(errMessage);
      resolve({ isSuccess: false, message: errMessage, code: 400 });
      return;
    }
    const filePath = `${RNFS.ExternalStorageDirectoryPath}/${fileName}.csv`;
    let value = Object.keys(data[0]).join();
    for (let i = 0; i < data.length; i += 1) {
      value += `\n${Object.values(data[i]).join()}`;
    }
    await RNFS.writeFile(filePath, value, 'utf8');
    resolve({ isSuccess: true, message: 'CSV Created', code: 201 });
  } catch (error) {
    resolve({ isSuccess: false, message: error.message, code: 500 });
  }
});

/**
 * @description a function to convert the pixel size determined by the UI / UX team
 * which refers to a design with a certain width into a responsive size
 * @param px: the pixel size determined by the UI / UX team
 * @param referenceWidth: the screen width used in the UI / UX design team. (Mobile: 360px, Tablet: 1280px)
 */
export const wp = (px, referenceWidth = isTablet() ? 1280 : 360) => {
  const percentage = Number(px) * 100 / Number(referenceWidth); // the ratio of the desired size to the reference width
  return PixelRatio.roundToNearestPixel(Dimensions.get('window').width * percentage / 100);
};


/**
 * @param lower: lower limits of transaction time. (format = HHMM, default = 700).
 * @param upper: upper limits of transaction time. (format = HHMM, default = 1600).
 */
export const cutOffChecking = (lower = 700, upper = 1600) => new Promise((resolve) => {
  // NOTE: Please uncomment the code below for production environments

  // const date = moment(new Date()).utcOffset(7);
  // const time = Number(date.format('HHMM'));

  // const ulLength = String(upper).length;
  // const lllength = String(lower).length;

  // if (date.get('day') === 0 || date.get('day') === 6) {
  //   Alert.alert('', _('Transaksi hanya dapat dilakukan pada hari kerja.'));
  // } else if (time > upper || time < lower) {
  //   Alert.alert('', _(`Transaksi tidak dapat dilakukan di bawah jam ${
  //     toStringTwoDigit(String(lower).slice(0, lllength - 2))}.${String(lower).slice(lllength - 2)
  //   } WIB atau di atas jam ${
  //     toStringTwoDigit(String(upper).slice(0, ulLength - 2))}.${String(upper).slice(ulLength - 2)
  //   } WIB.`));
  // } else {
  resolve();
  // }
});

export const bankCodes = [
  {
    channel: 'SCB',
    bankCode: '050',
    bankName: 'STANDARD CHARTERED BANK',
  },
  {
    channel: 'BUOI',
    bankCode: '023',
    bankName: 'BANK UOB INDONESIA (BANK BUANA INDONESIA)',
  },
  {
    channel: 'UOB',
    bankCode: '023',
    bankName: 'BANK UOB INDONESIA (BANK BUANA INDONESIA)',
  },
];

export const bankAccountChecker = (channel, accountNumber, accountName) => new Promise(async (resolve, reject) => {
  try {
    const { bankCode } = bankCodes.find(x => x.channel === channel);
    const payload = {
      headers: [
        {
          keyHeader: 'X-CSRF-Token',
          valueHeader: 'Bearer undefined',
        },
      ],
      params: `["${AppJson.environtment === 'UAT' ? '013' : bankCode}","${accountNumber}","${accountName}"]`,
    };
    const { data } = await resourceRequest('adapters/PrufastPaymentAdapter/validateAccountInfo', 'post', payload);
    resolve(data);
  } catch (error) {
    reject(error);
  }
});

/** Format address from API */
export const formatAddress = (data = {}) => {
  const address = [];
  if (!isEmpty(data.address1)) address.push(data.address1);
  if (!isEmpty(data.address2) || !isEmpty(data.address3)) {
    if (!isEmpty(data.address2)) address.push(`${data.address2} ${data.address3}`);
    else address.push(data.address3);
  }
  if (!isEmpty(data.address4) || !isEmpty(data.address5)) {
    if (!isEmpty(data.address4) && !isEmpty(data.address5)) address.push(`${data.address4}, ${data.address5}`);
    else if (!isEmpty(data.address4)) address.push(data.address4);
    else address.push(data.address5);
  }
  return address;
};
