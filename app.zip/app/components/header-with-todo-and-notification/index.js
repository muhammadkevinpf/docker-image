import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { TouchableOpacity } from 'react-native-gesture-handler';
import {
  View, Text, Icon,
} from 'native-base';
import Header from '../header';
import Style from '../../styles';
import _ from '../../lang';
import { totalToDoFetch, trackerAddStack } from '../../modules/todo-list/ActionTodoList';
import { totalNotificationFetch } from '../../modules/notification/ActionNotification';
import { isEmpty, isText, setUpTo } from '../../utilities';
import LoadingModal from '../loading_modal';
import ConnectionStatus from '../connection-status';

const totalType = {
  TODO: 'TODO',
  NOTIF: 'NOTIFICATION',
};

const getFontColor = (headerColor, fontColor) => {
  if (!isEmpty(fontColor)) return fontColor;

  const whites = [Style.Color.white];
  if (whites.includes(headerColor)) return Style.Main.textColor3f3;
  return Style.Main.textWhite;
};

class HeaderWithTodo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    };
  }

  shouldComponentUpdate = (prevProps) => {
    if (this.props !== prevProps) return true;
    return false;
  }

  componentDidMount = () => {
    if (this.shouldUpdateTodo()) this.fetchTotal(totalType.TODO);
    if (this.shouldUpdateNotif()) this.fetchTotal(totalType.NOTIF);
    this.setState({ isLoading: false });
  }

  componentDidUpdate = (prevProps) => {
    if (this.props.isOnline !== prevProps.isOnline && this.props.isOnline && this.props.isShowRightButton && !this.props.headerColor) {
      if (this.shouldUpdateTodo()) this.fetchTotal(totalType.TODO);
      if (this.shouldUpdateNotif()) this.fetchTotal(totalType.NOTIF);
    }
  }

  shouldUpdateTodo = () => this.props.isShowRightButton && !this.props.headerColor;
  // shouldUpdateTodo = () => {
  //   if (isDataOutdated(this.props.lastFetchTodo) || !this.props.resTodo || Number(this.props.resTodo || 0) < 99) return true;
  //   return false;
  // }

  shouldUpdateNotif = () => this.props.isShowRightButton && !this.props.headerColor;
  // shouldUpdateNotif = () => {
  //   if (isDataOutdated(this.props.lastFetchNotif) || !this.props.resNotif || Number(this.props.resNotif || 0) < 99) return true;
  //   return false;
  // }

  fetchTotal = (type) => {
    if (this.props.resAuth && this.props.resAuth.access_token && this.props.resAuth.userProfile
      && this.props.resAuth.userProfile.agentCode && this.props.isOnline && this.props.isShowRightButton && !this.props.headerColor) {
      const tokenHeader = [{
        keyHeader: 'X-CSRF-Token',
        valueHeader: `Bearer ${this.props.resAuth.access_token}`,
      }];
      if (type === totalType.TODO) {
        const dataTotalTodo = {
          headers: tokenHeader,
          params: `["${this.props.resAuth.userProfile.agentCode}", "${this.props.resAuth.username}"]`,
        };
        this.props.dispatchTotalToDo(dataTotalTodo);
      }
      if (type === totalType.NOTIF) {
        const dataTotalNotification = {
          headers: tokenHeader,
          params: `["${this.props.resAuth.userProfile.agentCode}", "All"]`,
        };
        this.props.dispatchTotalNotification(dataTotalNotification);
      }
    }
  }

  renderTodoNumber = () => {
    if (this.props.resTodo) return setUpTo(this.props.resTodo);
    return '0';
  }

  renderNotifNumber = () => {
    if (this.props.resNotif) return setUpTo(this.props.resNotif);
    return '0';
  }

  render() {
    return (
      <Header
        leftWidth={this.props.isShowRightButton && this.props.headerColor ? 9 : 3}
        leftContent={
          <View
            style={[Style.Main.fullWidth, Style.Main.rowDirection, Style.Main.pr18, Style.Main.mr5,
              Style.Main.pl15, Style.Main.pt15, Style.Main.headerHeight, Style.Main.alignCenter]}
          >
            <TouchableOpacity
              onPress={this.props.onBackClicked}
              activeOpacity={1}
              style={[Style.Main.rowDirection, Style.Main.pr18, Style.Main.mr5]}
            >

              {this.props.isShowBackButton && <Icon
                name="angle-left"
                type="FontAwesome"
                style={[getFontColor(this.props.headerColor, this.props.fontColor), Style.Main.mt2, Style.Main.mr12]}
              />}
              <Text
                ellipsizeMode="tail"
                style={[Style.Main.font16, getFontColor(this.props.headerColor, this.props.fontColor), Style.Main.fontAlbert]}
                numberOfLines={1}
              >
                {_(this.props.headerTitle)}
              </Text>
            </TouchableOpacity>
            <LoadingModal show={this.state.isLoading} size="large" color="white" />
          </View>
        }
        rightWidth={this.props.isShowRightButton && !this.props.headerColor ? 1 : 0}
        rightContent={
          this.props.isShowRightButton && !this.props.headerColor ? (
            <View style={[Style.Main.rowDirectionFlexEnd, Style.Main.container, Style.Main.pr5]}>
              <View style={[Style.Main.alignCenter, Style.Main.mr20]}>
                <ConnectionStatus />
              </View>
              <TouchableOpacity
                activeOpacity={0.75}
                style={[Style.Main.alignContentCenter, Style.Main.justifyCenter, Style.Main.fullHeight, Style.Main.pl5, Style.Main.pr25]}
                onPress={() => {
                  const { trackerTodo } = this.props;
                  const lastRoute = trackerTodo.length >= 1 ? trackerTodo[trackerTodo.length - 1].route : '';
                  console.log('lastRoute: ', lastRoute);
                  if (this.props.navigation.state.routeName !== 'MainTodoList') {
                    if (lastRoute !== this.props.navigation.state.routeName) {
                      this.props.trackerAddStack({
                        route: this.props.navigation.state.routeName,
                      });
                    }
                    if (this.props.navigation.state.params) {
                      this.props.trackerAddStack({
                        route: 'MainTodoList',
                        param: {
                          ...this.props.navigation.state.params,
                        },
                      });
                    } else {
                      this.props.trackerAddStack({
                        route: 'MainTodoList',
                      });
                    }
                    this.props.navigation.replace('MainTodoList');
                  }
                }}
              >
                <View style={[Style.Main.newBadge]}>
                  <Text style={[Style.Main.textWhite, Style.Main.font10, Style.Main.textAlignCenter]}>{this.renderTodoNumber()}</Text>
                </View>
                <Icon
                  active
                  name="checkbox"
                  type="Ionicons"
                  style={[Style.Main.textWhite, Style.Main.font22, Style.Main.alignCenter]}
                />
              </TouchableOpacity>
              <TouchableOpacity
                activeOpacity={0.75}
                style={[Style.Main.alignContentCenter, Style.Main.justifyCenter, Style.Main.fullHeight, Style.Main.pl5, Style.Main.pr25]}
                onPress={() => {
                  if (this.props.navigation.state.routeName !== 'MainNotification') {
                    this.props.navigation.replace('MainNotification', {
                      route: this.props.navigation.state.routeName,
                      param: {
                        ...this.props.navigation.state.params,
                      },
                    });
                  }
                }}
              >
                <View style={[Style.Main.newBadge]}>
                  <Text style={[Style.Main.textWhite, Style.Main.font10, Style.Main.textAlignCenter]}>{this.renderNotifNumber()}</Text>
                </View>
                <Icon
                  active
                  name="notifications"
                  type="Ionicons"
                  style={[Style.Main.textWhite, Style.Main.font22]}
                />
              </TouchableOpacity>
            </View>
          ) : (
            <View style={[Style.Main.alignEnd, Style.Main.justifyCenter, Style.Main.container, Style.Main.pr15]}>
              <ConnectionStatus />
            </View>
          )
        }
        {...this.props}
        subHeader={this.props.subHeader && isText(this.props.subHeader) ? _(this.props.subHeader).toUpperCase() : this.props.subHeader || undefined}
        subHeaderPress={this.props.subHeaderPress}
        subHeaderContent={this.props.subHeaderContent ? this.props.subHeaderContent : undefined}
      />
    );
  }
}

HeaderWithTodo.propTypes = {
  onBackClicked: PropTypes.func,
  headerTitle: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  subHeader: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  subHeaderContent: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  isShowBackButton: PropTypes.bool,
  isShowRightButton: PropTypes.bool,
  subHeaderPress: PropTypes.func,
  subMenus: PropTypes.string,
  styledSubHeader: PropTypes.bool,
};

HeaderWithTodo.defaultProps = {
  onBackClicked: () => { },
  headerTitle: 'PRUFast',
  subHeader: undefined,
  subHeaderContent: undefined,
  isShowBackButton: true,
  isShowRightButton: true,
  subHeaderPress: () => { },
  subMenus: undefined,
  styledSubHeader: true,
};

const mapStateToProps = state => ({
  resAuth: state.auth.res,
  resTodo: state.dashboard.totalTodo,
  resNotif: state.dashboard.totalNotif,
  lastFetchTodo: state.dashboard.lastFetchTodo,
  lastFetchNotif: state.dashboard.lastFetchNotif,
  isOnline: state.connectionStatus.isOnline,
  trackerTodo: state.todo.trackerTodo,
});

const mapDispatchToProps = dispatch => ({
  dispatchTotalToDo: value => dispatch(totalToDoFetch(value)),
  dispatchTotalNotification: value => dispatch(totalNotificationFetch(value)),
  trackerAddStack: value => dispatch(trackerAddStack(value)),
});

export default connect(mapStateToProps, mapDispatchToProps)(HeaderWithTodo);
