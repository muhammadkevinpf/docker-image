/* eslint-disable max-len */
/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import { TouchableOpacity, BackHandler } from 'react-native';
import {
  Container,
  Body,
  Card, CardItem, Text,
  View,
} from 'native-base';
import Communications from 'react-native-communications';
import Icon from 'react-native-vector-icons/FontAwesome';
import { connect } from 'react-redux';
import _ from '../../../lang';
import Style from '../../../styles';
import { cityBranchOfficeFetch, branchOfficeFetch, clearHospitalAndOfficeList } from '../ActionHome';
import {
  HeaderWithTodo, SortFilter, SearchNativeBase, CustomFlatList,
} from '../../../components';
import {
  CITYBRANCHOFFICESUCCESS, CITYBRANCHOFFICEFAILED, BRANCHOFFICEFAILED, BRANCHOFFICESUCCESS, BRANCHOFFICEFETCH, // BRANCHOFFICEFETCH,
} from '../ConfigHome';
import { isArrayEmpty, isTablet } from '../../../utilities';

class ListPruAgentOfficeHome extends Component {
  constructor(props) {
    super(props);
    this.state = {
      pageSize: 30,
      page: 1,
      searchWord: '',
      selectedFilter: '',
      isRefresh: false,
      onEndReachedCalledDuringMomentum: true,
      filterItems: [],
      branchOffice: [],
    };
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.actionHome !== prevState.actionHome) {
      if (nextProps.actionHome === CITYBRANCHOFFICEFAILED) {
        return {
          ...prevState,
          // listToDoNewBusinessPending: [],
          filterItems: prevState.filterItems,
          page: prevState.page === 1 ? prevState.page : prevState.page - 1,
          isRefresh: false,
          actionHome: nextProps.actionHome,
        };
      }
      if (nextProps.actionHome === CITYBRANCHOFFICESUCCESS) {
        let newFilter = nextProps.resHome && !isArrayEmpty(nextProps.resHome.cityBranchOffice) ? nextProps.resHome.cityBranchOffice : [];
        if (isArrayEmpty(newFilter)) newFilter = prevState.filterItems;
        else {
          const temp = newFilter.filter(item => item.city_code !== '') || [];
          if (!isArrayEmpty(temp)) newFilter = temp.map(item => ({ value: item.city_code, label: item.city_code }));
        }
        return {
          ...prevState,
          filterItems: newFilter,
          isRefresh: false,
          actionHome: nextProps.actionHome,
        };
      }

      if (nextProps.actionHome === BRANCHOFFICEFAILED) {
        return {
          ...prevState,
          // listToDoNewBusinessPending: [],
          page: prevState.page === 1 ? prevState.page : prevState.page - 1,
          branchOffice: nextProps.resHome ? (nextProps.resHome.branchOffice || []) : prevState.branchOffice,
          isRefresh: false,
          actionHome: nextProps.actionHome,
        };
      }
      if (nextProps.actionHome === BRANCHOFFICESUCCESS) {
        return {
          ...prevState,
          branchOffice: nextProps.resHome ? (nextProps.resHome.branchOffice || []) : prevState.branchOffice,
          isRefresh: false,
          actionHome: nextProps.actionHome,
        };
      }
      return {
        ...prevState,
        actionHome: nextProps.actionHome,
      };
    }

    return null;
  }

  componentDidMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleBack();
      return true;
    });

    // if (this.props.isOnline) {
    this.getFilter();
    this.getData();
    // } else {
    //   this.setState({ isRefresh: false });
    // }
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  onSearchBarValue = (val) => {
    this.setState({ searchWord: val, page: 1, isRefresh: true }, () => {
      this.props.clearList();
      this.getData();
    });
  }

  onSearchTyped = (searchWord) => {
    this.setState({ searchWord });
  }

  onValueChangeFilter = (value) => {
    if (value !== this.state.selectedFilter) {
      this.setState({ selectedFilter: value, page: 1, isRefresh: true }, () => {
        this.props.clearList();
        this.getData();
      });
    }
  }

  handleLoadData = () => {
    if (!this.state.onEndReachedCalledDuringMomentum && !this.props.home.fetchBranchOffice) {
      this.setState(prevState => ({ showSpinner: true, page: prevState.page + 1 }), () => this.getData());
    }
  }

  getData = () => {
    const item = {
      params: `[${this.state.page}, ${this.state.pageSize}, "${this.state.selectedFilter}", "${this.state.searchWord}"]`,
    };
    this.props.dispatchFetchBrachOffice(item);
  }

  getFilter = () => {
    const item = {
      params: '[]',
    };
    this.props.dispatchFetchCityBrachOffice(item);
  }

  handleRefresh = () => {
    this.setState({ page: 1, isRefresh: true }, () => {
      this.props.clearList();
      this.getData();
    });
  }

  handleBack = () => {
    this.props.navigation.replace('MainHome');
  }

  renderTopBar = () => (
    <View>
      <SearchNativeBase
        placeholder={_('Cari')}
        onInputBlur={value => this.onSearchBarValue(value)}
        value={this.state.searchWord}
        onChangeText={this.onSearchTyped}
      />
      <Card style={[Style.Main.mb10]}>
        <CardItem bordered>
          <Body>
            <View Style={Style.Main.textWrap}>
              <Text style={Style.Main.fontAlbert}>
                {_('Silakan menghubungi Kantor Prudential terdekat untuk mendapatkan informasi produk yang sesuai untuk Kebutuhan Anda.')}
              </Text>
            </View>
          </Body>
        </CardItem>
      </Card>
      <View style={[Style.Main.mV10]}>
        <Text style={Style.Main.fontAlbert}>{ _('Pilih Lokasi') }</Text>
        <SortFilter
          onFilterSelected={this.onValueChangeFilter}
          filterItems={this.state.filterItems}
          filterBy={this.state.selectedFilter}
          showSort={false}
          customLabel={this.state.selectedFilter || 'Tampilkan Semua'}
        />
      </View>
    </View>
  );

  render() {
    const { branchOffice, pageSize, isRefresh } = this.state;
    return (
      <Container style={[isTablet() && Style.Main.rowDirection]}>
        <Container>
          <HeaderWithTodo
            {...this.props}
            headerTitle="KANTOR PRUDENTIAL"
            isShowBackButton
            isShowRightButton={false}
            onBackClicked={() => this.props.navigation.replace('MainHome')}
          />
          <CustomFlatList
            ignoreOffline
            listData={branchOffice}
            showLoadingEmpty={(this.props.actionHome === BRANCHOFFICEFETCH || this.props.home.fetchBranchOffice) && !this.state.isRefresh}
            showLoadingFooter={this.props.actionHome === BRANCHOFFICEFETCH && !isArrayEmpty(branchOffice) && !this.state.isRefresh}
            topBar={this.renderTopBar()}
            itemComponent={({ item, index }) => (
              <Card key={index} style={[Style.Main.padding15, Style.Main.container]}>
                <View style={Style.Main.textWrap}>
                  <Text style={[Style.Main.fontAlbert, Style.Main.textStrong]}>
                    {item.officeName}
                  </Text>
                </View>
                <View style={[Style.Main.textWrap, Style.Main.columnDirection]}>
                  <Text style={[Style.Main.fontAlbert, Style.Main.mr5]}>
                    {item.officeAddr1}
                  </Text>
                  <Text style={[Style.Main.fontAlbert]}>
                    {`${item.officeAddr2} ${item.officeAddr3}`}
                  </Text>
                </View>
                {item.officePhone ?
                  <TouchableOpacity
                    style={[Style.Main.textWrap, Style.Main.mt10]}
                    onPress={() => Communications.phonecall(item.officePhone, true)}
                  >
                    <Icon
                      name="phone"
                      style={[Style.Main.textRed, Style.Main.font16, Style.Main.pt5]}
                    />
                    <Text
                      style={[Style.Main.fontAlbert, Style.Main.textBlue, Style.Main.ml4]}
                    >
                      {item.officePhone}
                    </Text>
                  </TouchableOpacity>
                  : null
                  }
              </Card>
            )}
            pageSize={pageSize}
            handleLoadData={this.handleLoadData}
            onRefresh={this.handleRefresh}
            refreshing={isRefresh}
            statusList={this.props.apiStatus}
            onMomentumScrollBegin={() => this.setState({ onEndReachedCalledDuringMomentum: false })}
          />
        </Container>
      </Container>
    );
  }
}

const mapStateToProps = state => ({
  isOnline: state.connectionStatus.isOnline,
  actionHome: state.home.action,
  resHome: state.home.res,
  home: state.home,
});

const mapDispatchToProps = dispatch => ({
  dispatchFetchCityBrachOffice: value => dispatch(cityBranchOfficeFetch(value)),
  dispatchFetchBrachOffice: value => dispatch(branchOfficeFetch(value)),
  clearList: () => dispatch(clearHospitalAndOfficeList()),
});

export default connect(mapStateToProps, mapDispatchToProps)(ListPruAgentOfficeHome);
