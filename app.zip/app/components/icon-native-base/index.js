import React, { PureComponent } from 'react';
import { Icon } from 'native-base';
import PropTypes from 'prop-types';

class Icons extends PureComponent {
  render() {
    const {
      color,
      name,
      type,
      style,
      ios,
      android,

    } = this.props;
    return (
      <Icon
        color={color}
        type={type}
        name={name}
        style={style}
        ios={ios}
        android={android}
      />
    );
  }
}

Icons.propTypes = {
  name: PropTypes.string.isRequired,
  type: PropTypes.string,
};

Icons.defaultProps = {
  type: 'FontAwesome',
};

export default Icons;
