/**
 * @author: dwi.setiyadi@gmail.com
*/

import Bootstrap from '../bootstrap/container';
// import { ReducerAuth } from '../modules/auth/ReducerAuth';
import { ReducerSQSNSpaj, ReducerIllustration } from '../modules/sqs-spaj/ReducerSQSNSpaj';
import { ReducerAuth, ReducerConnection } from '../modules/auth/ReducerAuth';
// import { ReducerSQSNSpaj } from '../modules/sqs-spaj/ReducerSQSNSpaj';
import { ReducerNotification } from '../modules/notification/ReducerNotification';
import { ReducerNews } from '../modules/news-and-update/ReducerNews';
import { ReducerDashboard, ReducerSetting } from '../modules/dashboard/ReducerDashboard';
import { ReducerHome } from '../modules/home/ReducerHome';
import { ReducerProduction } from '../modules/production/ReducerProduction';
import { ReducerPersistency } from '../modules/persistency/ReducerPersistency';
import { ReducerProposalPolicy } from '../modules/proposal-policy/ReducerProposalPolicy';
import { ReducerDueDate, ReducerToDo } from '../modules/todo-list/ReducerTodoList';
import { ReducerClient } from '../modules/client/ReducerClient';
import { ReducerCommissionEstimation } from '../modules/commission-estimation/ReducerCommission';
import { ReducerIncomeStatement, ReducerIncomeDetail, ReducerTaxSlip } from '../modules/income-statement/ReducerIncomeStatement';
import { ReducerFeedback } from '../modules/feedback/ReducerFeedback';
import { ReducerCorrespondence } from '../modules/correspondence/ReducerCorrespondence';
import { ReducerActivity } from '../modules/activity-management/ReducerActivity';
import { ReducerPRUExpert } from '../modules/pruexpert/ReducerPruexpert';
import { ReducerPolicyTransaction } from '../modules/policy-transaction/ReducerPolicyTransaction';
import ReducerSpaj from '../modules/spaj/reducers';

export default {
  bootstrap: Bootstrap.Reducer,
  home: ReducerHome,
  auth: ReducerAuth,
  sqs: ReducerSQSNSpaj,
  todo: ReducerToDo,
  todoDueDate: ReducerDueDate,
  notification: ReducerNotification,
  spaj: ReducerSpaj,
  illustration: ReducerIllustration,
  connectionStatus: ReducerConnection,
  news: ReducerNews,
  dashboard: ReducerDashboard,
  setting: ReducerSetting,
  prod: ReducerProduction,
  persistency: ReducerPersistency,
  inquiries: ReducerProposalPolicy,
  client: ReducerClient,
  estimatedCommission: ReducerCommissionEstimation,
  incomeStatement: ReducerIncomeStatement,
  incomeDetail: ReducerIncomeDetail,
  taxSlip: ReducerTaxSlip,
  feedback: ReducerFeedback,
  correspondence: ReducerCorrespondence,
  activity: ReducerActivity,
  pruexpert: ReducerPRUExpert,
  policyTransaction: ReducerPolicyTransaction,
};
