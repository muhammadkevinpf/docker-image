/* eslint-disable react/no-array-index-key */
import React from 'react';
import { StyleSheet } from 'react-native';
import { View, Text } from 'native-base';
import { isEmpty } from '../../../utilities';
import Colors from '../../../styles/Colors';
import Style from '../../../styles';

export class ActivityTrack extends React.PureComponent {
  notes = (text) => {
    if (isEmpty(text)) return null;
    return <Text style={[Style.Main.fontAlbert12]}>{text}</Text>;
  }

  Step = ({ showLine = true, data = {} }) => (
    <View style={[Style.Main.rowDirection]}>
      <View style={styles.stepIndicator}>
        <View style={[styles.mainCircle, { backgroundColor: data.reason.feedback[0].fontColor || Colors.gray }]} />
        {showLine && <View style={[styles.stepLine, { backgroundColor: data.reason.feedback[0].fontColor || Colors.gray }]} />}
      </View>
      <View style={[Style.Main.pb30]}>
        <Text style={[styles.label, { color: data.reason.feedback[0].fontColor || Colors.gray }]}>{data.reason.feedback[0].description}</Text>
        {this.notes(data.activityDate)}
        {this.notes(data.reason.description)}
        {this.notes(data.notes)}
      </View>
    </View>
  )

  render() {
    const { log = [] } = this.props;
    return (
      <View style={Style.Main.mt5}>
        {
          log.map((item, index) => (
            <View key={index}>
              <this.Step data={item} showLine={index < (log.length - 1)} />
            </View>
          ))
        }
      </View>
    );
  }
}

const styles = StyleSheet.create({
  stepIndicator: {
    width: 20, marginRight: 15,
  },
  stepLine: {
    width: 1, flex: 1, margin: 5, alignSelf: 'center',
  },
  mainCircle: {
    width: 20, height: 20, borderRadius: 10,
  },
  label: {
    ...Style.Main.fontAlbert14, marginBottom: 3,
  },
});
