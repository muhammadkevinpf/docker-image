/* eslint-disable react-native/no-inline-styles */
/**
 * @author: ahmdichsanb@gmail.com
 */

import React, { Component, Fragment } from 'react';
import { Text, View } from 'native-base';
import PropTypes from 'prop-types';
import { Row, Col } from 'react-native-easy-grid';
import { Platform } from 'react-native';
import OutlineCheckbox from '../outline-checkbox';
import _ from '../../lang';
import InputField from '../input-field-new';
// eslint-disable-next-line import/no-named-as-default
import TextArea from '../textarea-new';
import Style from '../../styles';
import StyleCheckBox from './style';

class CheckBoxCard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      checkBoxData: this.props.renderData,
      validStatus: false,
      validStatusInvoked: true,
      errorMessage: 'Checkbox wajib dipilih salah satu!',
      errorMessageInvoked: '',
      // disabled: false,
    };
  }

  // shouldComponentUpdate = (prevProps) => {
  //   if (JSON.stringify(this.props) === JSON.stringify(prevProps)) return false;
  //   // || this.props.selectedValue === prevProps.selectedValue) return false;
  //   return true;
  // }

  componentDidMount() {
    this.checkValidStatusSelected(this.props.renderData);
  }

  onCheckBoxPressed = (value) => {
    // const { checkBoxData } = this.state;
    const checkBoxData = this.props.renderData;
    const obj = checkBoxData.find(x => x.value === value);
    obj.isSelected = !obj.isSelected;
    if (!obj.isSelected) {
      if (obj.input) {
        if (obj.input !== '') {
          obj.input = '';
        }
      }
    }
    this.setState({ checkBoxData });
    this.checkValidStatusSelected(checkBoxData);
    if (this.props.onPress) {
      this.props.onPress(obj);
    }
  };

  setValueFromChild = (id, value) => {
    this.setState({ [`dataChild${id}`]: value }, () => {
      this.onTextInput(id);
    });
  };

  onTextInput = (i) => {
    console.log('state input field on checkbox: ', this.state[`dataChild${i}`]);
    const { checkBoxData } = this.state;
    const copyCheckBoxData = [...checkBoxData];
    copyCheckBoxData[i].input = this.state[`dataChild${i}`];
    // copyCheckBoxData[i].input = this[`_inputField${i}`]._input._root._getText();
    this.setState({ checkBoxData: copyCheckBoxData });
    this.checkValidStatusByInput(copyCheckBoxData);
    if (this.props.onChangeText) {
      this.props.onChangeText(copyCheckBoxData[i]);
    }
  };

  checkValidStatusSelected = (checkBoxData) => {
    const { invokedValidation, errorMessageInvoked } = this.props;
    const selected = checkBoxData.filter(x => x.isSelected);
    const noSelected = selected.length === 0;
    const selectedWInput = selected.filter(x => x.isTextInput && x.input === '').length >= 1;
    const { isAllRequired } = this.props;
    if (noSelected) {
      this.setState({ validStatus: false, errorMessage: isAllRequired ? 'Semua checkbox wajib dipilih!' : 'Checkbox wajib dipilih salah satu!' });
    } else if (selectedWInput) {
      this.setState({ validStatus: false, errorMessage: 'Mohon input field diisi!' });
    } else if (isAllRequired && checkBoxData.some(x => x.isSelected === false)) {
      this.setState({ validStatus: false, errorMessage: 'Semua checkbox wajib dipilih!' });
    } else {
      this.setState({ validStatus: true, errorMessage: '' });
    }

    if (invokedValidation) {
      this.setState({ validStatus: true, validStatusInvoked: false, errorMessageInvoked });
    }
  };

  checkValidStatusByInput = (checkBoxData) => {
    // const selectedWInputValue = checkBoxData.filter(x => x.isSelected && x.isTextInput && x.input).length > 0;
    const filterredBySelectedWithInput = checkBoxData.filter(x => x.isSelected && x.isTextInput);
    const selectedWInputValue = filterredBySelectedWithInput.every(x => x.input !== '');
    if (selectedWInputValue) {
      this.setState({ validStatus: true, errorMessage: '' });
    } else {
      this.setState({ validStatus: false, errorMessage: 'Mohon input field diisi!' });
    }
  };

  invokeValidation = (validStatusInvoked, errorMessageInvoked) => {
    if (errorMessageInvoked === null || errorMessageInvoked === undefined || errorMessageInvoked === '') {
      // eslint-disable-next-line no-param-reassign
      errorMessageInvoked = '';
    }
    this.setState({
      validStatusInvoked,
      errorMessageInvoked,
    });
  };

  onDisabledCheckBox = () => {
    this.setState({
      checkBoxData: this.props.renderData,
      // disabled: true,
      validStatus: true,
      errorMessage: '',
    });
  };

  isIncluded = (obj, arr) => {
    if (arr && arr.length > 0 && arr.find(item => item[this.props.valueProp] === obj)) return true;
    return false;
  };

  renderInputValue = (data) => {
    let val = '';
    if (this.isIncluded(data.value, this.props.selectedObjects)) {
      val = this.props.selectedObjects.find(item => item[this.props.valueProp] === data.value)[this.props.inputLabelProp];
    }
    return val;
  };

  renderOneColumn = (i, data) => {
    const {
      colIconStyle,
      // colLabelStyle,
      fontStyle,
      textType,
      isThreeRow,
      isInputBackgroundWhite,
    } = this.props;
    // const { checkBoxData } = this.state;
    const isChecked = this.isIncluded(data.value, this.props.selectedObjects);
    const isDisabled = this.isIncluded(data.value, this.props.disabledValues);
    return (
      <View key={i}>
        <Row style={[Style.Main.fullWidth, isDisabled && Style.Main.halfOpacity]}>
          <Col size={isThreeRow ? 0.9 : 0.95} style={[colIconStyle, Style.Main.justifyCenter]}>
            <OutlineCheckbox
              label={data.label}
              checked={isChecked}
              sideLabel={isThreeRow && data.value}
              // value={data.value}
              // color={isChecked ? 'red' : 'lightgrey'}
              // styleLabel={[Style.Main.textAlmostBlack, Style.Main.fontAlbert, this.props.fontStyle]}
              // style={[{ margin: -10 }]}
              style={this.props.style && this.props.style.length ? [...this.props.style] : [this.props.style]}
              styleLabel={fontStyle && fontStyle.length ? [...fontStyle] : [fontStyle]}
              onPress={isDisabled ? () => {} : () => this.onCheckBoxPressed(data.value)}
            />
          </Col>
          {/* <Col size={18} style={[colLabelStyle]}>
            <Text
              style={[Style.Main.textAlmostBlack, Style.Main.fontAlbert, this.props.fontStyle]}
              onPress={isDisabled ? () => { } : () => this.onCheckBoxPressed(data.value)}
            >
              {data.label}
            </Text>
          </Col> */}
        </Row>
        {data.isTextInput && isChecked && (
          <InputField
            value={this.renderInputValue(data) || ''}
            ref={(ref) => {
              this[`_inputField${i}`] = ref;
            }}
            placeholder="Enter"
            onChangeText={() => this.onTextInput(i)}
            type={data.textType || textType}
            setValueToParent={this.setValueFromChild}
            isRequired={this.props.isRequiredTextInput}
            index={i}
            isInsideCheckbox
            editable={!isDisabled}
            textInputStyle={Platform.OS === 'ios' ? Style.Main.mt0 : null}
            formStyle={[Style.Main.mt0]}
            labelStyle={[Style.Main.mt0, Style.Main.font0]}
            style={[isInputBackgroundWhite ? Style.Main.backgroundWhite : Style.Main.backgroundBrightGray]}
          />
        )}

        {data.isTextArea && isChecked && (
          <TextArea
            onChangeText={() => this.onTextInput(i)}
            setValueToParent={this.setValueFromChild}
            index={i}
            value={this.renderInputValue(data) || ''}
            ref={(ref) => {
              this[`_inputField${i}`] = ref;
            }}
            placeholder={this.props.placeholder}
          />
        )}
      </View>
    );
  };

  renderColumn = (i, data) => {
    const {
      fontStyle,
      renderData,
      colIconStyle,
      // colLabelStyle,
      colInputStyle,
      colIconSize,
      // colLabelSize,
      textType,
    } = this.props;
    // const {
    //   checkBoxData,
    //   // disabled,
    // } = this.state;
    const lastIndex = renderData.length - 1;
    const oddsIndex = renderData.length % 2 !== 0;
    const isChecked = this.isIncluded(data.value, this.props.selectedObjects);
    const isDisabled = this.isIncluded(data.value, this.props.disabledValues);
    // const isChecked = this.isIncluded(data.value, this.props.selectedObjects) || checkBoxData[i].isSelected;
    // const isDisabled = this.isIncluded(data.value, this.props.disabledValues) || disabled;
    return (
      <Col size={oddsIndex && i === lastIndex ? 0.5 : 1} key={`col ${i}`}>
        <Row style={isDisabled && Style.Main.halfOpacity}>
          <Col size={colIconSize} style={[colIconStyle]}>
            <OutlineCheckbox
              checked={isChecked}
              // checked={checkBoxData[i].isSelected}
              // value={data.value}
              label={data.label}
              // color={isChecked ? 'red' : 'lightgrey'}
              // color={checkBoxData[i].isSelected ? 'red' : 'lightgrey'}
              // eslint-disable-next-line react-native/no-inline-styles
              // style={[{ marginLeft: -10 }]}
              style={this.props.style && this.props.style.length ? [...this.props.style] : [this.props.style]}
              styleLabel={fontStyle && fontStyle.length ? [...fontStyle] : [fontStyle]}
              onPress={isDisabled ? () => {} : () => this.onCheckBoxPressed(data.value)}
            />
          </Col>
          {/* <Col size={colLabelSize} style={[colLabelStyle]}>
            <Text
              style={[Style.Main.textAlmostBlack, Style.Main.fontAlbert, fontStyle]}
              onPress={isDisabled ? () => { } : () => this.onCheckBoxPressed(data.value)}
            >
              {data.label}
            </Text>
          </Col> */}
        </Row>
        {
          // (data.isTextInput && checkBoxData[i].isSelected) && (
          (data.isTextInput && isChecked) && (
            <Row>
              <Col style={[colInputStyle]}>
                <InputField
                  value={this.renderInputValue(data) || ''}
                  ref={(ref) => { this[`_inputField${i}`] = ref; }}
                  placeholder="Enter"
                  onChangeText={() => this.onTextInput(i)}
                  type={data.textType || textType}
                  setValueToParent={this.setValueFromChild}
                  index={i}
                  isRequired={this.props.isRequiredTextInput}
                  editable={!isDisabled}
                  textInputStyle={Platform.OS === 'ios' ? Style.Main.mt0 : null}
                  formStyle={[Style.Main.mt0, Style.Main.pt0]}
                  labelStyle={[Style.Main.mt0, Style.Main.pt0]}
                  itemStyle={[Style.Main.height30]}
                />
              </Col>
            </Row>
          )
        }
      </Col>
    );
  };

  render() {
    console.log('this checkbox being rendered');
    const {
      title, titleStyle, isAllRequired,
    } = this.props;
    const {
      checkBoxData, validStatus, errorMessage,
      validStatusInvoked, errorMessageInvoked,
    } = this.state;
    // eslint-disable-next-line prefer-const
    let renderData = [];
    for (let i = 0; i < checkBoxData.length; i += 2) {
      // eslint-disable-next-line prefer-const
      let column = [];
      column.push(this.renderColumn(i, checkBoxData[i]));
      if (i + 1 < checkBoxData.length) {
        column.push(this.renderColumn(i + 1, checkBoxData[i + 1]));
      }
      renderData.push(<Row key={`row ${i}`}>{column}</Row>);
    }
    const selected = checkBoxData.filter(x => x.isSelected);
    const selectedWInput = selected.filter(x => x.isTextInput && x.input === '').length >= 1;
    const selectedObjs = this.props.selectedObjects ? this.props.selectedObjects : [];
    const selectedObj = isAllRequired ? this.state.checkBoxData.some(x => !x.isSelected) : selectedObjs.length <= 0;
    return (
      <Fragment>
        {
          title && (
            // <Row style={[Style.Main.mt15, Style.Main.mb5]}>
            <Row style={[Style.Main.mt15]}>
              <Text style={[Style.Main.textGray, Style.Main.font11, Style.Main.fontAlbert11, titleStyle]}>
                {_(title)}
              </Text>
            </Row>
          )
        }
        <View style={this.props.itemStyle}>
          {this.props.isOneColumn ? this.props.renderData.map((item, i) => this.renderOneColumn(i, item)) : renderData}
        </View>
        {!validStatus && (!this.props.selectedObjects || selectedObj || selectedWInput) && this.props.isRequired && (
          <Row>
            <Text style={[Style.Main.textRed, Style.Main.ml15, Style.Main.font10, Style.Main.mb15, Style.Main.fontAlbert]}>{_(errorMessage)}</Text>
          </Row>
        )}
        {!validStatusInvoked && this.props.isRequired && (
          <Row>
            <Text style={[Style.Main.textRed, Style.Main.ml15, Style.Main.font10, Style.Main.mb15, Style.Main.fontAlbert]}>
              {_(errorMessageInvoked)}
            </Text>
          </Row>
        )}
      </Fragment>
    );
  }
}

CheckBoxCard.propTypes = {
  colIconSize: PropTypes.number,
  // colLabelSize: PropTypes.number,
  fontStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  colIconStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  // colLabelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  colInputStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  textType: PropTypes.string,

  // added
  itemStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  selectedObjects: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  valueProp: PropTypes.string,
  inputLabelProp: PropTypes.string,
  isOneColumn: PropTypes.bool,
  isInputBackgroundWhite: PropTypes.bool,
  isRequired: PropTypes.bool,
  isAllRequired: PropTypes.bool,
  disabledValues: PropTypes.arrayOf(PropTypes.oneOfType([
    PropTypes.number, PropTypes.string, PropTypes.bool, PropTypes.object,
  ])),
  isRequiredTextInput: PropTypes.bool,
  invokedValidation: PropTypes.bool,

};

CheckBoxCard.defaultProps = {
  colIconSize: 10,
  // colLabelSize: 90,
  fontStyle: StyleCheckBox.fontStyle,
  colIconStyle: StyleCheckBox.colIconStyle,
  // colLabelStyle: StyleCheckBox.colLabelStyle,
  colInputStyle: StyleCheckBox.colInputStyle,
  textType: 'default',

  // added
  itemStyle: null,
  valueProp: 'value',
  inputLabelProp: 'input',
  selectedObjects: null,
  isOneColumn: false,
  isInputBackgroundWhite: false,
  isRequired: true,
  isAllRequired: false,
  disabledValues: null,
  isRequiredTextInput: true,
  invokedValidation: false,

};

export default CheckBoxCard;

// ========== KETERANGAN PROPS =========== //
// renderData: Strukturnya seperti berikut
// const data = [
//   {
//     label: 'Kerja Serabutan',
//     value: 'B',
//     isSelected: false,
//     isTextInput: true,
//     textType: 'default',
//     input: '',
//   },
//   {
//     label: 'Pengangguran',
//     value: 'C',
//     isSelected: false,
//     isTextInput: false,
//   },
// ]
//
//  ref CheckBoxCard ini adalah:
//  1. CheckBoxData: berupa arrayObject yang di lemparkan
//     sebagai dataRender yang sudah diedit di dalam komponen ini;
//  2. ValidStatus: berupa bolean yang menandakan bahwa komponen ini
//     sudah ada pilihan atau belum;
//  3. ValidStatusInvoke: berupa bolean yang menandakan bahwa komponen ini
//     sudah ada pilihan atau belum berdasarkan validasi khusus dari index atau parent;
//  4. ErrorMessage: pesan mengenai terdapat pilihan yang kurang atau belum diisi input field
//  5. ErrorMessageInvoked: pesan mengenai terdapat pilihan yang kurang atau belum diisi input field
//     berdasarkan validasi khusus dari index atau parent;
