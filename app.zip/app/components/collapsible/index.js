import React from 'react';
import PropTypes from 'prop-types';
import { View, Card, Icon } from 'native-base';
import { TouchableWithoutFeedback } from 'react-native-gesture-handler';
import { StyledText } from '../common-components';
import Style from '../../styles';
import Colors from '../../styles/Colors';
import _ from '../../lang';
import { rowLayout, Skeleton } from '../skeleton-loading';
import { isEmpty } from '../../utilities';

/** @augments {React.PureComponent<Props, State>} */
class Collapsible extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isExpanded: this.props.isExpanded !== null ? this.props.isExpanded : true,
    };
  }

  componentDidUpdate = (prevProps) => {
    if (!this.props.onExpand && prevProps.isExpanded !== this.props.isExpanded) this.onPropsChanged();
  }

  componentDidMount = () => this.onPropsChanged()

  componentWillUnmount = () => this.onPropsChanged()

  onPropsChanged = () => this.setState({ isExpanded: this.props.isExpanded !== null ? this.props.isExpanded : true });

  onExpand = () => {
    this.setState(prevState => ({ isExpanded: !prevState.isExpanded }), () => {
      if (this.props.onExpand) this.props.onExpand();
    });
  }

  render() {
    const {
      title, rightTitle, titleStyle, rightTitleStyle, content, expandedContent, noShadow, style, lineType, onDetail,
      isLoading, expandable, onExpand, noBorder, titleBold, headerStyle, iconName, iconType,
    } = this.props;
    const isExpanded = this.props.isExpanded !== null && onExpand ? this.props.isExpanded : this.state.isExpanded;
    const Tag = noShadow || noBorder ? View : Card;
    const HeaderTag = expandable ? TouchableWithoutFeedback : View;
    return (
      <Tag style={[!noBorder && Style.Main.padding12, Style.Main.container,
        noShadow && [Style.Main.mb10, Style.Main.setBorder({ borderRadius: 5 })], style]}
      >
        <HeaderTag
          onPress={this.onExpand}
          style={[Style.Main.container, Style.Main.rowDirectionSpaceBetween, noBorder && Style.Main.py7,
            lineType === 'bottom' && [Style.Main.borderBottomNativeBase, Style.Main.pb10], headerStyle]}
        >
          <View style={[!isEmpty(iconName) && Style.Main.rowDirection, Style.Main.setSize({ maxWidth: isEmpty(rightTitle) ? '85%' : '65%' }),
            lineType !== 'center' && Style.Main.container]}
          >
            {!isEmpty(iconName) && <Icon type={iconType} name={iconName} style={[Style.Main.pr25, Style.Main.textColor3f3]} />}
            <Skeleton isLoading={isLoading} layout={[rowLayout({ h: 9, w: 150 })]}>
              <StyledText ellipsizeMode="tail" numberOfLines={1} bold={titleBold} style={[Style.Main.container, titleStyle]}>{title}</StyledText>
            </Skeleton>
          </View>
          {lineType === 'center' && <View style={[Style.Main.horizontalLine, Style.Main.ml10, Style.Main.fullWidth]} />}
          <>
            {!isEmpty(rightTitle) && <StyledText style={[Style.Main.ml10, rightTitleStyle]}>{rightTitle}</StyledText>}
            {expandable && <Icon style={[Style.Main.pl10, Style.Main.textColor3f3]} name={isExpanded ? 'chevron-up' : 'chevron-down'} />}
          </>
        </HeaderTag>
        <View style={[Style.Main.container, lineType !== 'no-line' && Style.Main.mt10]}>
          {content}
          {
            expandable && isExpanded &&
            <View style={[Style.Main.container, noBorder ? Style.Main.pb10 : Style.Main.mt10]}>
              {expandedContent}
              {
                onDetail && onDetail !== (() => {}) &&
                <StyledText bold color={Colors.red} style={[Style.Main.pt18, Style.Main.pl25, Style.Main.timeStyle]} onPress={onDetail}>
                  {_('Lihat Rincian')}
                </StyledText>
              }
            </View>
          }
        </View>
      </Tag>
    );
  }
}

Collapsible.propTypes = {
  /** @type 'bottom' | 'center' | 'no-line' */
  lineType: PropTypes.string,
  title: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  rightTitle: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  titleStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  rightTitleStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  headerStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  content: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  expandedContent: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  iconName: PropTypes.string,
  iconType: PropTypes.string,
  titleBold: PropTypes.bool,
  noShadow: PropTypes.bool,
  noBorder: PropTypes.bool,
  isLoading: PropTypes.bool,
  isExpanded: PropTypes.bool,
  expandable: PropTypes.bool,
  onExpand: PropTypes.func,
  onDetail: PropTypes.func,
};

Collapsible.defaultProps = {
  lineType: 'center',
  title: '',
  rightTitle: '',
  titleStyle: null,
  rightTitleStyle: null,
  style: null,
  headerStyle: null,
  content: null,
  expandedContent: null,
  iconName: null,
  iconType: 'MaterialCommunityIcons',
  titleBold: true,
  noShadow: false,
  noBorder: false,
  isLoading: false,
  expandable: true,
  isExpanded: null,
  onExpand: null,
  onDetail: null,
};

export default Collapsible;
