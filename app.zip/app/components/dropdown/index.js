/**
 * @author: ahmdichsanb@gmail.com
*/

import React, { PureComponent, Fragment } from 'react';
import {
  Picker, Platform, View,
} from 'react-native';
import PropTypes from 'prop-types';
import InputField from '../input-field';
import StyleDropdown from './StyleDropdown';
import Style from '../../styles';

class Dropdown extends PureComponent {
  render() {
    const {
      mode,
      enabled,
      placeholder,
      styleTextInput,
      stylePickerBody,
      stylePickerView,
      dropdownData,
      selectedValue,
      textColor,
      valueProperty,
      labelProperty,
    } = this.props;

    const dropdown = dropdownData.map((item, index) => {
      const label = item[labelProperty];
      const value = item[valueProperty];
      const order = index;
      return (
        <Picker.Item
          key={order}
          label={label}
          value={value}
          color={textColor}
          style={[Style.Main.fontAlbert, Style.Main.font14]}
        />
      );
    });

    const normalPicker = (
      <View style={stylePickerView}>
        <Picker
          mode={mode}
          selectedValue={selectedValue || ''}
          style={stylePickerBody}
          onValueChange={e => this.props.handleDropdownValue(e)}
          enabled={enabled}
          itemStyle={[Style.Main.fontAlbert, Style.Main.font14]}
        >
          {dropdown}
        </Picker>
      </View>
    );

    const value = dropdownData.find(e => e[valueProperty] === selectedValue);
    const iosPickerDisable = (
      <InputField
        type="text"
        value={value ? value[labelProperty] : ''}
        editable={false}
        placeholder={placeholder}
        styleTextInput={styleTextInput}
      />
    );
    return (
      <Fragment>
        {
          Platform.OS === 'ios' && enabled === false ? iosPickerDisable : normalPicker
        }
      </Fragment>
    );
  }
}

Dropdown.propTypes = {
  enabled: PropTypes.bool,
  placeholder: PropTypes.string,
  mode: PropTypes.string,
  selectedValue: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
  ]).isRequired,
  handleDropdownValue: PropTypes.func.isRequired,
  dropdownData: PropTypes.arrayOf(PropTypes.object).isRequired,
  styleTextInput: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  stylePickerBody: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  stylePickerView: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  labelProperty: PropTypes.string,
  valueProperty: PropTypes.string,
};

Dropdown.defaultProps = {
  enabled: true,
  placeholder: 'Type here',
  mode: 'dialog',
  styleTextInput: StyleDropdown.styleTextInput,
  stylePickerBody: null,
  stylePickerView: StyleDropdown.styleTextInput,
  labelProperty: 'label',
  valueProperty: 'value',
};

export default Dropdown;
