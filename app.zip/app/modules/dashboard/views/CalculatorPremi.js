import React, { Component } from 'react';
import {
  TouchableOpacity, View, Modal, SafeAreaView, BackHandler, Dimensions, Alert, Image,
} from 'react-native';
import { Icon } from 'native-base';
import WebView from 'react-native-webview';
import { connect } from 'react-redux';
import Style from '../../../styles';
import { isTablet } from '../../../utilities';
import calculatorImage from '../../../assets/images/PrufastBanner-KalkulatorAsuransi.jpg';


class CalculatorPremi extends Component {
  state = {
    openCalculator: false,
    canGoBack: false,
  }

  imageWidth = '100%';

  imageHeight = this.props.height;

  onOpenCalculator = () => {
    if (!this.props.isOnline) {
      Alert.alert('Kesalahan', 'Pastikan anda sedang online',
        [{ text: 'Tutup', onPress: () => this.setState({ openCalculator: false }) }], { cancelable: false });
    } else {
      this.setState({ openCalculator: true });
    }
  }

  onCloseCalculator = () => {
    this.setState({ openCalculator: false });
  }

  onShowCalculator = () => {
    BackHandler.addEventListener('hardwareBackPress', this.backHandlerWebView);
  }

  onDismissCalculator = () => {
    BackHandler.removeEventListener('hardwareBackPress', this.backHandlerWebView);
  }

  backHandlerWebView = () => {
    if (this.state.canGoBack) {
      this._webview.goBack();
      return true;
    }
    this.setState({ openCalculator: false });
    return false;
  }

  renderWebView = () => (
    <Modal
      visible={this.state.openCalculator}
      animationType="slide"
      onDismiss={this.onDismissCalculator}
      onShow={this.onShowCalculator}
      onRequestClose={this.backHandlerWebView}
      presentationStyle="fullScreen"
    >
      <SafeAreaView style={[Style.Main.container]}>
        <View style={{ height: Dimensions.get('window').width * (isTablet() ? 0.04 : 0.1) }}>
          <View
            style={[Style.Main.fullWidth, Style.Main.rowDirectionFlexEnd, Style.Main.padding10, Style.Main.alignCenter]}
          >
            <TouchableOpacity
              onPress={() => this.onCloseCalculator()}
              activeOpacity={1}
              style={[Style.Main.rowDirection]}
            >
              <Icon
                name="close"
                type="MaterialIcons"
                style={[Style.Main.textRed, Style.Main.font24, Style.Main.mr5]}
              />
            </TouchableOpacity>
          </View>
        </View>
        <WebView
          style={[Style.Main.container]}
          scalesPageToFit={false}
          startInLoadingState
          ref={(ref) => { this._webview = ref; }}
          onNavigationStateChange={state => this.setState({ canGoBack: state.canGoBack })}
          source={{ uri: 'https://www.prudential.co.id/id/kalkulator-premi/nat_html5/id-id.html' }}
        />
      </SafeAreaView>
    </Modal>
  )

  render() {
    return (
      <React.Fragment>
        <TouchableOpacity
          onPress={() => this.onOpenCalculator()}
          style={[Style.Main.mb15, Style.Main.mr12, Style.Main.ml12]}
        >
          <Image
            source={calculatorImage}
            resizeMode="stretch"
            style={[
              Style.Main.radius8,
              Style.Main.container,
              {
                height: this.imageHeight,
                width: this.imageWidth,
              },
            ]}
          />
        </TouchableOpacity>
        {this.renderWebView()}
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  isOnline: state.connectionStatus.isOnline,
});
export default connect(mapStateToProps)(CalculatorPremi);
