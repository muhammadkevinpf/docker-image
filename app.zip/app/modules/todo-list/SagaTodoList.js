
import {
  call, put, takeLatest, takeEvery,
} from 'redux-saga/effects';
import {
  TOTALTODOFETCH, TOTALTODOAPI,
  TOTALTODORECRUITMENTFETCH, TOTALTODORECRUITMENTAPI,
  TOTALTODONTUCASEFETCH, TOTALTODONTUCASEAPI,
  TOTALTODOBILLINGPENDINGFETCH, TOTALTODOBILLINGPENDINGAPI,
  TOTALTODOPOLICYHOLDERFETCH, TOTALTODOPOLICYHOLDERAPI,
  TOTALTODOCLAIMPENDINGFETCH, TOTALTODOCLAIMPENDINGAPI,
  TOTALTODOPOLICYDUEDATEFETCH, TOTALTODOPOLICYDUEDATEAPI,
  TOTALTODOCLIENTBIRTHDAYFETCH, TOTALTODOCLIENTBIRTHDAYAPI,
  TOTALTODOPOLICYDUEDATEAGEINGFETCH, TOTALTODOPOLICYDUEDATEAGEINGAPI,

  FINDLISTTODORECRUITMENTFETCH, FINDLISTTODORECRUITMENTAPI,
  FINDLISTTODONEWBUSINESSFETCH, FINDLISTTODONEWBUSINESSAPI,
  FINDLISTTODOFUNDHISTORYFETCH, FINDLISTTODOFUNDHISTORYAPI,
  FINDLISTTODOFOLLOWUPFETCH, FINDLISTTODOFOLLOWUPAPI,
  FINDLISTTODOFOLLOWUPPOLICYFETCH, FINDLISTTODOFOLLOWUPPOLICYAPI,
  FINDLISTTODOCLAIMHISTORYNONDEATHFETCH, FINDLISTTODOCLAIMHISTORYNONDEATHAPI,
  FINDLISTTODOCLAIMHISTORYPREMIUMFETCH, FINDLISTTODOCLAIMHISTORYPREMIUMAPI,
  FINDLISTTODOCLAIMHISTORYDEATHFETCH, FINDLISTTODOCLAIMHISTORYDEATHAPI,
  FINDLISTTODOBILLINGPENDINGFETCH, FINDLISTTODOBILLINGPENDINGAPI,
  FINDLISTTODOPOLICYHOLDERFETCH, FINDLISTTODOPOLICYHOLDERAPI,
  FINDLISTTODOPENDINGCLAIMFETCH, FINDLISTTODOPENDINGCLAIMAPI,
  FINDLISTTODOCLIENTBIRTHDAYRECENTFETCH, FINDLISTTODOCLIENTBIRTHDAYRECENTAPI,
  FINDLISTTODOCLIENTBIRTHDAYTODAYFETCH, FINDLISTTODOCLIENTBIRTHDAYTODAYAPI,
  FINDLISTTODOCLIENTBIRTHDAYUPCOMINGFETCH, FINDLISTTODOCLIENTBIRTHDAYUPCOMINGAPI,
  FINDLASTUPDATECLIENTAPI, FINDLASTUPDATECLIENTFETCH,
  FINDLASTUPDATEPOLICYAPI, FINDLASTUPDATEPOLICYFETCH, CLIENTPROFILEAPI,
  CLIENTPROFILEFETCH, CLIENTPOLICYOWNERAPI, CLIENTPOLICYOWNERFETCH,
  CLIENTPOLICYLISTAPI, CLIENTPOLICYLISTFETCH, CLIENTPROPOSALLISTAPI,
  CLIENTPROPOSALLISTFETCH, CLIENTSUMATRISKAPI, CLIENTSUMATRISKFETCH, FINDLISTTODOPRODUCTDETAILAPI, FINDLISTTODOPRODUCTDETAILFETCH,
  // AfterDueDateTotal
  AFTERDUEDATETOTALAPI,
  AFTERDUEDATETOTALFETCH,
  // AllAfterDueDateTotal
  ALLAFTERDUEDATETOTALAPI,
  ALLAFTERDUEDATETOTALFETCH,
  // AfterDueDatePolicyList
  AFTERDUEDATEPOLICYLISTAPI,
  AFTERDUEDATEPOLICYLISTFETCH,
  // BeforeDueDatePolicyList
  BEFOREDUEDATEPOLICYLISTAPI,
  BEFOREDUEDATEPOLICYLISTFETCH,
  // afterDueDatePolicyDetail
  AFTERDUEDATEPOLICYDETAILAPI,
  AFTERDUEDATEPOLICYDETAILFETCH,

  TOTALPOLICYINCANCELPERIODAPI,
  TOTALPOLICYINCANCELPERIODFETCH,

  POLICYINCANCELPERIODAPI,
  POLICYINCANCELPERIODFETCH,

  // Rincian Polis Start
  LISTCLIENTBYAGENTNUMBERAPI,
  LISTCLIENTBYAGENTNUMBERFETCH,

  PROFILECLIENTBYAGENTNUMBERAPI,
  PROFILECLIENTBYAGENTNUMBERFETCH,

  // getPolicyMovementHistory
  GETPOLICYMOVEMENTHISTORYFETCH,
  GETPOLICYMOVEMENTHISTORYAPI,
  MEDICAL_LETTER_PDF,
  CLIENT_VIP_INFO,
  HNWI_TAGGING,
  HNWI_CALCULATOR,
  DOWNLOAD_PROPOSAL_PDF,
  BEFOREDUEDATETOTALAPI,
  BEFOREDUEDATETOTALFETCH,
  DOWNLOAD_CLIENT_DETAIL_PDF,
  DOWNLOAD_FUND_TRANSACTION_PDF,
  GET_PERSONAL_DATA,
  GET_PROPOSAL_POLICY,
  GET_PREMIUM_DATA,
  GET_PRODUCT_LIST,
  GET_UPDATED_DATE,
  GET_ALLOCATION,
  GET_FUND_HOLDING,
  GET_DOCUMENT,
  FINDFILTERFOLLOWUPSTATUSAPI,
  FINDFILTERFOLLOWUPSTATUSFETCH,
  FINDFILTERFOLLOWUPSTATUSTODOAPI,
  FINDFILTERFOLLOWUPSTATUSTODOFETCH,
} from './ConfigTodoList';

import {
  totalToDoSuccess,
  totalToDoFailed,

  totalToDoRecruitmentSuccess,
  totalToDoRecruitmentFailed,

  totalToDoNTUCaseSuccess,
  totalToDoNTUCaseFailed,

  totalToDoBillingPendingSuccess,
  totalToDoBillingPendingFailed,

  totalToDoPolicyHolderSuccess,
  totalToDoPolicyHolderFailed,

  totalToDoClaimPendingSuccess,
  totalToDoClaimPendingFailed,

  totalToDoPolicyDueDateSuccess,
  totalToDoPolicyDueDateFailed,

  totalToDoPolicyDueDateAgeingSuccess,
  totalToDoPolicyDueDateAgeingFailed,

  totalToDoClientBirthDaySuccess,
  totalToDoClientBirthDayFailed,

  findListToDoRecruitmentSuccess,
  findListToDoRecruitmentFailed,

  findListToDoNewBusinessSuccess,
  findListToDoNewBusinessFailed,

  findListToDoFundHistorySuccess,
  findListToDoFundHistoryFailed,

  findListToDoFollowUpSuccess,
  findListToDoFollowUpFailed,

  findListToDoFollowUpPolicySuccess,
  findListToDoFollowUpPolicyFailed,

  findListToDoClaimHistoryNonDeathSuccess,
  findListToDoClaimHistoryNonDeathFailed,

  findListToDoClaimHistoryPremiumSuccess,
  findListToDoClaimHistoryPremiumFailed,

  findListToDoClaimHistoryDeathSuccess,
  findListToDoClaimHistoryDeathFailed,

  findListToDoBillingPendingSuccess,
  findListToDoBillingPendingFailed,

  findListToDoPolicyHolderSuccess,
  findListToDoPolicyHolderFailed,

  findListToDoPendingClaimSuccess,
  findListToDoPendingClaimFailed,

  findListToDoClientBirthDayRecentSuccess,
  findListToDoClientBirthDayRecentFailed,

  findListToDoClientBirthDayTodaySuccess,
  findListToDoClientBirthDayTodayFailed,

  findListToDoClientBirthDayUpComingSuccess,
  findListToDoClientBirthDayUpComingFailed,
  findLastUpdateClientSuccess,
  findLastUpdateClientFailed,
  findLastUpdatePolicySuccess,
  findLastUpdatePolicyFailed,
  clientProfileSuccess,
  clientProfileFailed,
  clientPolicyOwnerSuccess,
  clientPolicyOwnerFailed,
  clientPolicyListSuccess,
  clientPolicyListFailed,
  clientProposalListSuccess,
  clientProposalListFailed,
  clientSumAtRiskSuccess,
  clientSumAtRiskFailed,
  findListToDoProductDetailSuccess,
  findListToDoProductDetailFailed,
  afterDueDateTotalSuccess,
  afterDueDateTotalFailed,
  beforeDueDateTotalSuccess,
  beforeDueDateTotalFailed,

  allAfterDueDateTotalSuccess,
  allAfterDueDateTotalFailed,

  afterDueDatePolicyListSuccess,
  afterDueDatePolicyListFailed,

  beforeDueDatePolicyListSuccess,
  beforeDueDatePolicyListFailed,

  afterDueDatePolicyDetailSuccess,
  afterDueDatePolicyDetailFailed,

  totalPolicyInCancelPeriodSuccess,
  totalPolicyInCancelPeriodFailed,

  policyInCancelPeriodSuccess,
  policyInCancelPeriodFailed,

  // Rincian Polis Start
  listClientByAgentNumberSuccess,
  listClientByAgentNumberFailed,

  profileClientByAgentNumberSuccess,
  profileClientByAgentNumberFailed,

  // getPolicyMovementHistory
  getPolicyMovementHistorySuccess,
  getPolicyMovementHistoryFailed,
  findFilterFollowUpStatusSuccess,
  findFilterFollowUpStatusFailed,
  findFilterFollowUpStatusTodoSuccess,
  findFilterFollowUpStatusTodoFailed,
} from './ActionTodoList';
import { resourceRequest } from '../../utilities/StoreApi';
import { sagaWatcherErrorHandling } from '../../utilities/ErrorHandling';
import { apiTakeLatest } from '../../utilities';

// -- Saga Total ToDo -- //

function* workerSagaTotalToDo(params) {
  try {
    const resTotalToDo = yield call(resourceRequest, TOTALTODOAPI, 'post', params.send);
    // console.log('Success response: ', resTotalToDo); // eslint-disable-line no-console

    if (resTotalToDo.status === '200' || resTotalToDo.status === 200) {
      yield put.resolve(totalToDoSuccess(resTotalToDo.data.total));
    } else {
      yield put.resolve(totalToDoFailed(resTotalToDo.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(totalToDoFailed(parseError));
  }
}

// -- Saga Total List ToDo -- //

function* workerSagaTotalRecruitmentToDo(params) {
  try {
    const resTotalRecruitmentToDo = yield call(resourceRequest, TOTALTODORECRUITMENTAPI, 'post', params.send);
    // console.log('Success response Recruitment: ', resTotalRecruitmentToDo); // eslint-disable-line no-console

    if (
      (resTotalRecruitmentToDo.status === '200' || resTotalRecruitmentToDo.status === 200)
      &&
      resTotalRecruitmentToDo.data.array[0].total !== undefined
    ) {
      yield put.resolve(totalToDoRecruitmentSuccess(resTotalRecruitmentToDo.data.array[0].total));
    } else {
      yield put.resolve(totalToDoRecruitmentFailed(resTotalRecruitmentToDo.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(totalToDoRecruitmentFailed(parseError));
  }
}

function* workerSagaTotalNTUCaseToDo(params) {
  try {
    const resTotalNTUCaseToDo = yield call(resourceRequest, TOTALTODONTUCASEAPI, 'post', params.send);
    // console.log('Success response NTU: ', resTotalNTUCaseToDo); // eslint-disable-line no-console

    if (
      (resTotalNTUCaseToDo.status === '200' || resTotalNTUCaseToDo.status === 200)
      &&
      resTotalNTUCaseToDo.data.array[0].total !== undefined
    ) {
      yield put.resolve(totalToDoNTUCaseSuccess(resTotalNTUCaseToDo.data.array[0].total));
    } else {
      yield put.resolve(totalToDoNTUCaseFailed(resTotalNTUCaseToDo.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(totalToDoNTUCaseFailed(parseError));
  }
}

function* workerSagaTotalBillingPendingToDo(params) {
  try {
    const resTotalBillingPendingToDo = yield call(resourceRequest, TOTALTODOBILLINGPENDINGAPI, 'post', params.send);
    // console.log('Success response Billing: ', resTotalBillingPendingToDo); // eslint-disable-line no-console

    if (
      (resTotalBillingPendingToDo.status === '200' || resTotalBillingPendingToDo.status === 200)
      &&
      resTotalBillingPendingToDo.data.array[0].total !== undefined
    ) {
      yield put.resolve(totalToDoBillingPendingSuccess(resTotalBillingPendingToDo.data.array[0].total));
    } else {
      yield put.resolve(totalToDoBillingPendingFailed(resTotalBillingPendingToDo.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(totalToDoBillingPendingFailed(parseError));
  }
}

function* workerSagaTotalPolicyHolderToDo(params) {
  try {
    const resTotalPolicyHolderToDo = yield call(resourceRequest, TOTALTODOPOLICYHOLDERAPI, 'post', params.send);
    // console.log('Success response Policy Holder: ', resTotalPolicyHolderToDo); // eslint-disable-line no-console

    if (
      (resTotalPolicyHolderToDo.status === '200' || resTotalPolicyHolderToDo.status === 200)
      &&
      resTotalPolicyHolderToDo.data.array[0].total !== undefined
    ) {
      yield put.resolve(totalToDoPolicyHolderSuccess(resTotalPolicyHolderToDo.data.array[0].total));
    } else {
      yield put.resolve(totalToDoPolicyHolderFailed(resTotalPolicyHolderToDo.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(totalToDoPolicyHolderFailed(parseError));
  }
}

function* workerSagaTotalClaimPendingToDo(params) {
  try {
    const resTotalClaimPendingToDo = yield call(resourceRequest, TOTALTODOCLAIMPENDINGAPI, 'post', params.send);
    // console.log('Success response Claim Pending: ', resTotalClaimPendingToDo); // eslint-disable-line no-console

    if (
      (resTotalClaimPendingToDo.status === '200' || resTotalClaimPendingToDo.status === 200)
      &&
      resTotalClaimPendingToDo.data.array[0].total !== undefined
    ) {
      yield put.resolve(totalToDoClaimPendingSuccess(resTotalClaimPendingToDo.data.array[0].total));
    } else {
      yield put.resolve(totalToDoClaimPendingFailed(resTotalClaimPendingToDo.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(totalToDoClaimPendingFailed(parseError));
  }
}

function* workerSagaTotalPolicyDueDateToDo(params) {
  try {
    const resTotalPolicyDueDateToDo = yield call(resourceRequest, TOTALTODOPOLICYDUEDATEAPI, 'post', params.send);
    // console.log('Success response Due Date: ', resTotalPolicyDueDateToDo); // eslint-disable-line no-console

    if (
      (resTotalPolicyDueDateToDo.status === '200' || resTotalPolicyDueDateToDo.status === 200)
      &&
      resTotalPolicyDueDateToDo.data.array[0].total !== undefined
    ) {
      yield put.resolve(totalToDoPolicyDueDateSuccess(resTotalPolicyDueDateToDo.data.array[0].total));
    } else {
      yield put.resolve(totalToDoPolicyDueDateFailed(resTotalPolicyDueDateToDo.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(totalToDoPolicyDueDateFailed(parseError));
  }
}

function* workerSagaTotalPolicyDueDateAgeingToDo(params) {
  try {
    const resTotalPolicyDueDateAgeingToDo = yield call(resourceRequest, TOTALTODOPOLICYDUEDATEAGEINGAPI, 'post', params.send);
    console.log('Success response Due Date: ', resTotalPolicyDueDateAgeingToDo); // eslint-disable-line no-console

    if (
      (resTotalPolicyDueDateAgeingToDo.status === '200' || resTotalPolicyDueDateAgeingToDo.status === 200)
      &&
      resTotalPolicyDueDateAgeingToDo.data.responseData.count !== undefined
    ) {
      yield put.resolve(totalToDoPolicyDueDateAgeingSuccess(resTotalPolicyDueDateAgeingToDo.data.responseData.count));
    } else {
      yield put.resolve(totalToDoPolicyDueDateAgeingFailed(resTotalPolicyDueDateAgeingToDo.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(totalToDoPolicyDueDateAgeingFailed(parseError));
  }
}

function* workerSagaTotalClientBirthDayToDo(params) {
  try {
    const resTotalClientBirthDayToDo = yield call(resourceRequest, TOTALTODOCLIENTBIRTHDAYAPI, 'post', params.send);
    // console.log('Success response Client BirthDay: ', resTotalClientBirthDayToDo); // eslint-disable-line no-console

    if (
      (resTotalClientBirthDayToDo.status === '200' || resTotalClientBirthDayToDo.status === 200)
      &&
      resTotalClientBirthDayToDo.data.totalclient !== undefined
    ) {
      yield put.resolve(totalToDoClientBirthDaySuccess(resTotalClientBirthDayToDo.data.totalclient));
    } else {
      yield put.resolve(totalToDoClientBirthDayFailed(resTotalClientBirthDayToDo.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(totalToDoClientBirthDayFailed(parseError));
  }
}

// --Saga Detail List ToDo--//

// SagaListDetailRecruitmentToDo
function* workerSagaGetListToDoRecruitment(params) {
  try {
    const resListRescruitmentToDo = yield call(resourceRequest, FINDLISTTODORECRUITMENTAPI, 'post', params.send);
    // console.log('Success response Recruitment: ', resListRescruitmentToDo); // eslint-disable-line no-console

    if (
      (resListRescruitmentToDo.status === '200' || resListRescruitmentToDo.status === 200)
      &&
      resListRescruitmentToDo.data.array.length
    ) {
      yield put.resolve(findListToDoRecruitmentSuccess(resListRescruitmentToDo.data.array));
    } else {
      yield put.resolve(findListToDoRecruitmentFailed(resListRescruitmentToDo.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findListToDoRecruitmentFailed(parseError));
  }
}

// SagaListDetailNewBusinessToDo
function* workerSagaGetListToDoNewBusiness(params) {
  try {
    const resListNewBusinessToDo = yield call(resourceRequest, FINDLISTTODONEWBUSINESSAPI, 'post', params.send);
    // console.log('Success response New Business Pending: ', resListNewBusinessToDo); // eslint-disable-line no-console

    if (
      (resListNewBusinessToDo.status === '200' || resListNewBusinessToDo.status === 200)
      &&
      resListNewBusinessToDo.data.array.length
    ) {
      yield put.resolve(findListToDoNewBusinessSuccess(resListNewBusinessToDo.data.array));
    } else {
      yield put.resolve(findListToDoNewBusinessFailed(resListNewBusinessToDo.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findListToDoNewBusinessFailed(parseError));
  }
}

// SagaListDetailFundHistoryToDo
function* workerSagaGetListToDoFundHistory(params) {
  try {
    const resListFundHistory = yield call(resourceRequest, FINDLISTTODOFUNDHISTORYAPI, 'post', params.send);

    if (
      (resListFundHistory.status === '200' || resListFundHistory.status === 200)
      &&
      resListFundHistory.data.array.length
    ) {
      yield put.resolve(findListToDoFundHistorySuccess(resListFundHistory.data.array));
    } else {
      yield put.resolve(findListToDoFundHistoryFailed(resListFundHistory.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findListToDoFundHistoryFailed(parseError));
  }
}

// SagaGetFilterFollowUp
function* workerSagaGetFilterFollowUp(params) {
  try {
    const resFilterFollowUp = yield call(resourceRequest, FINDFILTERFOLLOWUPSTATUSTODOAPI, 'post', params.send);
    if (
      (resFilterFollowUp.status === '200' || resFilterFollowUp.status === 200)
      &&
      resFilterFollowUp.data.array.length
    ) {
      yield put.resolve(findFilterFollowUpStatusTodoSuccess(resFilterFollowUp.data.array));
    } else {
      yield put.resolve(findFilterFollowUpStatusTodoFailed(resFilterFollowUp.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findFilterFollowUpStatusTodoFailed(parseError));
  }
}

// SagaListDetailFollowUpToDo
function* workerSagaGetListToDoFollowUp(params) {
  try {
    const resListFollowUp = yield call(resourceRequest, FINDLISTTODOFOLLOWUPAPI, 'post', params.send);

    if (
      (resListFollowUp.status === '200' || resListFollowUp.status === 200)
      &&
      resListFollowUp.data.array.length
    ) {
      yield put.resolve(findListToDoFollowUpSuccess(resListFollowUp.data.array));
    } else {
      yield put.resolve(findListToDoFollowUpFailed(resListFollowUp.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findListToDoFollowUpFailed(parseError));
  }
}

// SagaListDetailFollowUpPolicyToDo
function* workerSagaGetListToDoFollowUpPolicy(params) {
  try {
    const resListFollowUpPolicy = yield call(resourceRequest, FINDLISTTODOFOLLOWUPPOLICYAPI, 'post', params.send);
    if (
      (resListFollowUpPolicy.status === '200' || resListFollowUpPolicy.status === 200)
      &&
      resListFollowUpPolicy.data.array.length
    ) {
      yield put.resolve(findListToDoFollowUpPolicySuccess(resListFollowUpPolicy.data.array));
    } else {
      yield put.resolve(findListToDoFollowUpPolicyFailed(resListFollowUpPolicy.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findListToDoFollowUpPolicyFailed(parseError));
  }
}

// SagaGetFilterFollowUpPolicy
function* workerSagaGetFilterFollowUpPolicy(params) {
  try {
    const resFilterFollowUpPolicy = yield call(resourceRequest, FINDFILTERFOLLOWUPSTATUSAPI, 'post', params.send);
    if (
      (resFilterFollowUpPolicy.status === '200' || resFilterFollowUpPolicy.status === 200)
      &&
      resFilterFollowUpPolicy.data.array.length
    ) {
      yield put.resolve(findFilterFollowUpStatusSuccess(resFilterFollowUpPolicy.data.array));
    } else {
      yield put.resolve(findFilterFollowUpStatusFailed(resFilterFollowUpPolicy.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findFilterFollowUpStatusFailed(parseError));
  }
}

// SagaListClaimHistoryNonDeath
function* workerSagaGetListToDoClaimHistoryNonDeath(params) {
  try {
    const resListClaimHistoryNonDeath = yield call(resourceRequest, FINDLISTTODOCLAIMHISTORYNONDEATHAPI, 'post', params.send);

    if (
      (resListClaimHistoryNonDeath.status === '200' || resListClaimHistoryNonDeath.status === 200)
      &&
      resListClaimHistoryNonDeath.data.array.length
    ) {
      yield put.resolve(findListToDoClaimHistoryNonDeathSuccess(resListClaimHistoryNonDeath.data.array));
    } else {
      yield put.resolve(findListToDoClaimHistoryNonDeathFailed(resListClaimHistoryNonDeath.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findListToDoClaimHistoryNonDeathFailed(parseError));
  }
}

// SagaListClaimHistoryPremium
function* workerSagaGetListToDoClaimHistoryPremium(params) {
  try {
    const resListClaimHistoryPremium = yield call(resourceRequest, FINDLISTTODOCLAIMHISTORYPREMIUMAPI, 'post', params.send);

    if (
      (resListClaimHistoryPremium.status === '200' || resListClaimHistoryPremium.status === 200)
      &&
      resListClaimHistoryPremium.data.array.length
    ) {
      yield put.resolve(findListToDoClaimHistoryPremiumSuccess(resListClaimHistoryPremium.data.array));
    } else {
      yield put.resolve(findListToDoClaimHistoryPremiumFailed(resListClaimHistoryPremium.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findListToDoClaimHistoryPremiumFailed(parseError));
  }
}

// SagaListClaimHistoryDeath
function* workerSagaGetListToDoClaimHistoryDeath(params) {
  try {
    const resListClaimHistoryDeath = yield call(resourceRequest, FINDLISTTODOCLAIMHISTORYDEATHAPI, 'post', params.send);

    if (
      (resListClaimHistoryDeath.status === '200' || resListClaimHistoryDeath.status === 200)
      &&
      resListClaimHistoryDeath.data.array.length
    ) {
      yield put.resolve(findListToDoClaimHistoryDeathSuccess(resListClaimHistoryDeath.data.array));
    } else {
      yield put.resolve(findListToDoClaimHistoryDeathFailed(resListClaimHistoryDeath.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findListToDoClaimHistoryNonDeathFailed(parseError));
  }
}

// SagaListDetailProductDetailToDo
function* workerSagaGetListToDoProductDetail(params) {
  try {
    const resListProductDetail = yield call(resourceRequest, FINDLISTTODOPRODUCTDETAILAPI, 'post', params.send);
    if (
      (resListProductDetail.status === '200' || resListProductDetail.status === 200)
    ) {
      yield put.resolve(findListToDoProductDetailSuccess(resListProductDetail.data));
    } else {
      yield put.resolve(findListToDoProductDetailFailed(resListProductDetail.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findListToDoProductDetailFailed(parseError));
  }
}

// SagaListDetailBillingPendingToDo
function* workerSagaGetListToDoBillingPending(params) {
  try {
    const resListBillingPendingToDo = yield call(resourceRequest, FINDLISTTODOBILLINGPENDINGAPI, 'post', params.send);
    // console.log('Success response Billing Pending: ', resListBillingPendingToDo); // eslint-disable-line no-console
    if (
      (resListBillingPendingToDo.status === '200' || resListBillingPendingToDo.status === 200)
      &&
      resListBillingPendingToDo.data.array.length
    ) {
      yield put.resolve(findListToDoBillingPendingSuccess(resListBillingPendingToDo.data.array));
    } else {
      yield put.resolve(findListToDoBillingPendingFailed(resListBillingPendingToDo.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findListToDoBillingPendingFailed(parseError));
  }
}

// SagaListDetailPolicyHolderToDo
function* workerSagaGetListToDoPolicyHolder(params) {
  try {
    const resListPolicyHolderToDo = yield call(resourceRequest, FINDLISTTODOPOLICYHOLDERAPI, 'post', params.send);
    // console.log('Success response Policy Holder: ', resListPolicyHolderToDo); // eslint-disable-line no-console

    if (
      (resListPolicyHolderToDo.status === '200' || resListPolicyHolderToDo.status === 200)
      &&
      resListPolicyHolderToDo.data.array[0].total !== undefined
    ) {
      yield put.resolve(findListToDoPolicyHolderSuccess(resListPolicyHolderToDo.data.array[0].total));
    } else {
      yield put.resolve(findListToDoPolicyHolderFailed(resListPolicyHolderToDo.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findListToDoPolicyHolderFailed(parseError));
  }
}

// SagaListDetailPendingClaimToDo
function* workerSagaGetListToDoPendingClaim(params) {
  try {
    const resListPendingClaimToDo = yield call(resourceRequest, FINDLISTTODOPENDINGCLAIMAPI, 'post', params.send);
    if (
      (resListPendingClaimToDo.status === '200' || resListPendingClaimToDo.status === 200)
      &&
      resListPendingClaimToDo.data.array.length
    ) {
      yield put.resolve(findListToDoPendingClaimSuccess(resListPendingClaimToDo.data.array));
    } else {
      yield put.resolve(findListToDoPendingClaimFailed(resListPendingClaimToDo.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findListToDoPendingClaimFailed(parseError));
  }
}

// SagaListDetailClientBirthDay - Recent
function* workerSagaGetListToDoClientBirthDayRecent(params) {
  try {
    const resListClientBirthDayRecent = yield call(resourceRequest, FINDLISTTODOCLIENTBIRTHDAYRECENTAPI, 'post', params.send);
    if (
      (resListClientBirthDayRecent.status === '200' || resListClientBirthDayRecent.status === 200)
      &&
      resListClientBirthDayRecent.data
    ) {
      yield put.resolve(findListToDoClientBirthDayRecentSuccess(resListClientBirthDayRecent.data.array));
    } else {
      yield put.resolve(findListToDoClientBirthDayRecentFailed(resListClientBirthDayRecent.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findListToDoClientBirthDayRecentFailed(parseError));
  }
}

// SagaListDetailClientBirthDay - Today
function* workerSagaGetListToDoClientBirthDayToday(params) {
  try {
    const resListClientBirthDayToday = yield call(resourceRequest, FINDLISTTODOCLIENTBIRTHDAYTODAYAPI, 'post', params.send);
    if (
      (resListClientBirthDayToday.status === '200' || resListClientBirthDayToday.status === 200)
      &&
      resListClientBirthDayToday.data
    ) {
      yield put.resolve(findListToDoClientBirthDayTodaySuccess(resListClientBirthDayToday.data.array));
    } else {
      yield put.resolve(findListToDoClientBirthDayTodayFailed(resListClientBirthDayToday.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findListToDoClientBirthDayTodayFailed(parseError));
  }
}

// SagaListDetailClientBirthDay - UpComing
function* workerSagaGetListToDoClientBirthDayUpComing(params) {
  try {
    const resListClientBirthDayUpComing = yield call(resourceRequest, FINDLISTTODOCLIENTBIRTHDAYUPCOMINGAPI, 'post', params.send);
    if (
      (resListClientBirthDayUpComing.status === '200' || resListClientBirthDayUpComing.status === 200)
      &&
      resListClientBirthDayUpComing.data
    ) {
      yield put.resolve(findListToDoClientBirthDayUpComingSuccess(resListClientBirthDayUpComing.data.array));
    } else {
      yield put.resolve(findListToDoClientBirthDayUpComingFailed(resListClientBirthDayUpComing.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findListToDoClientBirthDayUpComingFailed(parseError));
  }
}

// SagaLastUpdateClient
function* workerSagaGetLastUpdateClient(params) {
  try {
    const res = yield call(resourceRequest, FINDLASTUPDATECLIENTAPI, 'post', params.send);
    if ((res.status === '200' || res.status === 200) && res.data) {
      yield put.resolve(findLastUpdateClientSuccess(res.data.latest));
    } else {
      yield put.resolve(findLastUpdateClientFailed(res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findLastUpdateClientFailed(parseError));
  }
}

// SagaLastUpdatePolicy
function* workerSagaGetLastUpdatePolicy(params) {
  try {
    const res = yield call(resourceRequest, FINDLASTUPDATEPOLICYAPI, 'post', params.send);
    if ((res.status === '200' || res.status === 200) && res.data) {
      yield put.resolve(findLastUpdatePolicySuccess(res.data.latest));
    } else {
      yield put.resolve(findLastUpdatePolicyFailed(res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(findLastUpdatePolicyFailed(parseError));
  }
}

// Saga Get Client Profile
function* workerSagaGetClientProfile(params) {
  try {
    const res = yield call(resourceRequest, CLIENTPROFILEAPI, 'post', params.send);
    if ((res.status === '200' || res.status === 200) && res.data) {
      yield put.resolve(clientProfileSuccess(res.data));
    } else {
      yield put.resolve(clientProfileFailed(res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(clientProfileFailed(parseError));
  }
}

// Saga Get Policy Owner
function* workerSagaGetClientPolicyOwner(params) {
  try {
    const res = yield call(resourceRequest, CLIENTPOLICYOWNERAPI, 'post', params.send);
    if ((res.status === '200' || res.status === 200) && res.data) {
      yield put.resolve(clientPolicyOwnerSuccess(res.data.array));
    } else {
      yield put.resolve(clientPolicyOwnerFailed(res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(clientPolicyOwnerFailed(parseError));
  }
}

// Saga Get Policy List
function* workerSagaGetClientPolicyList(params) {
  try {
    const res = yield call(resourceRequest, CLIENTPOLICYLISTAPI, 'post', params.send);
    if ((res.status === '200' || res.status === 200) && res.data) {
      yield put.resolve(clientPolicyListSuccess(res.data.array));
    } else {
      yield put.resolve(clientPolicyListFailed(res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(clientPolicyListFailed(parseError));
  }
}

// Saga Get Proposal List
function* workerSagaGetClientProposalList(params) {
  try {
    const res = yield call(resourceRequest, CLIENTPROPOSALLISTAPI, 'post', params.send);
    if ((res.status === '200' || res.status === 200) && res.data) {
      yield put.resolve(clientProposalListSuccess(res.data.array));
    } else {
      yield put.resolve(clientProposalListFailed(res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(clientProposalListFailed(parseError));
  }
}

// Saga Get Sum At Risk
function* workerSagaGetClientSumAtRisk(params) {
  try {
    const res = yield call(resourceRequest, CLIENTSUMATRISKAPI, 'post', params.send);
    if ((res.status === '200' || res.status === 200) && res.data) {
      yield put.resolve(clientSumAtRiskSuccess(res.data));
    } else {
      yield put.resolve(clientSumAtRiskFailed(res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(clientSumAtRiskFailed(parseError));
  }
}

function* workerSagaAfterDueDateTotal(params) {
  try {
    const resAfterDueDateTotal = yield call(resourceRequest, AFTERDUEDATETOTALAPI, 'post', params.send);
    // console.log('Success response: ', resTotalToDo); // eslint-disable-line no-console

    if (resAfterDueDateTotal.status === '200' || resAfterDueDateTotal.status === 200) {
      yield put.resolve(afterDueDateTotalSuccess(resAfterDueDateTotal.data));
    } else {
      yield put.resolve(afterDueDateTotalFailed(resAfterDueDateTotal.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(afterDueDateTotalFailed(parseError));
  }
}

function* workerSagaBeforeDueDateTotal(params) {
  try {
    const resBeforeDueDateTotal = yield call(resourceRequest, BEFOREDUEDATETOTALAPI, 'post', params.send);
    console.log(params);
    console.log('Success response Due Date: ', resBeforeDueDateTotal); // eslint-disable-line no-console

    if (
      (resBeforeDueDateTotal.status === '200' || resBeforeDueDateTotal.status === 200)
      &&
      resBeforeDueDateTotal.data.responseData.count !== undefined
    ) {
      yield put.resolve(beforeDueDateTotalSuccess(resBeforeDueDateTotal.data.responseData.count, params.end));
    } else {
      yield put.resolve(beforeDueDateTotalFailed(resBeforeDueDateTotal.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(beforeDueDateTotalFailed(parseError));
  }
}

function* workerSagaAllAfterDueDateTotal(params) {
  try {
    const resAllAfterDueDateTotal = yield call(resourceRequest, ALLAFTERDUEDATETOTALAPI, 'post', params.send);
    // console.log('Success response Recruitment: ', resTotalRecruitmentToDo); // eslint-disable-line no-console

    if (
      (resAllAfterDueDateTotal.status === '200' || resAllAfterDueDateTotal.status === 200)
      &&
      resAllAfterDueDateTotal.data !== undefined
    ) {
      yield put.resolve(allAfterDueDateTotalSuccess(resAllAfterDueDateTotal.data.array[0].total));
    } else {
      yield put.resolve(allAfterDueDateTotalFailed(resAllAfterDueDateTotal.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(allAfterDueDateTotalFailed(parseError));
  }
}

function* workerSagaAfterDueDatePolicyList(params) {
  try {
    const resAfterDueDatePolicyList = yield call(resourceRequest, AFTERDUEDATEPOLICYLISTAPI, 'post', params.send);

    if (
      (resAfterDueDatePolicyList.status === '200' || resAfterDueDatePolicyList.status === 200)
      && resAfterDueDatePolicyList.data.array.length) {
      yield put.resolve(afterDueDatePolicyListSuccess(resAfterDueDatePolicyList.data.array));
    } else {
      yield put.resolve(afterDueDatePolicyListFailed(resAfterDueDatePolicyList.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(afterDueDatePolicyListFailed(parseError));
  }
}

function* workerSagaBeforeDueDatePolicyList(params) {
  try {
    const resAfterDueDatePolicyList = yield call(resourceRequest, BEFOREDUEDATEPOLICYLISTAPI, 'post', params.send);
    console.log('premiumduedate', resAfterDueDatePolicyList);
    if (
      (resAfterDueDatePolicyList.status === '200' || resAfterDueDatePolicyList.status === 200)
      && resAfterDueDatePolicyList.data.responseData.length) {
      yield put.resolve(beforeDueDatePolicyListSuccess(resAfterDueDatePolicyList.data.responseData));
    } else {
      yield put.resolve(beforeDueDatePolicyListFailed(resAfterDueDatePolicyList.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(beforeDueDatePolicyListFailed(parseError));
  }
}

function* workerSagaAfterDueDatePolicyDetail(params) {
  try {
    const resAfterDueDatePolicyDetail = yield call(resourceRequest, AFTERDUEDATEPOLICYDETAILAPI, 'post', params.send);

    if (
      (resAfterDueDatePolicyDetail.status === '200' || resAfterDueDatePolicyDetail.status === 200)
    ) {
      // yield put.resolve(afterDueDatePolicyDetailSuccess(resAfterDueDatePolicyDetail.data));
      yield put.resolve(afterDueDatePolicyDetailSuccess(resAfterDueDatePolicyDetail.data));
    } else {
      yield put.resolve(afterDueDatePolicyDetailFailed(resAfterDueDatePolicyDetail.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(afterDueDatePolicyDetailFailed(parseError));
  }
}

function* workerSagaTotalPolicyInCancelPeriod(params) {
  try {
    const resTotalPolicyInCancelPeriod = yield call(resourceRequest, TOTALPOLICYINCANCELPERIODAPI, 'post', params.send);

    if (
      (resTotalPolicyInCancelPeriod.status === '200' || resTotalPolicyInCancelPeriod.status === 200)
      &&
      resTotalPolicyInCancelPeriod.data.array[0].total !== undefined
    ) {
      yield put.resolve(totalPolicyInCancelPeriodSuccess(resTotalPolicyInCancelPeriod.data.array[0].total));
    } else {
      yield put.resolve(totalPolicyInCancelPeriodFailed(resTotalPolicyInCancelPeriod.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(totalPolicyInCancelPeriodFailed(parseError));
  }
}

function* workerSagaPolicyInCancelPeriod(params) {
  try {
    const resPolicyInCancelPeriod = yield call(resourceRequest, POLICYINCANCELPERIODAPI, 'post', params.send);

    if (
      (resPolicyInCancelPeriod.status === '200' || resPolicyInCancelPeriod.status === 200)
      &&
      resPolicyInCancelPeriod.data.array.length
    ) {
      yield put.resolve(policyInCancelPeriodSuccess(resPolicyInCancelPeriod.data.array));
    } else {
      yield put.resolve(policyInCancelPeriodFailed(resPolicyInCancelPeriod.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(policyInCancelPeriodFailed(parseError));
  }
}

function* workerSagaListClientByAgentNumber(params) {
  try {
    const resListClientByAgentNumber = yield call(resourceRequest, LISTCLIENTBYAGENTNUMBERAPI, 'post', params.send);

    if (
      (resListClientByAgentNumber.status === '200' || resListClientByAgentNumber.status === 200)
    ) {
      yield put.resolve(listClientByAgentNumberSuccess(resListClientByAgentNumber.data.array));
    } else {
      yield put.resolve(listClientByAgentNumberFailed(resListClientByAgentNumber.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(listClientByAgentNumberFailed(parseError));
  }
}

function* workerSagaProfileClientByAgentNumber(params) {
  try {
    const resProfileClientByAgentNumber = yield call(resourceRequest, PROFILECLIENTBYAGENTNUMBERAPI, 'post', params.send);

    if (
      (resProfileClientByAgentNumber.status === '200' || resProfileClientByAgentNumber.status === 200)
    ) {
      yield put.resolve(profileClientByAgentNumberSuccess(resProfileClientByAgentNumber.data));
    } else {
      yield put.resolve(profileClientByAgentNumberFailed(resProfileClientByAgentNumber.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(profileClientByAgentNumberFailed(parseError));
  }
}
function* workerSagaGetPolicyMovementHistory(params) {
  try {
    const resGetPolicyMovementHistory = yield call(resourceRequest, GETPOLICYMOVEMENTHISTORYAPI, 'post', params.send);

    if (
      (resGetPolicyMovementHistory.status === '200' || resGetPolicyMovementHistory.status === 200)
      && resGetPolicyMovementHistory.data.array.length
    ) {
      yield put.resolve(getPolicyMovementHistorySuccess(resGetPolicyMovementHistory.data.array));
    } else {
      yield put.resolve(getPolicyMovementHistoryFailed(resGetPolicyMovementHistory.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(getPolicyMovementHistoryFailed(parseError));
  }
}

export const watcherToDo = [
  takeLatest(TOTALTODOFETCH, workerSagaTotalToDo),
  takeLatest(TOTALTODORECRUITMENTFETCH, workerSagaTotalRecruitmentToDo),
  takeLatest(TOTALTODONTUCASEFETCH, workerSagaTotalNTUCaseToDo),
  takeLatest(TOTALTODOBILLINGPENDINGFETCH, workerSagaTotalBillingPendingToDo),
  takeLatest(TOTALTODOPOLICYHOLDERFETCH, workerSagaTotalPolicyHolderToDo),
  takeLatest(TOTALTODOCLAIMPENDINGFETCH, workerSagaTotalClaimPendingToDo),
  takeLatest(TOTALTODOPOLICYDUEDATEFETCH, workerSagaTotalPolicyDueDateToDo),
  takeLatest(TOTALTODOPOLICYDUEDATEAGEINGFETCH, workerSagaTotalPolicyDueDateAgeingToDo),
  takeLatest(TOTALTODOCLIENTBIRTHDAYFETCH, workerSagaTotalClientBirthDayToDo),

  takeLatest(FINDLISTTODORECRUITMENTFETCH, workerSagaGetListToDoRecruitment),
  takeLatest(FINDLISTTODONEWBUSINESSFETCH, workerSagaGetListToDoNewBusiness),
  takeLatest(FINDLISTTODOFUNDHISTORYFETCH, workerSagaGetListToDoFundHistory),
  takeLatest(FINDLISTTODOFOLLOWUPFETCH, workerSagaGetListToDoFollowUp),
  takeLatest(FINDFILTERFOLLOWUPSTATUSTODOFETCH, workerSagaGetFilterFollowUp),
  takeLatest(FINDLISTTODOFOLLOWUPPOLICYFETCH, workerSagaGetListToDoFollowUpPolicy),
  takeLatest(FINDFILTERFOLLOWUPSTATUSFETCH, workerSagaGetFilterFollowUpPolicy),
  takeLatest(FINDLISTTODOCLAIMHISTORYNONDEATHFETCH, workerSagaGetListToDoClaimHistoryNonDeath),
  takeLatest(FINDLISTTODOCLAIMHISTORYPREMIUMFETCH, workerSagaGetListToDoClaimHistoryPremium),
  takeLatest(FINDLISTTODOCLAIMHISTORYDEATHFETCH, workerSagaGetListToDoClaimHistoryDeath),
  takeLatest(FINDLISTTODOPRODUCTDETAILFETCH, workerSagaGetListToDoProductDetail),
  takeLatest(FINDLISTTODOBILLINGPENDINGFETCH, workerSagaGetListToDoBillingPending),
  takeLatest(FINDLISTTODOPOLICYHOLDERFETCH, workerSagaGetListToDoPolicyHolder),
  takeLatest(FINDLISTTODOPENDINGCLAIMFETCH, workerSagaGetListToDoPendingClaim),
  takeLatest(FINDLISTTODOCLIENTBIRTHDAYRECENTFETCH, workerSagaGetListToDoClientBirthDayRecent),
  takeLatest(FINDLISTTODOCLIENTBIRTHDAYTODAYFETCH, workerSagaGetListToDoClientBirthDayToday),
  takeLatest(FINDLISTTODOCLIENTBIRTHDAYUPCOMINGFETCH, workerSagaGetListToDoClientBirthDayUpComing),

  takeLatest(FINDLASTUPDATECLIENTFETCH, workerSagaGetLastUpdateClient),
  takeLatest(FINDLASTUPDATEPOLICYFETCH, workerSagaGetLastUpdatePolicy),
  takeLatest(CLIENTPROFILEFETCH, workerSagaGetClientProfile),
  takeLatest(CLIENTPOLICYOWNERFETCH, workerSagaGetClientPolicyOwner),
  takeLatest(CLIENTPOLICYLISTFETCH, workerSagaGetClientPolicyList),
  takeLatest(CLIENTPROPOSALLISTFETCH, workerSagaGetClientProposalList),
  takeLatest(CLIENTSUMATRISKFETCH, workerSagaGetClientSumAtRisk),

  takeLatest(AFTERDUEDATETOTALFETCH, workerSagaAfterDueDateTotal),
  takeEvery(BEFOREDUEDATETOTALFETCH, workerSagaBeforeDueDateTotal),
  takeLatest(ALLAFTERDUEDATETOTALFETCH, workerSagaAllAfterDueDateTotal),
  takeLatest(AFTERDUEDATEPOLICYLISTFETCH, workerSagaAfterDueDatePolicyList),
  takeLatest(BEFOREDUEDATEPOLICYLISTFETCH, workerSagaBeforeDueDatePolicyList),
  takeLatest(AFTERDUEDATEPOLICYDETAILFETCH, workerSagaAfterDueDatePolicyDetail),
  takeLatest(TOTALPOLICYINCANCELPERIODFETCH, workerSagaTotalPolicyInCancelPeriod),
  takeLatest(POLICYINCANCELPERIODFETCH, workerSagaPolicyInCancelPeriod),
  takeLatest(LISTCLIENTBYAGENTNUMBERFETCH, workerSagaListClientByAgentNumber),
  takeLatest(PROFILECLIENTBYAGENTNUMBERFETCH, workerSagaProfileClientByAgentNumber),
  takeLatest(GETPOLICYMOVEMENTHISTORYFETCH, workerSagaGetPolicyMovementHistory),

  apiTakeLatest(MEDICAL_LETTER_PDF, { timeout: 8000 }),
  apiTakeLatest(CLIENT_VIP_INFO),
  apiTakeLatest(HNWI_TAGGING),
  apiTakeLatest(HNWI_CALCULATOR, { timeout: 8000 }),
  apiTakeLatest(DOWNLOAD_PROPOSAL_PDF),
  apiTakeLatest(DOWNLOAD_CLIENT_DETAIL_PDF),
  apiTakeLatest(DOWNLOAD_FUND_TRANSACTION_PDF),
  apiTakeLatest(GET_UPDATED_DATE),
  apiTakeLatest(GET_PERSONAL_DATA),
  apiTakeLatest(GET_PROPOSAL_POLICY),
  apiTakeLatest(GET_PREMIUM_DATA),
  apiTakeLatest(GET_PRODUCT_LIST),
  apiTakeLatest(GET_ALLOCATION),
  apiTakeLatest(GET_FUND_HOLDING),
  apiTakeLatest(GET_DOCUMENT),
];
