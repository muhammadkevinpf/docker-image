/**
 * @author: ahmdichsanb@gmail.com
*/

import React, { Component } from 'react';
import { Platform, Dimensions } from 'react-native';
import { TabView, TabBar } from 'react-native-tab-view';
import { Text, View } from 'native-base';
import PropTypes from 'prop-types';
import Style from '../../styles';

import StyleTabContainer from './StyleTabContainer';

class TabContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      index: this.props.index || 0,
      width: null,
    };
  }

  renderScene = ({ route }) => {
    const scene = this.props.sceneMap.find(obj => obj.key === route.key);
    const display = scene.scene;
    return display;
  }

  handleIndexChange = (index) => {
    this.setState({ index });
    if (this.props.parentFunction) {
      this.props.parentFunction(index);
    }
  };

  renderLabel = ({ route, color }) => <Text style={[Style.Main.font14, color === 'red' && Style.Main.textRed]}> {route.title}</Text>

  renderTabBar = (props) => {
    const { sceneMap, fitTabBar, minTabBarWidth } = this.props;
    const tabBarWidth = this.state.width / sceneMap.length;
    const width = fitTabBar && !(minTabBarWidth && tabBarWidth && minTabBarWidth >= tabBarWidth) ? { width: tabBarWidth } : Style.Main.autoWidth;
    const tabStyle = sceneMap.length === 1 ? Style.Main.fullWidth : width;

    return (
      <TabBar
        {...props}
        renderLabel={this.renderLabel}
        tabStyle={[!this.props.withoutTabStyle && tabStyle]}
        indicatorStyle={[StyleTabContainer.indicatorStyle, this.props.indicatorStyle]}
        style={[StyleTabContainer.tabBarStyle, this.props.style]}
        activeColor="red"
        inactiveColor="black"
        scrollEnabled
      />
    );
  }

  render() {
    const { index } = this.state;
    const { routes } = this.props;

    return (
      <View style={[Style.Main.container]} onLayout={e => this.setState({ width: e.nativeEvent.layout.width })}>
        <TabView
          navigationState={{ index, routes }}
          renderScene={this.renderScene}
          renderTabBar={props => this.renderTabBar(props)}
          onIndexChange={this.handleIndexChange}
          removeClippedSubviews={Platform.OS === 'android' && true}
          initialLayout={{ width: Dimensions.get('window').width }}
        />
      </View>
    );
  }
}

TabContainer.propTypes = {
  routes: PropTypes.arrayOf(PropTypes.object).isRequired,
  sceneMap: PropTypes.arrayOf(PropTypes.object).isRequired,
  parentFunction: PropTypes.func,
  renderLabel: PropTypes.bool,
  withoutTabStyle: PropTypes.bool,
  fitTabBar: PropTypes.bool,
  minTabBarWidth: PropTypes.number,
};

TabContainer.defaultProps = {
  parentFunction: null,
  renderLabel: false,
  withoutTabStyle: false,
  fitTabBar: false,
  minTabBarWidth: null,
};

export default TabContainer;
