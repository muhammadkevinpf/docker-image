/* eslint-disable no-unused-vars */
/**
 * @author:
 * dwi.setiyadi@gmail.com
*/

import React, { Component } from 'react';

// import Pdflib from 'react-native-html-to-pdf';
import Share from 'react-native-share';

import Button from '../button-custom';

class CreatePDF extends Component {
  // createIt = async () => {
  //   const options = {
  //     html: (this.props.pdfContent) ? this.props.pdfContent : '<h1>No Content</h1>',
  //     fileName: (this.props.pdfFilename) ? this.props.pdfFilename : 'noname',
  //     // directory: 'Documents',
  //   };

  //   const file = await Pdflib.convert(options);
  //   Share.open({
  //     title: (this.props.shareTitle) ? this.props.shareTitle : 'No Title',
  //     message: (this.props.shareMessage) ? this.props.shareMessage : '',
  //     url: file.filePath,
  //     subject: (this.props.shareSubject) ? this.props.shareSubject : '',
  //     failOnCancel: false,
  //   });
  // }

  // render() {
  //   return (
  //     <Button {...this.props} onPress={this.createIt} />
  //   );
  // }
}

export default CreatePDF;
