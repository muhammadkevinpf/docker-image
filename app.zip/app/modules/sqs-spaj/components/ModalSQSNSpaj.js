import React, { PureComponent } from 'react';
import { Modal } from 'react-native';
import {
  Button, View,
} from 'native-base';
import Icon from 'react-native-vector-icons/FontAwesome';
import Style from '../../../styles';

class ModalSQSNSpaj extends PureComponent {
  render() {
    return (
      <Modal
        animationType="slide"
        transparent={false}
        visible={this.props.visible}
        onRequestClose={this.props.onRequestClose}
        presentationStyle="fullScreen"
        onShow={this.props.onShow}
      >
        <View>
          <Button
            transparent
            light
            style={[Style.Main.textLeft, Style.Main.mt20, Style.Main.mb15]}
            onPress={this.props.onBackPress}
          >
            <Icon name="angle-left" style={Style.Main.btnSecondary} />
          </Button>
        </View>
        {this.props.children}
      </Modal>
    );
  }
}

export default ModalSQSNSpaj;
