// @flow

import { Platform, Dimensions } from 'react-native';
// import { getStatusBarHeight } from 'react-native-status-bar-height';

import variable from '../variables/platform';

const deviceHeight = Dimensions.get('window').height;
export default (variables /* : * */ = variable) => {
  const theme = {
    flex: 1,
    height: Platform.OS === 'ios' ? deviceHeight : deviceHeight - 20,
    backgroundColor: variables.containerBgColor,
    // marginTop: Platform.OS === 'android' ? getStatusBarHeight() : 0,
  };

  return theme;
};
