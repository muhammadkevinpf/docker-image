import { requestStatus } from '../../utilities/ApiConnection';
import {
  PROPOSAL_POLICY, PROPOSAL_POLICY_FILTER, PROPOSAL_POLICY_UNIT, PROPOSAL_POLICY_UNIT_FILTER,
  PROPOSAL_GRAPH, POLICY_GRAPH, PROPOSAL_POLICY_UPDATED_DATE,
} from './ConfigProposalPolicy';
import { RESET_ALL_STATE } from '../dashboard/ConfigDashboard';

const initialState = {
  lastUpdateStatus: requestStatus.IDLE,
  proposalGraphStatus: requestStatus.IDLE,
  policyGraphStatus: requestStatus.IDLE,
  listStatus: requestStatus.IDLE,
  filterStatus: requestStatus.IDLE,
  unitListStatus: requestStatus.IDLE,
  unitFilterStatus: requestStatus.IDLE,

  lastUpdate: null,
  list: [],
  filter: [],
  unitList: [],
  unitFilter: [],
  error: null,
  send: null,
};

export function ReducerProposalPolicy(state = initialState, action) {
  switch (action.type) {
    case RESET_ALL_STATE: return initialState;

    case PROPOSAL_POLICY_UPDATED_DATE.FETCH: return { ...state, lastUpdateStatus: requestStatus.FETCH, send: action.payload };
    case PROPOSAL_POLICY_UPDATED_DATE.FAILED: return { ...state, lastUpdateStatus: requestStatus.FAILED, error: action.payload };
    case PROPOSAL_POLICY_UPDATED_DATE.SUCCESS: return { ...state, lastUpdateStatus: requestStatus.SUCCESS, lastUpdate: action.payload.latest };

    case PROPOSAL_GRAPH.FETCH: return { ...state, proposalGraphStatus: requestStatus.FETCH };
    case PROPOSAL_GRAPH.FAILED: return { ...state, proposalGraphStatus: requestStatus.FAILED };
    case PROPOSAL_GRAPH.SUCCESS: return { ...state, proposalGraphStatus: requestStatus.SUCCESS };

    case POLICY_GRAPH.FETCH: return { ...state, policyGraphStatus: requestStatus.FETCH };
    case POLICY_GRAPH.FAILED: return { ...state, policyGraphStatus: requestStatus.FAILED };
    case POLICY_GRAPH.SUCCESS: return { ...state, policyGraphStatus: requestStatus.SUCCESS };

    case PROPOSAL_POLICY.FETCH: return { ...state, listStatus: requestStatus.FETCH, send: action.payload };
    case PROPOSAL_POLICY.FAILED: return { ...state, listStatus: requestStatus.FAILED, error: action.payload };
    case PROPOSAL_POLICY.SUCCESS:
      return {
        ...state,
        listStatus: requestStatus.SUCCESS,
        list: state.list.length ?
          [...state.list, ...action.payload.filter(x => !state.list.some(item => item.policyNumber === x.policyNumber))] : action.payload,
      };
    case PROPOSAL_POLICY.RESET: return {
      ...state, listStatus: requestStatus.IDLE, filterStatus: requestStatus.IDLE, list: [],
    };

    case PROPOSAL_POLICY_FILTER.FETCH: return { ...state, filterStatus: requestStatus.FETCH, send: action.payload };
    case PROPOSAL_POLICY_FILTER.FAILED: return { ...state, filterStatus: requestStatus.FAILED, error: action.payload };
    case PROPOSAL_POLICY_FILTER.SUCCESS: return { ...state, filterStatus: requestStatus.SUCCESS, filter: action.payload };

    case PROPOSAL_POLICY_UNIT.FETCH: return { ...state, unitListStatus: requestStatus.FETCH, send: action.payload };
    case PROPOSAL_POLICY_UNIT.FAILED: return { ...state, unitListStatus: requestStatus.FAILED, error: action.payload };
    case PROPOSAL_POLICY_UNIT.SUCCESS:
      return {
        ...state,
        unitListStatus: requestStatus.SUCCESS,
        unitList: state.unitFilter.length ?
          [...state.unitList, ...action.payload.filter(x => !state.unitList.some(item => item === x))] : action.payload,
      };
    case PROPOSAL_POLICY_UNIT.RESET: return {
      ...state, unitListStatus: requestStatus.IDLE, unitFilterStatus: requestStatus.IDLE, unitList: [],
    };

    case PROPOSAL_POLICY_UNIT_FILTER.FETCH: return { ...state, unitFilterStatus: requestStatus.FETCH, send: action.payload };
    case PROPOSAL_POLICY_UNIT_FILTER.FAILED: return { ...state, unitFilterStatus: requestStatus.FAILED, error: action.payload };
    case PROPOSAL_POLICY_UNIT_FILTER.SUCCESS: return { ...state, unitFilterStatus: requestStatus.SUCCESS, unitFilter: action.payload };

    default: return state;
  }
}
