/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
 * definite maji arsana
*/

import React, { Component, Fragment } from 'react';
import {
  Text, View, TouchableOpacity, Image, Modal, Alert, YellowBox, Platform,
} from 'react-native';
import {
  Button, Icon,
} from 'native-base';
import moment from 'moment';
import PropTypes from 'prop-types';
// import SignaturePad from 'react-native-signature-pad';
import { SketchCanvas } from '@terrylinla/react-native-sketch-canvas';
import RNFS from 'react-native-fs';
// import Orientation from 'react-native-orientation-locker';
import { Grid, Row, Col } from 'react-native-easy-grid';
import ImageResizer from 'react-native-image-resizer';
import { InputFieldNew } from '../index';
import Style from '../../styles';
import _ from '../../lang';
import { isTablet } from '../../utilities';

class SignatureCanvas extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modalTTD: false,
      ttd: null,
      tglttd: '',
      location: '',
      tempTTD: null,
      renderUlang: false,
      imagePath: null,
      tabletDevice: isTablet(),
    };
  }

  componentDidMount() {
    // if (Platform.OS === 'ios' && !this.state.tabletDevice) Orientation.unlockAllOrientations();
    // Orientation.unlockAllOrientations();
    // eslint-disable-next-line max-len
    YellowBox.ignoreWarnings(['Accessing view manager configs directly off UIManager via UIManager[\'RNSketchCanvas\'] is no longer supported. Use UIManager.getViewManagerConfig(\'RNSketchCanvas\') instead.']);
  }

  componentWillUnmount() {
    // if (Platform.OS === 'ios' && !this.state.tabletDevice) Orientation.lockToPortrait();
    // Orientation.lockToPortrait();
  }

  onInputLocation = (item) => {
    this.props.onInputLocation(item);
    this.setState({ location: item });
  }

  setModalTTD(visible) {
    this.setState({ modalTTD: visible });
  }

  setTTD(result) {
    this.setState({
      ttd: result,
    });
  }

  saveToCacheAndroid = () => new Promise(async (resolve, reject) => {
    try {
      const { nama, qqCD } = this.props;
      const path = `${RNFS.CachesDirectoryPath}/signature`;
      const filename = `${path}/${nama ? 'agen' : 'nasabah'}-${qqCD}`;
      await RNFS.mkdir(path);
      await RNFS.writeFile(filename, `${this.state.ttd}`, 'base64');
      this.setState({ imagePath: filename });
      console.log('File Written!');
      resolve('SAVED');
    } catch (error) {
      reject(error);
    }
  })

  removeSavedSignature = () => new Promise(async (resolve, reject) => {
    try {
      const { nama, qqCD } = this.props;
      const path = `${RNFS.CachesDirectoryPath}/signature`;
      const filename = `${path}/${nama ? 'agen' : 'nasabah'}-${qqCD}`;
      const isExist = await RNFS.exists(filename);
      if (this.state.modalTTD) {
        this._signatureCanvas.clear();
      }
      if (isExist) {
        await RNFS.unlink(filename);
      }
      resolve('DELETED');
    } catch (error) {
      reject(error);
    }
  })

  onOpenSignature = async () => {
    try {
      const { nama, qqCD } = this.props;
      const { tabletDevice } = this.state;
      const path = `${RNFS.CachesDirectoryPath}/signature`;
      // const filename = `${path}/${nama ? 'agen' : 'nasabah'}/${qqCD}`;
      if (this.state.ttd !== '' && this.state.ttd !== null) {
        await this.saveToCacheAndroid();
        const res = await RNFS.readDir(path);
        const name = `${nama ? 'agen' : 'nasabah'}-${qqCD}`;
        const signPath = res.find(x => x.name === name).path;
        const base64 = await RNFS.readFile(signPath, 'base64');
        if (!tabletDevice) {
          await this.rotateImage(base64, 90);
        }
        await this.saveToCacheAndroid();
        this.setState({ imagePath: signPath });
      }
      // RNFS.readDir(path).then(res => console.log('dir', res), err => console.log(err));
      this.setState({
        modalTTD: true,
      },
      () => {
        if (Platform.OS === 'ios' && !tabletDevice) {
          // Orientation.unlockAllOrientations();
          // Orientation.lockToLandscape();
        }
      });
      // () => {
      //   Orientation.unlockAllOrientations();
      //   Orientation.lockToLandscape();
      // });
    } catch (error) {
      console.log(error);
    }
  }

  onSaveSignature = async () => {
    const { tempTTD, modalTTD, tabletDevice } = this.state;
    const date = moment().format('Do MMMM YYYY, H:mm:ss');

    if (tempTTD) {
      this.setState({ tglttd: date });
      this.setState(prevState => ({ ttd: prevState.tempTTD }));
      await this.saveToCacheAndroid();
      if (!tabletDevice) {
        await this.rotateImage(this.state.tempTTD, 270);
        await this.saveToCacheAndroid();
      }
    }

    this.props.onChange();

    this.setModalTTD(!modalTTD);

    if (Platform.OS === 'ios' && !tabletDevice) {
      // Orientation.unlockAllOrientations();
      // Orientation.lockToPortrait();
    }

    // Orientation.unlockAllOrientations();
    // Orientation.lockToPortrait();
    console.log(this.state);
  }

  onCancelSignature = async () => {
    const { tabletDevice } = this.state;
    await this.saveToCacheAndroid();
    if (!tabletDevice) {
      await this.rotateImage(this.state.ttd, 270);
      await this.saveToCacheAndroid();
    }
    this.setModalTTD(!this.state.modalTTD);
    if (Platform.OS === 'ios' && !tabletDevice) {
      // Orientation.unlockAllOrientations();
      // Orientation.lockToPortrait();
    }
    // Orientation.unlockAllOrientations();
    // Orientation.lockToPortrait();
  }

  // _signaturePadError = (error) => {
  //   console.error(error);
  // };

  // _signaturePadChange = ({ base64DataUrl }) => {
  //   this.setState({
  //     tempTTD: base64DataUrl,
  //   });
  // };

  clearCanvas = () => this._signatureCanvas.clear();

  rotateImage = async (base64, angle) => {
    try {
      const rotated = await ImageResizer.createResizedImage(
        Platform.OS === 'ios' ? this.state.imagePath : `data:image/png,${base64}`, 1000, 1000, 'PNG', 100, angle, undefined,
      );
      const result = await RNFS.readFile(rotated.uri, 'base64');
      this.setState({ tempTTD: result, ttd: result });
      // if (Platform.OS !== 'ios') {
      // }
    } catch (error) {
      console.log(error);
    }
    return base64;
  }

  saveCanvas = () => {
    this._signatureCanvas.getBase64(
      'png',
      false,
      true,
      false,
      false,
      (err, res) => {
        try {
          this.setState({ tempTTD: res });
        } catch (error) {
          console.log(error);
        }
        console.log(err);
      },
    );
  }

  clearTTD = () => {
    this.setState({
      ttd: null,
      tempTTD: null,
      tglttd: '',
      renderUlang: true,
    }, () => {
      this.setState({ renderUlang: false, ttd: null });
    });
  };

  renderPhone() {
    const { imagePath } = this.state;
    return (
      <View style={[Style.Main.justifyCenter, Style.Main.flexTop, Style.Main.container, Style.Main.backgroundWhite]}>
        <Grid>
          <Row>
            <Col size={2}>
              <View
                style={[
                  Style.Main.center,
                  Style.Main.columnDirectionSpaceEvently,
                  Style.Main.container,
                  Style.Main.backgroundF9,
                ]}
              >
                <Button
                  bordered
                  danger
                  block
                  style={[Style.Main.dialogOutlineBtn, Style.Main.alignCenter, Style.Main.rotate90Deg]}
                  onPress={() => {
                    this.removeSavedSignature().then(() => {
                      this.clearTTD();
                    });
                  }}
                >
                  <Text style={[Style.Main.textRed]}>{_('RESET')}</Text>
                </Button>
                <Button
                  bordered
                  danger
                  block
                  style={[Style.Main.dialogOutlineBtn, Style.Main.alignCenter, Style.Main.rotate90Deg]}
                  onPress={this.onSaveSignature}
                >
                  <Text style={[Style.Main.textRed]}>{_('SIMPAN')}</Text>
                </Button>
                <Button
                  bordered
                  danger
                  block
                  style={[Style.Main.dialogOutlineBtn, Style.Main.alignCenter, Style.Main.rotate90Deg]}
                  onPress={this.onCancelSignature}
                >
                  <Text style={[Style.Main.textRed]}>{_('BATAL')}</Text>
                </Button>
              </View>
            </Col>
            <Col size={8}>
              {!this.state.renderUlang &&
                (
                  <SketchCanvas
                    style={Style.Main.container}
                    strokeColor="black"
                    strokeWidth={7}
                    ref={(ref) => { this._signatureCanvas = ref; }}
                    onStrokeEnd={this.saveCanvas}
                    localSourceImage={{
                      filename: `${imagePath}`,
                      directory: null,
                      mode: 'AspectFill',
                    }}
                  />
                )}
            </Col>
          </Row>
        </Grid>
      </View>
    );
  }

  renderTablet() {
    const { imagePath } = this.state;
    return (
      <View style={[Style.Main.justifyCenter, Style.Main.flexTop, Style.Main.container, Style.Main.backgroundWhite]}>
        <Grid>
          <Row size={8}>
            {!this.state.renderUlang &&
              (
                <SketchCanvas
                  style={Style.Main.container}
                  strokeColor="black"
                  strokeWidth={7}
                  ref={(ref) => { this._signatureCanvas = ref; }}
                  onStrokeEnd={this.saveCanvas}
                  localSourceImage={{
                    filename: `${imagePath}`,
                    directory: null,
                    mode: 'AspectFill',
                  }}
                />
              )}
          </Row>

          <Row size={2}>
            <Row
              style={[
                Style.Main.center,
                Style.Main.container,
                Style.Main.backgroundF9,
              ]}
            >
              <Col>
                <Button
                  bordered
                  danger
                  block
                  style={[Style.Main.dialogOutlineBtn, Style.Main.alignCenter]}
                  onPress={() => {
                    this.removeSavedSignature().then(() => {
                      this.clearTTD();
                    });
                  }}
                >
                  <Text style={[Style.Main.textRed]}>{_('RESET')}</Text>
                </Button>
              </Col>
              <Col>
                <Button
                  bordered
                  danger
                  block
                  style={[Style.Main.dialogOutlineBtn, Style.Main.alignCenter]}
                  onPress={this.onSaveSignature}
                >
                  <Text style={[Style.Main.textRed]}>{_('SIMPAN')}</Text>
                </Button>
              </Col>
              <Col>
                <Button
                  bordered
                  danger
                  block
                  style={[Style.Main.dialogOutlineBtn, Style.Main.alignCenter]}
                  onPress={this.onCancelSignature}
                >
                  <Text style={[Style.Main.textRed]}>{_('BATAL')}</Text>
                </Button>
              </Col>
            </Row>
          </Row>
        </Grid>
      </View>
    );
  }

  render() {
    const {
      tglttd, ttd, modalTTD, tabletDevice, location,
    } = this.state;
    console.log(this.state);
    return (
      <Fragment>
        <Modal
          animationType="slide"
          visible={modalTTD}
          supportedOrientations={['portrait', 'landscape']}
          onShow={() => {
            // Orientation.unlockAllOrientations();
            // Orientation.lockToLandscape();
            console.log('cilukbaa');
          }}
          onRequestClose={this.onCancelSignature}
        >
          {!tabletDevice ? this.renderPhone() : this.renderTablet()}
        </Modal>
        <View style={[this.props.style,
          (ttd)
            ? Style.Main.displayNone
            : Style.Main.displayFlex, Style.Main.mt12,
        ]}
        >
          <TouchableOpacity
            style={[Style.Main.imgTTD, Style.Main.flexTop, Style.Main.justifyCenter]}
            onPress={this.onOpenSignature}
          >
            <Text style={[Style.Main.textTTD]}>{_('TANDA TANGAN')}</Text>
          </TouchableOpacity>
        </View>
        <View style={[
          !this.state.ttd
            ? Style.Main.displayNone
            : Style.Main.displayFlex, Style.Main.mt12,
        ]}
        >
          <TouchableOpacity
            style={[Style.Main.flexTop, Style.Main.justifyCenter, Style.Main.padding2, Style.Main.ttdContainer]}
            onPress={this.onOpenSignature}
          >
            <Image
              source={ttd ? { uri: `data:image/png;base64,${ttd}` } : null}
              resizeMethod="scale"
              // resizeMode="cover"
              // eslint-disable-next-line no-nested-ternary
              resizeMode={Platform.OS === 'ios' ? (isTablet ? 'stretch' : 'cover') : 'cover'}
              style={[Style.Main.imgTTDContainer]}
            />
          </TouchableOpacity>
        </View>
        <View style={[Style.Main.mt15]}>
          <InputFieldNew
            value={location}
            label={_('Tempat')}
            onChangeText={this.onInputLocation}
            // type="address"
            isRequired={false}
          />
        </View>
        <View style={[Style.Main.mt20]}>
          <Text style={[Style.Main.fontAlbert, Style.Main.gray83, Style.Main.font11]}>{(tglttd === '') ? '' : _('Tanggal')}</Text>
        </View>
        <View style={[Style.Main.mb15, Style.Main.rowDirectionSpaceBetween, Style.Main.grayBorderBottom]}>
          <Text style={[Style.Main.fontAlbert, Style.Main.textAlmostBlack, Style.Main.font14, Style.Main.pb5]}>
            {(tglttd === '') ? _('Tanggal') : tglttd}
          </Text>
          <Icon name="calendar" type="AntDesign" style={[Style.Main.gray83]} />
        </View>
        {
          !this.props.withoutSignatory && (
            <View style={[Style.Main.rowDirectionSpaceBetween]}>
              <View style={[Style.Main.container]}>
                <Text style={[Style.Main.fontAlbert]}>{_('Nama Tenaga Pemasar')}</Text>
                <Text style={[Style.Main.fontAlbert, Style.Main.textAlmostBlack]}>{this.props.nama}</Text>
              </View>
              <View style={[Style.Main.container, Style.Main.pl15]}>
                <Text style={[Style.Main.fontAlbert]}>{_('Kode Tenaga Pemasar')}</Text>
                <Text style={[Style.Main.fontAlbert, Style.Main.textAlmostBlack]}>{this.props.kode}</Text>
              </View>
            </View>
          )
        }
        <View style={[Style.Main.mt15]}>
          <Button
            bordered
            block
            danger
            style={[Style.Main.largeOutlineBtn]}
            onPress={() => {
              Alert.alert(_('Warning'), _('Apakah Anda yakin untuk reset tanda tangan?'),
                [
                  { text: _('Tidak') },
                  {
                    text: _('Ya'),
                    onPress: () => {
                      this.removeSavedSignature().then(() => {
                        this.setState({
                          ttd: null,
                          location: '',
                          tglttd: '',
                          tempTTD: null,
                        });
                        const { onClear } = this.props;
                        onClear();
                      });
                    },
                  },
                ]);
            }}
          >
            <Text style={[Style.Main.textAlmostBlack]}>{_('RESET')}</Text>
          </Button>
        </View>
      </Fragment>
    );
  }
}

SignatureCanvas.propTypes = {
  // tempat: PropTypes.string,
  nama: PropTypes.string,
  kode: PropTypes.string,
  qqCD: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  style: PropTypes.shape({}),
  onChange: PropTypes.func,
  onInputLocation: PropTypes.func,
  onClear: PropTypes.func,
  withoutSignatory: PropTypes.bool,
};

SignatureCanvas.defaultProps = {
  // tempat: '',
  qqCD: '',
  nama: '',
  kode: '',
  style: {},
  withoutSignatory: false,
  onChange: () => _.noop,
  onClear: () => _.noop,
  onInputLocation: () => { },
};

export default SignatureCanvas;
