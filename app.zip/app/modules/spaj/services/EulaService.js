// eslint-disable-next-line import/no-cycle
import { ConfigProductSPAJ } from '../configs';
import {
  styleHtml,
  tncSpaj,
  tncIllustration,
  tncKepatuhan,
  tncKetentuan,
  tncKesehatan,
  akad,
  tncSpajSyariah,
  tncKeshatanPLHP,
} from '../views/eula-spaj/NewDisclaimerTemplate';
// } from '../views/eula-spaj/HtmlVMA';

// import {
//   styleHtmlUSAVE,
//   tncSpajUSAVE,
//   tncKepatuhanUSAVE,
//   tncKetentuanUSAVE,
// } from '../views/eula-spaj/HtmlUSAVE';

// import {
//   styleHtmlFIA,
//   tncSpajFIA,
//   tncKepatuhanFIA,
//   tncKetentuanFIA,
//   tncKetentuanBIA,
// } from '../views/eula-spaj/HtmlFIA';

// import {
//   styleHtml as newStyleHtml,
//   tncSpaj as newTncSpaj,
//   tncIllustration as newTncIlustration,
//   tncKepatuhan as newTncKepatuhan,
//   tncKetentuan as newTncKetentuan,
// } from '../views/eula-spaj/NewHtmlVMA';

// import {
//   styleHtmlFIA as newStyleHtmlFIA,
//   tncSpajFIA as newTncSpajFIA,
//   tncKepatuhanFIA as newTncKepatuhanFIA,
//   tncKetentuanFIA as newTncKetentuanFIA,
//   tncKetentuanBIA as newTncKetentuanBIA,
// } from '../views/eula-spaj/NewHtmlFIA';

// const VMA = productCd => [
const eula = productCd => [
  {
    label: 'Pernyataan Ilustrasi Penjualan',
    value: styleHtml + tncIllustration,
    id: 1,
  },
  {
    label: 'Pernyataan Calon Pemegang Polis Pada Formulir SPAJ',
    value: styleHtml + tncSpaj(productCd, ConfigProductSPAJ.productWithEulaLine16.some(x => x === productCd)),
    id: 2,
  },
  {
    label: 'Syarat dan Ketentuan Kepatuhan, Pelayanan Konsumen dan Perikatan',
    value: styleHtml + tncKepatuhan(productCd),
    id: 3,
  },
  {
    label: 'Ketentuan Pertanggungan Manfaat Meninggal Dunia Karena Kecelakaan Sebelum Polis Diterbitkan',
    value: styleHtml + tncKetentuan(productCd),
    id: 4,
  },
];

const eulaPIPP = productCd => [
  {
    label: 'Pernyataan Calon Pemegang Polis dan/atau Tertanggung Perihal Kesehatan Calon Tertanggung',
    value: styleHtml + tncKesehatan(productCd),
    id: 1,
  },
  {
    label: 'Pernyataan Ilustrasi Penjualan',
    value: styleHtml + tncIllustration,
    id: 2,
  },
  {
    label: 'Pernyataan Calon Pemegang Polis Pada Formulir SPAJ',
    value: styleHtml + tncSpaj(productCd, ConfigProductSPAJ.productWithEulaLine16.some(x => x === productCd)),
    id: 3,
  },
  {
    label: 'Syarat dan Ketentuan Kepatuhan, Pelayanan Konsumen dan Perikatan',
    value: styleHtml + tncKepatuhan(productCd),
    id: 4,
  },
  {
    label: 'Ketentuan Pertanggungan Manfaat Meninggal Dunia Karena Kecelakaan Sebelum Polis Diterbitkan',
    value: styleHtml + tncKetentuan(productCd),
    id: 5,
  },
];

const eulaPRUCinta = (productCd, agentChannel) => [
  {
    label: 'Pernyataan Ilustrasi Penjualan',
    value: styleHtml + tncIllustration,
    id: 1,
  },
  {
    label: 'AKAD',
    value: styleHtml + akad(productCd),
    id: 2,
  },
  {
    label: 'Pernyataan Calon Pemegang Polis Pada Formulir SPAJ',
    value: styleHtml + tncSpajSyariah(productCd),
    id: 3,
  },
  {
    label: 'Syarat dan Ketentuan Kepatuhan, Pelayanan Konsumen dan Perikatan',
    value: styleHtml + tncKepatuhan(productCd),
    id: 4,
  },
  {
    label: 'Ketentuan Kepesertaan Manfaat Meninggal Dunia Karena Kecelakaan Sebelum Polis Diterbitkan',
    value: styleHtml + tncKetentuan(productCd, agentChannel),
    id: 5,
  },
];

const eulaPLHP = (productCd, agentChannel) => [
  {
    label: 'Pernyataan Ilustrasi Penjualan',
    value: styleHtml + tncIllustration,
    id: 1,
  },
  {
    label: 'Pernyataan Calon Pemegang Polis dan/atau Tertanggung Perihal Kesehatan Calon Tertanggung',
    value: styleHtml + tncKeshatanPLHP,
    id: 2,
  },
  {
    label: 'Pernyataan Calon Pemegang Polis Pada Formulir SPAJ',
    value: styleHtml + tncSpaj(productCd, ConfigProductSPAJ.productWithEulaLine16.some(x => x === productCd)),
    id: 3,
  },
  {
    label: 'Syarat dan Ketentuan Kepatuhan, Pelayanan Konsumen dan Perikatan',
    value: styleHtml + tncKepatuhan(productCd),
    id: 4,
  },
  {
    label: 'Ketentuan Pertanggungan Manfaat Meninggal Dunia Karena Kecelakaan Sebelum Polis Diterbitkan',
    value: styleHtml + tncKetentuan(productCd, agentChannel),
    id: 5,
  },
];
// // eslint-disable-next-line no-unused-vars
// const USAVE = [
//   {
//     label: 'Pernyataan Ilustrasi Penjualan',
//     value: styleHtml + tncIllustration,
//     id: 1,
//   },
//   {
//     label: 'Pernyataan Calon Pemegang Polis Pada Formulir SPAJ',
//     value: styleHtmlUSAVE + tncSpajUSAVE(),
//     id: 2,
//   },
//   {
//     label: 'Syarat dan Ketentuan Kepatuhan, Pelayanan Konsumen dan Perikatan',
//     value: styleHtmlUSAVE + tncKepatuhanUSAVE,
//     id: 3,
//   },
//   {
//     label: 'Ketentuan Pertanggungan Manfaat Meninggal Dunia Karena Kecelakaan Sebelum Polis Diterbitkan',
//     value: styleHtmlUSAVE + tncKetentuanUSAVE,
//     id: 4,
//   },
// ];

// // eslint-disable-next-line no-unused-vars
// const FIA = (productCd) => {
//   const ketentuan = ConfigProductSPAJ.productBuilder.includes(productCd) ? tncKetentuanBIA : tncKetentuanFIA;

//   return (
//     [
//       {
//         label: 'Pernyataan Ilustrasi Penjualan',
//         value: styleHtml + tncIllustration,
//         id: 1,
//       },
//       {
//         label: 'Pernyataan Calon Pemegang Polis Pada Formulir SPAJ',
//         value: styleHtmlFIA + tncSpajFIA(),
//         id: 2,
//       },
//       {
//         label: 'Syarat dan Ketentuan Kepatuhan, Pelayanan Konsumen dan Perikatan',
//         value: styleHtmlFIA + tncKepatuhanFIA(productCd),
//         id: 3,
//       },
//       {
//         label: 'Ketentuan Pertanggungan Manfaat Meninggal Dunia Karena Kecelakaan Sebelum Polis Diterbitkan',
//         value: styleHtmlFIA + ketentuan,
//         id: 4,
//       },
//     ]
//   );
// };

// // eslint-disable-next-line no-unused-vars
// const TRD = (productCd) => {
//   const ketentuan = ConfigProductSPAJ.productBuilder.includes(productCd) ? newTncKetentuanBIA : newTncKetentuanFIA;

//   return (
//     [
//       {
//         label: 'Pernyataan Ilustrasi Penjualan',
//         value: newStyleHtmlFIA + newTncIlustration,
//         id: 1,
//       },
//       {
//         label: 'Pernyataan Calon Pemegang Polis Pada Formulir SPAJ',
//         value: newStyleHtmlFIA + newTncSpajFIA(),
//         id: 2,
//       },
//       {
//         label: 'Syarat dan Ketentuan Kepatuhan, Pelayanan Konsumen dan Perikatan',
//         value: newStyleHtmlFIA + newTncKepatuhanFIA(productCd),
//         id: 3,
//       },
//       {
//         label: 'Ketentuan Pertanggungan Manfaat Meninggal Dunia Karena Kecelakaan Sebelum Polis Diterbitkan',
//         value: newStyleHtmlFIA + ketentuan,
//         id: 4,
//       },
//     ]
//   );
// };

// // eslint-disable-next-line no-unused-vars
// const UL = productCd => [
//   {
//     label: 'Pernyataan Ilustrasi Penjualan',
//     value: newStyleHtml + newTncIlustration,
//     id: 1,
//   },
//   {
//     label: 'Pernyataan Calon Pemegang Polis Pada Formulir SPAJ',
//     value: newStyleHtml + newTncSpaj(),
//     id: 2,
//   },
//   {
//     label: 'Syarat dan Ketentuan Kepatuhan, Pelayanan Konsumen dan Perikatan',
//     value: newStyleHtml + newTncKepatuhan(productCd),
//     id: 3,
//   },
//   {
//     label: 'Ketentuan Pertanggungan Manfaat Meninggal Dunia Karena Kecelakaan Sebelum Polis Diterbitkan',
//     value: newStyleHtml + newTncKetentuan,
//     id: 4,
//   },
// ];


function getEulaData(productCd, agentChannel) {
// function getEulaData(productCd, productCategory) {
  // if (productCategory) {
  //   if (productCategory === ConfigProductSPAJ.productCategory.UL) return UL(productCd);
  //   if (productCategory === ConfigProductSPAJ.productCategory.TRD) return TRD(productCd);
  // }
  // // eslint-disable-next-line max-len
  // if (ConfigProductSPAJ.productVMA.includes(productCd) || ConfigProductSPAJ.productVMPPlus.includes(productCd)) {
  //   return VMA(productCd);
  // }
  // if (ConfigProductSPAJ.productUSAVE.includes(productCd)) {
  //   return USAVE;
  // }
  // if (ConfigProductSPAJ.productFIA.includes(productCd)) {
  //   return FIA(productCd);
  // }
  // return [];
  if (productCd === 'L2I') {
    return eulaPIPP(productCd);
  } if (productCd === 'T2U') {
    return eulaPRUCinta(productCd, agentChannel);
  } if (productCd === 'R2A') {
    return eulaPLHP(productCd, agentChannel);
  } return eula(productCd);
}

function getEulaDetail(data = [], id) {
  return data.find(x => x.id === id);
}

export default {
  getEulaData,
  getEulaDetail,
};
