/**
 * @author:
 * ecomindo
*/

import SubHeader_ from './SubHeader';

const SubHeader = SubHeader_;

export {
  SubHeader,
};
