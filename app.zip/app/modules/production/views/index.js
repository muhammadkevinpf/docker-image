import MainProduction from './main-production';
import ProductionHistoryDetail from './history-detail-production';
import ProductionUnitList from './unit-production-list';
import ProductionIndividuList from './individu-production-list';

export default {
  MainProduction,
  ProductionUnitList,
  ProductionHistoryDetail,
  ProductionIndividuList,
};
