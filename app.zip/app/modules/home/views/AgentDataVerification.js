import React, { Component } from 'react';
import { View, Button, Text } from 'native-base';
import moment from 'moment';
import { connect } from 'react-redux';
import { BackHandler, Alert } from 'react-native';
import _ from '../../../lang';
// import ComponentsHome from '../components';

import Style from '../../../styles';
import {
  pageType as page, CHECK_AGENT_VERIFICATION, CHECK_EMAIL_VERIFICATION, CHECK_AGENT_BANCA_BY_AGENT_CODE, GET_USER_ID, VERIFY_AGENT,
} from '../ConfigHome';
import { authAction, verifyBancaAction } from '../ActionHome';
import { requestStatus } from '../../../utilities';
import LoadingModal from '../../../components/loading_modal';
import HomeScreen from '../components/HomeScreen';
import { InputFieldNew, DatePickerNew } from '../../../components';

const headers = [
  {
    keyHeader: 'X-CSRF-Token',
    valueHeader: 'Bearer undefined',
  },
];

class AgentDataVerification extends Component {
  constructor(props) {
    super(props);
    this.state = {
      agentCode: '',
      birthdate: null,
      isLoading: false,
      isBancaVerified: false,
      pageType: '',
      id: '',
      telephone: '',
    };
  }

  componentDidMount() {
    const pageType = this.props.navigation.getParam('pageType', '');
    this.setState({ pageType });
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleBack();
      return true;
    });
  }

  componentDidUpdate(prevProps) {
    if (this.props !== prevProps) {
      if ((this.props.status !== prevProps.status && this.props.status === requestStatus.FETCH)
        || (this.props.emailStatus !== prevProps.emailStatus && this.props.emailStatus === requestStatus.FETCH)
        || (this.props.getUserIdStatus !== prevProps.getUserIdStatus && this.props.getUserId === requestStatus.FETCH)
        || (this.props.verifAgentStatus !== prevProps.verifAgentStatus && this.props.verifAgentStatus === requestStatus.FETCH)) {
        this.handleLoading(true);
      }

      if ((this.props.checkAgentTypeStatus !== prevProps.checkAgentTypeStatus)
        && (this.props.checkAgentTypeStatus === requestStatus.FETCH)) { this.handleLoading(true); }

      if ((this.props.checkAgentTypeStatus !== prevProps.checkAgentTypeStatus)
        && (this.props.checkAgentTypeStatus === requestStatus.SUCCESS)) {
        if (!this.props.verifyBancaData.isBanca) {
          if (this.props.verifyBancaData.responseMessage === 'Data not found') {
            Alert.alert(
              '',
              'Data yang Anda masukkan tidak sesuai dengan database kami. Silakan hubungi Agency Administration Support.',
              [{ text: 'Ok', onPress: () => this.handleLoading(false) }],
              { cancelable: false },
            );
            return;
          }
          Alert.alert(
            '',
            'Saat ini PRUFast hanya dapat di akses oleh tenaga pemasar Bancassurance',
            [{ text: 'Ok', onPress: () => { this.handleLoading(false); } }],
            { cancelable: false },
          );
          return;
        }
        if (!this.state.isBancaVerified) {
          // eslint-disable-next-line react/no-did-update-set-state
          this.setState({ isBancaVerified: this.props.verifyBancaData.isBanca }, () => {
            this.onVerify();
          });
        }
      }

      if (this.props.status !== prevProps.status && this.props.status === requestStatus.SUCCESS) {
        this.handleLoading(false, () => {
          if (this.props.checkAgent.body.respCode === 200) {
            if (this.state.pageType === page.createPRUFastID) {
              const { agentId } = this.props.checkAgent.body.result;
              this.getUser(agentId);
            } else {
              this.getEmail();
            }
          } else {
            Alert.alert(
              '',
              'Data yang Anda masukkan tidak sesuai dengan database kami. Silakan hubungi Agency Administration Support.',
              [{ text: 'Ok', onPress: () => { this.setState({ isBancaVerified: false }, () => this.handleLoading(false)); } }],
              { cancelable: false },
            );
          }
        });
      }

      if (this.props.verifAgentStatus !== prevProps.verifAgentStatus && this.props.verifAgentStatus === requestStatus.SUCCESS) {
        this.handleLoading(false, () => {
          if (this.props.verifAgent.respCode === 200) {
            this.getEmail();
          } else {
            Alert.alert(
              '',
              'Data yang Anda masukkan tidak sesuai dengan database kami. Silakan hubungi Agency Administration Support.',
              [{ text: 'Ok', onPress: () => { this.setState({ isBancaVerified: false }, () => this.handleLoading(false)); } }],
              { cancelable: false },
            );
          }
        });
      }

      if (this.props.emailStatus !== prevProps.emailStatus && this.props.emailStatus === requestStatus.SUCCESS) {
        if (this.props.email.statusCode === 200) {
          this.handleLoading(false, () => {
            if (this.state.pageType === page.createPRUFastIDNoSFA) {
              this.getUser(this.state.agentCode);
            } else {
              this.goToSMSVerification();
            }
          });
        } else {
          Alert.alert('', this.props.email.errorMessage || '', [{ text: 'Ok', onPress: () => { this.handleLoading(false); } }]);
        }
      }

      if (this.props.getUserIdStatus !== prevProps.getUserIdStatus && this.props.getUserIdStatus === requestStatus.SUCCESS) {
        if (this.props.getUserId.errorCode === '000000') {
          Alert.alert('', 'Kode Agen Anda sudah terdaftar di PRUFast ID', [{ text: 'Ok', onPress: () => { this.handleLoading(false); } }]);
        } else {
          this.handleLoading(false, () => {
            switch (this.state.pageType) {
              case page.createPRUFastID:
                this.props.navigation.replace('SignUpAgent', { route: 'AgentDataVerification', pageType: page.createPRUFastID });
                break;
              case page.createPRUFastIDNoSFA:
                this.goToSMSVerification();
                break;
              default:
                console.log(this.state.pageType);
                break;
            }
          });
        }
      }

      if ((this.props.status !== prevProps.status && this.props.status === requestStatus.FAILED)
        || (this.props.emailStatus !== prevProps.emailStatus && this.props.emailStatus === requestStatus.FAILED)
        || (this.props.getUserIdStatus !== prevProps.getUserIdStatus && this.props.getUserId === requestStatus.FAILED)
        || (this.props.verifAgentStatus !== prevProps.verifAgentStatus && this.props.verifAgentStatus === requestStatus.FAILED)
        || (this.props.checkAgentTypeStatus !== prevProps.status && this.props.checkAgentTypeStatus === requestStatus.FAILED)) {
        this.handleLoading(false, () => {
          Alert.alert('', 'Gagal memanggil service', [{ text: 'Ok', onPress: () => { } }]);
        });
      }
    }
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  handleLoading = (val, func) => {
    const callbackFunc = func || (() => { });
    this.setState({ isLoading: val }, callbackFunc);
  }

  goToSMSVerification = () => {
    const { pageType, agentCode } = this.state;
    const { verifAgent, checkAgent } = this.props;
    const dataResult = pageType === page.createPRUFastIDNoSFA ? { ...verifAgent.result, agentId: agentCode } : checkAgent.body.result;
    const { email } = this.props.email;
    const dob = this.state.birthdate ? moment(this.state.birthdate).format('YYYY-MM-DD') : null;
    this.props.navigation.replace('SMSVerification', {
      pageType: this.state.pageType,
      userType: 'agent',
      data: { ...dataResult, birthdate: dob, email },
    });
  }

  setDate = (value) => {
    this.setState({ birthdate: value });
  }

  handleBack = () => {
    switch (this.state.pageType) {
      case page.createPRUFastIDNoSFA:
        this.props.navigation.replace('AgentDataVerification', { pageType: page.createPRUFastID });
        break;
      default:
        this.props.navigation.replace('MainRouteHome', { pageType: this.state.pageType });
        break;
    }
  }

  onVerify = () => {
    const {
      agentCode, birthdate, id, telephone, pageType,
    } = this.state;

    const dob = birthdate ? moment(birthdate).format('YYYY-MM-DD') : null;
    const type = 'new'; // angular reference
    const noSFA = pageType === page.createPRUFastIDNoSFA;

    let data = { headers, params: `["${agentCode}", "${dob}", "${type}"]` };

    if (agentCode === '' || birthdate === null || (noSFA && (id === '' || telephone === ''))) {
      Alert.alert('', 'Mohon mengisi semua kolom isian', [{ text: 'Ok', onPress: () => { } }]);
    } else {
      switch (this.state.pageType) {
        case page.createPRUFastID:
          this.props.verifyAgent(CHECK_AGENT_VERIFICATION.FETCH, data);
          break;
        case page.createPRUFastIDNoSFA:
          data = { headers, params: `["${agentCode}", "${id}", "${dob}", "${telephone}", "${type}"]` };
          this.props.verifyAgent(VERIFY_AGENT.FETCH, data);
          break;
        default:
          if (!this.state.isBancaVerified) {
            data = { headers, params: `["${agentCode}"]` };
            this.props.verifyBanca(data);
          } else {
            this.props.verifyAgent(CHECK_AGENT_VERIFICATION.FETCH, data);
          }
          break;
      }
    }
  }

  getEmail = () => {
    const userType = 'agent';
    const data = { headers, params: `["${this.state.agentCode}", "${userType}"]` };

    this.props.checkEmail(data);
  }

  getUser = (agentCode) => {
    const npa = '';
    const data = { headers, params: `["${agentCode}", "${npa}"]` };

    this.props.getUserID(data);
  }

  render() {
    const sfaLabel = this.state.pageType === page.createPRUFastID ? 'SFA ID / ' : '';
    const title = this.state.pageType === page.createPRUFastID ? 'Belum Memiliki PRUFast ID - Agen' : 'Verifikasi Data Agen';
    return (
      <React.Fragment>
        <HomeScreen
          title={title}
          onBackClicked={this.handleBack}
          content={
            <View style={[Style.Main.width200, Style.Main.alignCenter]}>
              <InputFieldNew
                value={this.state.agentCode}
                label={_(`${sfaLabel}Kode Agen`)}
                onChangeText={agentCode => this.setState({ agentCode })}
                isRequired={false}
                keyboardType={this.state.pageType === page.createPRUFastID ? null : 'numeric'}
              />
              <DatePickerNew
                defaultDate={this.state.birthdate}
                locale="id"
                timeZoneOffsetInMinutes={undefined}
                modalTransparent={false}
                animationType="fade"
                androidMode="spinner"
                placeHolderText="Tanggal Lahir"
                label={this.state.birthdate !== null && 'Tanggal Lahir'}
                onDateChange={this.setDate}
                style={[Style.Main.fullWidth]}
                disabled={false}
              />
              {
                this.state.pageType === page.createPRUFastIDNoSFA && (
                  <React.Fragment>
                    <InputFieldNew
                      value={this.state.id}
                      label={_('Nomor KTP')}
                      type="phone"
                      maxLength={16}
                      onChangeText={id => this.setState({ id })}
                      isRequired={false}
                    />
                    <InputFieldNew
                      value={this.state.telephone}
                      label={_('Nomor Handphone Terdaftar')}
                      minLength={9}
                      maxLength={13}
                      keyboardType="numeric"
                      onChangeText={telephone => this.setState({ telephone })}
                      isRequired={false}
                    />
                  </React.Fragment>
                )
              }
              <Button
                rounded
                danger
                style={[Style.Main.mt35, Style.Main.buttonRed]}
                onPress={this.onVerify}
              >
                <Text style={[Style.Main.fontAlbert14, Style.Main.textWhite]}>
                  {_(this.state.pageType === page.createPRUFastID ? 'MASUK' : 'VERIFIKASI')}
                </Text>
              </Button>
              {
                this.state.pageType === page.createPRUFastID && (
                  <Text
                    onPress={() => this.props.navigation.replace('AgentDataVerification',
                      { pageType: page.createPRUFastIDNoSFA })}
                    style={[Style.Main.textAlmostBlack, Style.Main.textCenter, Style.Main.font11, Style.Main.mb15, Style.Main.mt5]}
                  >
                    Tidak Memiliki SFA ID?
                  </Text>
                )
              }
            </View>
          }
        />
        <LoadingModal
          show={this.state.isLoading}
          size="large"
          color="white"
        />
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  isOnline: state.connectionStatus.isOnline,
  checkAgent: state.home.checkAgent,
  status: state.home.checkAgentStatus,
  verifAgent: state.home.verifyAgent,
  verifAgentStatus: state.home.verifyAgentStatus,
  email: state.home.checkEmail,
  emailStatus: state.home.checkEmailStatus,
  getUserId: state.home.getUserId,
  getUserIdStatus: state.home.getUserIdStatus,
  verifyBancaData: state.home.verifyBanca,
  checkAgentTypeStatus: state.home.checkAgentTypeStatus,
});

const mapDispatchToProps = dispatch => ({
  verifyAgent: (type, value) => dispatch(authAction(type, value)),
  checkEmail: value => dispatch(authAction(CHECK_EMAIL_VERIFICATION.FETCH, value)),
  verifyBanca: value => dispatch(verifyBancaAction(CHECK_AGENT_BANCA_BY_AGENT_CODE.FETCH, value)),
  getUserID: value => dispatch(verifyBancaAction(GET_USER_ID.FETCH, value)),
});

export default connect(mapStateToProps, mapDispatchToProps)(AgentDataVerification);
