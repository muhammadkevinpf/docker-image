/**
 * @author: dwi.setiyadi@gmail.com
*/

import { dimensions } from './Platform';
import AppJson from '../../app.json';

export const SETSCREEN = 'SETSCREEN';
export const SET_SIDEBAR_WIDTH = 'SET_SIDEBAR_WIDTH';

export const coverageStartText = [
  'PRU', 'SPARK', 'VERSA', 'BUILDER', 'FLEXI', 'PREVINA', 'CI', 'USave PRUStar', 'USave', 'Usave', 'T3ST', 'PRESTIGE',
];

export const DashboardAgentTypes = {
  individu: ['FC', 'PS'],
  unit: ['AS', 'MF'],
  group: ['MF'],
};

export const AgentScopes = {
  individu: 'Individual',
  unit: 'Unit',
  group: 'Group',
};

export const SortDir = {
  ASC: 'asc',
  DESC: 'desc',
};

export const tabSizeRef = {
  height: 768,
  width: 1280,
  screenHeight: dimensions.width > dimensions.height ? 768 : 1280,
  screenWidth: dimensions.width > dimensions.height ? 1280 : 768,
};

export const adapter = {
  COMMON: `adapters/${AppJson.environtment === 'UAT' ? 'PrufastCommonAdapter_uat' : 'PrufastCommonAdapter'}`,
  BO: 'adapters/PrufastBOAdapter',
  INQUIRY: 'adapters/HTTPAdapterInquiry',
  PMN: 'adapters/PrufastPMNAdapter',
};

export const timeoutLoading = 2000;
