import { StyleSheet, Dimensions } from 'react-native';
import Styles from '../../styles';

const deviceWidth = Dimensions.get('window').width;
let defaultContainerWidth = (70 / 100) * deviceWidth;
if (deviceWidth > 800) {
  defaultContainerWidth = (50 / 100) * deviceWidth;
}

const StyleMorePopupMenu = StyleSheet.create({
  touchArea: size => ({
    width: size,
    height: size,
  }),
  container: {
    width: defaultContainerWidth,
    backgroundColor: Styles.Color.white,
    padding: 20,
    borderRadius: 10,
  },
  menuContent: {
    // color: Styles.Color.black,
    textAlign: 'left',
    fontSize: 16,
    ...Styles.Main.fontAlbert,
  },
  textStyle: {
    color: Styles.Color.black,
    textAlign: 'left',
    fontSize: 14,
  },
  textWrapper: {
    padding: 15,
  },
});

export default StyleMorePopupMenu;
