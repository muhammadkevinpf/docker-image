const translation = [
  {
    id: 'Notifikasi',
    en: 'Notification',
  },
];

export default translation;
