/* eslint-disable react-native/no-color-literals */
/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import { StyleSheet, Platform } from 'react-native';
import { dimensions } from '../../config/Platform';
import Styles from '../../styles';

// const carouselWidth = dimensions.screenWidth;
// const carouselHeight = (carouselWidth / 3) * 2;


const size = 200;
const width = 15;
const textOffset = width;
const cropDegree = 90;
const textWidth = size - (textOffset * 2);
const textHeight = size * (1 - cropDegree / 360) - (textOffset * 2);

let PickerInput = {};
switch (Platform.OS) {
  case 'ios':
    PickerInput = {
      width: dimensions.screenWidth - 15,
      marginLeft: -15,
    };
    break;

  case 'android':
    PickerInput = {
      width: dimensions.screenWidth - 43,
      marginLeft: -8,
      marginRight: -15,
      color: Styles.Color.lightGray,
    };
    break;

  default:
    break;
}

let PickerInputDetailPage = {};
switch (Platform.OS) {
  case 'ios':
    PickerInputDetailPage = {
      width: 150,
      marginLeft: -15,
    };
    break;

  case 'android':
    PickerInputDetailPage = {
      width: dimensions.screenWidth - 43,
      marginLeft: -8,
      marginRight: -15,
      color: Styles.Color.lightGray,
    };
    break;

  default:
    break;
}


export default StyleSheet.create({
  Container: {
    marginTop: 0,
  },
  PickerInput,
  iOSPickerIcon: {
    marginRight: 0,
    fontSize: 14,
  },
  iOSPickerIconVoucher: {
    marginRight: 30,
    fontSize: 14,
  },
  PickerInputDetailPage,
  iOSPickerIconDetail: {
    marginRight: 0,
    marginLeft: -5,
    fontSize: 14,
  },
  textView: {
    position: 'absolute',
    top: textOffset,
    left: textOffset,
    width: textWidth,
    height: textHeight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    fontSize: 20,
  },
  SegmentAccordion: {
    width: '50%',
  },
  rowSortable: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 16,
    height: 80,
    flex: 1,
    marginTop: 7,
    marginBottom: 12,
    borderRadius: 4,


    ...Platform.select({
      ios: {
        width: window.width - 30 * 2,
        shadowColor: 'rgba(0,0,0,0.2)',
        shadowOpacity: 1,
        shadowOffset: { height: 2, width: 2 },
        shadowRadius: 2,
      },

      android: {
        width: window.width - 30 * 2,
        elevation: 0,
        marginHorizontal: 30,
      },
    }),
  },
  containerSortable: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#eee',

    ...Platform.select({
      ios: {
        paddingTop: 20,
      },
    }),
  },
  listSortable: {
    flex: 1,
  },
  contentSortable: {
    width: window.width,

    ...Platform.select({
      ios: {
        paddingHorizontal: 30,
      },

      android: {
        paddingHorizontal: 0,
      },
    }),
  },
});
