/* eslint-disable no-console */

import React, { Component, Fragment } from 'react';
import ImageResizer from 'react-native-image-resizer';
import moment from 'moment';
import PropTypes from 'prop-types';
import RNFS from 'react-native-fs';
// import Orientation from 'react-native-orientation-locker';
import {
  View, TouchableOpacity, Image, Modal, YellowBox, Platform, Alert,
} from 'react-native';
import { Button, Icon, Text } from 'native-base';
import { SketchCanvas } from '@terrylinla/react-native-sketch-canvas';
import { Grid, Row, Col } from 'react-native-easy-grid';
import { isTablet, isEmpty } from '../../utilities';
import InputFieldNew from '../input-field-new';
import Style from '../../styles';
import _ from '../../lang';

export class SignatureForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modalTTD: false,
      ttd: null,
      tglttd: '',
      location: '',
      tempTTD: null,
      renderUlang: false,
      imagePath: null,
      tabletDevice: isTablet(),
    };
  }

  componentDidMount() {
    // if (Platform.OS === 'ios' && !this.state.tabletDevice) Orientation.unlockAllOrientations();
    // eslint-disable-next-line max-len
    YellowBox.ignoreWarnings(['Accessing view manager configs directly off UIManager via UIManager[\'RNSketchCanvas\'] is no longer supported. Use UIManager.getViewManagerConfig(\'RNSketchCanvas\') instead.']);

    this.setState({
      ttd: this.props.value,
      location: this.props.location,
      tglttd: this.props.dateValue,
    });
  }

  componentWillUnmount() {
    // if (Platform.OS === 'ios' && !this.state.tabletDevice) Orientation.lockToPortrait();
    if (this.props.deleteCache) this.removeSavedSignature();
  }

  onInputLocation = (item) => {
    this.props.onInputLocation(item);
    this.setState({ location: item });
  }

  setModalTTD(visible) { this.setState({ modalTTD: visible }); }

  setTTD(result) { this.setState({ ttd: result }); }

  saveToCacheAndroid = () => new Promise(async (resolve, reject) => {
    try {
      const name = this.props.signFileName;
      const path = `${RNFS.CachesDirectoryPath}/signature`;
      const filename = `${path}/${name}`;
      await RNFS.mkdir(path);
      await RNFS.writeFile(filename, `${this.state.ttd}`, 'base64');
      this.setState({ imagePath: filename });
      console.log('File Written!');
      if (this.state.tabletDevice) {
        this.props.onChange({ value: this.state.tempTTD, date: this.state.tglttd });
      }
      resolve('SAVED');
    } catch (error) {
      reject(error);
    }
  })

  orientationPortrait = () => {
    // if (Platform.OS === 'ios' && !this.state.tabletDevice) {
    //   Orientation.unlockAllOrientations();
    //   Orientation.lockToPortrait();
    // }
  }

  orientationLandscape = () => {
    // if (Platform.OS === 'ios' && !this.state.tabletDevice) {
    //   Orientation.unlockAllOrientations();
    //   Orientation.lockToLandscape();
    // }
  }

  removeSavedSignature = () => new Promise(async (resolve, reject) => {
    try {
      const name = this.props.signFileName;
      const path = `${RNFS.CachesDirectoryPath}/signature`;
      const filename = `${path}/${name}`;
      const isExist = await RNFS.exists(filename);
      if (this.state.modalTTD) { this._signatureCanvas.clear(); }
      if (isExist) { await RNFS.unlink(filename); }
      resolve('DELETED');
    } catch (error) {
      reject(error);
    }
  })

  onOpenSignature = async () => {
    try {
      const { tabletDevice } = this.state;
      const name = this.props.signFileName;
      const path = `${RNFS.CachesDirectoryPath}/signature`;
      if (this.state.ttd !== '' && this.state.ttd !== null) {
        await this.saveToCacheAndroid();
        const res = await RNFS.readDir(path);
        const signPath = res.find(x => x.name === name).path;
        const base64 = await RNFS.readFile(signPath, 'base64');
        if (!tabletDevice) {
          await this.rotateImage(base64, 90);
        }
        await this.saveToCacheAndroid();
        this.setState({ imagePath: signPath });
      }
      this.setState({ modalTTD: true }, () => this.orientationLandscape());
    } catch (error) {
      console.log(error);
    }
  }

  onSaveSignature = async () => {
    const { tempTTD, modalTTD, tabletDevice } = this.state;
    const date = moment().format('Do MMMM YYYY, H:mm:ss');
    if (tempTTD) {
      this.setState({ tglttd: date });
      this.setState(prevState => ({ ttd: prevState.tempTTD }));
      await this.saveToCacheAndroid();
      if (!tabletDevice) {
        await this.rotateImage(this.state.tempTTD, 270);
      }
      await this.saveToCacheAndroid();
    }
    this.setModalTTD(!modalTTD);
    this.orientationPortrait();
  }

  onCancelSignature = async () => {
    const { tabletDevice } = this.state;
    await this.saveToCacheAndroid();
    if (!tabletDevice) {
      await this.rotateImage(this.state.ttd, 270);
    }
    await this.saveToCacheAndroid();
    this.setModalTTD(!this.state.modalTTD);
    this.orientationPortrait();
  }

  clearCanvas = () => this._signatureCanvas.clear();

  rotateImage = async (base64, angle) => {
    try {
      const rotated = await ImageResizer.createResizedImage(
        Platform.OS === 'ios' ? this.state.imagePath : `data:image/png,${base64}`, 1000, 1000, 'PNG', 100, angle, undefined,
      );
      const result = await RNFS.readFile(rotated.uri, 'base64');
      this.setState({ tempTTD: result, ttd: result }, () => {
        this.props.onChange({ value: this.state.tempTTD, date: this.state.tglttd });
      });
    } catch (error) {
      console.log(error);
    }
    return base64;
  }

  saveCanvas = () => {
    this._signatureCanvas.getBase64('png', false, true, false, false, (err, res) => {
      try {
        this.setState({ tempTTD: res });
      } catch (error) {
        console.log(error);
      }
      console.log(err);
    });
  }

  clearTTD = (type = 'clear') => {
    this.removeSavedSignature().then(() => {
      if (type === 'reset') {
        this.setState({
          ttd: null,
          location: '',
          tglttd: '',
          tempTTD: null,
        });
      } else {
        this.setState({
          ttd: null,
          tempTTD: null,
          tglttd: '',
          renderUlang: true,
        }, () => {
          this.setState({ renderUlang: false, ttd: null });
        });
      }
    }).then(() => this.props.onClear({ value: this.state.tempTTD, date: this.state.tglttd, location: this.state.location }));
  };

  renderPhone() {
    const { imagePath } = this.state;
    return (
      <View style={[Style.Main.justifyCenter, Style.Main.flexTop, Style.Main.container, Style.Main.backgroundWhite]}>
        <Grid>
          <Row>
            <Col size={2}>
              <View
                style={[
                  Style.Main.center,
                  Style.Main.columnDirectionSpaceEvently,
                  Style.Main.container,
                  Style.Main.backgroundF9,
                ]}
              >
                <Button
                  bordered
                  danger
                  block
                  style={[Style.Main.dialogOutlineBtn, Style.Main.alignCenter, Style.Main.rotate90Deg]}
                  onPress={this.clearTTD}
                >
                  <Text style={[Style.Main.textRed]}>{_('RESET')}</Text>
                </Button>
                <Button
                  bordered
                  danger
                  block
                  style={[Style.Main.dialogOutlineBtn, Style.Main.alignCenter, Style.Main.rotate90Deg]}
                  onPress={this.onSaveSignature}
                >
                  <Text style={[Style.Main.textRed]}>{_('SIMPAN')}</Text>
                </Button>
                <Button
                  bordered
                  danger
                  block
                  style={[Style.Main.dialogOutlineBtn, Style.Main.alignCenter, Style.Main.rotate90Deg]}
                  onPress={this.onCancelSignature}
                >
                  <Text style={[Style.Main.textRed]}>{_('BATAL')}</Text>
                </Button>
              </View>
            </Col>
            <Col size={8}>
              {!this.state.renderUlang &&
                (
                  <SketchCanvas
                    style={Style.Main.container}
                    strokeColor="black"
                    strokeWidth={7}
                    ref={(ref) => { this._signatureCanvas = ref; }}
                    onStrokeEnd={this.saveCanvas}
                    localSourceImage={{
                      filename: `${imagePath}`,
                      directory: null,
                      mode: 'AspectFill',
                    }}
                  />
                )}
            </Col>
          </Row>
        </Grid>
      </View>
    );
  }

  renderTablet() {
    const { imagePath } = this.state;
    return (
      <View style={[Style.Main.justifyCenter, Style.Main.flexTop, Style.Main.container, Style.Main.backgroundWhite]}>
        <Grid>
          <Row size={8}>
            {!this.state.renderUlang &&
              (
                <SketchCanvas
                  style={Style.Main.container}
                  strokeColor="black"
                  strokeWidth={7}
                  ref={(ref) => { this._signatureCanvas = ref; }}
                  onStrokeEnd={this.saveCanvas}
                  localSourceImage={{
                    filename: `${imagePath}`,
                    directory: null,
                    mode: 'AspectFill',
                  }}
                />
              )}
          </Row>

          <Row size={2}>
            <Row
              style={[
                Style.Main.center,
                Style.Main.container,
                Style.Main.backgroundF9,
              ]}
            >
              <Col>
                <Button
                  bordered
                  danger
                  block
                  style={[Style.Main.dialogOutlineBtn, Style.Main.alignCenter]}
                  onPress={this.clearTTD}
                >
                  <Text style={[Style.Main.textRed]}>{_('RESET')}</Text>
                </Button>
              </Col>
              <Col>
                <Button
                  bordered
                  danger
                  block
                  style={[Style.Main.dialogOutlineBtn, Style.Main.alignCenter]}
                  onPress={this.onSaveSignature}
                >
                  <Text style={[Style.Main.textRed]}>{_('SIMPAN')}</Text>
                </Button>
              </Col>
              <Col>
                <Button
                  bordered
                  danger
                  block
                  style={[Style.Main.dialogOutlineBtn, Style.Main.alignCenter]}
                  onPress={this.onCancelSignature}
                >
                  <Text style={[Style.Main.textRed]}>{_('BATAL')}</Text>
                </Button>
              </Col>
            </Row>
          </Row>
        </Grid>
      </View>
    );
  }

  render() {
    const {
      tglttd, ttd, modalTTD, tabletDevice, location,
    } = this.state;
    return (
      <Fragment>
        <Modal
          animationType="slide"
          visible={modalTTD}
          supportedOrientations={['portrait', 'landscape']}
          onRequestClose={this.onCancelSignature}
        >{!tabletDevice ? this.renderPhone() : this.renderTablet()}
        </Modal>
        {
          !isEmpty(this.props.label) &&
          <Text style={[Style.Main.fontAlbert14, Style.Main.textAlignCenter, Style.Main.mt12, this.props.labelStyle]}>{_(this.props.label)}</Text>
        }
        {
          isEmpty(ttd) ?
            <TouchableOpacity
              style={[Style.Main.imgTTD, Style.Main.flexTop, Style.Main.justifyCenter, Style.Main.mt12, this.props.style]}
              onPress={this.onOpenSignature}
            >
              <Text style={[Style.Main.textTTD]}>{_('TANDA TANGAN')}</Text>
            </TouchableOpacity> :
            <TouchableOpacity
              style={[Style.Main.flexTop, Style.Main.justifyCenter, Style.Main.padding2, Style.Main.ttdContainer, Style.Main.mt12, this.props.style]}
              onPress={this.onOpenSignature}
            >
              <Image
                source={ttd ? { uri: `data:image/png;base64,${ttd}` } : null}
                resizeMethod="scale"
                resizeMode={Platform.OS === 'ios' && isTablet() ? 'stretch' : 'cover'}
                style={[Style.Main.imgTTDContainer]}
              />
            </TouchableOpacity>
        }
        {
          this.props.placeAndDate &&
          <React.Fragment>
            <View style={[Style.Main.mt15]}>
              <InputFieldNew
                value={location}
                label={_('Tempat')}
                onChangeText={this.onInputLocation}
                type="address"
                isRequired={this.props.placeRequired}
              />
            </View>
            <View style={[Style.Main.mt20]}>
              <Text style={[Style.Main.fontAlbert, Style.Main.gray83, Style.Main.font11]}>{(tglttd === '') ? '' : _('Tanggal')}</Text>
            </View>
            <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.grayBorderBottom]}>
              <Text style={[Style.Main.fontAlbert, Style.Main.textAlmostBlack, Style.Main.font14, Style.Main.pb5]}>
                {(tglttd === '') ? _('Tanggal') : tglttd}
              </Text>
              <Icon name="calendar" type="AntDesign" style={[Style.Main.gray83]} />
            </View>
          </React.Fragment>
        }
        {this.props.children}
        <View style={[Style.Main.mt15]}>
          <Button
            bordered
            block
            danger
            style={[Style.Main.largeOutlineBtn]}
            onPress={() => {
              Alert.alert(_('Warning'), _('Apakah Anda yakin untuk reset tanda tangan?'), [
                { text: _('Tidak') },
                { text: _('Ya'), onPress: () => this.clearTTD('reset') },
              ]);
            }}
          >
            <Text style={[Style.Main.textAlmostBlack]}>{_('RESET')}</Text>
          </Button>
        </View>
      </Fragment>
    );
  }
}

SignatureForm.propTypes = {
  signFileName: PropTypes.string.isRequired,
  onChange: PropTypes.func,
  onInputLocation: PropTypes.func,
  onClear: PropTypes.func,
  placeAndDate: PropTypes.bool,
  placeRequired: PropTypes.bool,
  deleteCache: PropTypes.bool,
  label: PropTypes.string,
  value: PropTypes.string,
  location: PropTypes.string,
  dateValue: PropTypes.string,
  style: PropTypes.shape({}),
};

SignatureForm.defaultProps = {
  onChange: () => _.noop,
  onClear: () => _.noop,
  onInputLocation: () => {},
  placeAndDate: true,
  placeRequired: false,
  deleteCache: false,
  label: null,
  value: null,
  location: '',
  dateValue: '',
  style: {},
};
