import Views from './views';

export default {
  CorrespondenceList: { screen: Views.CorrespondenceList },
  CorrespondenceDocPreview: { screen: Views.CorrespondenceDocPreview },
  DownloadFileList: { screen: Views.DownloadFileList },
  DownloadDocPreview: { screen: Views.DownloadDocPreview },
};
