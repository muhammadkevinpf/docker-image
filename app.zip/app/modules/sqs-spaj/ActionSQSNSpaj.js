import {
  ConfigIntegration,
} from './config';

const {
  LISTPROPOSALFAILED,
  LISTPROPOSALFETCH,
  LISTPROPOSALSUCCESS,
  STOREILLUSTRATIONDATA,
} = ConfigIntegration;

export const listProposalFetch = value => ({ type: LISTPROPOSALFETCH, send: value });
export const listProposalSuccess = value => ({ type: LISTPROPOSALSUCCESS, res: value });
export const listProposalFailed = value => ({ type: LISTPROPOSALFAILED, err: value });
export const storeIllustrationData = value => ({ type: STOREILLUSTRATIONDATA, data: value });
