import {
  NEWS_LIST_FETCH, NEWS_LIST_SUCCESS, NEWS_LIST_FAILED,
  NEWS_DETAIL_FETCH, NEWS_DETAIL_SUCCESS, NEWS_DETAIL_FAILED,
  FILE_BASE_64_FETCH, FILE_BASE_64_SUCCESS, FILE_BASE_64_FAILED,
  FILE_BASE_64_RESET,
  NEWS_LIST_RESET,
  NEWS_DETAIL_RESET,
} from './ConfigNews';
import { requestStatus } from '../../utilities/ApiConnection';
import { RESET_ALL_STATE } from '../dashboard/ConfigDashboard';
import { isEmpty } from '../../utilities';

const initialNewsState = {
  newsListStatus: requestStatus.IDLE,
  newsDetailStatus: requestStatus.IDLE,
  newsList: [],
  newsDetail: {},
  send: null,
  err: null,
  base64: [],
  base64Status: requestStatus.IDLE,
};

export function ReducerNews(state = initialNewsState, action) {
  switch (action.type) {
    case RESET_ALL_STATE: return initialNewsState;
    case NEWS_LIST_FETCH:
      return {
        ...state,
        newsListStatus: requestStatus.FETCH,
        send: action.send,
        action: action.type,
      };

    case NEWS_LIST_SUCCESS:
      return {
        ...state,
        newsListStatus: requestStatus.SUCCESS,
        newsList: isEmpty(action.res) ? [] : [...state.newsList, ...action.res.filter(x => !state.newsList.some(news => news.id === x.id))],
        err: null,
        action: action.type,
      };

    case NEWS_LIST_FAILED:
      return {
        ...state,
        newsListStatus: requestStatus.FAILED,
        err: action.err,
        action: action.type,
      };

    case NEWS_LIST_RESET:
      return {
        ...state,
        newsListStatus: requestStatus.IDLE,
        newsList: [],
      };

    case NEWS_DETAIL_FETCH:
      return {
        ...state,
        newsDetailStatus: requestStatus.FETCH,
        send: action.send,
        action: action.type,
      };

    case NEWS_DETAIL_SUCCESS:
      return {
        ...state,
        newsDetailStatus: requestStatus.SUCCESS,
        newsDetail: action.res,
        err: null,
        action: action.type,
      };

    case NEWS_DETAIL_FAILED:
      return {
        ...state,
        newsDetailStatus: requestStatus.FAILED,
        newsDetail: {},
        err: action.err,
        action: action.type,
      };

    case NEWS_DETAIL_RESET:
      return {
        ...state,
        newsDetailStatus: requestStatus.IDLE,
        newsDetail: {},
      };

    case FILE_BASE_64_FETCH:
      return {
        ...state,
        base64Status: requestStatus.FETCH,
        send: action.send,
        action: action.type,
      };

    case FILE_BASE_64_SUCCESS:
      return {
        ...state,
        base64Status: requestStatus.SUCCESS,
        base64: action.res,
        err: null,
        action: action.type,
      };

    case FILE_BASE_64_RESET:
      return {
        ...state,
        base64Status: null,
        base64: null,
        err: null,
        action: action.type,
      };

    case FILE_BASE_64_FAILED:
      return {
        ...state,
        base64Status: requestStatus.FAILED,
        base64: [],
        err: action.err,
        action: action.type,
      };

    default:
      return state;
  }
}
