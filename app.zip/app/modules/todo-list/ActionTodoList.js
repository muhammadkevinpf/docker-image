
import {
  TOTALTODOFETCH,
  TOTALTODOSUCCESS,
  TOTALTODOFAILED,

  TOTALTODORECRUITMENTFETCH,
  TOTALTODORECRUITMENTSUCCESS,
  TOTALTODORECRUITMENTFAILED,

  TOTALTODONTUCASEFETCH,
  TOTALTODONTUCASESUCCESS,
  TOTALTODONTUCASEFAILED,

  TOTALTODOBILLINGPENDINGFETCH,
  TOTALTODOBILLINGPENDINGSUCCESS,
  TOTALTODOBILLINGPENDINGFAILED,

  TOTALTODOPOLICYHOLDERFETCH,
  TOTALTODOPOLICYHOLDERSUCCESS,
  TOTALTODOPOLICYHOLDERFAILED,

  TOTALTODOCLAIMPENDINGFETCH,
  TOTALTODOCLAIMPENDINGSUCCESS,
  TOTALTODOCLAIMPENDINGFAILED,

  TOTALTODOPOLICYDUEDATEFETCH,
  TOTALTODOPOLICYDUEDATESUCCESS,
  TOTALTODOPOLICYDUEDATEFAILED,

  TOTALTODOPOLICYDUEDATEAGEINGFETCH,
  TOTALTODOPOLICYDUEDATEAGEINGSUCCESS,
  TOTALTODOPOLICYDUEDATEAGEINGFAILED,

  TOTALTODOCLIENTBIRTHDAYFETCH,
  TOTALTODOCLIENTBIRTHDAYSUCCESS,
  TOTALTODOCLIENTBIRTHDAYFAILED,

  FINDLISTTODORECRUITMENTFETCH,
  FINDLISTTODORECRUITMENTSUCCESS,
  FINDLISTTODORECRUITMENTFAILED,

  FINDLISTTODONEWBUSINESSFETCH,
  FINDLISTTODONEWBUSINESSSUCCESS,
  FINDLISTTODONEWBUSINESSFAILED,

  FINDLISTTODOFUNDHISTORYFETCH,
  FINDLISTTODOFUNDHISTORYSUCCESS,
  FINDLISTTODOFUNDHISTORYFAILED,

  FINDLISTTODOFOLLOWUPFETCH,
  FINDLISTTODOFOLLOWUPSUCCESS,
  FINDLISTTODOFOLLOWUPFAILED,

  FINDLISTTODOFOLLOWUPPOLICYFETCH,
  FINDLISTTODOFOLLOWUPPOLICYSUCCESS,
  FINDLISTTODOFOLLOWUPPOLICYFAILED,

  FINDLISTTODOCLAIMHISTORYNONDEATHFETCH,
  FINDLISTTODOCLAIMHISTORYNONDEATHSUCCESS,
  FINDLISTTODOCLAIMHISTORYNONDEATHFAILED,

  FINDLISTTODOCLAIMHISTORYPREMIUMFETCH,
  FINDLISTTODOCLAIMHISTORYPREMIUMSUCCESS,
  FINDLISTTODOCLAIMHISTORYPREMIUMFAILED,

  FINDLISTTODOCLAIMHISTORYDEATHFETCH,
  FINDLISTTODOCLAIMHISTORYDEATHSUCCESS,
  FINDLISTTODOCLAIMHISTORYDEATHFAILED,

  FINDLISTTODOPRODUCTDETAILFETCH,
  FINDLISTTODOPRODUCTDETAILSUCCESS,
  FINDLISTTODOPRODUCTDETAILFAILED,

  FINDLISTTODOBILLINGPENDINGFETCH,
  FINDLISTTODOBILLINGPENDINGSUCCESS,
  FINDLISTTODOBILLINGPENDINGFAILED,

  FINDLISTTODOPOLICYHOLDERFETCH,
  FINDLISTTODOPOLICYHOLDERSUCCESS,
  FINDLISTTODOPOLICYHOLDERFAILED,

  FINDLISTTODOPENDINGCLAIMFETCH,
  FINDLISTTODOPENDINGCLAIMSUCCESS,
  FINDLISTTODOPENDINGCLAIMFAILED,

  FINDLISTTODOCLIENTBIRTHDAYRECENTFETCH,
  FINDLISTTODOCLIENTBIRTHDAYRECENTSUCCESS,
  FINDLISTTODOCLIENTBIRTHDAYRECENTFAILED,

  FINDLISTTODOCLIENTBIRTHDAYTODAYFETCH,
  FINDLISTTODOCLIENTBIRTHDAYTODAYSUCCESS,
  FINDLISTTODOCLIENTBIRTHDAYTODAYFAILED,

  FINDLISTTODOCLIENTBIRTHDAYUPCOMINGFETCH,
  FINDLISTTODOCLIENTBIRTHDAYUPCOMINGSUCCESS,
  FINDLISTTODOCLIENTBIRTHDAYUPCOMINGFAILED,
  FINDLASTUPDATECLIENTFETCH,
  FINDLASTUPDATECLIENTSUCCESS,
  FINDLASTUPDATECLIENTFAILED,
  FINDLASTUPDATEPOLICYFETCH,
  FINDLASTUPDATEPOLICYSUCCESS,
  FINDLASTUPDATEPOLICYFAILED,
  CLIENTPROFILEFETCH,
  CLIENTPROFILESUCCESS,
  CLIENTPROFILEFAILED,
  CLIENTPOLICYOWNERFETCH,
  CLIENTPOLICYOWNERSUCCESS,
  CLIENTPOLICYOWNERFAILED,
  CLIENTPOLICYLISTFETCH,
  CLIENTPOLICYLISTSUCCESS,
  CLIENTPOLICYLISTFAILED,
  CLIENTPROPOSALLISTFETCH,
  CLIENTPROPOSALLISTSUCCESS,
  CLIENTPROPOSALLISTFAILED,
  CLIENTSUMATRISKFETCH,
  CLIENTSUMATRISKSUCCESS,
  CLIENTSUMATRISKFAILED,

  // Due Date State before:after
  DUEDATESTATECHANGE,

  // Tracker for Todo
  TRACKERADDSTACK,
  TRACKERGOBACK,
  DELETETRACKER,

  CLEARTODONEWBUSINNESS,
  CLEARTODOCLIENTBIRTHDAYRECENT,
  CLEARTODOCLIENTBIRTHDAYTODAY,
  CLEARTODOCLIENTBIRTHDAYUPCOMING,

  // AfterDueDateTotal
  AFTERDUEDATETOTALFETCH,
  AFTERDUEDATETOTALSUCCESS,
  AFTERDUEDATETOTALFAILED,
  // BeforeDueDateTotal
  BEFOREDUEDATETOTALFETCH,
  BEFOREDUEDATETOTALSUCCESS,
  BEFOREDUEDATETOTALFAILED,
  // AllAfterDueDateTotal
  ALLAFTERDUEDATETOTALFETCH,
  ALLAFTERDUEDATETOTALSUCCESS,
  ALLAFTERDUEDATETOTALFAILED,
  // AfterDueDatePolicyList
  AFTERDUEDATEPOLICYLISTFETCH,
  AFTERDUEDATEPOLICYLISTSUCCESS,
  AFTERDUEDATEPOLICYLISTFAILED,
  DELETEDUEDATEPOLICYLISTREDUCER,
  // BeforeDueDatePolicyList
  BEFOREDUEDATEPOLICYLISTFETCH,
  BEFOREDUEDATEPOLICYLISTSUCCESS,
  BEFOREDUEDATEPOLICYLISTFAILED,
  // afterDueDatePolicyDetail
  AFTERDUEDATEPOLICYDETAILFETCH,
  AFTERDUEDATEPOLICYDETAILSUCCESS,
  AFTERDUEDATEPOLICYDETAILFAILED,
  DELETEDUEDATEPOLICYDETAILREDUCER,

  TOTALPOLICYINCANCELPERIODFETCH,
  TOTALPOLICYINCANCELPERIODSUCCESS,
  TOTALPOLICYINCANCELPERIODFAILED,

  POLICYINCANCELPERIODFETCH,
  POLICYINCANCELPERIODSUCCESS,
  POLICYINCANCELPERIODFAILED,

  // Rincian Polis Start
  LISTCLIENTBYAGENTNUMBERFETCH,
  LISTCLIENTBYAGENTNUMBERSUCCESS,
  LISTCLIENTBYAGENTNUMBERFAILED,

  PROFILECLIENTBYAGENTNUMBERFETCH,
  PROFILECLIENTBYAGENTNUMBERSUCCESS,
  PROFILECLIENTBYAGENTNUMBERFAILED,

  // function getPolicyMovementHistory
  GETPOLICYMOVEMENTHISTORYFETCH,
  GETPOLICYMOVEMENTHISTORYSUCCESS,
  GETPOLICYMOVEMENTHISTORYFAILED,

  RESETPOLICYANDPROPOSALDETAILREDUCER,
  RESETPROPOSALPOLICYDATAREDUCER,
  FINDFILTERFOLLOWUPSTATUSFETCH,
  FINDFILTERFOLLOWUPSTATUSFAILED,
  FINDFILTERFOLLOWUPSTATUSSUCCESS,
  FINDFILTERFOLLOWUPSTATUSTODOFETCH,
  FINDFILTERFOLLOWUPSTATUSTODOSUCCESS,
  FINDFILTERFOLLOWUPSTATUSTODOFAILED,
} from './ConfigTodoList';

export const todoAction = (action, value) => ({ type: action, payload: value });

// -- Action Find Total List ToDo -- //
export const totalToDoFetch = value => ({ type: TOTALTODOFETCH, send: value });
export const totalToDoSuccess = value => ({ type: TOTALTODOSUCCESS, res: value });
export const totalToDoFailed = value => ({ type: TOTALTODOFAILED, err: value });

export const totalToDoRecruitmentFetch = value => ({ type: TOTALTODORECRUITMENTFETCH, send: value });
export const totalToDoRecruitmentSuccess = value => ({ type: TOTALTODORECRUITMENTSUCCESS, res: value });
export const totalToDoRecruitmentFailed = value => ({ type: TOTALTODORECRUITMENTFAILED, err: value });

export const totalToDoNTUCaseFetch = value => ({ type: TOTALTODONTUCASEFETCH, send: value });
export const totalToDoNTUCaseSuccess = value => ({ type: TOTALTODONTUCASESUCCESS, res: value });
export const totalToDoNTUCaseFailed = value => ({ type: TOTALTODONTUCASEFAILED, err: value });

export const totalToDoBillingPendingFetch = value => ({ type: TOTALTODOBILLINGPENDINGFETCH, send: value });
export const totalToDoBillingPendingSuccess = value => ({ type: TOTALTODOBILLINGPENDINGSUCCESS, res: value });
export const totalToDoBillingPendingFailed = value => ({ type: TOTALTODOBILLINGPENDINGFAILED, err: value });

export const totalToDoPolicyHolderFetch = value => ({ type: TOTALTODOPOLICYHOLDERFETCH, send: value });
export const totalToDoPolicyHolderSuccess = value => ({ type: TOTALTODOPOLICYHOLDERSUCCESS, res: value });
export const totalToDoPolicyHolderFailed = value => ({ type: TOTALTODOPOLICYHOLDERFAILED, err: value });

export const totalToDoClaimPendingFetch = value => ({ type: TOTALTODOCLAIMPENDINGFETCH, send: value });
export const totalToDoClaimPendingSuccess = value => ({ type: TOTALTODOCLAIMPENDINGSUCCESS, res: value });
export const totalToDoClaimPendingFailed = value => ({ type: TOTALTODOCLAIMPENDINGFAILED, err: value });

export const totalToDoPolicyDueDateFetch = value => ({ type: TOTALTODOPOLICYDUEDATEFETCH, send: value });
export const totalToDoPolicyDueDateSuccess = value => ({ type: TOTALTODOPOLICYDUEDATESUCCESS, res: value });
export const totalToDoPolicyDueDateFailed = value => ({ type: TOTALTODOPOLICYDUEDATEFAILED, err: value });

export const totalToDoPolicyDueDateAgeingFetch = value => ({ type: TOTALTODOPOLICYDUEDATEAGEINGFETCH, send: value });
export const totalToDoPolicyDueDateAgeingSuccess = value => ({ type: TOTALTODOPOLICYDUEDATEAGEINGSUCCESS, res: value });
export const totalToDoPolicyDueDateAgeingFailed = value => ({ type: TOTALTODOPOLICYDUEDATEAGEINGFAILED, err: value });

export const totalToDoClientBirthDayFetch = value => ({ type: TOTALTODOCLIENTBIRTHDAYFETCH, send: value });
export const totalToDoClientBirthDaySuccess = value => ({ type: TOTALTODOCLIENTBIRTHDAYSUCCESS, res: value });
export const totalToDoClientBirthDayFailed = value => ({ type: TOTALTODOCLIENTBIRTHDAYFAILED, err: value });

// -- Action Detail List ToDo -- //

// Action List Recruitment //
export const findListToDoRecruitmentFetch = value => ({ type: FINDLISTTODORECRUITMENTFETCH, send: value });
export const findListToDoRecruitmentSuccess = value => ({ type: FINDLISTTODORECRUITMENTSUCCESS, res: value });
export const findListToDoRecruitmentFailed = value => ({ type: FINDLISTTODORECRUITMENTFAILED, err: value });

// Action List News Business //
export const findListToDoNewBusinessFetch = value => ({ type: FINDLISTTODONEWBUSINESSFETCH, send: value });
export const findListToDoNewBusinessSuccess = value => ({ type: FINDLISTTODONEWBUSINESSSUCCESS, res: value });
export const findListToDoNewBusinessFailed = value => ({ type: FINDLISTTODONEWBUSINESSFAILED, err: value });
export const clearListNewBusiness = () => ({ type: CLEARTODONEWBUSINNESS });

// Action List Fund History //
export const findListToDoFundHistoryFetch = value => ({ type: FINDLISTTODOFUNDHISTORYFETCH, send: value });
export const findListToDoFundHistorySuccess = value => ({ type: FINDLISTTODOFUNDHISTORYSUCCESS, res: value });
export const findListToDoFundHistoryFailed = value => ({ type: FINDLISTTODOFUNDHISTORYFAILED, err: value });

// Action List Follow Up //
export const findListToDoFollowUpFetch = value => ({ type: FINDLISTTODOFOLLOWUPFETCH, send: value });
export const findListToDoFollowUpSuccess = value => ({ type: FINDLISTTODOFOLLOWUPSUCCESS, res: value });
export const findListToDoFollowUpFailed = value => ({ type: FINDLISTTODOFOLLOWUPFAILED, err: value });

// Action Filter Follow Up //
export const findFilterFollowUpStatusTodoFetch = value => ({ type: FINDFILTERFOLLOWUPSTATUSTODOFETCH, send: value });
export const findFilterFollowUpStatusTodoSuccess = value => ({ type: FINDFILTERFOLLOWUPSTATUSTODOSUCCESS, res: value });
export const findFilterFollowUpStatusTodoFailed = value => ({ type: FINDFILTERFOLLOWUPSTATUSTODOFAILED, err: value });

// Action List Follow Up Policy //
export const findListToDoFollowUpPolicyFetch = value => ({ type: FINDLISTTODOFOLLOWUPPOLICYFETCH, send: value });
export const findListToDoFollowUpPolicySuccess = value => ({ type: FINDLISTTODOFOLLOWUPPOLICYSUCCESS, res: value });
export const findListToDoFollowUpPolicyFailed = value => ({ type: FINDLISTTODOFOLLOWUPPOLICYFAILED, err: value });

// Action Filter Follow Up Policy //
export const findFilterFollowUpStatusFetch = value => ({ type: FINDFILTERFOLLOWUPSTATUSFETCH, send: value });
export const findFilterFollowUpStatusSuccess = value => ({ type: FINDFILTERFOLLOWUPSTATUSSUCCESS, res: value });
export const findFilterFollowUpStatusFailed = value => ({ type: FINDFILTERFOLLOWUPSTATUSFAILED, err: value });

// Action List Claim History Non Death //
export const findListToDoClaimHistoryNonDeathFetch = value => ({ type: FINDLISTTODOCLAIMHISTORYNONDEATHFETCH, send: value });
export const findListToDoClaimHistoryNonDeathSuccess = value => ({ type: FINDLISTTODOCLAIMHISTORYNONDEATHSUCCESS, res: value });
export const findListToDoClaimHistoryNonDeathFailed = value => ({ type: FINDLISTTODOCLAIMHISTORYNONDEATHFAILED, err: value });

// Action List Claim History Premium //
export const findListToDoClaimHistoryPremiumFetch = value => ({ type: FINDLISTTODOCLAIMHISTORYPREMIUMFETCH, send: value });
export const findListToDoClaimHistoryPremiumSuccess = value => ({ type: FINDLISTTODOCLAIMHISTORYPREMIUMSUCCESS, res: value });
export const findListToDoClaimHistoryPremiumFailed = value => ({ type: FINDLISTTODOCLAIMHISTORYPREMIUMFAILED, err: value });

// Action List Claim History Death //
export const findListToDoClaimHistoryDeathFetch = value => ({ type: FINDLISTTODOCLAIMHISTORYDEATHFETCH, send: value });
export const findListToDoClaimHistoryDeathSuccess = value => ({ type: FINDLISTTODOCLAIMHISTORYDEATHSUCCESS, res: value });
export const findListToDoClaimHistoryDeathFailed = value => ({ type: FINDLISTTODOCLAIMHISTORYDEATHFAILED, err: value });

// Action List Product Detail //
export const findListToDoProductDetailFetch = value => ({ type: FINDLISTTODOPRODUCTDETAILFETCH, send: value });
export const findListToDoProductDetailSuccess = value => ({ type: FINDLISTTODOPRODUCTDETAILSUCCESS, res: value });
export const findListToDoProductDetailFailed = value => ({ type: FINDLISTTODOPRODUCTDETAILFAILED, err: value });

// Action list Billing Pending //
export const findListToDoBillingPendingFetch = value => ({ type: FINDLISTTODOBILLINGPENDINGFETCH, send: value });
export const findListToDoBillingPendingSuccess = value => ({ type: FINDLISTTODOBILLINGPENDINGSUCCESS, res: value });
export const findListToDoBillingPendingFailed = value => ({ type: FINDLISTTODOBILLINGPENDINGFAILED, err: value });

// Action List Policy Holder //
export const findListToDoPolicyHolderFetch = value => ({ type: FINDLISTTODOPOLICYHOLDERFETCH, send: value });
export const findListToDoPolicyHolderSuccess = value => ({ type: FINDLISTTODOPOLICYHOLDERSUCCESS, res: value });
export const findListToDoPolicyHolderFailed = value => ({ type: FINDLISTTODOPOLICYHOLDERFAILED, err: value });

// Action List Pending Claim //
export const findListToDoPendingClaimFetch = value => ({ type: FINDLISTTODOPENDINGCLAIMFETCH, send: value });
export const findListToDoPendingClaimSuccess = value => ({ type: FINDLISTTODOPENDINGCLAIMSUCCESS, res: value });
export const findListToDoPendingClaimFailed = value => ({ type: FINDLISTTODOPENDINGCLAIMFAILED, err: value });

// Action List Client BirthDay - Recent //
export const findListToDoClientBirthDayRecentFetch = value => ({ type: FINDLISTTODOCLIENTBIRTHDAYRECENTFETCH, send: value });
export const findListToDoClientBirthDayRecentSuccess = value => ({ type: FINDLISTTODOCLIENTBIRTHDAYRECENTSUCCESS, res: value });
export const findListToDoClientBirthDayRecentFailed = value => ({ type: FINDLISTTODOCLIENTBIRTHDAYRECENTFAILED, err: value });
export const clearListBirthdayRecent = () => ({ type: CLEARTODOCLIENTBIRTHDAYRECENT });

// Action List Client BirthDay - Today //
export const findListToDoClientBirthDayTodayFetch = value => ({ type: FINDLISTTODOCLIENTBIRTHDAYTODAYFETCH, send: value });
export const findListToDoClientBirthDayTodaySuccess = value => ({ type: FINDLISTTODOCLIENTBIRTHDAYTODAYSUCCESS, res: value });
export const findListToDoClientBirthDayTodayFailed = value => ({ type: FINDLISTTODOCLIENTBIRTHDAYTODAYFAILED, err: value });
export const clearListBirthdayToday = () => ({ type: CLEARTODOCLIENTBIRTHDAYTODAY });

// Action List Client BirthDay - UpComing //
export const findListToDoClientBirthDayUpComingFetch = value => ({ type: FINDLISTTODOCLIENTBIRTHDAYUPCOMINGFETCH, send: value });
export const findListToDoClientBirthDayUpComingSuccess = value => ({ type: FINDLISTTODOCLIENTBIRTHDAYUPCOMINGSUCCESS, res: value });
export const findListToDoClientBirthDayUpComingFailed = value => ({ type: FINDLISTTODOCLIENTBIRTHDAYUPCOMINGFAILED, err: value });
export const clearListBirthdayUpcoming = () => ({ type: CLEARTODOCLIENTBIRTHDAYUPCOMING });

// Action Get Latest Updated Date - Client
export const findLastUpdateClientFetch = value => ({ type: FINDLASTUPDATECLIENTFETCH, send: value });
export const findLastUpdateClientSuccess = value => ({ type: FINDLASTUPDATECLIENTSUCCESS, res: value });
export const findLastUpdateClientFailed = value => ({ type: FINDLASTUPDATECLIENTFAILED, err: value });

// Action Get Latest Updated Date - Client
export const findLastUpdatePolicyFetch = value => ({ type: FINDLASTUPDATEPOLICYFETCH, send: value });
export const findLastUpdatePolicySuccess = value => ({ type: FINDLASTUPDATEPOLICYSUCCESS, res: value });
export const findLastUpdatePolicyFailed = value => ({ type: FINDLASTUPDATEPOLICYFAILED, err: value });

// Action Get Client Profile Information
export const clientProfileFetch = value => ({ type: CLIENTPROFILEFETCH, send: value });
export const clientProfileSuccess = value => ({ type: CLIENTPROFILESUCCESS, res: value });
export const clientProfileFailed = value => ({ type: CLIENTPROFILEFAILED, err: value });

// Action Get Policy Owner List
export const clientPolicyOwnerFetch = value => ({ type: CLIENTPOLICYOWNERFETCH, send: value });
export const clientPolicyOwnerSuccess = value => ({ type: CLIENTPOLICYOWNERSUCCESS, res: value });
export const clientPolicyOwnerFailed = value => ({ type: CLIENTPOLICYOWNERFAILED, err: value });

// Action Get Policy List
export const clientPolicyListFetch = value => ({ type: CLIENTPOLICYLISTFETCH, send: value });
export const clientPolicyListSuccess = value => ({ type: CLIENTPOLICYLISTSUCCESS, res: value });
export const clientPolicyListFailed = value => ({ type: CLIENTPOLICYLISTFAILED, err: value });

// Action Get Proposal List
export const clientProposalListFetch = value => ({ type: CLIENTPROPOSALLISTFETCH, send: value });
export const clientProposalListSuccess = value => ({ type: CLIENTPROPOSALLISTSUCCESS, res: value });
export const clientProposalListFailed = value => ({ type: CLIENTPROPOSALLISTFAILED, err: value });

// Action Get Sum At Risk
export const clientSumAtRiskFetch = value => ({ type: CLIENTSUMATRISKFETCH, send: value });
export const clientSumAtRiskSuccess = value => ({ type: CLIENTSUMATRISKSUCCESS, res: value });
export const clientSumAtRiskFailed = value => ({ type: CLIENTSUMATRISKFAILED, err: value });

// Due Date State before:after
export const dueDateState = value => ({ type: DUEDATESTATECHANGE, props: value });

// Tracker for Todo
export const trackerAddStack = value => ({ type: TRACKERADDSTACK, props: value });
export const trackerGoBack = value => ({ type: TRACKERGOBACK, props: value });
export const deleteTracker = () => ({ type: DELETETRACKER });

export const afterDueDateTotalFetch = value => ({ type: AFTERDUEDATETOTALFETCH, send: value });
export const afterDueDateTotalSuccess = value => ({ type: AFTERDUEDATETOTALSUCCESS, res: value });
export const afterDueDateTotalFailed = value => ({ type: AFTERDUEDATETOTALFAILED, err: value });

export const beforeDueDateTotalFetch = (value, end) => ({ type: BEFOREDUEDATETOTALFETCH, send: value, end });
export const beforeDueDateTotalSuccess = (value, end) => ({ type: BEFOREDUEDATETOTALSUCCESS, res: value, end });
export const beforeDueDateTotalFailed = value => ({ type: BEFOREDUEDATETOTALFAILED, err: value });

export const allAfterDueDateTotalFetch = value => ({ type: ALLAFTERDUEDATETOTALFETCH, send: value });
export const allAfterDueDateTotalSuccess = value => ({ type: ALLAFTERDUEDATETOTALSUCCESS, res: value });
export const allAfterDueDateTotalFailed = value => ({ type: ALLAFTERDUEDATETOTALFAILED, err: value });

export const afterDueDatePolicyListFetch = value => ({ type: AFTERDUEDATEPOLICYLISTFETCH, send: value });
export const afterDueDatePolicyListSuccess = value => ({ type: AFTERDUEDATEPOLICYLISTSUCCESS, res: value });
export const afterDueDatePolicyListFailed = value => ({ type: AFTERDUEDATEPOLICYLISTFAILED, err: value });
export const deleteAfterDueDatePolicyListReducer = () => ({ type: DELETEDUEDATEPOLICYLISTREDUCER, res: [] });

export const beforeDueDatePolicyListFetch = value => ({ type: BEFOREDUEDATEPOLICYLISTFETCH, send: value });
export const beforeDueDatePolicyListSuccess = value => ({ type: BEFOREDUEDATEPOLICYLISTSUCCESS, res: value });
export const beforeDueDatePolicyListFailed = value => ({ type: BEFOREDUEDATEPOLICYLISTFAILED, err: value });

export const afterDueDatePolicyDetailFetch = value => ({ type: AFTERDUEDATEPOLICYDETAILFETCH, send: value });
export const afterDueDatePolicyDetailSuccess = value => ({ type: AFTERDUEDATEPOLICYDETAILSUCCESS, res: value });
export const afterDueDatePolicyDetailFailed = value => ({ type: AFTERDUEDATEPOLICYDETAILFAILED, err: value });
export const deleteAfterDueDatePolicyDetailReducer = () => ({ type: DELETEDUEDATEPOLICYDETAILREDUCER, res: null });

export const totalPolicyInCancelPeriodFetch = value => ({ type: TOTALPOLICYINCANCELPERIODFETCH, send: value });
export const totalPolicyInCancelPeriodSuccess = value => ({ type: TOTALPOLICYINCANCELPERIODSUCCESS, res: value });
export const totalPolicyInCancelPeriodFailed = value => ({ type: TOTALPOLICYINCANCELPERIODFAILED, err: value });

export const policyInCancelPeriodFetch = value => ({ type: POLICYINCANCELPERIODFETCH, send: value });
export const policyInCancelPeriodSuccess = value => ({ type: POLICYINCANCELPERIODSUCCESS, res: value });
export const policyInCancelPeriodFailed = value => ({ type: POLICYINCANCELPERIODFAILED, err: value });

// Rincian Polis Start
export const listClientByAgentNumberFetch = value => ({ type: LISTCLIENTBYAGENTNUMBERFETCH, send: value });
export const listClientByAgentNumberSuccess = value => ({ type: LISTCLIENTBYAGENTNUMBERSUCCESS, res: value });
export const listClientByAgentNumberFailed = value => ({ type: LISTCLIENTBYAGENTNUMBERFAILED, err: value });

export const profileClientByAgentNumberFetch = value => ({ type: PROFILECLIENTBYAGENTNUMBERFETCH, send: value });
export const profileClientByAgentNumberSuccess = value => ({ type: PROFILECLIENTBYAGENTNUMBERSUCCESS, res: value });
export const profileClientByAgentNumberFailed = value => ({ type: PROFILECLIENTBYAGENTNUMBERFAILED, err: value });

// getPolicyMovementHistory
export const getPolicyMovementHistoryFetch = value => ({ type: GETPOLICYMOVEMENTHISTORYFETCH, send: value });
export const getPolicyMovementHistorySuccess = value => ({ type: GETPOLICYMOVEMENTHISTORYSUCCESS, res: value });
export const getPolicyMovementHistoryFailed = value => ({ type: GETPOLICYMOVEMENTHISTORYFAILED, err: value });

export const resetPolicyAndProposalDetailReducer = () => ({ type: RESETPOLICYANDPROPOSALDETAILREDUCER });
export const resetProposalPolicyDataReducer = () => ({ type: RESETPROPOSALPOLICYDATAREDUCER });
