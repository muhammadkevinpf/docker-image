/* eslint-disable react-native/no-inline-styles */
/* eslint-disable react/no-array-index-key */
/* eslint-disable no-alert */
/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { PureComponent } from 'react';
import {
  Button,
  Card, CardItem, Col, Icon, Row, View,
} from 'native-base';
import moment from 'moment';
import { connect } from 'react-redux';
import { Platform } from 'react-native';
import { ConfigProduct } from '../config';
import _ from '../../../lang';
import Style from '../../../styles';
import {
  MorePopupMenu, StyledText, Skeleton, rowLayout,
} from '../../../components';
import { ConfigProductSPAJ } from '../../spaj/configs';
import Caches from '../../../utilities/Caches';
import Colors from '../../../styles/Colors';
import { isTablet } from '../../../utilities/Functions';

class CardSQSNSpaj extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      openMorePopupMenu: false,
      onEndReachedCalledDuringMomentum: true,
    };
    this.onPressMorePopupMenu = this.onPressMorePopupMenu.bind(this);
    this.onDismissMorePopupMenu = this.onDismissMorePopupMenu.bind(this);
  }

  onPressMorePopupMenu = draftId => this.setState({ [`openMorePopupMenu${draftId}`]: true });

  onDismissMorePopupMenu = draftId => this.setState({ [`openMorePopupMenu${draftId}`]: false });

  CardItems = (label = '', value = '', wLabel = '50%', wValue = '70%', color = Colors.almostBlack) => (
    <Skeleton isLoading={this.props.fetchData} style={Style.Main.mb10} layout={[rowLayout({ w: wLabel, h: 8 }), rowLayout({ w: wValue, h: 10 })]}>
      <StyledText font={10} color={Colors.gray83}>{_(label)}</StyledText>
      <StyledText color={color}>{value}</StyledText>
    </Skeleton>
  );

  renderCard = () => {
    const item = this.props.proposalData;
    if (item.draftId === 'header') {
      return this.props.header();
    } if (item.draftId === 'none') {
      return <View style={[Style.displayNone]} />;
    }

    const coState = item.counterOfferState ? item.counterOfferState : '';
    const { agentChannel } = this.props.resAuth.userProfile;
    let statusText = ConfigProduct.masterStatus[item.originStatus];
    let status = item.originStatus;
    if (item.isNF2F && statusText === ConfigProduct.masterStatus.spajPendingUW) {
      statusText = ConfigProduct.masterStatus.spajPendingSubmitCekatan;
      status = 'spajPendingSubmitCekatan';
    }
    if (JSON.parse(!item.isSync)) statusText += ' (Not Sync)';
    if (coState) statusText += ` - ${coState}`;
    const channel = Caches.get('channel').CHANNEL[agentChannel];
    const ProductCategory = channel ? channel.PRODUCT_CATEGORY : [];
    const productUL = ProductCategory.find(x => x.code === 'UL');
    const productTRD = ProductCategory.find(x => x.code === 'TRD');
    const allProduct = [...(productTRD ? productTRD.PRODUCT : []), ...(productUL ? productUL.PRODUCT : [])];
    const product = allProduct.find(x => x.code === item.productCd);
    const menus = [
      {
        text: 'Lanjutkan',
        onPress: () => this.props.handleContinueData(item),
        showFor: ['ilustration', 'spajPendingSubmit', 'spajPendingUW', 'counterOfferDraft'],
        // 'spajPendingUW' only for UAT or dev
      },
      {
        text: 'Lihat Ilustrasi',
        onPress: () => this.props.handleViewIllustration(item),
        showFor: [
          'ilustration', 'spajPendingSubmit', ...ConfigProductSPAJ.viewModeSpaj,
        ],
      },
      {
        text: 'Salin Ilustrasi',
        onPress: () => this.props.handleCopy(item),
        showFor: this.props.isCounterOffer ? [] : [
          'ilustration', 'spajPendingSubmit', ...ConfigProductSPAJ.viewModeSpaj,
        ],
      },
      {
        text: 'Hapus',
        onPress: () => this.props.handleDeleteData(item),
        showFor: ['ilustration', 'spajPendingSubmit', 'counterOfferSubmitted', 'counterOfferDraft'],
      },
      {
        text: 'Lihat',
        onPress: () => this.props.handleViewSpaj(item),
        showFor: ConfigProductSPAJ.viewModeSpaj,
      },
      {
        text: 'Dokumen Susulan',
        onPress: () => this.props.handleOpenDoc(item),
        showFor: this.props.isCounterOffer ? ['spajPendingUW', 'spajPendingUWCekatan', 'spajPendingSubmitCekatan'] : [],
      },
      {
        text: 'Submit Ulang',
        onPress: () => this.props.handleSubmit(item.quotId.trim()),
        showFor: ['submitted'],
      },
      {
        text: 'Kirim Ulang SMS',
        onPress: () => this.props.handleResendSMS(item.quotId.trim()),
        showFor: this.props.isCounterOffer ? [] : ['spajPendingSubmitCekatan'],
      },
    ].filter((x) => {
      if (item.isSync) return x.showFor.map(y => y.toLowerCase()).includes(status.toLowerCase());
      return null;
    });

    const createdDate = item.originCreatedDate ? moment(item.originCreatedDate.replace('Z', '')).format('DD MMMM YYYY HH:mm:ss').toString() : '';
    const submitedDate = item.originSubmitedDate ? moment(item.originSubmitedDate.replace('Z', '')).format('DD MMMM YYYY HH:mm:ss').toString() : '-';

    const itemValues = [
      {
        label: 'Nama Proposal', value: item.propNo || item.quotId || '', wLabel: '25%', wValue: '40%',
      },
      {
        label: 'Dibuat', value: createdDate, wLabel: '15%', wValue: '30%',
      },
      {
        label: 'Disubmit', value: submitedDate, wLabel: '15%', wValue: '30%',
      },
      {
        label: 'Produk', value: product ? product.longName : '', wLabel: '15%', wValue: '35%',
      },
      {
        label: 'Tertanggung Utama', value: item.tuName || '', wLabel: '30%', wValue: '50%',
      },
      // {
      //   label: 'Alasan Rekomendasi', value: item.reason || '', wLabel: '30%', wValue: '55%',
      // },
      {
        label: 'Status', value: statusText || '', wLabel: '15%', wValue: '50%', color: Colors.red,
      },

    ];
    const isUsingTablet = isTablet();
    return (
      <Card key={item.draftId} style={[Style.Main.container]}>
        <CardItem header bordered style={Style.Main.pl5}>
          <Skeleton
            isLoading={this.props.fetchData}
            layout={[rowLayout({ w: '50%', h: 11 })]}
            style={[Style.Main.ml12, Style.Main.rowDirectionSpaceBetween]}
          >
            <Row>
              <Col size={isUsingTablet ? 14 : 8} style={{ justifyContent: 'center', paddingRight: 10 }}>
                <StyledText bold color={Colors.red}>{`${item.phName}`}</StyledText>
              </Col>
              {!this.props.isCounterOffer && (
              <Col size={isUsingTablet ? 14 : 8} style={{ justifyContent: 'center' }}>
                <Button
                  rounded
                  danger
                  iconLeft
                  style={{
                    height: 25, width: 100, alignSelf: 'flex-end', backgroundColor: Colors.red, justifyContent: 'center',
                  }}
                  onPress={() => this.props.handleSync(item)}
                >
                  <Icon
                    name="sync"
                    type="Ionicons"
                    style={[Style.Main.font12, { marginRight: -10, paddingTop: Platform.OS === 'android' ? 2 : 1 }]}
                  />
                  <StyledText color="white">Sinkronisasi</StyledText>
                </Button>
              </Col>

              )}
              <Col size={2} style={{ justifyContent: 'center' }}>
                <MorePopupMenu
                  menus={menus}
                  size={17}
                  touchArea={30}
                  onPress={() => this.onPressMorePopupMenu(item.draftId)}
                  onDismiss={() => this.onDismissMorePopupMenu(item.draftId)}
                  opened={this.state[`openMorePopupMenu${item.draftId}`] || false}
                  disabled={!item.isSync}
                />
              </Col>
            </Row>


          </Skeleton>
        </CardItem>

        <View style={[Style.Main.mt5, Style.Main.mb5, Style.Main.ml3, Style.Main.padding15]}>
          {itemValues.map((val, index) => (
            <Skeleton
              key={index}
              isLoading={this.props.fetchData}
              style={Style.Main.mb10}
              layout={[rowLayout({ w: val.wLabel, h: 8 }), rowLayout({ w: val.wValue, h: 10 })]}
            >
              <StyledText font={10} color={Colors.gray83}>{_(val.label)}</StyledText>
              <StyledText color={val.color ? val.color : Colors.almostBlack}>{val.value}</StyledText>
            </Skeleton>
          ))}

        </View>
      </Card>
    );
  };

  render() {
    return this.renderCard();
  }
}

const mapStateToProps = state => ({
  resAuth: state.auth.res,
});

export default connect(mapStateToProps, null)(CardSQSNSpaj);
