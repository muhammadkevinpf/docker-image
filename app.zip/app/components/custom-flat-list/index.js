import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FlatList, TouchableOpacity } from 'react-native';
import { View, Icon } from 'native-base';
import { isTablet, isArrayEmpty, requestStatus } from '../../utilities';
import { RenderFooter, ListEmpty } from '../list-information';
import { SearchSortFilter } from '../seacrh-sort-filter';
import { ImageHeader } from '../common-components';
import Style from '../../styles';

export const listMode = {
  LIST: 'LIST',
  GRID: 'GRID',
};

export const getListModeIcon = ({ viewMode = listMode.LIST }) => {
  if (viewMode === listMode.GRID) return 'view-list';
  return 'view-grid';
};

export const ListModeIcon = ({ viewMode = listMode.LIST, onModeChanged = () => { } }) => (
  <TouchableOpacity
    style={[Style.Main.margin3, Style.Main.mr0, Style.Main.dialogBtnCnt, Style.Main.borderRadius5, Style.Main.boxShadow, Style.Main.px10,
      Style.Main.backgroundWhite, Style.Main.height40]}
    onPress={onModeChanged}
  ><Icon name={getListModeIcon(viewMode)} type="MaterialCommunityIcons" style={[Style.Main.font16, Style.Main.alignCenter]} />
  </TouchableOpacity>
);

class CustomFlatList extends React.Component {
  pageSize = Number(this.props.pageSize || 30);

  renderTopBar = index => (
    <View style={[Style.Main.fullWidth]}>
      {this.props.imgHeader && <ImageHeader style={this.props.imgHeaderStyle} source={this.props.imgHeader} />}
      {this.props.hideTopBar ? null :
      <View key={index} style={[Style.Main.fullWidth, Style.Main.pr12, Style.Main.pl12, Style.Main.mt12]}>
        {
            this.props.topBar !== undefined ? this.props.topBar :
            <SearchSortFilter {...this.props} value={this.props.searchValue}>
              {this.props.topBarContent}
            </SearchSortFilter>
          }
      </View>
      }
    </View>
  );

  listEmpty = () => {
    if (this.props.forceEmptyAbsolute) {
      return (
        <View style={Style.Main.absoluteFull}>
          <ListEmpty
            showImage={this.props.showListEmptyImage}
            isOnline={this.props.ignoreOffline || this.props.isOnline || !isArrayEmpty(this.props.listData)}
            showIndicator={this.props.showLoadingEmpty ||
              (this.props.statusList === requestStatus.FETCH && !this.props.refreshing && isArrayEmpty(this.props.listData))}
          />
        </View>
      );
    }
    return (
      <ListEmpty
        image={this.props.emptyImage}
        imageStyle={this.props.emptyImageStyle}
        showImage={this.props.showListEmptyImage}
        isOnline={this.props.ignoreOffline || this.props.isOnline || !isArrayEmpty(this.props.listData)}
        showIndicator={this.props.showLoadingEmpty ||
          (this.props.statusList === requestStatus.FETCH && !this.props.refreshing && isArrayEmpty(this.props.listData))}
      />
    );
  }

  renderFooter = () => (
    <RenderFooter
      isOnline={this.props.ignoreOffline || this.props.isOnline}
      isLastData={this.props.isLastData ||
        (this.props.statusList === requestStatus.FAILED && this.props.listData && this.props.listData.length >= this.pageSize) ||
        (this.props.statusList === requestStatus.SUCCESS && !isArrayEmpty(this.props.listData) && this.props.listData.length < this.pageSize)}
      showIndicator={this.props.showLoadingFooter ||
        (this.props.statusList === requestStatus.FETCH && !this.props.refreshing && !isArrayEmpty(this.props.listData))}
    />
  )

  setItemStyle = (i) => {
    if (this.props.numColumns > 2) {
      const modulo = i % this.props.numColumns;
      if (modulo === 1) return null; // Align item to the left if it is the first item of the row
      if (modulo === 0) return Style.Main.alignEnd; // Align item to the right if it is the last item of the row
      return Style.Main.center; // Align the rest of items to the center
    }
    return null;
  }

  render() {
    const { listData, numColumns } = this.props;
    const isNoData = isArrayEmpty(listData);
    const dummyHeader = [{ id: 'header' }];
    const isEndReacedCalled = this.props.callEndReached || (!isArrayEmpty(listData) && listData.length >= this.props.pageSize);
    if (numColumns > 1) dummyHeader.push(...Array(numColumns - 1).fill({ id: 'null' }));
    const data = !isNoData ? [...dummyHeader, ...listData] : [];
    if (isTablet() && !isNoData && listData.length % 2 !== 0) data.push({ id: 'space' });
    return (
      <View style={[Style.Main.container]}>
        {isNoData && this.renderTopBar()}
        <FlatList
          {...this.props}
          key={numColumns}
          numColumns={numColumns}
          overScrollMode="always"
          contentContainerStyle={[Style.Main.pb15, isNoData && Style.Main.container,
            this.props.hideTopBar && Style.Main.mt12, this.props.contentContainerStyle]}
          data={data}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item, index }) => {
            if (item.id === 'header') return this.renderTopBar(index);
            if (item.id === 'null' || !this.props.itemComponent) return null;
            if (item.id === 'space') return <View style={[Style.Main.ml12, Style.Main.mr12, Style.Main.container]} />;
            return (
              <View style={[Style.Main.ml12, Style.Main.mr12, Style.Main.container,
                this.setItemStyle(index + 1), this.props.itemComponentStyle]}
              >{this.props.itemComponent({ item, index })}
              </View>
            );
          }}
          initialNumToRender={this.pageSize + dummyHeader.length}
          onEndReached={isEndReacedCalled ? this.props.handleLoadData : () => { }}
          onEndReachedThreshold={0.5}
          ListEmptyComponent={this.props.hideListEmpty ? <View /> : this.listEmpty}
          ListFooterComponent={this.renderFooter}
        />
      </View>
    );
  }
}

const mapStateToProps = state => ({
  isOnline: state.connectionStatus.isOnline,
});

CustomFlatList.propTypes = {
  numColumns: PropTypes.number,
};

CustomFlatList.defaultProps = {
  numColumns: isTablet() ? 2 : 1,
};

export default connect(mapStateToProps, null)(CustomFlatList);
