/* eslint-disable no-console */
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import {
  Container, View, Button, Text, Footer, FooterTab, // Content
} from 'native-base';
import { HeaderWithTodo, SearchSortFilter } from '../../../components';
import Style from '../../../styles';

export default class TodoComponent extends PureComponent {
  render() {
    return (
      <Container>
        <HeaderWithTodo {...this.props} onBackClicked={this.props.onBackClicked} headerTitle="DAFTAR TUGAS" subHeader={this.props.subHeader} />
        <View style={[Style.Main.containerWithMargin12, this.props.style]}>
          { this.props.showTopBar && <SearchSortFilter {...this.props} /> }
          { !this.props.showTopBar && this.props.children !== undefined && this.props.children }
        </View>
        {
          this.props.showFooter && (
            <Footer style={[Style.Main.footerHeight]}>
              <FooterTab>
                <Button
                  style={[Style.Main.btnLanjutkan, this.props.footerButtonStyle]}
                  onPress={this.props.onPressFooter}
                >
                  <Text
                    style={[Style.Main.font16, Style.Main.textWhite, Style.Main.fontAlbert]}
                  >{this.props.footerButtonLabel}
                  </Text>
                </Button>
              </FooterTab>
            </Footer>
          )
        }
      </Container>
    );
  }
}

TodoComponent.propTypes = {
  showTopBar: PropTypes.bool,
  searchPlaceholder: PropTypes.string,
  subHeader: PropTypes.string,
  showSearchBar: PropTypes.bool,
  showSortAndFilter: PropTypes.bool,
  filterBy: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  sortBy: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  onFilterSelected: PropTypes.func,
  onSortSelected: PropTypes.func,
  sortItems: PropTypes.arrayOf(PropTypes.object),
  filterItems: PropTypes.arrayOf(PropTypes.object),
  showSort: PropTypes.bool,
  showFilter: PropTypes.bool,
  showFooter: PropTypes.bool,
  footerButtonLabel: PropTypes.string,
  onPressFooter: PropTypes.func,
  onSearch: PropTypes.func,
  onSearchBlur: PropTypes.func,
};

TodoComponent.defaultProps = {
  showTopBar: true,
  searchPlaceholder: 'Search',
  subHeader: undefined,
  showSearchBar: true,
  showSortAndFilter: true,
  filterBy: '',
  sortBy: '',
  onFilterSelected: () => { },
  onSortSelected: () => { },
  sortItems: null,
  filterItems: null,
  showSort: true,
  showFilter: true,
  showFooter: false,
  footerButtonLabel: '',
  onPressFooter: () => { },
  onSearch: () => {},
  onSearchBlur: () => {},
};
