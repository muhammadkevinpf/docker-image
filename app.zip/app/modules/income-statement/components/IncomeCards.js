/* eslint-disable no-console */
import React, { PureComponent } from 'react';
import {
  Text, View, Card,
} from 'native-base';
import { TouchableArrow, TouchableArrow2 } from '../../../components';
import { toFixedCurrency } from '../../../utilities/String';
import NavigationService from '../../../bootstrap/NavigationService';
import Style from '../../../styles';
import Colors from '../../../styles/Colors';
import _ from '../../../lang';

export class IncomeComponent extends PureComponent {
  render() {
    return (
      <TouchableArrow2
        {...this.props}
        iconStyle={[Style.Main.gray83]}
        style={[Style.Main.borderBottomWidth1, Style.Main.padding12, this.props.isDetail ? {
          ...Style.Main.pl25, borderBottomColor: Colors.white,
        } : Style.Main.borderBottomWhiteSmoke]}
        value={`IDR ${toFixedCurrency(this.props.value || 0, 2)}`}
      />
    );
  }
}

export class IncomeComponent2 extends PureComponent {
  render() {
    return (
      <TouchableArrow
        {...this.props}
        // iconStyle={[Style.Main.textRed]}
        style={[Style.Main.borderBottomWidth1, Style.Main.padding5, this.props.isDetail ? {
          ...Style.Main.pl25, borderBottomColor: Colors.white, ...Style.Main.backgroundWhiteSmoke,
        } : Style.Main.borderBottomGray]}
      >
        <View style={[Style.Main.rowDirectionSpaceBetween]}>
          <View style={[Style.Main.container, Style.Main.ml2]}>
            <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.fullWidth]}>
              <Text style={[Style.Main.fontAlbert11]}>{this.props.label}</Text>
              <Text style={[Style.Main.fontAlbert11]}>{this.props.info}</Text>
            </View>
            <Text style={[Style.Main.fontAlbert14, Style.Main.textRed]}>Rp. {toFixedCurrency(this.props.value || 0, 2)}</Text>
          </View>
          { this.props.onExpand &&
            <Text onPress={this.props.onExpand} style={[Style.Main.fontAlbert11, Style.Main.textRed, Style.Main.padding10, Style.Main.pr0]}>
              {this.props.isExpanded ? `- ${_('Tutup Rincian')}` : `+ ${_('Lihat Rincian')}`}
            </Text>
          }
        </View>
      </TouchableArrow>
    );
  }
}

export class TaxSlipItem extends PureComponent {
  render() {
    const { date, asCard } = this.props;
    const Tag = asCard ? Card : View;
    return (
      <Tag>
        <TouchableArrow
          style={[Style.Main.pv10, !asCard && Style.Main.borderBottomGray, Style.Main.mt5]}
          onPress={() => NavigationService.replace('TaxSlipPreview', { date })}
        >
          <Text style={[Style.Main.fontAlbert12]}>{date}</Text>
        </TouchableArrow>
      </Tag>
    );
  }
}
