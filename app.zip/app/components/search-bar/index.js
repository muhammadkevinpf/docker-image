/**
 * @author:
 * dwi.setiyadi@gmail.com
*/

import React, { Component } from 'react';
import { View } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { Grid, Row, Col } from 'react-native-easy-grid';
import PropTypes from 'prop-types';

import InputField from '../input-field';
import Style from '../../styles';
import StyleSearchBar from './StyleSearchBar';

class SearchBar extends Component {
  focus = () => {
    this._input.focus();
  }

  blur = () => {
    this._input.blur();
  }

  render() {
    const { editable, placeholder } = this.props;

    return (
      <Grid>
        <Row>
          <Col>
            <View style={[StyleSearchBar.searchPrimary, Style.Main.mt15, Style.Main.mr15, Style.Main.mb15, Style.Main.ml15]}>
              <Row>
                <View style={Style.Main.textWrap}>
                  <Col size={12}>
                    <Icon
                      name="search"
                      size={18}
                      style={[Style.Main.textGray, Style.Main.mt15, Style.Main.ml15]}
                    />
                  </Col>
                  <Col size={88}>
                    <InputField
                      placeholder={placeholder}
                      placeholderTextColor={Style.Color.lightGray}
                      styleTextInput={[
                        Style.Main.textGray,
                        Style.Main.noBorderBottom,
                        Style.Main.textStrong,
                        Style.Main.ml5,
                      ]}
                      onChangeText={text => this.props.onSearchBarValue(text)}
                      value={this.props.value}
                      onFocus={this.props.onFocus}
                      ref={(ref) => { this._input = ref; }}
                      editable={editable}
                    />
                  </Col>
                </View>
              </Row>
            </View>
          </Col>
        </Row>

      </Grid>
    );
  }
}

SearchBar.propTypes = {
  editable: PropTypes.bool,
  placeholder: PropTypes.string,
  onSearchBarValue: PropTypes.func.isRequired,
  onFocus: PropTypes.func,
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
};

SearchBar.defaultProps = {
  editable: false,
  placeholder: 'Type here',
  onFocus: () => {},
};

export default SearchBar;
