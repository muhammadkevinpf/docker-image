/* eslint-disable react/no-unused-state */
/* eslint-disable array-callback-return */
/* eslint-disable no-console */
/* eslint-disable react/no-array-index-key */
/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import {
  Image, BackHandler, Alert, TouchableOpacity,
} from 'react-native';
import {
  Container, Content, Button, Icon, Text, View, Footer, FooterTab,
} from 'native-base';
import { connect } from 'react-redux';
import { DotIndicator } from 'react-native-indicators';
import RNExitApp from 'react-native-exit-app'; // jangan di hapus
import _ from '../../../lang';
import Style from '../../../styles';
import { HeaderWithTodo, SideBarMenu } from '../../../components/index';
import plus from '../../../assets/images/plus.png';
import NewsBanner from './NewsBanner';
import { newsListReset } from '../../news-and-update/ActionNews';
import {
  campaignBannerFetch, firstCampaignFetch, secondCampaignFetch, thirdCampaignFetch,
} from '../ActionDashboard';
import {
  CAMPAIGN_BANNER_FETCH, FIRST_CAMPAIGN_FETCH, SECOND_CAMPAIGN_FETCH, THIRD_CAMPAIGN_FETCH,
} from '../ConfigDashboard';
import CampaignBanner from './CampaignBanner';
import LoadingModal from '../../../components/loading_modal';
// import { getAgentChannel } from '../../auth/ServiceAuth';
import { AgentScopes, tabSizeRef } from '../../../config/Constants';
import {
  isTablet, isMenuActive, isFetching,
} from '../../../utilities';
import { dimensions } from '../../../config/Platform';
import CalculatorPremi from './CalculatorPremi';

const width = isTablet() && dimensions.height > dimensions.width ? dimensions.height : dimensions.width;
const bannerWidth = Math.round((width * 880) / tabSizeRef.width);
const bannerHeight = Math.round(bannerWidth * 0.5);

class MainDashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      sapa: 'Selamat Pagi',
      loading: false,
      showModal: false,
      hoverData: {},
      dropData: {},
      hoverDataIndex: -1,
      fullModal: false,
      onEditIcons: false,
      showMyAccount: false,
      showMore: false,
    };
  }

  static getDerivedStateFromProps(props, state) {
    if (props.action !== state.action) {
      return {
        action: props.action,
      };
    }
    return null;
  }

  componentDidMount() {
    this.setState({ loading: true });
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleBack();
      return true;
    });
    const jam = new Date().getHours();
    switch (true) {
      case (jam < 12):
        this.setState({
          sapa: 'Selamat Pagi',
        });
        break;
      case (jam < 16):
        this.setState({
          sapa: 'Selamat Siang',
        });
        break;
      case (jam < 17):
        this.setState({
          sapa: 'Selamat Sore',
        });
        break;
      case (jam < 24):
        this.setState({
          sapa: 'Selamat Malam',
        });
        break;
      default:
        break;
    }

    this.setState({ loading: false });
  }

  // componentDidUpdate = () => {
  //   if (this.state.action === 'USERPROFILESUCCESS') {
  //     const { office, raddName } = this.props.resAuth.userProfile;
  //     if (!office) {
  //       Alert.alert(
  //         _('Kesalahan'),
  //         _('Terjadi Kesalahan ketika mengambil data detail agen. Silakan hubungi Call Center Kami di 021 29958585'),
  //         [{ text: _('Keluar'), onPress: () => this.props.navigation.replace('MainHome') }],
  //         { cancelable: false },
  //       );
  //     }
  //     const channel = getAgentChannel(office || '', raddName || '');
  //     if (this.props.resAuth.userProfile.agentChannel !== channel) {
  //       const newUserProfile = { ...this.props.resAuth.userProfile, agentChannel: channel };
  //       this.props.updateChannel(newUserProfile);
  //     }
  //   }
  // }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  handleBack = () => {
    Alert.alert(_('Warning'), _('Apakah anda yakin ingin keluar dari PRUFast?'), [{
      text: _('Ya'),
      onPress: () => RNExitApp.exitApp(), // biar ketika di back ga jadi background apps
    }, { text: _('Tidak'), onPress: () => { } }]);
  }

  isIndividu = () => {
    if (this.props.resAuth && (this.props.resAuth.agent_scope === AgentScopes.individu
      // Please delete this condition if PS is ready
      || !this.props.resAuth.agent_scope)) return true;
    return false;
  }

  isUserProfileExist = () => {
    if (this.props.resAuth && this.props.resAuth.userProfile) return true;
    return false;
  }

  renderHeaderArt = () => {
    if (isTablet()) return null;
    return <View style={[Style.Main.headerArt]} />;
  }

  renderHeader = () => {
    let userName = 'Agent';
    // Request Pras & User to change the displayed name from adsName to clientName
    if (this.props.resAuth && this.props.resAuth.userProfile) userName = this.props.resAuth.userProfile.clientName;
    return (
      <React.Fragment>
        <HeaderWithTodo
          {...this.props}
          headerTitle={`${this.state.sapa}, ${userName}`}
          isShowBackButton={false}
        />
        {this.renderHeaderArt()}
      </React.Fragment>
    );
  }

  renderCampaign = () => <CampaignBanner {...this.props} style={isTablet() ? { height: bannerHeight } : null} />


  renderNews = () => {
    const { newsStatus } = this.props;
    return (
      <React.Fragment>
        <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.container, Style.Main.mb15, Style.Main.mr12, Style.Main.ml12]}>
          <Text style={[Style.Main.textColor3f3, Style.Main.fontBold]}>{_('Berita Terbaru')}</Text>
          <View style={[Style.Main.rowDirectionSpaceBetween]}>
            {isFetching(newsStatus) && <DotIndicator color={Style.Color.red} size={5} count={3} style={[Style.Main.mr20]} />}
            <Text
              onPress={() => { this.props.resetNewsList(); this.props.navigation.replace('NewsList'); }}
              style={[Style.Main.textRed, Style.Main.font12, Style.Main.ml5]}
            >{_('Lihat Semua')}
            </Text>
          </View>
        </View>
        <View style={[Style.Main.ml8]}>
          <NewsBanner width={isTablet() ? Math.round(bannerWidth / 3.2) : null} {...this.props} />
        </View>
      </React.Fragment>
    );
  }

  renderBottomSpace = () => <View style={[Style.Main.mb30]} />

  renderBanner = () => (
    <View style={isTablet() ? [Style.Main.alignCenter, { width: bannerWidth }] : null}>
      {this.renderCampaign()}
      {this.renderNews()}
      <CalculatorPremi height={isTablet() ? Math.round((bannerWidth - 20) / 4) : Math.round(bannerWidth / 2.7)} />
      {this.renderBottomSpace()}
    </View>
  )

  renderFooter = () => (
    <Footer>
      <FooterTab>
        <Button
          vertical
        >
          <Icon name="home" type="MaterialIcons" style={[Style.Main.textRed]} />
          <Text style={[Style.Main.textRed]}>{_('Beranda')}</Text>
        </Button>
        {
          isMenuActive(this.props.resAuth.mobileMenu, 'PD_MODULE_NEW_SQS') &&
          <Button
            vertical
            onPress={this.isIndividu() ? () => this.props.navigation.replace('ExistingPolicySQSNSpaj', { previousScreen: 'MainDashboard' })
              : (() => { })}
            style={[Style.Main.mb20]}
          >
            <Image
              source={plus}
              style={[Style.Main.width75, Style.Main.height75]}
            />
          </Button>
        }
        <Button
          vertical
          style={[!this.isUserProfileExist() && Style.Main.halfOpacity]}
          onPress={this.isUserProfileExist() ? () => this.props.navigation.replace('MyAccount') : () => { }}
        >
          <Icon name="person" type="Ionicons" />
          <Text>{_('Akun Saya')}</Text>
        </Button>
      </FooterTab>
    </Footer>
  )

  renderLoading = () => <LoadingModal show={this.state.loading} size="large" color="white" />

  render() {
    if (isTablet()) {
      return (
        <Container style={[Style.Main.rowDirection]}>
          <SideBarMenu navigation={this.props.navigation} />
          <TouchableOpacity
            activeOpacity={1}
            onPress={() => this.setState({ showMyAccount: false })}
            style={[Style.Main.container, { minWidth: dimensions.width - 100 }]}
          >
            {this.renderHeader()}
            <Content style={[Style.Main.backgroundColorEe]} keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
              {this.renderBanner()}
            </Content>
          </TouchableOpacity>
          {this.renderLoading()}
        </Container>
      );
    }
    return (
      <Container>
        {this.renderHeader()}
        <Content style={[Style.Main.backgroundColorEe]} keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
          <SideBarMenu navigation={this.props.navigation} />
          {this.renderBanner()}
        </Content>
        {this.renderFooter()}
        {this.renderLoading()}
      </Container>
    );
  }
}

const mapStateToProps = state => ({
  resAuth: state.auth.res,
  action: state.auth.action,
  dashboard: state.dashboard,
  isOnline: state.connectionStatus.isOnline,
  newsStatus: state.news.newsListStatus,
});

const mapDispatchToProps = dispatch => ({
  resetNewsList: () => dispatch(newsListReset()),
  getCampaignList: value => dispatch(campaignBannerFetch(CAMPAIGN_BANNER_FETCH, value)),
  getFirstCampaign: value => dispatch(firstCampaignFetch(FIRST_CAMPAIGN_FETCH, value)),
  getSecondCampaign: value => dispatch(secondCampaignFetch(SECOND_CAMPAIGN_FETCH, value)),
  getThirdCampaign: value => dispatch(thirdCampaignFetch(THIRD_CAMPAIGN_FETCH, value)),
});

export default connect(mapStateToProps, mapDispatchToProps)(MainDashboard);
