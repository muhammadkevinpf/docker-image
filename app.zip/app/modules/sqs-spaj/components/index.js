/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import AdvanceSearchSQSNSpaj_ from './AdvanceSearchSQSNSpaj';
import CardSQSNSpaj_ from './CardSQSNSpaj';
import FooterSQSNSpaj_ from './FooterSQSNSpaj';
import ActionButtonSQSNSpaj_ from './ActionButtonSQSNSpaj';
import ModalSQSNSpaj_ from './ModalSQSNSpaj';
import SubHeaderSQSNSpaj_ from './SubHeaderSQSNSpaj';
import AllocationPremi_ from './allocation-premi';
import BenefitsModal_ from './benefits-modal';
import SqsPopupMenu_ from './sqs-popup-menu';
import SqsHeader_ from './sqs-header';
import ProgressBarWithBackButton from './progress-bar-with-back-button';

const AdvanceSearchSQSNSpaj = AdvanceSearchSQSNSpaj_;
const CardSQSNSpaj = CardSQSNSpaj_;
const FooterSQSNSpaj = FooterSQSNSpaj_;
const ActionButtonSQSNSpaj = ActionButtonSQSNSpaj_;
const ModalSQSNSpaj = ModalSQSNSpaj_;
const SubHeaderSQSNSpaj = SubHeaderSQSNSpaj_;
const AllocationPremi = AllocationPremi_;
const BenefitsModal = BenefitsModal_;
const SqsPopupMenu = SqsPopupMenu_;
const SqsHeader = SqsHeader_;

export {
  AdvanceSearchSQSNSpaj,
  CardSQSNSpaj,
  FooterSQSNSpaj,
  ActionButtonSQSNSpaj,
  ModalSQSNSpaj,
  SubHeaderSQSNSpaj,
  AllocationPremi,
  BenefitsModal,
  SqsPopupMenu,
  SqsHeader,
  ProgressBarWithBackButton,
};
