/* eslint-disable react-native/no-inline-styles */
/**
 * @author: ahmdichsanb@gmail.com
*/

import React, { Component } from 'react';
import { View, TouchableOpacity } from 'react-native';
import { Row, Col } from 'react-native-easy-grid';
import PropTypes from 'prop-types';

import StyleAlertTemplate from './StyleAlertTemplate';

class AlertTemplate extends Component {
  render() {
    const {
      headerContent, bodyContent, buttonRightContent, buttonLeftContent,
      bodyContentStyle, containerStyle, footertContentStyle, headerContentStyle,
    } = this.props;
    return (
      <TouchableOpacity
        style={[containerStyle]}
        onPress={() => {}}
        // this empty function to override function on the wrapper (modal), so when user not clicking on the transparent area, the modal won't closed
        activeOpacity={1}
      >
        {
          headerContent && (
            <Row style={[headerContentStyle]}>
              {headerContent}
            </Row>
          )
        }
        {
          bodyContent && (
            <Row style={[bodyContentStyle]}>
              <View onStartShouldSetResponder={() => true}>
                {bodyContent}
              </View>
            </Row>
          )
        }
        {(buttonLeftContent || buttonRightContent) && (
          <Row style={[footertContentStyle]}>
            {
              buttonLeftContent && (
                <Col style={{ marginRight: 0.5 }}>
                  {buttonLeftContent}
                </Col>
              )
            }
            {
              buttonRightContent && (
                <Col style={{ marginLeft: 0.5 }}>
                  {buttonRightContent}
                </Col>
              )
            }
          </Row>
        )}
      </TouchableOpacity>
    );
  }
}

AlertTemplate.propTypes = {
  headerContent: PropTypes.element,
  bodyContent: PropTypes.element.isRequired,
  bodyContentStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  containerStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  footertContentStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  headerContentStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  buttonRightContent: PropTypes.element,
  buttonLeftContent: PropTypes.element,
};

AlertTemplate.defaultProps = {
  headerContent: null,
  buttonLeftContent: null,
  buttonRightContent: null,
  bodyContentStyle: StyleAlertTemplate.bodyContent,
  containerStyle: StyleAlertTemplate.container,
  footertContentStyle: StyleAlertTemplate.footertContent,
  headerContentStyle: StyleAlertTemplate.headerContent,
};

export default AlertTemplate;
