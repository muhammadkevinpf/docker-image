/**
 * @author: ahmdichsanb@gmail.com
*/

import { StyleSheet } from 'react-native';
import Styles from '../../styles';

const Style = StyleSheet.create({
  styleTextInput: {
    borderBottomColor: Styles.Color.gray,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
});

export default Style;
