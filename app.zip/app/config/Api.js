/**
 * @author: dwi.setiyadi@gmail.com
*/

// API constants needed for newsapi
