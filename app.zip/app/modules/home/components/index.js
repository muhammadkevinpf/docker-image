/* eslint-disable import/no-cycle */
/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import Banner_ from './BannerHome';
import BtnAgentNonAgent_ from './BtnAgentNonAgent';
import PickerLogin_ from './PickerLogin';
import HomeScreen_ from './HomeScreen';

const Banner = Banner_;
const BtnAgentNonAgent = BtnAgentNonAgent_;
const PickerLogin = PickerLogin_;
const HomeScreen = HomeScreen_;


export default {
  Banner,
  BtnAgentNonAgent,
  PickerLogin,
  HomeScreen,
};
