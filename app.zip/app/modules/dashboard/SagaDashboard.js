/* eslint-disable no-console */
/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import {
  call, put, takeLatest,
} from 'redux-saga/effects';
import { resourceRequest } from '../../utilities/StoreApi';
import { sagaWatcherErrorHandling } from '../../utilities/ErrorHandling';
import { FILE_BASE_64_API } from '../news-and-update/ConfigNews';
import {
  firstBannerFetch, secondBannerFetch, thirdBannerFetch,
  changePasswordFetch,
  campaignBannerFetch,
  firstCampaignFetch,
  secondCampaignFetch,
  thirdCampaignFetch,
} from './ActionDashboard';
import {
  FIRST_BANNER_SUCCESS, FIRST_BANNER_FAILED, SECOND_BANNER_SUCCESS,
  SECOND_BANNER_FAILED, THIRD_BANNER_SUCCESS, THIRD_BANNER_FAILED,
  FIRST_BANNER_FETCH, SECOND_BANNER_FETCH, THIRD_BANNER_FETCH,
  CHANGE_PASSWORD_API, CHANGE_PASSWORD_FAILED, CHANGE_PASSWORD_FETCH, CHANGE_PASSWORD_SUCCESS,
  CAMPAIGN_BANNER_API, CAMPAIGN_BANNER_FAILED, CAMPAIGN_BANNER_IMAGE_API,
  FIRST_CAMPAIGN_FAILED, SECOND_CAMPAIGN_FAILED, THIRD_CAMPAIGN_FAILED,
  CAMPAIGN_BANNER_FETCH, FIRST_CAMPAIGN_FETCH, SECOND_CAMPAIGN_FETCH, THIRD_CAMPAIGN_FETCH,
  CAMPAIGN_BANNER_SUCCESS, FIRST_CAMPAIGN_SUCCESS, SECOND_CAMPAIGN_SUCCESS, THIRD_CAMPAIGN_SUCCESS,
} from './ConfigDashboard';
import { apiTakeLatest } from '../../utilities';
import { GET_DICTIONARY } from '../dictionary/ConfigDictionary';

function* workerSagaFirstBanner(params) {
  try {
    const res = yield call(resourceRequest, FILE_BASE_64_API, 'post', params.payload);
    if (res.data && (res.status === '200' || res.status === 200)) {
      yield put.resolve(firstBannerFetch(FIRST_BANNER_SUCCESS, res.data.content[0]));
    } else {
      yield put.resolve(firstBannerFetch(FIRST_BANNER_FAILED, res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(firstBannerFetch(FIRST_BANNER_FAILED, parseError));
  }
}

function* workerSagaSecondBanner(params) {
  try {
    const res = yield call(resourceRequest, FILE_BASE_64_API, 'post', params.payload);
    if (res.data && (res.status === '200' || res.status === 200)) {
      yield put.resolve(secondBannerFetch(SECOND_BANNER_SUCCESS, res.data.content[0]));
    } else {
      yield put.resolve(secondBannerFetch(SECOND_BANNER_FAILED, res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(secondBannerFetch(SECOND_BANNER_FAILED, parseError));
  }
}

function* workerSagaThirdBanner(params) {
  try {
    const res = yield call(resourceRequest, FILE_BASE_64_API, 'post', params.payload);
    if (res.data && (res.status === '200' || res.status === 200)) {
      yield put.resolve(thirdBannerFetch(THIRD_BANNER_SUCCESS, res.data.content[0]));
    } else {
      yield put.resolve(thirdBannerFetch(THIRD_BANNER_FAILED, res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(thirdBannerFetch(THIRD_BANNER_FAILED, parseError));
  }
}

function* workerSagaCampaignList(params) {
  try {
    const res = yield call(resourceRequest, CAMPAIGN_BANNER_API, 'post', params.payload);
    if (res.data && (res.status === '200' || res.status === 200)) {
      yield put.resolve(campaignBannerFetch(CAMPAIGN_BANNER_SUCCESS, res.data.array));
    } else {
      yield put.resolve(campaignBannerFetch(CAMPAIGN_BANNER_FAILED, res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(campaignBannerFetch(CAMPAIGN_BANNER_FAILED, parseError));
  }
}

function* workerSagaFirstCampaign(params) {
  try {
    const res = yield call(resourceRequest, CAMPAIGN_BANNER_IMAGE_API, 'post', params.payload);
    if (res.data && (res.status === '200' || res.status === 200)) {
      // yield put.resolve(firstCampaignFetch(FIRST_CAMPAIGN_SUCCESS, res.data.array[0] ? res.data.array[0].imageBase64 || '' : ''));
      yield put.resolve(firstCampaignFetch(FIRST_CAMPAIGN_SUCCESS, res.data.content[0] ? res.data.content[0].fileData || '' : ''));
    } else {
      yield put.resolve(firstCampaignFetch(FIRST_CAMPAIGN_FAILED, res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(firstCampaignFetch(FIRST_CAMPAIGN_FAILED, parseError));
  }
}

function* workerSagaSecondCampaign(params) {
  try {
    const res = yield call(resourceRequest, CAMPAIGN_BANNER_IMAGE_API, 'post', params.payload);
    if (res.data && (res.status === '200' || res.status === 200)) {
      yield put.resolve(secondCampaignFetch(SECOND_CAMPAIGN_SUCCESS, res.data.content[0] ? res.data.content[0].fileData || '' : ''));
    } else {
      yield put.resolve(secondCampaignFetch(SECOND_CAMPAIGN_FAILED, res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(secondCampaignFetch(SECOND_CAMPAIGN_FAILED, parseError));
  }
}

function* workerSagaThirdCampaign(params) {
  try {
    const res = yield call(resourceRequest, CAMPAIGN_BANNER_IMAGE_API, 'post', params.payload);
    if (res.data && (res.status === '200' || res.status === 200)) {
      yield put.resolve(thirdCampaignFetch(THIRD_CAMPAIGN_SUCCESS, res.data.content[0] ? res.data.content[0].fileData || '' : ''));
    } else {
      yield put.resolve(thirdCampaignFetch(THIRD_CAMPAIGN_FAILED, res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(thirdCampaignFetch(THIRD_CAMPAIGN_FAILED, parseError));
  }
}

function* workerSagaChangePassword(params) {
  try {
    const res = yield call(resourceRequest, CHANGE_PASSWORD_API, 'post', params.payload);
    if (res.data && (res.status === '200' || res.status === 200) && res.data.status) {
      yield put.resolve(changePasswordFetch(CHANGE_PASSWORD_SUCCESS, res.data));
    } else {
      yield put.resolve(changePasswordFetch(CHANGE_PASSWORD_FAILED, res.data.errorMessage));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(changePasswordFetch(CHANGE_PASSWORD_FAILED, parseError));
  }
}

export const watcherDashboard = [
  takeLatest(FIRST_BANNER_FETCH, workerSagaFirstBanner),
  takeLatest(SECOND_BANNER_FETCH, workerSagaSecondBanner),
  takeLatest(THIRD_BANNER_FETCH, workerSagaThirdBanner),
  takeLatest(CAMPAIGN_BANNER_FETCH, workerSagaCampaignList),
  takeLatest(FIRST_CAMPAIGN_FETCH, workerSagaFirstCampaign),
  takeLatest(SECOND_CAMPAIGN_FETCH, workerSagaSecondCampaign),
  takeLatest(THIRD_CAMPAIGN_FETCH, workerSagaThirdCampaign),
  takeLatest(CHANGE_PASSWORD_FETCH, workerSagaChangePassword),

  apiTakeLatest(GET_DICTIONARY, { resAttribute: 'data' }),
];
