import Views from './views';

export default {
  CounterOffer: { screen: Views.CounterOffer },
  CounterOfferSubmit: { screen: Views.CounterOfferSubmit },
};
