export const productionAction = (action, value) => ({ type: action, payload: value });
