/* eslint-disable react/no-array-index-key */
/* eslint-disable no-plusplus */
import React from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import { Modal, TouchableOpacity, Platform } from 'react-native';
import {
  View, Text, Picker, Content,
} from 'native-base';
import { Row, Col } from 'react-native-easy-grid';
import Style from '../../styles';
import _ from '../../lang';
import Icons from '../icon-native-base';
import { toStringTwoDigit } from '../../utilities';

class MonthYearPicker extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedYear: this.props.selectedYear,
      selectedMonth: this.props.selectedMonth,
      pickerShowed: false,
      endMonth: this.props.selectedYear === (new Date()).getFullYear() ? (new Date()).getMonth() + 1 : 12,
    };
  }

  endMonthByYear = (year) => {
    if (year === (new Date()).getFullYear()) {
      return (new Date()).getMonth() + 1;
    } return 12;
  }

  getMonthYears = () => {
    const months = []; const years = [];
    const { startYear, endYear, monthLabelFormat } = this.props;

    const startMonth = this.state.selectedYear === startYear ? this.props.startMonth : 1;
    const endMonth = this.props.endMonthByYear ? this.state.endMonth : this.props.endMonth;

    for (let i = Number(startMonth); i <= Number(endMonth); i++) months.push(moment(String(i), 'MM').format(monthLabelFormat));
    for (let i = Number(startYear); i <= Number(endYear); i++) years.push(i);
    return { months, years };
  }

  confirm = () => {
    this.props.onConfirm({ selectedMonth: this.state.selectedMonth, selectedYear: this.state.selectedYear });
    this.setState({ pickerShowed: false });
  }

  renderPicker = () => {
    const { months, years } = this.getMonthYears();
    let getSelectedMonth = Number(this.state.selectedMonth) > this.state.endMonth ? this.state.endMonth : this.state.selectedMonth;
    const firstMonth = Number(moment(String(months[0]), this.props.monthLabelFormat).format('MM'));
    getSelectedMonth = getSelectedMonth < firstMonth ? firstMonth : getSelectedMonth;
    return (
      Platform.OS === 'android' ?
        <View style={[Style.Main.container, Style.Main.rowDirection]}>
          <Picker
            style={[Style.Main.container]}
            selectedValue={toStringTwoDigit(getSelectedMonth)}
            onValueChange={selectedMonth => this.setState({ selectedMonth })}
          >
            {months.map((item, i) => <Picker.Item key={i} label={item} value={moment(String(item), this.props.monthLabelFormat).format('MM')} />)}
          </Picker>
          <Picker
            style={[Style.Main.container]}
            selectedValue={this.state.selectedYear}
            onValueChange={
            val => this.setState({ selectedYear: val, endMonth: val === (new Date()).getFullYear() ? (new Date()).getMonth() + 1 : 12 })
          }
          >
            {years.map((item, i) => <Picker.Item key={i} label={String(item)} value={item} />)}
          </Picker>
        </View>
        :
        <Row style={[Style.Main.container]}>
          <Col>
            <Content>
              <Picker
                iosIcon={<Icons name="caret-down" />}
                style={[Style.Main.container, Style.Main.fullWidth]}
                selectedValue={toStringTwoDigit(getSelectedMonth)}
                placeholder={_('Pilih bulan')}
                onValueChange={selectedMonth => this.setState({ selectedMonth })}
              >
                {months.map((item, i) => <Picker.Item key={i} label={item} value={moment(String(item), this.props.monthLabelFormat).format('MM')} />)}
              </Picker>
            </Content>
          </Col>
          <Col>
            <Content>
              <Picker
                iosIcon={<Icons name="caret-down" />}
                style={[Style.Main.container, Style.Main.fullWidth]}
                selectedValue={this.state.selectedYear}
                onValueChange={
                val => this.setState({ selectedYear: val, endMonth: val === (new Date()).getFullYear() ? (new Date()).getMonth() + 1 : 12 })
              }
              >
                {years.map((item, i) => <Picker.Item key={i} label={String(item)} value={item} />)}
              </Picker>
            </Content>
          </Col>
        </Row>
    );
  }

  render() {
    const {
      selectedYear, selectedMonth, monthLabelFormat, pickerStyle, pickerTextStyle,
    } = this.props;
    console.log('month year state: ', this.state);
    return (
      <View style={[pickerStyle]}>
        <TouchableOpacity
          style={[Style.Main.rowDirection, Style.Main.center]}
          onPress={() => this.setState({
            pickerShowed: true,
            selectedYear: this.props.selectedYear,
            selectedMonth: this.props.selectedMonth,
            endMonth: this.props.selectedYear === (new Date()).getFullYear() ? (new Date()).getMonth() + 1 : 12,
          })}
        >
          <View style={[Style.Main.container, Style.Main.alignLeft, Style.Main.grayBorderBottom, Style.Main.padding10]}>
            <Text style={[Style.Main.fontAlbert14, pickerTextStyle]}>
              {moment(String(selectedMonth), 'MM').format(monthLabelFormat)} {String(selectedYear)}
            </Text>
          </View>
        </TouchableOpacity>
        <Modal transparent visible={this.state.pickerShowed} onRequestClose={() => this.setState({ pickerShowed: false })}>
          <View style={[Style.Main.justifyBottom, Style.Main.container, Style.Main.backgroundLightSmoke]}>
            <View
              style={[Style.Main.backgroundWhiteSmoke, Style.Main.fullWidth,
                Platform.OS === 'ios' ? Style.Main.height165 : Style.Main.height120, Style.Main.ph12]}
            >
              <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.fullWidth, Style.Main.mt12, Style.Main.mb12]}>
                <TouchableOpacity style={[Style.Main.container]} onPress={() => this.setState({ pickerShowed: false })}>
                  <Text style={[Style.Main.fontAlbert14]}>{_('Cancel')}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[Style.Main.container]} onPress={this.confirm}>
                  <Text style={[Style.Main.fontAlbert14, Style.Main.textRed, Style.Main.alignRight]}>{_('Confirm')}</Text>
                </TouchableOpacity>
              </View>
              {this.renderPicker()}
            </View>
          </View>
        </Modal>
      </View>
    );
  }
}

MonthYearPicker.propTypes = {
  monthLabelFormat: PropTypes.string,
  startMonth: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  endMonth: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  startYear: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  endYear: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  selectedMonth: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  selectedYear: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  onConfirm: PropTypes.func,
  endMonthByYear: PropTypes.bool,
  pickerStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  pickerTextStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
};

MonthYearPicker.defaultProps = {
  monthLabelFormat: 'MMMM',
  startMonth: 1,
  endMonth: 12,
  startYear: (new Date()).getFullYear(),
  endYear: (new Date()).getFullYear(),
  selectedMonth: (new Date()).getMonth() + 1,
  selectedYear: (new Date()).getFullYear(),
  onConfirm: () => { },
  endMonthByYear: false,
  pickerStyle: null,
  pickerTextStyle: null,
};

export default MonthYearPicker;
