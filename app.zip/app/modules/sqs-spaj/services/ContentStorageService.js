import CryptoJS from 'crypto-js';
import SQLiteUtils from '../../../utilities/SQLiteUtils';
import Database from '../../../config/Database';

const { content } = Database.pruSmart.tables;

// const querySelectByKey = `SELECT * FROM ${content.name} WHERE ID = ?`;
const queryUpdateByKey = `UPDATE ${content.name} SET content = ? WHERE ID = ?`;
const queryInsert = `INSERT INTO ${content.name} VALUES (?,?)`;
const queryDeleteByKey = `DELETE FROM ${content.name} WHERE ID = ?`;
const serviceName = 'ContentService';

const getByCode = (db, id) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeAdvanceQuery(db, content.name, 'content', 'WHERE ID = ?', [id]);
    if (res) {
      const base64 = JSON.parse(CryptoJS.AES.decrypt(res, SQLiteUtils.DBKEY).toString(CryptoJS.enc.Utf8));
      resolve(base64);
    } else {
      resolve(0);
    }
  } catch (error) {
    console.log(error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const deleteByCode = (db, id) => new Promise(async (resolve, reject) => {
  try {
    const checkData = await getByCode(db, id);
    if (!checkData) { reject(new Error(`${serviceName} Data not found`)); return; }
    const res = await SQLiteUtils.executeTransaction(
      db,
      queryDeleteByKey,
      [id],
    );
    resolve(res);
  } catch (error) {
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const insert = (db, id, data) => new Promise(async (resolve, reject) => {
  try {
    const encData = CryptoJS.AES.encrypt(JSON.stringify(data), SQLiteUtils.DBKEY).toString();
    const res = await SQLiteUtils.executeTransaction(db, queryInsert, [id, encData]);
    resolve({ id, content: encData, res });
  } catch (error) {
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const update = (db, id, data) => new Promise(async (resolve, reject) => {
  try {
    const encData = CryptoJS.AES.encrypt(JSON.stringify(data), SQLiteUtils.DBKEY).toString();
    const res = await SQLiteUtils.executeTransaction(db, queryUpdateByKey, [encData, id]);
    resolve({ id, content: encData, res });
  } catch (error) {
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

export default {
  getByCode,
  update,
  insert,
  deleteByCode,
};
