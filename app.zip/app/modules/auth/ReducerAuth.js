/**
 * @author: dwi.setiyadi@gmail.com
*/

import {
  SIGNINFETCH,
  SIGNINSUCCESS,
  SIGNINFAILED,

  USERPROFILEFETCH,
  USERPROFILESUCCESS,
  USERPROFILEFAILED,

  USERAVATARFETCH,
  USERAVATARSUCCESS,
  USERAVATARFAILED,

  SIGNOUTFETCH,
  SIGNOUTSUCCESS,
  SIGNOUTFAILED,

  VAFETCH,
  VAFAILED,
  VASUCCESS,
  VAUPDATE,

  // added
  HASHINGPASSWORD,
  UPDATEONLINEDATE,
  CONNECTIONONLINE,
  CONNECTIONOFFLINE,
  UPDATESIGNINDATE,
} from './ConfigAuth';
import { RESET_ALL_STATE } from '../dashboard/ConfigDashboard';
import { getAgentChannel } from './ServiceAuth';

const initialStateAuth = {
  fetchSignIn: false,
  fetchUserProfile: false,
  fetchUserAvatar: false,
  fetchSignOut: false,
  fetchVa: false,
  send: null,
  res: {
    vaNumber: [],
  },
  // res: {
  //   userAvatar: {
  // eslint-disable-next-line max-len
  //     text: 'https://ae01.alicdn.com/kf/HTB16U1Bc.vMR1JjSZPcq6A1tFXa3/15-cm-x-12-cm-Avatar-Airbender-Aang-Lucu-Car-Sticker-Untuk-Truk-Jendela-Bumper-Auto.jpg',
  //   },
  //   username: '00841117',
  //   userProfile: {
  //     agentCode: '00841117',
  //     agentChannel: 'SCB',
  //     adsName: 'Cukz',
  //     leaderName: 'BVT MANAGER KEAGENAN',
  //     officeCode: 'office4678',
  //     agentEmailAddress: 'rana@agent.pru.co.id',
  //   },
  // eslint-disable-next-line max-len
  //   access_token: 'eyJhbGciOiJIUzI1NiJ9.eyJwcmluY2lwYWwiOiJINHNJQUFBQUFBQUFBSlZUejJ2VVFCU2V4SmFWVnJRVkZEeFV5bHB2SmR0VlFYRXY2dm9EUzZ5RmRpOFZoTm5rYlpwMk1oTm5KdTB1VXRtVGdqMjBcL2lnSVwvZ3M5K2xcL294VDlBRkJSdlBZcFgzeVJaazVWQ2NVNlo3NzMzZmU5OTg3SlwvUUVhVkpEYzhFVG14VEh6Z09xVE1mSGFFOU1CQlBCTGNVZUFsTXRROUo5RWhjeGJ6YUV1QnZBMmFoa3g5ZjhsYUgxNzkrbWtUMnlYak5FQ2VMS0xKYVhlTmJ0QWFvenlvTFdrWjhxRGhrb3EzU2prSDlvUThJMVpYa3N1Qk5EUk96SklnUkwzWTVCV3FLT1JuUXM2OU5ORklrK3hZTnJGY1lvZitzTlREOWhwNHVvSGNsNFFNY3NhT3BCRnNDcmxlVE9RSkNVTUNCYlcxYTVQS0NwbWtuaWNTcmhjRXY5T05Rd24rQ3Brb01GZDQ2d1k2NDJFazgwK1ZVeXZBYVp1QmIzeEo5S3BBMVJDVUpxZXlabzJqdFNYUWFNcnhtQ3FGM2ZtcEszZzNiWEhzT0hNcHR2RGdZMTAwZGRsTE5BVmpPR1VvdUpwcDhVajRZU2MwWXNqWG4zcjllZWQ5djJVVGdoN01IbDFUNE9kdWtmN0h4N1wvUHA4WmFuaVpuUzYwV2FZMXVqTjFNRnN6TEVvenlsM2VMYlwvWU9Yanc2aHNvbTQrN1wvK3o5ek0zZXExeFJSVENYVm92UW1TTHM1WWk3ZFdKTVRadG5tNXE1ZHFkZnJWMUh0Wk5xUFdRSEhGYmhyMno5MlArMWMrSXF6ekpQUkRjb1NRRHNtaXFTRkpHcURmTDZcL056WCs5dHQyU2o1WUxHM05QeDJieGxOTkY3cDZmVHE3cHREZ3JSRGxDV096UlNSTlh1N0ZnS0c4c2hTRktHYWlCNUFuSEZiYkZINWFPNWlxWEs0b0E1WCtmZmY5QWY5aGVReW9EekpuK2tlRXh6U2JPaFVaWXRkVUo4ckE5V3FLYm1YQktrZ3A1QU5RQ3ZWTXVGckdpMzdOR1lUK2NtbVp3TmlXSmlPbTF6OU5jUkUyY1FRQUFBPT0iLCJzdWIiOiJhZ2VuMDA4NDExMTciLCJyb2xlcyI6W10sImV4cCI6MTU3MDA5OTA0MSwiaWF0IjoxNTcwMDEyNjQxfQ.yWJ2-LXNRMr3eIc0CycQEu_LINX795xvxeJArcEBWVg',
  // },
  err: null,
  pwd: null,
};

const initialStateConnection = {
  isOnline: false,
};

export function ReducerAuth(state = initialStateAuth, action) {
  switch (action.type) {
    case RESET_ALL_STATE:
      return {
        ...state,
        res: {
          ...state.res,
          vaNumber: [],
          userProfile: {},
          userAvatar: {},
        },
      };

    case SIGNINFETCH:
      return {
        ...state,
        fetchSignIn: true,
        send: action.send,
        action: action.type,
        err: null,
      };

    case SIGNINSUCCESS:
      return {
        ...state,
        fetchSignIn: false,
        res: {
          ...state.res,
          ...action.res,
        },
        err: null,
        action: action.type,
      };

    case SIGNINFAILED:
      return {
        ...state,
        fetchSignIn: false,
        // res: null,
        err: { code: action.err.code, message: action.err.message.replace('PRUforce', 'PRUFast') },
        action: action.type,
      };

    case USERPROFILEFETCH:
      return {
        ...state,
        fetchUserProfile: true,
        send: action.send,
        action: action.type,
      };

    case USERPROFILESUCCESS:
      // eslint-disable-next-line no-case-declarations
      const channel = action.res.channelType === 'AGENCY' ? 'AG' : getAgentChannel(action.res.office || '', '', state.res.access_token);
      // let channel; // eslint-disable-line no-case-declarations
      // if (action.res.agentChannel) {
      //   channel = action.res.agentChannel;
      // } else {
      //   channel = action.res.channelType === 'AGENCY' ? 'AG' : action.res.channelType;
      // }
      return {
        ...state,
        fetchSignIn: false,
        res: {
          ...state.res,
          userProfile: {
            ...action.res,
            agentChannel: channel,
          },
        },
        err: null,
        action: action.type,
      };

    case USERPROFILEFAILED:
      return {
        ...state,
        fetchSignIn: false,
        err: action.err,
        action: action.type,
      };

    case USERAVATARFETCH:
      return {
        ...state,
        fetchUserAvatar: true,
        send: action.send,
        action: action.type,
      };

    case USERAVATARSUCCESS:
      return {
        ...state,
        fetchSignIn: false,
        res: {
          ...state.res,
          userAvatar: {
            ...action.res,
          },
        },
        err: null,
        action: action.type,
      };

    case USERAVATARFAILED:
      return {
        ...state,
        fetchSignIn: false,
        err: action.err,
        action: action.type,
      };

    case SIGNOUTFETCH:
      return {
        ...state,
        fetchSignOut: true,
        send: action.send,
        action: action.type,
      };

    case SIGNOUTSUCCESS:
      return {
        ...state,
        fetchSignOut: false,
        res: null,
        err: null,
        action: action.type,
      };

    case SIGNOUTFAILED:
      return {
        ...state,
        fetchSignOut: false,
        err: action.err,
        action: action.type,
      };

    case VAFETCH:
      return {
        ...state,
        fetchVa: true,
        send: action.send,
        action: action.type,
      };

    case VASUCCESS:
      return {
        ...state,
        fetchVa: false,
        res: {
          ...state.res,
          vaNumber: action.res.vaList.map(x => ({
            ...x,
            isUsed: false,
          })),
        },
        err: null,
        action: action.type,
      };

    case VAFAILED:
      return {
        ...state,
        fetchSignOut: false,
        err: action.err,
        action: action.type,
      };

    case VAUPDATE:
      return {
        ...state,
        res: {
          ...state.res,
          vaNumber: action.res,
        },
        err: null,
        action: action.type,
      };

    case HASHINGPASSWORD:
      return {
        ...state,
        pwd: action.value,
        action: action.type,
      };

    case UPDATEONLINEDATE:
      return {
        ...state,
        activeOn: action.value,
        action: action.type,
      };

    case UPDATESIGNINDATE:
      return {
        ...state,
        signInDate: action.value,
        action: action.type,
      };

    default:
      return state;
  }
}

export function ReducerConnection(state = initialStateConnection, action) {
  switch (action.type) {
    case CONNECTIONONLINE:
      return {
        ...state,
        isOnline: true,
      };

    case CONNECTIONOFFLINE:
      return {
        ...state,
        isOnline: false,
      };

    default:
      return state;
  }
}
