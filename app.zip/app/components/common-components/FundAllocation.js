import React from 'react';
import PropTypes from 'prop-types';
import { Text, View } from 'native-base';
import { connect } from 'react-redux';
import { ActivityIndicator } from 'react-native';
import { CardRedHeader } from './Tags';
import { FundService } from '../../modules/spaj/services';
import { DatabaseUtils, isEmpty } from '../../utilities';
import AllocationPremi from '../../modules/sqs-spaj/components/allocation-premi';
import Style from '../../styles';
import _ from '../../lang';

class FundAllocation extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      fundMaster: [
        {
          fundRisk: 'konservatif',
          fundList: [],
          percent: 0,
          percentTopUp: 0,
        }, {
          fundRisk: 'moderat',
          fundList: [],
          percent: 0,
          percentTopUp: 0,
        }, {
          fundRisk: 'agresif',
          fundList: [],
          percent: 0,
          percentTopUp: 0,
        },
      ],
      choosedFund: [],
      showPremiWarning: false,
    };
  }

  componentDidMount = () => {
    this.getFundMaster();
  }

  fundMapping = () => {
    let choosedFund = [];
    const chooseFund = this.state.fundMaster.filter(item => item.percentTopUp > 0) || [];
    chooseFund.map(fund => fund.fundList.map((obj) => {
      if (obj.choosedTopUp) choosedFund = [...choosedFund, { ...obj }];
      return choosedFund;
    }));
    this.setState({ choosedFund },
      () => this.props.onChanged(this.state.choosedFund, this.renderPercent(), this.state.fundMaster, this.renderFundMasterWarning()));
  }

  countFundValue = (obj) => {
    const { val, orderFundRisk, orderFundList } = obj;
    this.setState((prevState) => {
      const fund = [...prevState.fundMaster];
      let totalTopUpRisk = 0;
      let flag = 0;
      let isTotalTopUpOver = false;
      let totalTopUp = 0;
      let flagChoosedTopUp = false;
      fund[orderFundRisk].fundList[orderFundList].valueTopUp = val;
      fund.forEach((itemRisk, indexFundRisk) => {
        const { fundList } = itemRisk;
        fundList.forEach((itemFundList) => {
          const { valueTopUp, choosedTopUp } = itemFundList;
          if (orderFundRisk === indexFundRisk) totalTopUpRisk += valueTopUp;
          if (choosedTopUp && valueTopUp === 0) flag += 1;
          if (choosedTopUp && !flagChoosedTopUp) flagChoosedTopUp = true;
          totalTopUp += valueTopUp;
        });
      });
      fund[orderFundRisk].percentTopUp = totalTopUpRisk;
      isTotalTopUpOver = totalTopUp > 100;
      console.log(flag, isTotalTopUpOver);
      return { fundMaster: fund, showPremiWarning: true };
    }, this.fundMapping);
  }

  chooseFund = (obj) => {
    const { orderFundRisk, orderFundList } = obj;
    const selectedData = this.state.fundMaster[orderFundRisk].fundList[orderFundList];
    const fund = [...this.state.fundMaster];
    fund[orderFundRisk].fundList[orderFundList].choosedTopUp = !selectedData.choosedTopUp;
    this.countFundValue({ ...obj, val: 0 });
  }

  getFundMaster = () => {
    const { agentChannel } = this.props.resAuth.userProfile;
    const { productCode, productCurr, productCategory } = this.props;
    let funds = this.props.fundMaster;
    if (isEmpty(funds)) {
      funds = FundService.getFundMaster(agentChannel, !isEmpty(productCategory) ? productCategory :
        DatabaseUtils.getCategoryFromCode(agentChannel, productCode), productCode, productCurr || 'IDR', this.props.goBack);
    }
    this.setState({ fundMaster: funds }, this.props.onFundReady);
  }

  renderPercent = () => {
    let percent = 0;
    const fund = this.state.fundMaster;
    if (fund && fund.length > 0) fund.map((item) => { percent += item.percentTopUp; return percent; });
    return percent;
  }

  renderFundMasterWarning = () => {
    const fund = this.state.choosedFund;
    if (this.renderPercent() > 100 || this.renderPercent() < 100) return 'Total alokasi dana investasi harus 100%';
    if (fund && fund.length > 0 && fund.find(x => x.valueTopUp === 0)) return 'Alokasi dana investasi harus kelipatan 5%';
    return '';
  }

  render() {
    const {
      label, labelStyle, style, warningStyle, children,
    } = this.props;
    return (
      <View style={[Style.Main.container, style]}>
        {
          this.state.showPremiWarning && this.renderFundMasterWarning() !== '' ?
            <Text style={[Style.Main.textRed, Style.Main.textAlignCenter, Style.Main.mV15, warningStyle]}>{this.renderFundMasterWarning()}</Text> :
            <Text style={isEmpty(this.props.renderWarning) ? [Style.Main.displayNone] :
              [Style.Main.textRed, Style.Main.textAlignCenter, Style.Main.mV15, warningStyle]}
            >{this.props.renderWarning}
            </Text>
        }
        <CardRedHeader
          header={(
            <View style={[Style.Main.rowDirectionSpaceBetween]}>
              <Text style={[Style.Main.textWhite, Style.Main.fontAlbert12, labelStyle]}>{_(label)}</Text>
              <Text style={[Style.Main.textWhite, Style.Main.fontAlbert12, labelStyle]}>{this.renderPercent()}%</Text>
            </View>
          )}
        >
          {children}
          {isEmpty(this.state.fundMaster) ? <ActivityIndicator color={Style.Color.red} style={[Style.Main.center, Style.Main.mV15]} /> :
            this.state.fundMaster.map((itemFundRisk, indexFundRisk) => {
              const orderFundRisk = indexFundRisk;
              const { fundRisk, fundList, percentTopUp } = itemFundRisk;
              const percent_ = percentTopUp;
              const type = 'topup';
              return (
                <AllocationPremi
                  key={orderFundRisk}
                  orderFundRisk={orderFundRisk}
                  fundList={fundList}
                  fundRisk={fundRisk}
                  percent={percent_}
                  type={type}
                  chooseFund={fundParam => this.chooseFund(fundParam)}
                  countFundValue={fundParam => this.countFundValue(fundParam)}
                />
              );
            })
          }
        </CardRedHeader>
      </View>
    );
  }
}

FundAllocation.propTypes = {
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.func, PropTypes.object]),
  productCode: PropTypes.string,
  productCurr: PropTypes.string,
  productCategory: PropTypes.string,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  labelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  warningStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  fundMaster: PropTypes.arrayOf(PropTypes.object),
  onChanged: PropTypes.func,
  onFundReady: PropTypes.func,
  goBack: PropTypes.func,
};

FundAllocation.defaultProps = {
  label: 'Alokasi Dana Investasi yang diinginkan',
  productCode: '',
  productCurr: 'IDR',
  productCategory: null,
  style: null,
  labelStyle: null,
  warningStyle: null,
  fundMaster: null, // if one needs to autopopulate the existing data
  onChanged: () => {},
  onFundReady: () => {},
  goBack: () => {},
};

const mapStateToProps = state => ({
  resAuth: state.auth.res,
});

export default connect(mapStateToProps, null)(FundAllocation);
