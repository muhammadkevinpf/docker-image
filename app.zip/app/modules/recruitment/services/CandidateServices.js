/* eslint-disable no-console */
/* eslint-disable no-prototype-builtins */
/* eslint-disable no-restricted-syntax */
/* eslint-disable no-unused-vars */
import moment from 'moment';
import SQLiteUtils from '../../../utilities/SQLiteUtils';
import Database from '../../../config/Database';

import ApiService from './ApiService';

// const allProcedure = ApiService.getAllProcedure();

/**
 * DB SERVICE
 */

const openDatabase = dbName => new Promise(async (resolve, reject) => {
  try {
    const db = await SQLiteUtils.openDatabase(dbName, 'default');
    resolve(db);
  } catch (error) {
    reject(error);
  }
});

const updateDataToStore = (collection, request, response) => new Promise(async (resolve, reject) => {
  try {
    const listData = getResponseData(response);
    const currentDate = moment(new Date()).format('DD/MM/YYYY HH:mm');

    const querySelect = `SELECT * FROM ${collection.table} WHERE method = ? and agentCode = ?`;
    let queryInsert = `INSERT INTO ${collection.table} VALUES (?,?,?,?)`;
    let queryUpdate = `UPDATE ${collection.table} SET data = ?,createDate = ? WHERE method = ? and agentCode = ?`;
    let selectParam = [collection.method, request.agentCode];
    let updateParam = [JSON.stringify(listData), currentDate, collection.method, request.agentCode];
    let insertParam = [collection.method, request.agentCode, JSON.stringify(listData), currentDate];

    if (request.procedure === 'getListCandidate') {
      queryInsert = `INSERT INTO ${collection.sqliteTable} VALUES (?,?,?,?,?)`;
      queryUpdate = `UPDATE ${collection.sqliteTable} SET data = ?, createDate = ? WHERE method = ? and agentCode = ?`;
      selectParam = [collection.method, request.agentCode, request.page];
      insertParam = [collection.method, request.agentCode, request.page, JSON.stringify(listData), currentDate];
      updateParam = [JSON.stringify(listData), currentDate, collection.method, request.agentCode, request.page];
    }

    const db = await openDatabase(collection.db);
    if (collection.db === 'pruforce') {
      const res = await SQLiteUtils.executeQuery(db, querySelect, selectParam);
      if (res.rows.length > 0) {
        const resUpdate = await SQLiteUtils.executeTransaction(db, queryUpdate, updateParam);
      } else {
        const resInsert = await SQLiteUtils.executeTransaction(db, queryInsert, insertParam);
      }
    }
    resolve(listData);
  } catch (error) {
    reject(error);
  }
});

const upsert = (agentCode, data, collection) => new Promise(async (resolve, reject) => {
  try {
    const arrayData = {};
    // eslint-disable-next-line guard-for-in
    for (const propertyName in data) {
      arrayData[propertyName] = data[propertyName];
    }

    const currentDate = moment(new Date()).format('DD/MM/YYYY HH:mm');
    arrayData.agentId = agentCode;
    arrayData.retrieveDate = currentDate;

    const querySelect = `SELECT * FROM ${collection.table} WHERE method = ? and agentCode = ? and page = ?`;
    const queryInsert = `INSERT INTO ${collection.table} VALUES (?,?,?,?,?)`;
    const queryUpdate = `UPDATE ${collection.table} SET data = ?,createDate = ? WHERE method = ? and agentCode = ? and page = ?`;
    const selectParam = [collection.method, agentCode, 0]; // for offline
    let parameterToProcess = [];
    let resToStore = [];
    let queryToProcess = queryInsert;

    const db = await openDatabase(collection.db);
    const res = await SQLiteUtils.executeQuery(db, querySelect, selectParam);
    if (res.rows.length > 0) {
      resToStore = JSON.parse(res.rows.item(0).data);
      for (let i = 0; i < resToStore.length; i += 1) {
        if (arrayData.id === resToStore[i].id) {
          // replace data
          resToStore[i] = arrayData;
        } else if (arrayData.id === undefined) {
          // set id from latest + 1
          arrayData.id = resToStore.length + 1;
          resToStore.push(arrayData);
        }
      }
      queryToProcess = queryUpdate;
      parameterToProcess = [JSON.stringify(resToStore), currentDate, collection.method, agentCode, 0];
    } else {
      // set initial for id;
      arrayData.id = 1;
      resToStore.push(arrayData);
      parameterToProcess = [collection.method, agentCode, 0, JSON.stringify(resToStore), currentDate];
    }

    const resUpsert = await SQLiteUtils.executeQuery(db, queryToProcess, parameterToProcess);
    resolve(resUpsert);
  } catch (error) {
    reject(error);
  }
});

const replaceDataSQL = (dataToBeRemove, agentCode, collection) => new Promise(async (resolve, reject) => {
  try {
    const currentDate = moment(new Date()).format('DD/MM/YYYY HH:mm');
    const querySelect = `SELECT * FROM ${collection.table} WHERE method = ? and agentCode = ?`;
    const queryReplace = `REPLACE INTO ${collection.table} VALUES(?,?,?,?,?)`;
    const selectParam = [collection.method, agentCode];
    let parameterToProcess = [];
    let resToStore = [];
    let data = [];

    const db = await openDatabase(collection.db);
    console.log(db);
    const res = await SQLiteUtils.executeQuery(db, querySelect, selectParam);
    console.log(res);
    if (res !== undefined) {
      if (res.rows.length > 0) {
        resToStore = JSON.parse(res.rows.item(0).data);
        data = resToStore.filter(x => x.id !== dataToBeRemove);
        parameterToProcess = [agentCode, collection.method, JSON.stringify(data), currentDate];
        const result = await SQLiteUtils.executeQuery(db, queryReplace, parameterToProcess);
        resolve(result);
      }
    }
    resolve();
  } catch (error) {
    reject(error);
  }
});

/**
 * API SERVICE
 */

/**
  *
  * @param {*} request
  * @param {*} isOnline
  * return candidate phoneNumber
  */
const verifyCalonCandidate = (request, isOnline) => new Promise(async (resolve, reject) => {
  try {
    // verify
    const allProcedure = ApiService.getAllProcedure();
    const collection = allProcedure[request.procedure];
    const respAVerify = await ApiService.requestToApi(request);
    resolve(respAVerify.result);
  } catch (error) {
    reject(error);
  }
});

const getData = (request, isOnline) => new Promise(async (resolve, reject) => {
  try {
    const allProcedure = ApiService.getAllProcedure();
    const collection = allProcedure[request.procedure];
    const responseApi = await ApiService.requestToApi(request);
    console.log(responseApi);
    const result = await getResponseData(request, responseApi);
    resolve(result);
  } catch (error) {
    reject(error);
  }
});


const getResponseData = (request, response) => new Promise(async (resolve, reject) => {
  let result = [];
  try {
    const retrieveDate = moment(new Date()).format('DD/MM/YYYY HH:mm');
    const npa = request.parameters.params[0];
    switch (request.procedure) {
      case 'AplicationPackData':
        result = response;
        break;
      case 'getListCandidate':
        result = response.array;
        break;
      default:
        try {
          let data = {};
          for (let i = 0; i < response.array.length; i += 1) {
            data = {};
            data.result = response.array[i];
            data.agentId = result.agentId;
            data.npa = npa;
            data.retrieveDate = result.retrieveDate;
            result[i] = data;
          }
        } catch (error) {
          result = [];
        }
        break;
    }
    resolve(result);
  } catch (error) {
    reject(error);
  }
});

export default {
  verifyCalonCandidate,
  upsert,
  replaceDataSQL,
};
