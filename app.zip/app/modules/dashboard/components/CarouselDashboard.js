/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

/* eslint-disable react-native/no-inline-styles */

import React, { Component } from 'react';
import {
  View, Image, Dimensions, Platform,
} from 'react-native';
import Carousel from 'react-native-carousel-view';

import Styles from '../../../styles';

class CarouselDashboard extends Component {
  constructor() {
    super();

    this.state = {
      width: Dimensions.get('window').width,
      height: this.aspectRatioHeight(Dimensions.get('window').width),
    };
  }

  componentDidMount() {
    this.refreshDimensions();

    Dimensions.addEventListener('change', () => {
      this.refreshDimensions();
    });
  }

  refreshDimensions = () => {
    if (this.refView) {
      this.setState({
        width: Dimensions.get('window').width,
        height: this.aspectRatioHeight(Dimensions.get('window').width),
      });
    }
  }

  aspectRatioHeight = width => (width / 2) * 1 // aspect ratio, / 2 * 1 means 2:1

  renderItems = data => data.map((item, i) => (
    <View
      key={i.toString()}
      style={{
        flex: 1,
        height: this.state.height,
      }}
    >
      <Image
        style={{
          flex: 1,
          width: 'auto',
        }}
        source={item.thumbnail}
      />
    </View>
  ))

  render() {
    return (
      <View
        ref={(c) => { this.refView = c; }}
        style={{
          width: this.state.width,
          height: this.state.height,
          margin: 0,
          marginBottom: 40,
          padding: 0,
        }}
      >
        <Carousel
          width={this.state.width}
          height={this.state.height}
          indicatorColor={Styles.Color.red}
          indicatorSize={Platform.OS === 'ios' ? 11 : 19}
          indicatorOffset={Platform.OS === 'ios' ? -24 : -28}
          delay={3000}
          loop
        >
          { this.renderItems(this.props.data) }
        </Carousel>
      </View>
    );
  }
}

export default CarouselDashboard;
