/* eslint-disable */
import { PermissionsAndroid, Platform } from 'react-native';
import _ from '../../app/lang';

export const STORAGE_PERMISSIONS = [
  PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
  PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
  PermissionsAndroid.PERMISSIONS.CAMERA,
  PermissionsAndroid.PERMISSIONS.READ_CONTACTS,
];

export const check = async (permission) => {
  if (Platform.OS === 'ios') return true;
  const result = await PermissionsAndroid.check(permission);
  return result;
};

export const request = async (permission) => {
  
  const granted = await PermissionsAndroid.request(permission);
  if (granted === PermissionsAndroid.RESULTS.GRANTED) {
    return true;
  }
  return false;
};

export const requestMultiplePermission = async (arrayPermission) => {
  
  const granted = await PermissionsAndroid.requestMultiple(arrayPermission);
  if (granted === PermissionsAndroid.RESULTS.GRANTED) {
    return true;
  }
  return false;
};

export const checkAndRequest = async (permissions) => {
  
  let checkPermissionResult = '';
  let result = false;
  if (permissions instanceof Array) {
    permissions.forEach(async (permission) => {
      result = await check(permission);
      if (!result) {
        // checkPermissionResult += `You Need ${permission} for this action.`;
        await request(permission);
      }
      // if (checkPermissionResult !== '') {
      //   Alert.alert(_('Denied'),
      //     checkPermissionResult,
      //     [
      //       {
      //         text: _('Request Permission'),
      //         onPress: async () => {
      //           await request(permission);
      //         },
      //       },
      //     ]);
      // }
    });
  } else {
    result = await check(permissions);
    if (!result) {
      // checkPermissionResult += `You Need ${permissions} for this action.`;
      await request(permissions);
    }
    // if (checkPermissionResult !== '') {
    //   Alert.alert(_('Denied'),
    //     checkPermissionResult,
    //     [
    //       {
    //         text: _('Request Permission'),
    //         onPress: async () => {
    //           await request(permissions);
    //         },
    //       },
    //     ]);
    // }
  }
};
