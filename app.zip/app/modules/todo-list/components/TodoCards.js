/* eslint-disable no-console */
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import { View, Text, Card } from 'native-base';
import { TouchableOpacity } from 'react-native-gesture-handler';
import Style from '../../../styles';
import _ from '../../../lang';
import { CoverageText, Skeleton } from '../../../components';
import { isEmpty, DatabaseUtils, toFixedCurrency } from '../../../utilities';

const cardStyle = [
  Style.Main.rowDirectionSpaceBetween, Style.Main.fullWidth,
];

const skeletonLayout = [
  {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    height: 9,
    marginVertical: 3,
    children: [
      {
        width: '35%',
        height: '100%',
        borderRadius: 1,
      },
      {
        width: '15%',
        height: '100%',
        borderRadius: 1,
      },
    ],
  },
  {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    height: 9,
    marginVertical: 3,
    children: [
      {
        width: '50%',
        height: '100%',
        borderRadius: 1,
      },
      {
        width: '25%',
        height: '100%',
        borderRadius: 1,
      },
    ],
  },
];
class NTUCard extends PureComponent {
  render() {
    const Tag = this.props.noCard ? View : Card;
    return (
      <Tag style={[Style.Main.padding10, this.props.noCard && Style.Main.borderBottomNativeBase]}>
        <TouchableOpacity
          activeOpacity={this.props.noCard ? 0.5 : 1}
          onPress={() => (this.props.isLoading ? {} : this.props.onCardClicked())}
          style={cardStyle}
        >
          <Skeleton isLoading={this.props.isLoading} layout={skeletonLayout}>
            <View style={cardStyle}>
              <View style={[Style.Main.flex8]}>
                <Text style={[Style.Main.fontAlbertBold14]}>{this.props.label ? this.props.label.toUpperCase() : 'N/A'}</Text>
                <Text style={[Style.Main.fontAlbert11]}>{`${_('Nomor SPAJ')} ${this.props.policyNumber}`}</Text>
                {
                !isEmpty(this.props.product) &&
                <CoverageText style={[Style.Main.fontAlbert11]} desc={DatabaseUtils.toCoverageFormat(this.props.product)} />
              }
              </View>
              <View style={[Style.Main.alignEnd, Style.Main.flex5]}>
                <Text style={[Style.Main.textRed, Style.Main.italic, Style.Main.fontAlbert11]}>{this.props.status}</Text>
                <Text style={[Style.Main.italic, Style.Main.fontAlbert11]}>
                  {_('Jumlah Follow Up ')}
                  <Text style={[Style.Main.textRed, Style.Main.italic, Style.Main.fontAlbert11]}>{this.props.followUpNumber}</Text>
                </Text>
              </View>
            </View>
          </Skeleton>
        </TouchableOpacity>
      </Tag>
    );
  }
}

NTUCard.propTypes = {
  onCardClicked: PropTypes.func,
  label: PropTypes.string,
  policyNumber: PropTypes.string,
  product: PropTypes.string,
  status: PropTypes.string,
  followUpNumber: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  noCard: PropTypes.bool,
};

NTUCard.defaultProps = {
  onCardClicked: () => {},
  label: '-',
  policyNumber: '',
  product: '',
  status: '-',
  followUpNumber: 0,
  noCard: false,
};

class AfterDueDateCard extends PureComponent {
  render() {
    const getCurrency = value => (value === undefined ? null : toFixedCurrency(value, 2, this.props.currency || 'Rp'));

    return (
      <Card style={[Style.Main.padding10]}>
        <TouchableOpacity
          activeOpacity={this.props.touchable ? 0.5 : 1}
          onPress={this.props.onCardClicked}
          style={cardStyle}
        >
          <View style={[Style.Main.flex8]}>
            <Text style={[Style.Main.fontAlbertBold14]}>{this.props.label.toUpperCase()}</Text>
            <Text style={[Style.Main.fontAlbert11]}>{`${_('Nomor Polis')} ${this.props.policyNumber}`}</Text>
            <Text style={[Style.Main.fontAlbert11]}>
              {_('Jatuh Tempo ')}
              <Text style={[Style.Main.fontAlbertBold11]}>{moment(this.props.paidToDate).format('DD MMMM YYYY')}</Text>
            </Text>
            <CoverageText style={[Style.Main.fontAlbert11]} desc={DatabaseUtils.toCoverageFormat(this.props.product)} />
            {/* <Text style={[Style.Main.fontAlbert11]}>{this.props.product}</Text> */}
            {
              this.props.isBefore &&
              <View>
                <Text style={[Style.Main.fontAlbert11]}>
                  {_('Issued Date ')}
                  <Text style={[Style.Main.fontAlbertBold11]}>{moment(this.props.issuedDate).format('DD MMMM YYYY')}</Text>
                </Text>
                <Text style={[Style.Main.fontAlbert11]}>{`${_('Jumlah Premi/Kontribusi')} ${getCurrency(this.props.premium)}`}</Text>
              </View>
            }
          </View>
          <View style={[Style.Main.alignEnd, Style.Main.flex5]}>
            <Text style={[Style.Main.italic, Style.Main.textGreen, Style.Main.fontAlbert11]}>{this.props.status}</Text>
          </View>
        </TouchableOpacity>
      </Card>
    );
  }
}

AfterDueDateCard.propTypes = {
  onCardClicked: PropTypes.func,
  label: PropTypes.string,
  policyNumber: PropTypes.string,
  product: PropTypes.string,
  status: PropTypes.string,
  paidToDate: PropTypes.oneOfType([PropTypes.object, PropTypes.func, PropTypes.string]),
  touchable: PropTypes.bool,
};

AfterDueDateCard.defaultProps = {
  onCardClicked: () => {},
  label: '-',
  policyNumber: '',
  product: '',
  status: '-',
  paidToDate: null,
  touchable: true,
};

class TransferHistoryCard extends PureComponent {
  render() {
    const { data } = this.props;
    return (
      <Card style={[Style.Main.padding10]}>
        <View style={[Style.Main.flex8, Style.Main.columnDirectionSpaceBetween]}>
          <Text style={[Style.Main.fontAlbertBold14, Style.Main.mb4]}>{data.agentName.toUpperCase()}</Text>
          <Text style={[Style.Main.fontAlbert11, Style.Main.mb4]}>{data.agentNumber}</Text>
          <Text style={[Style.Main.fontAlbert11, Style.Main.mb4]}>
            {_('Tanggal  Mulai Servis: ')}
            <Text style={[Style.Main.fontAlbert11]}>{moment(data.startDate).format('DD MMMM YYYY')}</Text>
          </Text>
        </View>
        {data.isCurrentAgent && (
        <View style={[Style.Main.alignEnd, Style.Main.flex5]}>
          <Text style={[Style.Main.textRed, Style.Main.fontAlbert11]}>{_('Agen saat ini')}</Text>
        </View>)}
      </Card>
    );
  }
}

TransferHistoryCard.propTypes = {
  // eslint-disable-next-line react/forbid-prop-types
  data: PropTypes.object.isRequired,
};

class BirthdayInfoCard extends PureComponent {
  render() {
    const Tag = this.props.noCard ? View : Card;
    return (
      <Tag style={[Style.Main.padding10, this.props.noCard && Style.Main.borderBottomNativeBase]}>
        <TouchableOpacity
          activeOpacity={this.props.noCard ? 0.5 : 1}
          onPress={() => (this.props.isLoading ? {} : this.props.onCardClicked())}
          style={cardStyle}
        >
          <Skeleton isLoading={this.props.isLoading} layout={skeletonLayout}>
            <View style={cardStyle}>
              <View style={[Style.Main.flex8]}>
                <Text style={[Style.Main.fontAlbert11, Style.Main.textColor3f3]}>{this.props.name.toUpperCase()}</Text>
                <Text style={[Style.Main.fontAlbert11, Style.Main.gray83]}>{this.props.desc}</Text>
              </View>
              <View style={[Style.Main.alignEnd, Style.Main.flex5, Style.Main.ml5]}>
                <Text style={[Style.Main.fontAlbert11, Style.Main.textColor3f3]}>{`${this.props.age} ${_('Tahun')}`}</Text>
                <Text style={[Style.Main.fontAlbert11, Style.Main.textColor3f3]}>{this.props.birthday}</Text>
              </View>
            </View>
          </Skeleton>
        </TouchableOpacity>
      </Tag>
    );
  }
}

BirthdayInfoCard.propTypes = {
  onCardClicked: PropTypes.func,
  name: PropTypes.string,
  desc: PropTypes.string,
  age: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  birthday: PropTypes.oneOfType([PropTypes.object, PropTypes.func, PropTypes.string]),
  noCard: PropTypes.bool,
};

BirthdayInfoCard.defaultProps = {
  onCardClicked: () => {},
  name: '-',
  desc: '',
  age: 0,
  birthday: null,
  noCard: false,
};


export {
  AfterDueDateCard,
  BirthdayInfoCard,
  NTUCard,
  TransferHistoryCard,
};
