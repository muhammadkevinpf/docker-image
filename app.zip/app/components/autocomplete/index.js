/**
 * @author: ahmdichsanb@gmail.com
 * Note: value cleared when focus, onblur will make value return to remained/new selected value
*/

import React, { PureComponent, Fragment } from 'react';
import {
  // eslint-disable-next-line no-unused-vars
  Text, View, FlatList, TouchableHighlight, ScrollView, ViewPropTypes,
} from 'react-native';
import filter from 'lodash/filter';
import PropTypes from 'prop-types';
import InputField from '../input-field';
import StyleAutocomplete from './StyleAutocomplete';
import Style from '../../styles';

class Autocomplete extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      dropdownData: [],
      suggestionList: props.dropdownData,
      inputFieldValue: props.autoCompleteValue[props.labelProperty],
      isSuggestionOpen: false,
      isOnPressActive: false,
      // eslint-disable-next-line react/no-unused-state
      isInitialLoad: true,
      onChangeText: false,
    };
  }

  static getDerivedStateFromProps = (props, state) => {
    if (state.isInitialLoad) {
      if (props.autoCompleteValue[props.labelProperty]) {
        if (props.autoCompleteValue[props.labelProperty] !== state.inputFieldValue) {
          return {
            inputFieldValue: props.autoCompleteValue[props.labelProperty],
            isInitialLoad: false,
            dropdownData: props.dropdownData,
          };
        }
      }
    } else if (state.isOnPressActive && props.autoCompleteValue.label !== state.inputFieldValue) {
      return {
        inputFieldValue: props.autoCompleteValue[props.labelProperty],
        isOnPressActive: false,
      };
    }

    return {
      dropdownData: props.dropdownData,
    };
  };

  handleOnPress = (autoCompleteValue) => {
    let { isOnPressActive } = this.state;

    this.props.onPress(autoCompleteValue);

    isOnPressActive = true;
    this.setState({ isSuggestionOpen: false, isOnPressActive });
  }

  handleOnFocus = () => {
    const { dropdownData } = this.state;
    this.setState({ isSuggestionOpen: true, inputFieldValue: '', suggestionList: dropdownData });
  }

  handleOnBlur = () => {
    const { autoCompleteValue, labelProperty } = this.props;
    this.setState({ isSuggestionOpen: false, inputFieldValue: autoCompleteValue[labelProperty], onChangeText: false });
  }

  handleOnChangeText = (inputFieldValue) => {
    const { dropdownData } = this.state;
    const { valueProperty, labelProperty } = this.props;
    let suggestionList = filter(dropdownData, item => item[labelProperty].toLowerCase().indexOf(inputFieldValue.toLowerCase()) > -1);

    this.setState({ onChangeText: true });
    if (this.props.onFocus && inputFieldValue.length === 1 && !this.state.onChangeText) {
      this.props.onFocus();
    }

    if (inputFieldValue.length < 1) {
      this.setState({ inputFieldValue, suggestionList: dropdownData, isSuggestionOpen: true });
      return;
    }

    if (suggestionList.length < 1) {
      suggestionList = [{}];
      suggestionList[0][labelProperty] = 'Data Tidak Ditemukan';
      suggestionList[0][valueProperty] = 'nodata';
      this.setState({ inputFieldValue, suggestionList, isSuggestionOpen: true });
      return;
    }

    this.setState({ inputFieldValue, suggestionList, isSuggestionOpen: true });
  }

  render() {
    const {
      enabled, placeholder, isRequired, styleTextInput, numberOfLines, underlayColor,
      labelProperty, valueProperty,
    } = this.props;
    const { inputFieldValue, suggestionList, isSuggestionOpen } = this.state;

    return (
      <Fragment>
        <InputField
          type="text"
          onChangeText={e => this.handleOnChangeText(e)}
          onFocus={() => this.handleOnFocus()}
          onBlur={() => this.handleOnBlur()}
          value={inputFieldValue}
          placeholder={placeholder}
          styleTextInput={styleTextInput}
          numberOfLines={numberOfLines}
          editable={enabled}
          isRequired={isRequired}
        />
        {
          isSuggestionOpen && (
          <ScrollView
            keyboardShouldPersistTaps="handled"
            nestedScrollEnabled
          >
            <FlatList
              style={[StyleAutocomplete.flatList]}
              data={suggestionList}
              keyboardShouldPersistTaps="handled"
              keyExtractor={item => item[valueProperty]}
              nestedScrollEnabled
              renderItem={({ item, index }) => (
                <TouchableHighlight
                  onPress={() => (item[valueProperty] !== 'nodata' ? this.handleOnPress(item) : () => {})}
                  underlayColor={underlayColor}
                  key={index}
                >
                  <View style={[Style.Main.font12, Style.Main.fontAlbert, Style.Main.gray83, Style.Main.pl6,
                    Style.Main.pr6, Style.Main.pt6, Style.Main.pb5]}
                  >
                    <Text style={[Style.Main.fontAlbert]}>{item[labelProperty]}</Text>
                  </View>
                </TouchableHighlight>
              )}
            />
          </ScrollView>
          )
        }
      </Fragment>
    );
  }
}

Autocomplete.propTypes = {
  enabled: PropTypes.bool,
  placeholder: PropTypes.string,
  isRequired: PropTypes.bool,
  numberOfLines: PropTypes.number,
  underlayColor: PropTypes.string,
  onPress: PropTypes.func.isRequired,
  autoCompleteValue: PropTypes.objectOf(PropTypes.oneOfType([PropTypes.string, PropTypes.number])).isRequired,
  dropdownData: PropTypes.arrayOf(PropTypes.object).isRequired,
  styleTextInput: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  labelProperty: PropTypes.string,
  valueProperty: PropTypes.string,
};

Autocomplete.defaultProps = {
  enabled: true,
  placeholder: 'Type here',
  isRequired: false,
  numberOfLines: 1,
  underlayColor: '#E0E0E0',
  styleTextInput: StyleAutocomplete.styleTextInput,
  labelProperty: 'label',
  valueProperty: 'value',
};

export default Autocomplete;
