
/* eslint-disable no-console */
/* eslint-disable react/no-array-index-key */

import React, { Component } from 'react';
import { ScrollView } from 'react-native-gesture-handler';
import { connect } from 'react-redux';
import { View, Text } from 'native-base';
import { Dimensions, Platform } from 'react-native';
import Configs from './ConfigSubMenu';
import LoadingModal from '../loading_modal';
import Style from '../../styles';
import Colors from '../../styles/Colors';
import _ from '../../lang';
import { isEmpty, isTablet } from '../../utilities';

const dimensions = Dimensions.get('window').width;

const {
  subMenuGroups, ProductionRoutes, PersitencyRoutes, ProposalPolicyRoutes, IncomeStatementRoutes, CommissionEstimationRoutes,
} = Configs;


class SubMenuComponent extends Component {
  labelStyle = [
    { backgroundColor: Colors.darkRed }, Style.Main.fullHeight,
    Style.Main.textAlignVerticalCenter, Style.Main.textCenter, Style.Main.container, Style.Main.fontAlbert14, Style.Main.textWhite,
    Platform.OS === 'ios' && Style.Main.pt5,
  ];

  constructor(props) {
    super(props);
    this.opt = {
      achievement: [
        { label: _('Produksi'), route: 'MainProduction', isActive: ProductionRoutes.some(x => x === this.props.navigation.state.routeName) },
        { label: _('Persistensi'), route: 'MainPersistency', isActive: PersitencyRoutes.some(x => x === this.props.navigation.state.routeName) },
        { label: _('Status'), route: 'MainProposalPolicy', isActive: ProposalPolicyRoutes.some(x => x === this.props.navigation.state.routeName) },
      ],
      cps: [
        {
          label: _('Komisi'),
          route: 'MainCommissionEstimation',
          isActive: CommissionEstimationRoutes.some(x => x === this.props.navigation.state.routeName),
        }, {
          label: _('Pendapatan'),
          route: 'MainIncomeStatement',
          isActive: IncomeStatementRoutes.some(x => x === this.props.navigation.state.routeName),
        },
      ],
      leads: [
        { label: _('Aktivitas'), route: 'ProspectList', isActive: Configs.ProspectRoutes.some(x => x === this.props.navigation.state.routeName) },
        { label: _('Dashboard'), route: 'AMDashboard', isActive: Configs.DashboardRoutes.some(x => x === this.props.navigation.state.routeName) },
        { label: _('Kalender'), route: 'AMCalendar', isActive: Configs.CalendarRoutes.some(x => x === this.props.navigation.state.routeName) },
      ],
      document: [
        {
          label: _('Korespondensi'),
          route: 'CorrespondenceList',
          isActive: Configs.CorrespondenceRoutes.some(x => x === this.props.navigation.state.routeName),
        }, {
          label: _('Download File'),
          route: 'DownloadFileList',
          isActive: Configs.DownloadFileRoutes.some(x => x === this.props.navigation.state.routeName),
        },
      ],
    };
    this.state = {
      loading: false,
    };
  }

  render() {
    if (this.props.subMenus) {
      const width = isTablet() ? dimensions - this.props.sideBarWidth : dimensions;
      return (
        <ScrollView
          ref={(ref) => { this.scrollview_ref = ref; }}
          style={[Style.Main.height30, { minWidth: dimensions, backgroundColor: Colors.darkRed }]}
          showsHorizontalScrollIndicator={false}
          horizontal
        >
          <View style={[Style.Main.rowDirection, Style.Main.fullHeight]}>
            {
              this.opt[this.props.subMenus].map((item, index) => (
                <Text
                  style={[
                    this.labelStyle,
                    item.isActive && Style.Main.backgroundRed,
                    { minWidth: isEmpty(this.opt[this.props.subMenus]) ? width : width / this.opt[this.props.subMenus].length },
                  ]}
                  key={index}
                  onPress={this.props.navigation.state.routeName !== item.route ? () => this.props.navigation.replace(item.route) : () => {}}
                >{item.label}
                </Text>
              ))
            }
          </View>
          <LoadingModal show={this.state.loading} size="large" color="white" />
        </ScrollView>
      );
    }
    return <View style={[Style.Main.displayNone]} />;
  }
}

const mapStateToProps = state => ({
  sideBarWidth: state.bootstrap.sideBarWidth,
});

const SubMenu = connect(mapStateToProps, null)(SubMenuComponent);

export {
  SubMenu,
  subMenuGroups,
};
