/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import { Image, BackHandler } from 'react-native';
import {
  Container, Content,
  Button, Text, Icon, View, Footer,
} from 'native-base';
import _ from '../../../lang';
import Style from '../../../styles';
import bg from '../../../assets/images/bg.png';

class SignUpHome extends Component {
  componentDidMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleBack();
      return true;
    });
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  handleBack = () => {
    this.props.navigation.replace('SignInHome');
  }

  render() {
    return (
      <Container>
        <Image source={bg} style={Style.Main.bgImage} />
        <View>
          <Button
            transparent
            iconLeft
            onPress={() => this.props.navigation.replace('SignInHome')}
          >
            <Icon name="angle-left" type="FontAwesome" style={[Style.Main.textRed]} />
            <Text style={[Style.Main.textRed]}>{_('Back')}</Text>
          </Button>
        </View>
        <Content style={[Style.Main.container]} keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
          <Text
            style={[Style.Main.font44, Style.Main.textRed, Style.Main.mt64, Style.Main.textAlignCenter, Style.Main.fontBold, Style.Main.mb55]}
          >PRUFast
          </Text>
          <Text
            style={[Style.Main.font18, Style.Main.textColor3f3, Style.Main.textAlignCenter]}
          >{_('Daftar PRUFast')}
          </Text>
          <View
            style={[Style.Main.container]}
          >
            <Button
              rounded
              transparent
              style={[Style.Main.alignCenter, Style.Main.backgroundWhite, Style.Main.mt20,
                Style.Main.width187, Style.Main.dialogBtnCnt, Style.Main.itemCenter, Style.Main.borderRed]}
              onPress={() => this.props.navigation.replace('SignUpAgentHome')}
            >
              <Text
                style={[Style.Main.textAlmostBlack]}
              >{_('AGEN')}
              </Text>
            </Button>
          </View>
          <View
            style={[Style.Main.container]}
          >
            <Button
              rounded
              transparent
              style={[Style.Main.alignCenter, Style.Main.backgroundWhite, Style.Main.mt20,
                Style.Main.width187, Style.Main.dialogBtnCnt, Style.Main.itemCenter, Style.Main.borderRed]}
              onPress={() => this.props.navigation.replace('SignUpNonAgentHome')}
            >
              <Text
                style={[Style.Main.textAlmostBlack]}
              >{_('CALON AGEN')}
              </Text>
            </Button>
          </View>
        </Content>
        <Footer
          style={[Style.Main.backgroundF9]}
        >
          <View
            style={[Style.Main.container, Style.Main.dialogBtnCnt, Style.Main.itemCenter]}
          >
            <Text
              style={[Style.Main.textCenter, Style.Main.container,
                Style.Main.font12]}
            >
              {_('Sudah memiliki PRUFast ID? ')}
              <Text
                style={[Style.Main.font12, Style.Main.textRed]}
                onPress={() => this.props.navigation.replace('SignInHome')}
              >{_('Masuk')}
              </Text>
            </Text>
          </View>
        </Footer>
      </Container>
    );
  }
}

export default SignUpHome;
