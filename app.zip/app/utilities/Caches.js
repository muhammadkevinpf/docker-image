module.exports = {
  cache: {},
  get(key) { return this.cache[key]; },
  set(key, val) { this.cache[key] = val; },
  dumpCache() { return this.cache; }, // this just for testing purpose
};
