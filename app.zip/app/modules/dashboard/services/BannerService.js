export const splitBase64 = (base64Data) => {
  const result = [];
  const splitLength = 102400;
  for (let i = 0; i < base64Data.length; i += splitLength) {
    result.push(base64Data.substr(i, splitLength));
  }
  return result;
};
