/* eslint-disable max-len */
import React from 'react';
import { Text } from 'native-base';
import Style from '../../../styles';
import SpajStyles from '../StyleSpaj';
import { DatabaseUtils } from '../../../utilities';
import { CoverageText, CoverageHTML } from '../../../components/pru-text/CoverageText';

export const diclaimer = (product, isHtml) => ({
  VMA: {
    title: 'PERNYATAAN CALON PEMEGANG POLIS',
    subtitle: '(selanjutnya disebut “SAYA”, harap dibaca dengan teliti sebelum menandatangani SPAJ ini)',
    statement: 'SAYA menyatakan bahwa telah mengerti dan telah mendapat penjelasan sepenuhnya dari Financial Services Consultant (FSC) dan selanjutnya menyatakan setuju mengenai hal-hal yang tersebut di bawah ini:',
    point: [
      {
        text: `Semua keterangan yang SAYA berikan di dalam SPAJ ini dan keterangan lain yang SAYA berikan kepada PT Prudential Life Assurance (selanjutnya disebut “Penanggung”) atau FSC atau kepada Pemeriksa Kesehatan yang ditunjuk oleh Penanggung dan/atau keterangan yang tertulis di dalam dokumen SPAJ tambahan, kuesioner dan/atau dokumen lain yang menjadi kelengkapan dan tidak terpisahkan dari SPAJ ini adalah benar dan tidak ada hal-hal lain yang SAYA sembunyikan, baik yang saya ketahui maupun tidak ketahui. Semua keterangan yang SAYA berikan di dalam SPAJ (termasuk yang ditulis di dalam Surat Pernyataan/Amandemen untuk SPAJ/SPAJT/Pengajuan pelayanan Polis) dan/atau Kuesioner (jika ada) dan yang
        disampaikan kepada Pemeriksa Kesehatan yang ditunjuk oleh Penanggung (jika ada) akan menjadi dasar bagi Penanggung
        dalam penerbitan Polis.`,
      },
      {
        text: `SAYA sendiri yang melengkapi dan menandatangani SPAJ ini serta telah menerima, memahami, dan menyetujui lembar
        ilustrasi yang menjelaskan Manfaat Asuransi dan jenis Dana Investasi ${formatedPrulink(isHtml)} yang telah disampaikan oleh FSC. Segala risiko
        pemilihan manfaat asuransi dan jenis Dana Investasi ${formatedPrulink(isHtml)} sepenuhnya menjadi tanggung jawab SAYA.`,
      },
      {
        text: 'Bahwa Penanggung dapat meminta dokumen berupa bukti penghasilan atau dokumen lainnya yang diperlukan untuk memastikan kesesuaian profil SAYA dan/atau Calon Tertanggung dan/atau Calon Pembayar Premi. Dalam hal dokumen yang diperlukan tersebut tidak diterima Penanggung atau dokumen yang diperlukan tersebut mempunyai informasi yang berbeda dan/atau tidak lengkap dengan informasi yang sebelumnya diterima oleh Penanggung, maka SAYA menyetujui bahwa Penanggung berhak menangguhkan transaksi apapun yang SAYA ajukan dengan memberikan pemberitahuan kepada SAYA.',
      },
      {
        text: `Tanpa mengesampingkan ketentuan pada Point D (Ketentuan Pertanggungan Manfaat Meninggal Dunia Karena Kecelakaan sebelum Polis Diterbitkan), pertanggungan tidak akan dimulai sebelum Polis diterbitkan. Jika terjadi peristiwa yang ditanggung dalam Polis sebelum tanggal Polis diterbitkan, atau SAYA tidak melengkapi persyaratan pengajuan asuransi yang diminta oleh Penanggung dalam waktu 60 hari sejak SPAJ terdaftar di Kantor Pusat Penanggung, atau SAYA membatalkan pengajuan asuransi kepada Penanggung, maka Penanggungan tidak berkewajiban untuk membayar manfaat apapun kecuali mengembalikan Premi (jika telah dibayarkan oleh SAYA) dikurangi semua biaya pemeriksaan kesehatan yang timbul (jika
          ada) tanpa disertai hasil investasi.`,
      },
      {
        text: `Pertanggungan akan dinilai ulang oleh Penanggung apabila terdapat pemeriksaan kesehatan yang dilakukan sebelum Polis
        terbit di luar pengetahuan Penanggung, yang hasilnya dapat memengaruhi/mengubah keputusan ${formatedUnderwriting(isHtml)} (Seleksi Risiko) dan/atau apabila terdapat keterangan, pernyataan atau pemberitahuan yang disampaikan (termasuk pernyataan sebagaimana dimaksud dalam butir 3 di atas) ternyata keliru atau berbeda atau berubah yang sifatnya sedemikian rupa sehingga pertanggugan dan/atau Polis dapat menjadi batal dan dianggap tidak pernah berlaku dan atas hal tersebut Penanggung tidak berkewajiban membayar apapun selain Biaya Asuransi dan Nilai Tunai (jika ada).`,
      },
      {
        text: 'Bahwa jika Penanggung melakukan pembayaran dana, Penanggung harus tunduk kepada aturan yang berlaku di Indonesia maupun sesuai standar Grup Prudential, di antaranya adalah diperlukannya tambahan proses tertentu jika SAYA termasuk dalam daftar sanksi tertentu.',
      },
      {
        text: 'Semua Pembayaran Premi harus sudah diterima di rekening Penanggung dan telah teridentifikasi.',
      },
      {
        text: `Jika terdapat perubahan jenis Dana Investasi ${formatedPrulink(isHtml)}, alokasi Dana Investasi ${formatedPrulink(isHtml)}, besar maupun komposisi Premi, termasuk tetapi tidak terbatas pada dikenakannya keputusan tidak standar pada pengajuan asuransi SAYA, maka Tanggal Perhitungan Harga Unit menjadi Tanggal Perhitungan berikutnya setelah diterimanya pemberitahuan perubahan jenis Dana Investasi ${formatedPrulink(isHtml)}, alokasi Dana Investasi ${formatedPrulink(isHtml)}, besar maupun komposisi Premi, Surat Persetujuan Keputusan Tidak Standar atas SPAJ ini atau teridentifikasinya seluruh pembayaran Premi Pertama di Kantor Pusat Penanggung, mana yang
        paling akhir.`,
      },
      {
        text: `Ketentuan pembentukan Unit dari Premi Pertama untuk investasi sebagaimana dijelaskan pada Poin C.3 di bawah ini
        otomatis menjadi batal apabila SAYA membatalkan SPAJ SAYA, atau pengajuan SPAJ SAYA dibatalkan/ditangguhkan/ditolak oleh Penaggung. Apabila dengan kebijakan khusus kemudian Penanggung setuju untuk menerbitkan Polis setelah sebelumnya SPAJ SAYA dibatalkan/ditangguhkan/ditolak oleh Penanggung, maka dengan ini SAYA menyetujui bahwa pembentukan Unit dari Premi. Pertama untuk Investasi yang pernah dilakukan tersebut akan tetap dibatalkan dan pembentukan Unit dari
        Premi Pertama untuk investasi (atas dikeluarkannya kebijakan khusus tersebut) akan mengikuti Harga Unit terdekat berikutnya setelah Polis diterbitkan.`,
      },
      {
        text: 'Jika SPAJ ini merupakan SPAJ pengganti, maka premi yang telah dibayarkan pada SPAJ sebelumnya dimana SAYA dan Calon Tertanggung merupakan orang yang sama, maka secara otomatis akan dialihkan ke SPAJ ini. Dalam hal pada SPAJ sebelumnya SAYA melampirkan Surat Kuasa Pendebitan Kartu Kredit (SKPKK) atau Surat Kuasa Pendebitan Rekening (SKPR), SAYA mengerti bahwa untuk SPAJ ini, SAYA perlu melampirkan SKPKK atau SKPR baru.',
      },
      {
        text: 'Bahwa pada waktu SAYA mengajukan klaim Manfaat Asuransi, Penanggung berhak meminta bukti keabsahan hubungan keterikatan asuransi antara Pemegang Polis, Tertanggung dan Penerima Manfaat. Dalam hal hubungan antara Pemegang Polis, Tertanggung dan PenerimaManfaat terdapat perbedaan dengan yang tertulis di SPAJ ini (tidak bisa diverifikasi), Penanggung berhak meminta dokumen pendukung yang wajar dan relevan dengan pengajuan klaim.',
      },
      {
        text: 'Bahwa pada waktu SAYA mengajukan klaim Manfaat Asuransi, Penanggung berhak meminta kesesuaian profil finansial SAYA dan/atau Tertanggung dan/atau Pembayar Premi. Dalam hal terdapat perbedaan pada profil finansial SAYA dan/atau Tertanggung dan/atau Pembayar Premi dengan yang tertulis di SPAJ ini (tidak bisa diverifikasi), Penanggung berhak meminta dokumen pendukung yang wajar dan relevan dengan pengajuan klaim.',
      },
      {
        text: 'SAYA dan/atau Calon Tertanggung, dengan ini memberikan kuasa dan izin kepada:',
        subtext: [
          {
            text: `Penanggung untuk meminta catatan riwayat kesehatan Calon Tertanggung atau informasi lain mengenai diri Calon
            Tertanggung dari setiap tenaga medis, rumah sakit, klinik, puskesmas, laboratorium, perusahaan asuransi, perusahaan reasuransi, badan, instansi/lembaga atau pihak lain yang mempunyai catatan/informasi riwayat kesehatan atau informasi lain mengenai diri Calon Tertanggung; dan`,
          },
          {
            text: 'setiap tenaga medis, rumah sakit, klinik, puskesmas, laboratorium, perusahaan asuransi atau perusahaan reasuransi, badan, instansi/lembaga atau pihak lain yang mempunyai catatan riwayat kesehatan atau informasi lain mengenai diri Calon Tertanggung untuk mengungkapkan atau memberikan kepada Penanggung semua catatan riwayat kesehatan, atau perawatan atau informasi lain mengenai diri Calon Tertanggung.',
          },
        ],
        subtexttype: 'i',
        endtext: 'Pemberian kuasa ini tidak dapat ditarik kembali atau dibatalkan dan tetap berlaku pada waktu Calon Tertanggung masih hidup maupun sesudah meninggal dunia, maupun oleh sebab-sebab yang disebutkan dalam Pasal 1813, Pasal 1814 dan Pasal 1816 Kitab Undang-undang Hukum Perdata Indonesia. Salinan/fotokopi dari kuasa ini memiliki kekuatan hukum yang sama dan mengikat sesuai dengan aslinya.',
      },
      {
        text: 'Jika ada perbedaan data antara data di Polis sebelumnya dengan data di dalam SPAJ ini, maka yang berlaku adalah data yang tertera di dalam SPAJ ini.',
      },
      {
        text: 'SAYA dan Calon Tertanggung dengan ini memberikan kuasa dan izin kepada Penanggung untuk menggunakan atau memberikan informasi kesehatan atau keterangan mengenai diri Calon Tertanggung yang tersedia, diperoleh atau disimpan oleh Penanggung, kepada perusahaan asuransi, perusahaan reasuransi atau pihak-pihak lain dalam rangka pengajuan dan pembayaran klaim, maupun pelayanan nasabah.',
      },
      {
        text: `Jika pengajuan SPAJ SAYA telah disetujui oleh Penanggung, namun premi belum diterima oleh Penanggung dalam waktu 14 hari atau 30 hari (sesuai besar Premi tahunan) sejak SPAJ tersebut disetujui oleh Penanggung atau dalam waktu 60 hari sejak SPAJ diterima di Kantor Pusat Penanggung, mana yang terjadi lebih dahulu, maka pengajuan SPAJ SAYA tersebut dianggap
        berakhir sesuai ketentuan yang berlaku di Penanggung.`,
      },
    ],
    section: [
      {
        code: 'A',
        title: 'SYARAT DAN KETENTUAN KEPATUHAN',
        statement: 'Dengan ini SAYA menyatakan bahwa menyetujui pernyataan di bawah ini:',
        point: [
          {
            text: `Apabila pembayaran yang dilakukan terdapat indikasi mencurigakan sebagaimana yang tercantum pada UU No.8 Tahun 2010,
            tentang Pencegahan dan Pemberantasan Tindak Pidana Pencucian Uang, maka Penanggung dapat melakukan hal-hal yang
            dibutuhkan sebagaimana tercantum didalam peraturan perundang-undangan tersebut.`,
          },
          {
            text: `Sesuai dengan Peraturan OJK No. 12/POJK.01/2017 tertanggal 16 Maret 2017 (”POJK No. 12”), SAYA menyadari, mengerti dan
            memahami bahwa SAYA memiliki kewajiban untuk senantiasa melakukan pengkinian data pribadi SAYA kepada Penanggung dan menyerahkan salinan dokumen pendukung yang berlaku kepada Penanggung. Berdasarkan POJK No. 12 tersebut, SAYA juga setuju bahwa Penanggung dapat menolak hubungan usaha/transaksi, membatalkan transaksi dan/atau menutup hubungan usaha dengan SAYA apabila (1) SAYA tidak melakukan pengkinian data tersebut; (2) diketahui dan/atau patut diduga menggunakan dokumen palsu; (3) menyampaikan informasi yang diragukan kebenarannya; dan/atau (4) SAYA terdapat di
            dalam Daftar Terduga Teroris dan Organisasi Teroris.`,
          },
          {
            text: `Selain hal tersebut di atas SAYA setuju bahwa Penanggung tetap dapat menolak hubungan usaha/transaksi, membatalkan transaksi
            dan/atau menutup hubungan usaha dengan SAYA apabila (1) SAYA memiliki sumber dana transaksi yang diketahui dan/atau patut diduga berasal dari hasil tindak pidana; dan/atau (2) SAYA terdapat di dalam Daftar Pendanaan Proliferasi Senjata Pemusnah Massal; dan/atau (3) SAYA Terdapat dalam Daftar Sanksi Ekonomi yang ada pada internal Penanggung.`,
          },
          {
            text: 'SAYA dengan ini mengakui dan menyetujui bahwa Penanggung dapat diwajibkan untuk mematuhi, mempelajari dan memenuhi persyaratan dari hukum, peraturan, perintah, petunjuk dan persyaratan-persyaratan termasuk persyaratan yang relevan berdasarkan Foreign Account Tax Compliance Act (FATCA) serta Common Reporting Standard (CRS) dan permintaan dari setiap badan yudisial, pajak, pemerintah dan/atau badan pengatur, termasuk namun tidak terbatas pada Internal Revenue Service (IRS) dari Amerika Serikat (selanjutnya disebut “Otoritas-otoritas” dan secara tersendiri disebut “Otoritas”) dalam berbagai yurisdiks sebagaimana diterbitkan dan diubah dari waktu ke waktu (selanjutnya disebut “Persyaratan yang Relevan”). Dalam hal ini, SAYA setuju bahwa Penanggung dapat mengambil setiap dan seluruh langkah yang secara wajar dianggap perlu untuk memastikan kepatuhan atau ketaatan Penanggung dengan Persyaratan yang Relevan, secara khusus pengungkapan atas keadaan khusus SAYA terhadap Otoritas.',
          },
          {
            text: `SAYA setuju bahwa Penanggung dapat mengungkapkan keadaan khusus SAYA atau informasi apapun mengenai SAYA kepada Otoritas sehubungan dengan ketaatan terhadap Persyaratan yang Relevan. Pengungkapan tersebut dapat diberlakukan secara langsung atau dikirimkan melalui salah satu dari Kantor Pusat Penanggung atau afiliasi lainnya dari Penanggung. Untuk tujuan tersebut dan tanpa mengabaikan ketentuan manapun lainnya dalam SPAJ atau Polis SAYA (apabila pengajuan SPAJ ini disetujui) Penanggung dapat meminta SAYA untuk memberikan informasi lebih lanjut sebagaimana dipersyaratkan untuk pengungkapan terhadap Otoritas manapun dan SAYA wajib memberikan informasi tersebut kepada Penanggung dalam jangka waktu tertentu sebagaimana dapat dipersyaratkan secara wajar. SAYA memahami konsekuensi jika SAYA tidak bersedia menyampaikan pernyataan persetujuan, instruksi atau pemberian kuasa secara tertulis dan sukarela. Penanggung berhak untuk menolak hubungan bisnis, transaksi dan/atau mengakhiri hubungan bisnis SAYA, dan SAYA berhak menolak memberikan pernyataan persetujuan, instruksi atau
            pemberian kuasa secara tertulis dan sukarela, dengan menerima konsekuensi seperti yang disebutkan diatas.`,
          },
          {
            text: `Tanpa mengabaikan ketentuan manapun lainnya dari SPAJ atau Polis SAYA (apabila pengajuan SPAJ ini disetujui), SAYA setuju untuk menyediakan bantuan yang mungkin secara wajar dibutuhkan untuk memungkinkan Penanggung mematuhi kewajiban
            Penanggung berdasarkan seluruh Persyaratan yang Relevan mengenai SAYA atau Polis SAYA pada Penanggung.`,
          },
          {
            text: `SAYA setuju untuk memberikan informasi kepada Penanggung secara tepat waktu atas setiap perubahan apapun dari keterangan yang sebelumnya telah disampaikan kepada Penanggung, atau selambat - lambatnya 90 (Sembilan puluh) hari kalender sejak terjadinya perubahan yang dimaksud, baik pada saat pengisian permohonan asuransi ini atau di waktu manapun lainnya. Secara khusus, merupakan hal yang sangat penting bagi SAYA untuk memberikan informasi kepada Penanggung secara langsung apabila terdapat perubahan atas kewarganegaraan SAYA, status pajak atau wajib pajak atau jika SAYA menjadi wajib pajak di lebih dari satu negara. Jika salah satu dari perubahan ini terjadi atau jika informasi manapun lainnya mengindikasikan adanya perubahan dimaksud, Penanggung dapat meminta SAYA untuk memberikan dokumen-dokumen tertentu atau informasi terkait, dan SAYA setuju untuk memberikan informasi tersebut. Dokumen dan informasi tersebut adalah termasuk namun tidak terbatas pada pernyataan atau formulir pajak (dan dilegalisasi oleh notaris, apabila diperlukan) yang telah dilengkapi dan/atau ditandatangani
            oleh SAYA.`,
          },
          {
            text: `Jika SAYA tidak menyediakan informasi dan dokumen-dokumen yang diminta tersebut kepada Penanggung dalam jangka waktu
            tertentu atau jika salah satu dari informasi atau dokumen-dokumen yang disediakan tersebut tidak tepat waktu, akurat atau lengkap, SAYA setuju bahwa Penanggung dapat, untuk memastikan kepatuhan dan ketaatan yang berkelanjutan terhadap Persyaratan yang Relevan, mengambil setiap dan seluruh langkah yang Penanggung anggap sesuai untuk memastikan kepatuhan atau ketaatan Penanggung terhadap Persyaratan yang Relevan, atau selainnya untuk melindungi kepentingan hukum dan/atau
            komersial Penanggung.`,
          },
        ],
      },
      {
        code: 'B',
        title: 'PELAYANAN KONSUMEN',
        statement: 'Dengan ini SAYA menyatakan bahwa menyetujui pernyataan di bawah ini:',
        point: [
          {
            text: `SAYA telah menerima, mendapatkan penjelasan dan memahami mengenai Ringkasan Informasi Produk dan/atau Layanan
            ${formatedProduct(product, isHtml)} dari FSC.`,
          },
          {
            text: `Bahwa Penanggung dari waktu ke waktu dapat menggunakan Informasi Pribadi (termasuk namun tidak terbatas pada nama,
              alamat surat menyurat, alamat Email, nomor telepon rumah, nomor telepon genggam dan lainnya) yang SAYA berikan dalam SPAJ ini, dan dokumen lainnya sehubungan dengan pengajuan asuransi ini, termasuk memberikannya kepada pihak ketiga sepanjang dianggap perlu oleh Penanggung dalam rangka memberikan pelayanan atas SPAJ dan/atau Polis, atau untuk tujua lain seperti informasi produk dan layanan terbaru sehubungan dengan pertanggungan SAYA pada Asuransi Dasar dan Asuransi Tambahan (jika diadakan) berdasarkan Polis jika SPAJ ini disetujui oleh Penanggung, dengan tunduk pada peraturan perundang-undangan yang berlaku.`,
          },
          {
            text: 'Bahwa Penanggung dapat menghubungi SAYA dan/atau (Calon) Tertanggung, baik secara langsung maupun melalui Tenaga Pemasar atau pihak lain yang ditunjuk oleh Penanggung, untuk menyampaikan informasi mengenai SPAJ dan/atau Polis, informasi terkait produk atau layanan Penanggung, termasuk namun tidak terbatas pada informasi mengenai alasan pemberian keputusan underwriting tertentu terhadap SPAJ dan/atau Polis, atau informasi berkaitan dengan Premi. Dalam hal informasi tersebut diberikan melalui Short Message Service (SMS), SAYA menyetujui bahwa SMS tersebut dapat terkirim baik pada atau di luar hari/jamkerja.',
          },
        ],
      },
      {
        code: 'C',
        title: 'PERIKATAN',
        statement: 'Dengan ini SAYA menyatakan bahwa menyetujui pernyataan di bawah ini:',
        point: [
          {
            text: `Bahwa setelah Penanggung menyetujui SPAJ ini dan Premi telah SAYA bayarkan, SAYA dan Penanggung sepakat membuat perjanjian
            pertanggungan jiwa dalam bentuk Polis yang akan diterbitkan oleh Penanggung, dan oleh karenanya SAYA dan Penanggung setuju untuk memenuhi hak dan melaksanakan kewajiban masing-masing berdasarkan syarat dan ketentuan yang tercantum di dalam Ringkasan Polis, Ketentuan Umum, Ketentuan Khusus Asuransi Dasar, Ketentuan Khusus Asuransi Tambahan dan Ketentuan lain (apabila diadakan) yang merupakan bagian yang tidak terpisahkan dari Polis yang akan diterbitkan Penanggung tersebut.`,
          },
          {
            text: 'Pemegang Polis memiliki kesempatan untuk mempelajari dengan seksama Polis tersebut sesuai ketentuan yang terdapat pada Polis dan keterangan yang terdapat pada Ringkasan Informasi Produk dan/atau Layanan.',
          },
          {
            text: 'SAYA menyetujui bahwa Premi yang telah dibayarkan akan segera dialokasikan ke dalam pilihan Dana Investasi PRULink sejak Polis diterbitkan, sebagaimana yang telah SAYA pilih dan tercantum dalam ilustrasi produk. SAYA sepenuhnya telah mengerti dan memahami risiko investasi atas penempatan dana SAYA pada pilihan Dana Investasi PRULink yang telah SAYA pilih tersebut.',
          },
          {
            text: `Dalam rentang waktu sebagaimana dimaksud pada butir 2 di atas, Pemegang Polis dapat mengurungkan maksud untuk mempertanggungkan diri Tertanggung Utama berdasarkan Polis tersebut, dengan cara mengembalikan dokumen Polis (untuk bentuk Polis Non-Elektronik (cetak)) atau dokumen Ringkasan Polis (untuk bentuk Polis Elektronik) kepada Penanggung, dan dengan ketentuan bahwa Pemegang Polis tidak pernah mengajukan perubahan Polis dan/atau melakukan transaksi Polis dan/atau mengajukan klaim atas Manfaat Asuransi yang ditanggung dalam Polis tersebut. Dalam hal ini, Penanggung akan mengembalikan Premi yang telah dibayarkan dikurangi biaya - biaya (jika ada) ditambah dengan hasil investasi atau dikurangi dengan kerugian investasi sesuai ketentuan yang terdapat pada Polis dan keterangan yang terdapat pada Ringkasan informasi Produk dan/atau
            Layanan.`,
          },
        ],
      },
      {
        code: 'D',
        title: 'KETENTUAN PERTANGGUNGAN MANFAAT MENINGGAL DUNIA KARENA KECELAKAAN SEBELUM POLIS DITERBITKAN',
        point: [
          {
            text: `Dalam hal SPAJ dan pembayaran Premi Berkala & Premi ${formatedTopup(isHtml)} Berkala Pertama sesuai dengan frekuensi pembayaran yang tercantum di dalam SPAJ/Ilustrasi (selanjutnya disebut "Premi Pertama"), atau pembayaran Premi Tunggal telah diterima oleh Penanggung, kemudian terjadi Kecelakaan yang menyebabkan Calon Tertanggung Utama Meninggal Dunia sebelum Polis diterbitkan, maka Penanggung akan membayarkan sejumlah uang tertentu (selanjutnya disebut "Manfaat Pertanggungan") kepada Calon Pemegang Polis (jika berbeda dengan Calon Tertanggung Utama) atau Penerima Manfaat dengan jumlah sebagai berikut:`,
            subtext: [
              {
                text: 'Jika Uang Pertanggungan Manfaat Asuransi Dasar dan Manfaat Meninggal Berjangka, jika ada, yang diajukan di dalam SPAJ/Ilustrasi (selanjutnya disebut "Uang Pertanggungan" atau "UP") lebih kecil dari Rp250.000.000, maka akan dibayarkan sejumlah UP tersebut; atau',
              },
              {
                text: `(1) Tindak pidana kejahatan atau percobaan tindak pidana kejahatan; atau (2) tindak pidana pelanggaran atau percobaan
                tindak pidana pelanggaran; yang dilakukan oleh pihak yang berhak atas Manfaat Pertanggungan ini; kecuali dibuktikan sebaliknya dengan suatu putusan pengadilan;`,
              },
              {
                text: 'Perlawanan oleh Calon Tertanggung Utama dalam hal terjadi penahanan terhadap Calon Tertanggung Utama atau orang lain yang dilakukan oleh pihak yang berwenang;',
              },
              {
                text: 'Pelanggaran terhadap peraturan perundang-undangan oleh Calon Tertanggung Utama, kecuali dibuktikan sebaiknya dengan putusan Pengadilan; atau',
              },
              {
                text: 'Hukuman mati berdasarkan putusan pengadilan.',
              },
            ],
            subtexttype: 'a',
          },
          {
            text: 'Pemegang Polis memiliki kesempatan untuk mempelajari dengan seksama Polis tersebut sesuai ketentuan yang terdapat pada Polis dan keterangan yang terdapat pada Ringkasan Informasi Produk dan/atau Layanan.',
          },
          {
            text: 'SAYA menyetujui bahwa Premi yang telah dibayarkan akan segera dialokasikan ke dalam pilihan Dana Investasi PRULink sejak Polis diterbitkan, sebagaimana yang telah SAYA pilih dan tercantum dalam ilustrasi produk. SAYA sepenuhnya telah mengerti dan memahami risiko investasi atas penempatan dana SAYA pada pilihan Dana Investasi PRULink yang telah SAYA pilih tersebut.',
          },
          {
            text: `Dalam rentang waktu sebagaimana dimaksud pada butir 2 di atas, Pemegang Polis dapat mengurungkan maksud untuk mempertanggungkan diri Tertanggung Utama berdasarkan Polis tersebut, dengan cara mengembalikan dokumen Polis (untuk bentuk Polis Non-Elektronik (cetak)) atau dokumen Ringkasan Polis (untuk bentuk Polis Elektronik) kepada Penanggung, dan dengan ketentuan bahwa Pemegang Polis tidak pernah mengajukan perubahan Polis dan/atau melakukan transaksi Polis dan/atau mengajukan klaim atas Manfaat Asuransi yang ditanggung dalam Polis tersebut. Dalam hal ini, Penanggung akan mengembalikan Premi yang telah dibayarkan dikurangi biaya - biaya (jika ada) ditambah dengan hasil investasi atau dikurangi dengan kerugian investasi sesuai ketentuan yang terdapat pada Polis dan keterangan yang terdapat pada Ringkasan informasi Produk dan/atau
            Layanan.`,
          },
        ],
      },
    ],
  },
});

export const formatedPrulink = (isHtml) => {
  if (isHtml) return '<b>PRU</b>Link';
  return (
    <React.Fragment>
      <Text style={[Style.Main.fontBoldExtra, SpajStyles.text]}>PRU</Text>
      <Text style={[SpajStyles.text]}>Link</Text>
    </React.Fragment>
  );
};

const formatedUnderwriting = (isHtml) => {
  if (isHtml) return '<i>Underwriting</i>';
  return (
    <Text style={[Style.Main.italic, SpajStyles.text]}>Underwriting</Text>
  );
};

export const formatedTopup = (isHtml) => {
  if (isHtml) return '<i>Top-up</i>';
  return (
    <Text style={[Style.Main.italic, SpajStyles.text]}>Top-up</Text>
  );
};

export const formatItalicFSC = (val) => {
  let str = '';
  let res = '';
  if (val.includes('Financial Services Consultant')) {
    str = val.split('Financial Services Consultant');
    res = [str[0], <Text style={[Style.Main.fontAlbert14, Style.Main.italic]}>Financial Services Consultant</Text>, str[1]];
    return res;
  } return val;
};

export const formatedProduct = (product, isHtml, styleForNative = []) => {
  const getDesc = DatabaseUtils.getCoverageDesc(product, true);
  if (isHtml) return CoverageHTML(getDesc);
  return <CoverageText desc={getDesc} style={[SpajStyles.text, SpajStyles.lineHeight22, ...styleForNative]} />;

  // NOTES:
  // Please comment all code below and uncomment the code above

  // let productDescription = '';
  // let ProductDescriptionComponent = <Text />;

  // switch (product) {
  //   case 'U2V':
  //     if (isHtml) {
  //       productDescription = '<b>VERSA</b>Link Maxima Account';
  //     } else {
  //       ProductDescriptionComponent = (
  //         <React.Fragment>
  //           <Text style={[Style.Main.fontBoldExtra, SpajStyles.text, ...styleForNative]}>VERSA</Text>
  //           <Text style={[SpajStyles.text, ...styleForNative]}>Link Maxima Account</Text>
  //         </React.Fragment>
  //       );
  //     }
  //     break;
  //   case 'U2T':
  //     if (isHtml) {
  //       productDescription = '<b>BUILDER</b>Assurance Account Max';
  //     } else {
  //       ProductDescriptionComponent = (
  //         <React.Fragment>
  //           <Text style={[Style.Main.fontBoldExtra, SpajStyles.text, ...styleForNative]}>BUILDER</Text>
  //           <Text style={[SpajStyles.text, ...styleForNative]}>Assurance Account Max</Text>
  //         </React.Fragment>
  //       );
  //     }
  //     break;
  //   case 'U2L':
  //     if (isHtml) {
  //       productDescription = '<b>FLEXI</b>Link Investor Account';
  //     } else {
  //       ProductDescriptionComponent = (
  //         <React.Fragment>
  //           <Text style={[Style.Main.fontBoldExtra, SpajStyles.text, ...styleForNative]}>FLEXI</Text>
  //           <Text style={[SpajStyles.text, ...styleForNative]}>Link Investor Account</Text>
  //         </React.Fragment>
  //       );
  //     }
  //     break;
  //   case 'U4D':
  //     if (isHtml) {
  //       productDescription = '<b>VERSA</b>Link Maxima Protection Plus';
  //     } else {
  //       ProductDescriptionComponent = (
  //         <React.Fragment>
  //           <Text style={[Style.Main.fontBoldExtra, SpajStyles.text, ...styleForNative]}>VERSA</Text>
  //           <Text style={[SpajStyles.text, ...styleForNative]}>Link Maxima Protection Plus</Text>
  //         </React.Fragment>
  //       );
  //     }
  //     break;
  //   case 'U4K':
  //     if (isHtml) {
  //       productDescription = '<b>VERSA</b>Link Investor Account Plus';
  //     } else {
  //       ProductDescriptionComponent = (
  //         <React.Fragment>
  //           <Text style={[Style.Main.fontBoldExtra, SpajStyles.text, ...styleForNative]}>VERSA</Text>
  //           <Text style={[SpajStyles.text, ...styleForNative]}>Link Investor Account Plus</Text>
  //         </React.Fragment>
  //       );
  //     }
  //     break;
  //   case 'U2Z':
  //     if (isHtml) {
  //       productDescription = '<b>BUILDER</b>Investor Account Max';
  //     } else {
  //       ProductDescriptionComponent = (
  //         <React.Fragment>
  //           <Text style={[Style.Main.fontBoldExtra, SpajStyles.text, ...styleForNative]}>BUILDER</Text>
  //           <Text style={[SpajStyles.text, ...styleForNative]}>Investor Account Max</Text>
  //         </React.Fragment>
  //       );
  //     }
  //     break;
  //   case 'E2E':
  //     if (isHtml) {
  //       productDescription = '<b>USave PRUStar</b>';
  //     } else {
  //       ProductDescriptionComponent = (
  //         <React.Fragment>
  //           <Text style={[Style.Main.fontBoldExtra, SpajStyles.text, ...styleForNative]}>USave PRUStar</Text>
  //         </React.Fragment>
  //       );
  //     }
  //     break;
  //   default:
  //     break;
  // }
  // return !isHtml ? ProductDescriptionComponent : productDescription;
};
