import React, { Component } from 'react';
import { Image } from 'react-native';
import {
  Container, View, Button, Icon, Text, Content,
} from 'native-base';
import PropTypes from 'prop-types';
import _ from '../../../lang';
import bg from '../../../assets/images/bg.png';
import logo from '../../../assets/images/prudential-logo-full.png';
import Style from '../../../styles';

class HomeScreen extends Component {
  render() {
    return (
      <Container>
        <Image source={bg} style={Style.Main.bgImage} />
        <View>
          <Button
            transparent
            iconLeft
            onPress={this.props.onBackClicked}
          >
            <Icon name="angle-left" type="FontAwesome" style={[Style.Main.textRed]} />
            <Text style={[Style.Main.textRed]}>{_('Back')}</Text>
          </Button>
        </View>
        <Content keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
          <View style={[Style.Main.mb30]}>
            <Image source={logo} style={[Style.Main.mt64, Style.Main.mb55, Style.Main.height100, Style.Main.alignCenter]} resizeMode="contain" />
            <Text style={[Style.Main.textAlmostBlack, Style.Main.textCenter, Style.Main.font16, Style.Main.mb15]}>{_(`${this.props.title}`)}</Text>
            {this.props.content}
          </View>
        </Content>
      </Container>
    );
  }
}

HomeScreen.propTypes = {
  onBackClicked: PropTypes.func,
  title: PropTypes.string,
};

HomeScreen.defaultProps = {
  onBackClicked: () => { },
  title: '',
};

export default HomeScreen;
