
import React, { PureComponent } from 'react';
import { Text, View, Card } from 'native-base';
import { TouchableOpacity } from 'react-native-gesture-handler';
import moment from 'moment';
import Style from '../../../styles';
import Colors from '../../../styles/Colors';
import { toFixedCurrency, DatabaseUtils } from '../../../utilities';
import {
  CoverageText, rowLayout, Skeleton, SkeletonText,
} from '../../../components';
import LoadingModal from '../../../components/loading_modal';

export class TransactionIndividuCard extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    };
  }

  render() {
    const { data, onCardClicked, isLoading } = this.props;
    return (
      <Card style={[Style.Main.container, Style.Main.mb5, Style.Main.padding10]}>
        <TouchableOpacity
          activeOpacity={onCardClicked ? 0.5 : 1}
          onPress={onCardClicked || (() => { })}
          style={[Style.Main.fullWidth]}
        >
          {/* <Text style={[Style.Main.borderBottomWidth1, Style.Main.borderBottomWhiteSmoke, Style.Main.fontAlbertBold14, Style.Main.pb10]}>
            {data.policyHolderName || data.clientName || 'N/A'}
          </Text> */}

          <Skeleton
            isLoading={isLoading}
            layout={[rowLayout({ w: '50%', h: 11 })]}
            style={[Style.Main.borderBottomWidth1, Style.Main.borderBottomWhiteSmoke, Style.Main.pb10]}
          >
            <Text style={[Style.Main.fontAlbertBold14]}>
              {data.policyHolderName || data.clientName || 'N/A'}
            </Text>
          </Skeleton>
          <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.mt10]}>
            <Skeleton
              isLoading={isLoading}
              layout={[rowLayout({ w: '30%', h: 8 }), rowLayout({ w: '40%', h: 8 }), rowLayout({ w: '35%', h: 8 })]}
              style={[Style.Main.flex8]}
            >
              <Text style={[Style.Main.fontAlbert11]}>{data.policyNumber || 'N/A'}</Text>
              <Text style={[Style.Main.fontAlbert11]}>{data.transactionDate ? moment(new Date(data.transactionDate)).format('LL') : ''}</Text>
              {/* <Text style={[Style.Main.fontAlbert11]}>{data.productCode}</Text> */}
              <CoverageText style={[Style.Main.fontAlbert11]} desc={data.productCode ? DatabaseUtils.toCoverageFormat(data.productCode) : ''} />
            </Skeleton>
            <Skeleton
              isLoading={isLoading}
              layout={[rowLayout({ w: '50%', h: 8 }), rowLayout({ w: '30%', h: 8 })]}
              style={[Style.Main.alignEnd, Style.Main.flex5]}
            >
              <Text style={[Style.Main.textGreen, Style.Main.fontAlbert11]}>{data.policyStatus || data.transactionType || 'N/A'}</Text>
              <Text style={[Style.Main.fontAlbert11]}>Rp. {toFixedCurrency(data.policyValue || data.api || 0)}</Text>
            </Skeleton>
          </View>
        </TouchableOpacity>
        <LoadingModal show={this.state.isLoading} size="large" color="white" />
      </Card>
    );
  }
}

export class TransactionUnitCard extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    };
  }

  render() {
    const { data, onCardClicked, isLoading } = this.props;
    return (
      <Card style={[Style.Main.container, Style.Main.mb5, Style.Main.padding10]}>
        <TouchableOpacity
          onPress={onCardClicked || (() => { })}
          style={[Style.Main.fullWidth]}
        >
          <Skeleton isLoading={isLoading} layout={[rowLayout({ w: '60%', h: 11 })]}>
            <Text style={[Style.Main.fontAlbertBold14]}>{data.clientName || 'N/A'}</Text>
          </Skeleton>
          <View style={[Style.Main.fullWidth, Style.Main.mt5, Style.Main.alignContentCenter, Style.Main.rowDirectionSpaceBetween]}>
            <Skeleton isLoading={isLoading} layout={[rowLayout({ w: '25%', h: 8 })]} style={[Style.Main.rowDirection]}>
              <Text
                style={[Style.Main.textWhite, Style.Main.fontAlbert11, Style.Main.ph5, Style.Main.pv2, Style.Main.borderRadius5, Style.Main.mr5,
                  { backgroundColor: Colors[data.agentType] }]}
              >{data.agentType || 'N/A'}
              </Text>
              <Text style={[Style.Main.pv2, Style.Main.fontAlbert11]}>{data.agentNumber || 'N/A'}</Text>
            </Skeleton>
            <View style={[Style.Main.alignEnd]}>
              <SkeletonText isLoading={isLoading} width="30%" font={11} style={[Style.Main.pv2]}>
                Rp. {toFixedCurrency(data.totalNetAPI || data.totalApe || 0)}
              </SkeletonText>
            </View>
          </View>
        </TouchableOpacity>
        <LoadingModal show={this.state.isLoading} size="large" color="white" />
      </Card>
    );
  }
}
