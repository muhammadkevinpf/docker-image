import { StyleSheet } from 'react-native';
import Styles from '../../styles';
import Fonts from '../../styles/Fonts';

const Style = StyleSheet.create({
  content: {
    marginTop: 5,
    // backgroundColor: 'white',
  },
  styleTextLabel: {
    flex: 1,
    marginTop: 4,
    fontSize: 12,
    color: Styles.Color.gray83,
    fontFamily: Fonts.FSAlbertPro,
  },
  styleTextLabelValEmpty: {
    color: Styles.Color.gray83,
  },
  styleBottomLabel: {
    fontFamily: Fonts.FSAlbertPro,
    // marginBottom: 15,
    color: Styles.Color.red,
    fontSize: 12,
    marginLeft: 1,
  },
  item: {
    // paddingBottom: 2,
    // backgroundColor: Styles.Color.mediumGray,
    height: 30,
    paddingLeft: 0,
    fontSize: 12,
  },
  iconStyle: {
    marginBottom: 20,
  },
  placeholderColor: {
    fontFamily: Fonts.FSAlbertPro,
    color: Styles.Color.gray83,
    fontSize: 12,
  },
  fieldStyle: {
    fontFamily: Fonts.FSAlbertPro,
    fontSize: 10,
    color: Styles.Color.gray83,
    // backgroundColor: Styles.Color.yellow,
    paddingLeft: 0,
    marginLeft: -6,
  },
  styleTextInput: {
    borderBottomColor: Styles.Color.gray,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
});

export default Style;
