import React from 'react';
import {
  Modal, Image, SafeAreaView, StyleSheet,
} from 'react-native';
import {
  Text, View, Button, Footer, FooterTab,
} from 'native-base';
import { isText } from '../../utilities';
import checklist from '../../assets/images/submitsuccess.png';
import info from '../../assets/images/info.png';
import Style from '../../styles';
import Colors from '../../styles/Colors';
import _ from '../../lang';

const styles = StyleSheet.create({
  img: {
    height: '50%',
    width: '50%',
    resizeMode: 'contain',
  },
});

const SubmitResultModal = ({
  isSuccess, visible, onClose = () => {}, successMsg = '', failedMsg = 'Silakan periksa kembali koneksi dan data anda.',
  note = '', buttonText = 'Kembali ke Halaman Sebelumnya',
}) => (
  <Modal transparent visible={visible} onRequestClose={onClose}>
    <SafeAreaView style={[Style.Main.flex1]}>
      <View
        style={[Style.Main.displayFlex, Style.Main.container, Style.Main.backgroundWhite, Style.Main.borderRadius5,
          Style.Main.justifySpaceBetween]}
      >
        <View style={[Style.Main.container, Style.Main.padding12]}>
          <Text style={[Style.Main.textRed]}>{_('KONFIRMASI')}</Text>
          <View style={[Style.Main.centerVertical]}>
            <Text style={[Style.Main.setFontAlbert(16, Colors.almostBlack), Style.Main.mb15, Style.Main.textAlignCenter]}>
              { isSuccess ? _('Selamat !') : _('Submit tidak berhasil')}
            </Text>
            { isSuccess ?
              <React.Fragment>
                {isText(successMsg) ?
                  <Text style={[Style.Main.setFontAlbert(14, Colors.almostBlack), Style.Main.mb15, Style.Main.textAlignCenter]}>{_(successMsg)}</Text>
                  : successMsg}
              </React.Fragment> :
              <React.Fragment>
                {isText(failedMsg) ?
                  <Text style={[Style.Main.setFontAlbert(14, Colors.almostBlack), Style.Main.mb15, Style.Main.textAlignCenter]}>{_(failedMsg)}</Text>
                  : failedMsg}
              </React.Fragment>
            }
            <Image source={isSuccess ? checklist : info} style={[styles.img, Style.Main.mV15, Style.Main.center]} />
            {isText(note) ?
              <Text style={[Style.Main.setFontAlbert(14, Colors.almostBlack), Style.Main.mt15, Style.Main.textAlignCenter]}>{_(note)}</Text>
              : note}
          </View>
        </View>
        <Footer style={[Style.Main.footerHeight]}>
          <FooterTab>
            <Button style={[Style.Main.btnPrimary, Style.Main.mH12]} onPress={onClose}>
              <Text style={[Style.Main.fontAlbert16, Style.Main.textWhite]}>{_(buttonText)}</Text>
            </Button>
          </FooterTab>
        </Footer>
      </View>
    </SafeAreaView>
  </Modal>
);

export default SubmitResultModal;
