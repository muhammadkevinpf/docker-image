/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import MainDashboard_ from './MainDashboard';


import SettingWidgetDashboard_ from './SettingWidgetDashboard';
import MyAccount_ from './MyAccount';
import MyAccountDetail_ from './MyAccountDetail';
import MyAccountSecretQuestion_ from './MyAccountSecretQuestion';
import MyAccountChangePassword_ from './MyAccountChangePassword';
import EditEmergencyContact_ from './EditEmergencyContact';
import CPDDetail_ from './CPDDetail';

const MainDashboard = MainDashboard_;


const SettingWidgetDashboard = SettingWidgetDashboard_;
const MyAccount = MyAccount_;
const MyAccountDetail = MyAccountDetail_;
const MyAccountSecretQuestion = MyAccountSecretQuestion_;
const MyAccountChangePassword = MyAccountChangePassword_;
const EditEmergencyContact = EditEmergencyContact_;
const CPDDetail = CPDDetail_;

export default {
  MainDashboard,

  SettingWidgetDashboard,

  MyAccount,
  MyAccountDetail,
  MyAccountSecretQuestion,
  MyAccountChangePassword,

  EditEmergencyContact,
  CPDDetail,
};
