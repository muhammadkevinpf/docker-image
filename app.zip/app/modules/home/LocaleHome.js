/**
 * @author
 */

const translation = [
];

export default translation;
