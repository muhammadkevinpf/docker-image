import React, { PureComponent, Fragment } from 'react';
import {
  View, Text, Button, Modal, YellowBox,
} from 'react-native';
import { SketchCanvas } from '@terrylinla/react-native-sketch-canvas';
import PropTypes from 'prop-types';
import Styles from '../../styles';

class SignaturePad extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      openCanvas: false,
    };
    this.clearCanvas = this.clearCanvas.bind(this);
    this.saveCanvas = this.saveCanvas.bind(this);
    this.openCanvas = this.openCanvas.bind(this);
  }

  componentDidMount() {
    // eslint-disable-next-line max-len
    YellowBox.ignoreWarnings(['Accessing view manager configs directly off UIManager via UIManager[\'RNSketchCanvas\'] is no longer supported. Use UIManager.getViewManagerConfig(\'RNSketchCanvas\') instead.']);
  }

  openCanvas = () => this.setState({ openCanvas: true });

  closeCanvas = () => this.setState({ openCanvas: false });

  clearCanvas = () => this._signatureCanvas.clear();

  saveCanvas = () => {
    this._signatureCanvas.getBase64(
      'png',
      false,
      false,
      false,
      false,
      (err, res) => this.props.onFinish(err, res),
    );
  }

  render() {
    const {
      onRequestClose, onShow, onDismiss,
    } = this.props;
    return (
      <Fragment>
        <Button
          color="red"
          title="Sign Here"
          onPress={this.openCanvas}
        />
        <Modal
          animationType="slide"
          onRequestClose={onRequestClose}
          onShow={onShow}
          onDismiss={onDismiss}
          presentationStyle="fullScreen"
          // supportedOrientations={Platform.OS === 'android' ? 'portrait' : ''}
          visible={this.state.openCanvas}
        >
          <View style={Styles.Main.container}>

            <SketchCanvas
              style={Styles.Main.container}
              strokeColor="black"
              strokeWidth={7}
              ref={(ref) => { this._signatureCanvas = ref; }}
              onStrokeEnd={this.saveCanvas}
            />

            <Button
              onPress={this.clearCanvas}
              color="red"
              title="reset"
            >
              <Text>Reset</Text>
            </Button>

            <Button
              onPress={this.closeCanvas}
              color="red"
              title="close"
            >
              <Text>Close</Text>
            </Button>

          </View>
        </Modal>
      </Fragment>
    );
  }
}

SignaturePad.propTypes = {
  onRequestClose: PropTypes.func,
  onDismiss: PropTypes.func,
  onShow: PropTypes.func,
  onFinish: PropTypes.func.isRequired,
};

SignaturePad.defaultProps = {
  onRequestClose: () => {},
  onDismiss: () => {},
  onShow: () => {},
};

export default SignaturePad;
