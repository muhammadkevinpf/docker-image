/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import { Dimensions, Image } from 'react-native';
import { View } from 'native-base';

import Style from '../../../styles';
import banner from '../../../assets/images/dummy-banner-home.png';


class BannerHome extends Component {
  constructor() {
    super();

    this.state = {
      width: Dimensions.get('window').width,
      height: this.aspectRatioHeight(Dimensions.get('window').width),
    };
  }

  componentDidMount() {
    this.refreshDimensions();

    Dimensions.addEventListener('change', () => {
      this.refreshDimensions();
    });
  }

  refreshDimensions = () => {
    if (this.refView) {
      this.setState({
        width: Dimensions.get('window').width,
        height: this.aspectRatioHeight(Dimensions.get('window').width),
      });
    }
  }

  aspectRatioHeight = width => (width / 2) * 1 // aspect ratio, / 2 * 1 means 2:1

  render() {
    return (
      <View
        ref={(c) => { this.refView = c; }}
        style={[Style.Main.container, Style.Main.mb10]}
      >
        <Image
          style={{
            width: this.state.width,
            height: this.state.height,
          }}
          source={banner}
        />
      </View>
    );
  }
}

export default BannerHome;
