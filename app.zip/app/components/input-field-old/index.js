/* eslint-disable no-nested-ternary */
/* eslint-disable no-undef */
/**
 * @author: ahmdichsanb@gmail.com
 * @author: definite maji arsana
*/

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {
  Item, Input, Label, Text, View, Form, Row, Col,
} from 'native-base';
import Style from '../../styles';
import StyleInput from './StyleInputField';
import _ from '../../lang';

class InputField extends Component {
  constructor(props) {
    super(props);
    this.state = {
      errorMessage: '',
      isOnEdit: false,
      // value: '',
    };
  }

  // shouldComponentUpdate = (prevProps, prevState) => {
  //   // console.log(this.props.isInsideCheckbox);
  //   if (!this.props.isInsideCheckbox && JSON.stringify(this.props) === JSON.stringify(prevProps) &&
  //   !this.state.isOnEdit && prevState.isOnEdit === this.state.isOnEdit) return false;
  //   return true;
  // }

  onFocusValidation = (input) => {
    const { onFocus, type } = this.props;
    if (type === 'currency') {
      // eslint-disable-next-line no-param-reassign
      input = input.replace(/,/g, '');// eslint-disable-line no-useless-escape
    }
    this.setState({ isOnEdit: true });
    this.inputCheck(input, false);
    if (onFocus) {
      onFocus(input);
    }
  }

  onChangeValidation = (input) => {
    // const { type } = this.props;

    // if (type === 'currency') {
    //   // eslint-disable-next-line no-param-reassign
    //   input = input.replace(/,/g, '');// eslint-disable-line no-useless-escape
    // }
    if (this.props.setValueToParent) {
      this.props.setValueToParent(this.props.index, input);
    }
    this.inputCheck(input, true);
  }

  onBlurValidation = (input) => {
    const { onBlur } = this.props;
    // if (type === 'currency') {
    //   // eslint-disable-next-line no-param-reassign
    //   input = input.replace(/,/g, '');// eslint-disable-line no-useless-escape
    // }
    this.setState({ isOnEdit: false });
    this.inputCheck(input, false);
    if (onBlur) {
      onBlur(input);
    }
  }

  convertToCurrency = val => val.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');

  numberValidation = (input, isOnChange) => {
    const {
      minVal,
      maxVal,
      onChangeText,
      type,
      kelipatan,
    } = this.props;
    // Cannot Contain other than Number
    const regex = /[^0-9]/gi;
    if (regex.test(input)) {
      return;
    }

    if (input.length > 1) {
      const regex2 = /^0+/;
      if (regex2.test(input)) {
        // eslint-disable-next-line no-param-reassign
        input = input.replace(regex2, '');
      }
    }

    const inputValue = parseInt(input, 0);
    if (inputValue > 0) {
      if (minVal) {
        if (inputValue < minVal) {
          this.setState({
            errorMessage: `Minimal masukkan ${type === 'currency' ? this.convertToCurrency(minVal) : minVal}`,
          });
          if (isOnChange) {
            onChangeText(input);
          }
          return;
        }
      }

      if (maxVal) {
        if (inputValue > maxVal) {
          this.setState({
            errorMessage: `Maksimal masukkan ${type === 'currency' ? this.convertToCurrency(maxVal) : maxVal}`,
          });
          if (isOnChange) {
            onChangeText(input);
          }
          return;
        }
      }
      if (kelipatan) {
        if (inputValue % kelipatan !== 0) {
          this.setState({
            errorMessage: `Masukkan harus kelipatan ${kelipatan}`,
          });
          if (isOnChange) {
            onChangeText(input);
          }
          return;
        }
      }
    }

    if (isOnChange) {
      onChangeText(input);
    }
  }

  mobileValidation = (input, isOnChange) => {
    const { onChangeText, countryCd } = this.props;
    let isValid = false;
    // Cannot Contain other than Number
    const regexJustWithNumber = /[^0-9]/gi;
    const regexNotStartWithZero = /^0+/;
    if (regexJustWithNumber.test(input) || regexNotStartWithZero.test(input)) {
      return;
    }

    if (countryCd.telephoneCode === '+62') {
      const regexMustMobileNumber = /^8[1-9][0-9]{5,11}$/;
      const regexMustNotRepetitive = /^(?!(((?!8)[0-9]*))\1+$)\d{9}/;
      const regexMustNotSeq = /^(?=.*(?:1(?![02])|2(?![13])|3(?![24])|4(?![35])|5(?![46])|6(?![57])|7(?![68])|8(?![79])|9(?!8)|0(?!1))(?!$))\d+$/;
      if (!regexMustMobileNumber.test(input) || !regexMustNotRepetitive.test(input) || !regexMustNotSeq.test(input)) {
        this.setState({
          errorMessage: 'Format No. Handphone tidak sesuai',
        });
      } else {
        this.setState({
          errorMessage: '',
        });
        isValid = true;
      }
    } else {
      this.setState({
        errorMessage: '',
      });
      isValid = true;
    }

    if (isOnChange) {
      onChangeText(input, isValid);
    }
  }

  phoneValidation = (input, isOnChange) => {
    const { onChangeText } = this.props;
    // Cannot Contain other than Number
    const regex = /[^0-9]/gi;
    const regex2 = /^0+/;
    if (regex.test(input) || regex2.test(input)) {
      return;
    }

    if (isOnChange) {
      onChangeText(input);
    }
  }

  emailValidation = (input, isOnChange) => {
    const { onChangeText } = this.props;
    // For Email Address
    const regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/gi; // eslint-disable-line no-useless-escape
    if (!regex.test(input)) {
      this.setState({
        errorMessage: 'Invalid email address!',
      });
    }
    if (isOnChange) {
      onChangeText(input);
    }
  }

  nameValidation = (input, isOnChange) => {
    const { onChangeText } = this.props;
    const regex = /[^a-zA-Z, ,.,',]/g;
    if (regex.test(input)) {
      return;
    }

    if (isOnChange) {
      console.log(`Sesudah: ${input}`);
      onChangeText(input);
    }
  }

  inputCheck = (input, isOnChange, minLengthInvoke) => {
    const {
      isRequired, type, onChangeText, minLength,
    } = this.props;
    let errorMessage = '';
    const minLength_ = minLengthInvoke || minLength;

    // console.log('state in input value: ', this.state.value);

    // Wajib diisi Check
    if (!input || input.length <= 0) {
      if (isRequired) {
        errorMessage = 'Wajib diisi!';
      } else {
        errorMessage = '';
      }
      if (isOnChange) {
        onChangeText(input);
      }
      this.setState({
        errorMessage,
      });
    } else {
      if (minLength_) {
        if (input.length < minLength_) {
          errorMessage = `minimal panjang karakter ${minLength_}`;
        } else {
          errorMessage = '';
        }
      }
      this.setState({
        errorMessage,
      });
      // for Validation
      // Number and Phone Number
      switch (type) {
        case 'currency':
        case 'number':
          this.numberValidation(input, isOnChange);
          break;
        case 'phone':
          this.phoneValidation(input, isOnChange);
          break;
        case 'mobile':
          this.mobileValidation(input, isOnChange);
          break;
        case 'email':
          this.emailValidation(input, isOnChange);
          break;
        case 'name':
          console.log(`Sebelum: ${input}`);
          this.nameValidation(input, isOnChange);
          break;
        default:
          if (isOnChange) {
            onChangeText(input);
          }
          break;
      }
    }
  }

  // invokeChecker = () => {
  //   const { value } = this.state;
  //   this.inputCheck(value);
  // }

  // getRefsData = () => this._input;

  render() {
    // console.log('ini ref: ', this._input);
    const {
      allowFontScaling,
      autoFocus,
      editable,
      multiline,
      numberOfLines,
      placeholder,
      placeholderTextColor,
      secureTextEntry,
      labelStyle,
      textInputStyle,
      errorLabelStyle,
      textAlignVertical,
      textAlign,
      label,
      bottomLabel,
      type,
      formStyle,
      maxLength,
      // add
      itemStyle,
      stackedLabel,
      regular,
      additionalText,
      withCounter,
    } = this.props;
    const {
      errorMessage,
      isOnEdit,
    } = this.state;
    // const errorMessage = this.props.errorMessage || this.state.errorMessage;
    let { keyboardType } = this.props;
    if (keyboardType === 'default') {
      switch (type) {
        case 'currency':
        case 'number':
          keyboardType = 'numeric';
          break;
        case 'email':
          keyboardType = 'email-address';
          break;
        case 'phone':
          keyboardType = 'phone-pad';
          break;
        case 'mobile':
          keyboardType = 'phone-pad';
          break;
        default:
          break;
      }
    }
    // eslint-disable-next-line no-nested-ternary
    const value = keyboardType === 'numeric' ? this.props.value.toString() : this.props.value;

    return (
      <View style={[formStyle]}>
        <View style={[Style.Main.mln12, Style.Main.mr12]}>
          <Form>
            <Item
              floatingLabel={!stackedLabel}
              stackedLabel={stackedLabel}
              style={itemStyle}
              regular={regular}
            >
              <Label
                numberOfLines={1}
                style={[labelStyle]}
              >{_(label)}
              </Label>
              <Input
                // getRef={(ref) => { this._input = ref; }}
                blurOnSubmit
                allowFontScaling={allowFontScaling}
                autoFocus={autoFocus}
                editable={editable}
                keyboardType={keyboardType}
                // eslint-disable-next-line no-nested-ternary
                maxLength={type === 'currency' ? (isOnEdit ? maxLength : maxLength + (value.length / 4)) : maxLength}
                multiline={multiline}
                numberOfLines={numberOfLines}
                onFocus={() => this.onFocusValidation(value)}
                onChangeText={e => this.onChangeValidation(e)}
                onBlur={() => this.onBlurValidation(value)}
                onContentSizeChange={() => {
                  // this.setState({ itemHeight: Math.max(45, event.nativeEvent.contentSize.height + 10) });
                }}
                placeholder={placeholder}
                placeholderTextColor={placeholderTextColor}
                secureTextEntry={secureTextEntry}
                style={[
                  StyleInput.input, editable ? Style.Main.textAlmostBlack : Style.Main.textDisabled,
                  Style.Main.fontAlbert,
                  !label && [Style.Main.pb5],
                  textInputStyle,
                ]}
                textAlignVertical={textAlignVertical}
                textAlign={textAlign}
                value={type === 'currency' && !isOnEdit ? this.convertToCurrency(value) : value}
              />
            </Item>
          </Form>
        </View>
        {withCounter ? (
          <Row>
            <Col>
              {errorMessage ? (<Text style={[Style.Main.fontAlbert, Style.Main.ml15, errorLabelStyle]}>{_(errorMessage)}</Text>) : null}
            </Col>
            <Col>
              <Text style={[Style.Main.font12, Style.Main.timeStyle]}>{additionalText}</Text>
            </Col>
          </Row>
        ) :
          errorMessage ? (<Text style={[Style.Main.fontAlbert, Style.Main.ml15, errorLabelStyle]}>{_(errorMessage)}</Text>) : null
        }
        {bottomLabel.length !== 0 ?
          (
            bottomLabel.map(element => (
              <Text key={element.toString()} style={[Style.Main.fontAlbert, Style.Main.ml15, errorLabelStyle]}>{_(element)}</Text>
            ))
          ) : null}
      </View>
    );
  }
}

InputField.propTypes = {
  allowFontScaling: PropTypes.bool,
  autoFocus: PropTypes.bool,
  maxLength: PropTypes.number,
  minLength: PropTypes.number,
  multiline: PropTypes.bool,
  numberOfLines: PropTypes.number,
  isRequired: PropTypes.bool,
  minVal: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  maxVal: PropTypes.number,
  placeholder: PropTypes.string,
  value: PropTypes.string.isRequired,
  placeholderTextColor: PropTypes.string,
  secureTextEntry: PropTypes.bool,
  formStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  labelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  textInputStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  errorLabelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  textAlignVertical: PropTypes.string,
  textAlign: PropTypes.string,
  editable: PropTypes.bool,
  onChangeText: PropTypes.func,
  onFocus: PropTypes.func,
  onBlur: PropTypes.func,
  label: PropTypes.string,
  stackedLabel: PropTypes.bool,
  additionalText: PropTypes.string,
  regular: PropTypes.bool,
  withCounter: PropTypes.bool,
  bottomLabel: PropTypes.arrayOf(PropTypes.string),
  type: PropTypes.string,
  keyboardType: PropTypes.string,
  // add
  itemStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  // isInsideCheckbox: PropTypes.bool,
  kelipatan: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  countryCd: PropTypes.arrayOf(PropTypes.object),
};

InputField.defaultProps = {
  allowFontScaling: false,
  autoFocus: false,
  maxLength: null,
  minLength: null,
  multiline: true,
  numberOfLines: null,
  isRequired: true,
  placeholder: '',
  textAlignVertical: 'bottom',
  textAlign: 'justify',
  secureTextEntry: false,
  editable: true,
  formStyle: null,
  labelStyle: StyleInput.styleTextLabel,
  textInputStyle: StyleInput.styleTextValue,
  errorLabelStyle: null,
  maxVal: null,
  minVal: null,
  placeholderTextColor: StyleInput.styleTextPlaceholder.color,
  onFocus: () => { },
  onBlur: () => { },
  label: null,
  stackedLabel: false,
  additionalText: '',
  regular: false,
  withCounter: false,
  bottomLabel: [],
  type: 'default', // default, name, email, number, currency, phone
  keyboardType: 'default',
  // add
  itemStyle: null,
  // isInsideCheckbox: false,
  kelipatan: null,
  onChangeText: () => { },
  countryCd: null,
};

export default InputField;

/**
keyboardType =

Cross platforms:
-default
-number-pad
-decimal-pad
-numeric
-email-address
-phone-pad

No yet Added for Validation
add this on Validation Condition
iOS only:
-ascii-capable
-numbers-and-punctuation
-url
-name-phone-pad
-twitter
-web-search

Android only:
-visible-password
 */
