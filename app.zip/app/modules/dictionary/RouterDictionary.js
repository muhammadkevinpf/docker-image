
import Views from './views';

export default {
  Dictionary: { screen: Views.Dictionary },
};
