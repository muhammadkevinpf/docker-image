/* eslint-disable react/no-array-index-key */
/* eslint-disable no-console */
import React, { PureComponent } from 'react';
import moment from 'moment';
import {
  Modal, TouchableOpacity, ActivityIndicator, Alert, Platform, Image,
} from 'react-native';
import {
  Text, View, Icon, Card,
} from 'native-base';
import {
  toFixedCurrency, downloadDoc, requestStatus, isEmpty,
} from '../../../utilities';
import { IncomeComponent } from './IncomeCards';
import {
  LoadingModal, ContentCentered, Skeleton, rowLayout,
} from '../../../components';
import Style from '../../../styles';
import Colors from '../../../styles/Colors';
import _ from '../../../lang';
import { IncomePassword } from './IncomePassword';
import { IncomeAgentBanner } from '../../../assets/images';

const docType = {
  PDF: 'PDF',
  EXCEL: 'XLSX',
};

class IncomeStatement extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      overridingDetail: false,
      detailShowed: false,
      infoShowed: false,
      showDowloadOpt: false,
      showSendOpt: false,
      isLoading: false,
    };
  }

  componentDidUpdate = (prevProps) => {
    if (prevProps.sendStatus !== this.props.sendStatus && prevProps.sendStatus === requestStatus.FETCH) {
      this.hideLoading();
      if (this.props.sendStatus === requestStatus.SUCCESS) {
        Alert.alert('', this.props.sendByEmail ? _('Laporan pendapatan telah dikirimkan') : _('Laporan pendapatan tidak berhasil dikirimkan'));
      } else if (this.props.sendStatus === requestStatus.FAILED) {
        Alert.alert('', _('Laporan pendapatan tidak berhasil dikirimkan'));
      }
    }
  }

  hideLoading = () => this.setState({ isLoading: false });

  download = (type) => {
    this.setState({ showDowloadOpt: false, isLoading: true });
    const content = type === docType.PDF ? this.props.pdf.file : this.props.excel.file;
    const name = type === docType.PDF ? this.props.pdf.filename : this.props.excel.filename;
    const fileName = type === docType.PDF ? `${name}.pdf` : name;
    downloadDoc({ content, fileName }).then(() => this.hideLoading());
  }

  sendEmail = (type) => {
    this.setState({ showSendOpt: false, isLoading: true });
    if (this.props.resAuth && this.props.isOnline && this.props.data) {
      const data = {
        headers: [{ keyHeader: 'X-CSRF-Token', valueHeader: `Bearer ${this.props.resAuth.access_token}` }],
        params: `["${this.props.data.periodEnding}", "${type}"]`,
      };
      this.props.sendEmail(data);
    } else { Alert.alert(`${this.props.isOnline ? '' : 'Tidak Ada Jaringan'}`, 'Laporan pendapatan tidak dapat dikirimkan.'); this.hideLoading(); }
  }

  renderButtons = () => {
    if (this.props.pdf || this.props.excel) {
      const { showDowloadOpt, showSendOpt } = this.state;
      const ios = Platform.OS === 'ios';
      return (
        <View style={[Style.Main.center, Style.Main.rowDirectionSpaceBetween]}>
          {(this.props.pdf || this.props.excel) &&
            <Icon
              type="MaterialCommunityIcons"
              name="information"
              onPress={() => this.setState({ infoShowed: true })}
              style={[Style.Main.textRed, Style.Main.font20, Style.Main.alignCenter, Style.Main.mr18]}
            />
          }
          {!ios && (
            <Icon
              type="FontAwesome"
              name="envelope"
              onPress={() => this.setState(prevState => ({ showSendOpt: !prevState.showSendOpt }))}
              style={[Style.Main.textBlack, Style.Main.font20, Style.Main.pr10]}
            />
          )}
          <Modal transparent animationType="fade" visible={showSendOpt} onRequestClose={() => this.setState({ showSendOpt: false })}>
            <TouchableOpacity
              onPress={() => this.setState({ showSendOpt: false })}
              style={[Style.Main.container, Style.Main.backgroundLightSmoke, Style.Main.halfOpacity]}
            />
            <View
              style={[Style.Main.backgroundWhite, Style.Main.height100,
                Style.Main.justifyBottom, Style.Main.justifySpaceBetween, Style.Main.padding12,
              ]}
            >
              {this.props.pdf &&
                <Text
                  onPress={() => this.sendEmail(docType.PDF)}
                  style={[Style.Main.fontAlbert14, Style.Main.alignCenter, Style.Main.py7, Style.Main.textBlack]}
                >{_('Kirim')} PDF
                </Text>
              }
              {this.props.excel &&
                <Text
                  onPress={() => this.sendEmail(docType.EXCEL)}
                  style={[Style.Main.fontAlbert14, Style.Main.alignCenter, Style.Main.py7, Style.Main.textBlack]}
                >{_('Kirim')} Excel
                </Text>
              }
            </View>
          </Modal>
          <Icon
            type="FontAwesome"
            name="download"
            onPress={() => this.setState(prevState => ({ showDowloadOpt: !prevState.showDowloadOpt }))}
            style={[Style.Main.textBlack, Style.Main.font20, Style.Main.pl10, Style.Main.mr10]}
          />
          <Modal transparent animationType="fade" visible={showDowloadOpt} onRequestClose={() => this.setState({ showDowloadOpt: false })}>
            <TouchableOpacity
              activeOpacity={0.5}
              onPress={() => this.setState({ showDowloadOpt: false })}
              style={[Style.Main.container, Style.Main.backgroundLightSmoke, Style.Main.halfOpacity]}
            />
            <View
              style={[Style.Main.backgroundWhite, Style.Main.height100,
                Style.Main.justifyBottom, Style.Main.justifySpaceBetween, Style.Main.padding12,
              ]}
            >
              {this.props.pdf &&
                <Text
                  onPress={() => this.download(docType.PDF)}
                  style={[Style.Main.fontAlbert14, Style.Main.alignCenter, Style.Main.py7, Style.Main.textBlack]}
                >{_('Unduh')} PDF
                </Text>
              }
              {this.props.excel &&
                <Text
                  onPress={() => this.download(docType.EXCEL)}
                  style={[Style.Main.fontAlbert14, Style.Main.alignCenter, Style.Main.py7, Style.Main.textBlack]}
                >{_('Unduh')} Excel
                </Text>
              }
            </View>
          </Modal>
          <LoadingModal show={this.state.isLoading} size="large" color="white" />
        </View>
      );
    } if (this.props.pdfStatus === requestStatus.FETCH || this.props.excelStatus === requestStatus.FETCH) {
      return <ActivityIndicator style={[Style.Main.center]} color="red" size="small" />;
    } return null;
  }

  render() {
    const { data } = this.props;
    const isDataShow = isEmpty(this.props.data) || this.props.dataStatus === requestStatus.FETCH;
    return (
      <ContentCentered>
        <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.fullWidth, data.periodEnding && Style.Main.mb15, Style.Main.mx2]}>
          <Image source={IncomeAgentBanner} style={[Style.Main.absolute, Style.Main.flex1, Style.Main.setSize({ w: '99%', h: 65, r: 5 })]} />
          <View style={[Style.Main.justifyCenter, Style.Main.padding14, Style.Main.container]}>
            <Skeleton
              isLoading={isDataShow}
              layout={[rowLayout({ w: '80%', h: 7 }), rowLayout({ w: '50%', h: 7 })]}
            >
              {(data.agency || data.agentNumber) &&
                <Text style={[Style.Main.fontAlbertBold14, Style.Main.textWhite]}>
                  {`${data.agency} ${!(!data.agentNumber) && `[${data.agentNumber}]`}`}
                </Text>
              }
              {!(!data.periodEnding) &&
                <Text style={[Style.Main.fontAlbert12, Style.Main.textWhite]}>
                  {_('Periode Berakhir ')}{moment(new Date(data.periodEnding)).format('LL')}
                </Text>
              }
            </Skeleton>
          </View>
        </View>
        {
          data &&
          <Card style={[Style.Main.padding12, Style.Main.container]}>
            <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.borderBottomGray, Style.Main.pb10]}>
              <Skeleton
                isLoading={isDataShow}
                layout={[rowLayout({ w: '70%', h: 7 }), rowLayout({ w: '50%', h: 10 })]}
              >
                <View style={[Style.Main.flex8]}>
                  <Text style={[Style.Main.fontAlbert14, Style.Main.textBlack]}>{_('Total Pendapatan Bersih')}</Text>
                  <Text style={[Style.Main.fontAlbert16, Style.Main.textRed]}>IDR {toFixedCurrency(data.total || 0, 2)}</Text>
                </View>
              </Skeleton>
              {this.renderButtons()}
            </View>

            <Skeleton
              isLoading={isDataShow}
              layout={skeletonLayout}
            >
              <IncomeComponent
                label={`A - ${_('Overriding')}`}
                value={data.a ? data.a.total : 0}
                // onPress={data.viewDetailEnabled ? (() => {}) : null}
                onExpand={data.a && data.a.detail && data.a.detail.length
                  ? (() => this.setState(prevState => ({ overridingDetail: !prevState.overridingDetail }))) : null}
                isExpanded={this.state.overridingDetail}
              />
              {
                this.state.overridingDetail &&
                <View style={[Style.Main.redBorderBottom, Style.Main.fullWidth]}>
                  {data.a.detail.map((x, i) => <IncomeComponent key={i} isDetail label={x.key} value={x.value} />)}
                </View>
              }
              <IncomeComponent
                label={`B - ${_('Komisi')}`}
                onPress={data.viewDetailEnabled ? () => this.props.navigation.navigate('CommissionDetail', { endPeriod: data.periodEnding }) : null}
                value={data.b ? data.b.total : 0}
              />
              <IncomeComponent
                label={`C - ${_('Grup Overriding')}`}
                value={data.l ? data.l.total : 0}
              // onPress={data.viewDetailEnabled ? (() => {}) : null}
              />
              <IncomeComponent
                label={`D - ${_('Grup Komisi')}`}
                value={data.k ? data.k.total : 0}
              // onPress={data.viewDetailEnabled ? (() => {}) : null}
              />
              <IncomeComponent
                label={`E - ${_('Pendapatan / Pembayaran / Pengurangan')}`}
                value={data.c ? data.c.total : 0}
              // onPress={data.viewDetailEnabled ? (() => {}) : null}
              />
              <IncomeComponent label={`F - ${_('Total Pendapatan Kotor')}`} info="(A+B+C+D+E)" value={data.d ? data.d.total : 0} />
              <IncomeComponent
                label={`G - ${_('Perhitungan Pajak')}`}
                onExpand={data.e && data.e.detail && data.e.detail.length ?
                  () => this.setState(prevState => ({ detailShowed: !prevState.detailShowed })) : null}
                isExpanded={this.state.detailShowed}
                value={data.e ? data.e.total : 0}
              />
              {
                this.state.detailShowed && data.e.detail.map((x, i) => (
                  <View key={i} style={[Style.Main.grayBorderBottom, Style.Main.fullWidth]}>
                    <IncomeComponent isDetail label={`G1 - ${_('Last Period Commission')}`} value={x.e1} />
                    <IncomeComponent isDetail label={`G2 - ${_('Total Gross Commission Current Month')}`} info="(F+G1)" value={x.e2} />
                    <IncomeComponent isDetail label={`G3 - ${_('Income for Tax')}`} value={x.e3} />
                    <IncomeComponent isDetail label={`G4 - ${_('Income Gross Earned')}`} value={x.e4} />
                    <IncomeComponent isDetail label={`G5 - ${_('50% Income for Tax (*1)')}`} value={x.e5} />
                    <IncomeComponent isDetail label={`G6 - ${_('PTKP <TO>')}`} value={x.e6} />
                    <IncomeComponent isDetail label={`G7 - ${_('PKP')}`} value={x.e7} />
                    <IncomeComponent isDetail label={`G8 - ${_('C/F PKP Last Month')}`} value={x.e8} />
                    <IncomeComponent isDetail label={`G9 - ${_('YTD PKP')}`} value={x.e9} />
                    <View
                      style={[Style.Main.backgroundWhiteSmoke, Style.Main.padding12,
                        Style.Main.borderBottomWidth1, { borderBottomColor: Colors.white }]}
                    >
                      <View style={[Style.Main.backgroundWhite, Style.Main.borderRadius5]}>
                        <Text style={[Style.Main.fontAlbert11, Style.Main.textRed, Style.Main.mt12, Style.Main.ml12, Style.Main.pl2]}>
                          {_('Tax Income Article 21 (PPh 21) for Personal')}
                        </Text>
                        {x.tax1Header !== '' && <IncomeComponent label={x.tax1Header} value={x.tax1} />}
                        {x.tax2Header !== '' && <IncomeComponent label={x.tax2Header} value={x.tax2} />}
                        {x.tax3Header !== '' && <IncomeComponent label={x.tax3Header} value={x.tax3} />}
                        {x.tax4Header !== '' && <IncomeComponent label={x.tax4Header} value={x.tax4} />}
                        {x.tax5Header !== '' && <IncomeComponent label={x.tax5Header} value={x.tax5} />}
                      </View>
                    </View>
                    <IncomeComponent isDetail label={`G10 - ${_('MTD Total Tax')}`} value={x.e10} />
                    <IncomeComponent isDetail label={`G11 - ${_('MTD Tax already Deducted in Last Period')}`} value={x.e11} />
                    <IncomeComponent isDetail label={`G12 - ${_('Remaining Tax to be Deducted')}`} value={x.e12} />
                    <IncomeComponent isDetail label={`G13 - ${_('Tax Refund')}`} value={x.e13} />
                  </View>
                ))
              }
              <IncomeComponent label={`H - ${_('Komisi Bersih')}`} value={data.f ? data.f.total : 0} />
              <IncomeComponent
                label={`I - ${_('Net Adjustment')}`}
                value={data.g ? data.g.total : 0}
              // onPress={data.viewDetailEnabled ? (() => {}) : null}
              />
              <IncomeComponent label={`J - ${_('Balance')}`} value={data.h ? data.h.total : 0} />
              <IncomeComponent
                label={`K - ${_('Lainnya')}`}
                value={data.i ? data.i.total : 0}
              // onPress={data.viewDetailEnabled ? (() => {}) : null}
              />
              <IncomeComponent label={`L - ${_('Payable')}`} info="(H+I+J+K)" value={data.j ? data.j.total : 0} />
            </Skeleton>
          </Card>
        }
        <IncomePassword
          visible={this.state.infoShowed}
          onRequestClose={() => this.setState({ infoShowed: false })}
          passwordFormat="ddMmmyyyyCPS"
          passwordExample="01Aug1970CPS"
        />
      </ContentCentered>
    );
  }
}

const skeletonLayout = [{
  flexDirection: 'row',
  justifyContent: 'space-between',
  width: '100%',
  height: 8,
  marginLeft: 10,
  marginTop: 17,
  marginBottom: 10,
  children: [
    { width: '90%', height: '100%', borderRadius: 1 },
  ],
}, {
  flexDirection: 'row',
  justifyContent: 'space-between',
  width: '100%',
  height: 8,
  marginLeft: 10,
  marginTop: 10,
  marginBottom: 10,
  children: [
    { width: '90%', height: '100%', borderRadius: 1 },
  ],
}, {
  flexDirection: 'row',
  justifyContent: 'space-between',
  width: '100%',
  height: 8,
  marginLeft: 10,
  marginTop: 10,
  marginBottom: 10,
  children: [
    { width: '90%', height: '100%', borderRadius: 1 },
  ],
}];

export default IncomeStatement;
