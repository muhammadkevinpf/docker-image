/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import ViewsHome from './views';

export default {
  MainHome: { screen: ViewsHome.MainHome },

  SignInHome: { screen: ViewsHome.SignInHome },
  MainRouteHome: { screen: ViewsHome.MainRouteHome },
  AgentDataVerification: { screen: ViewsHome.AgentDataVerification },
  ForgotPruIDNonAgentHome: { screen: ViewsHome.ForgotPruIDNonAgentHome },
  SecurityQuestions: { screen: ViewsHome.SecurityQuestions },

  SignUpHome: { screen: ViewsHome.SignUpHome },
  SignUpAgentHome: { screen: ViewsHome.SignUpAgentHome },
  SignUpAgentSFARegHome: { screen: ViewsHome.SignUpAgentSFARegHome },
  SignUpNonAgentHome: { screen: ViewsHome.SignUpNonAgentHome },

  ListPruHospitalHome: { screen: ViewsHome.ListPruHospitalHome },
  ListPruAgentOfficeHome: { screen: ViewsHome.ListPruAgentOfficeHome },

  PrivacyPolicyHome: { screen: ViewsHome.PrivacyPolicyHome },

  SMSVerification: { screen: ViewsHome.SMSVerification },
  SignUpAgent: { screen: ViewsHome.SignUpAgent },
};
