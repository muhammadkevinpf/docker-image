/* eslint-disable max-len */
/* eslint-disable no-console */
import { takeLatest } from 'redux-saga/effects';
import { correspondenceAction } from './ActionCorrespondence';
import { apiSagaFunction } from '../../utilities/Functions';
import {
  GET_LETTER_TYPE, GET_UNIT_AGENT, GET_UNIT_AGENT_LEADER, GET_DOCUMENT_CATEGORY,
  GET_PASSWORD_INFO, GET_PDF_DOCUMENT, SEND_CORRESPONDENCE_DOC, GET_CORRESPONDENCE, GET_DOC_CATEGORY, GET_DOC_BY_ID, GET_DOC_BASE64, SEND_DOC_BY_EMAIL,
} from './ConfigCorrespondence';
import { apiTakeLatest } from '../../utilities';

const timeout = 20000;
export const watcherCorrespondence = [
  takeLatest(GET_LETTER_TYPE.FETCH, params => apiSagaFunction(params.payload, correspondenceAction, GET_LETTER_TYPE, { timeout, isResponArray: true })),
  takeLatest(GET_UNIT_AGENT.FETCH, params => apiSagaFunction(params.payload, correspondenceAction, GET_UNIT_AGENT, { timeout })),
  takeLatest(GET_UNIT_AGENT_LEADER.FETCH, params => apiSagaFunction(params.payload, correspondenceAction, GET_UNIT_AGENT_LEADER, { timeout })),
  takeLatest(GET_DOCUMENT_CATEGORY.FETCH, params => apiSagaFunction(params.payload, correspondenceAction, GET_DOCUMENT_CATEGORY, { timeout, isResponArray: true })),
  takeLatest(GET_PASSWORD_INFO.FETCH, params => apiSagaFunction(params.payload, correspondenceAction, GET_PASSWORD_INFO, { timeout, isResponArray: true })),
  takeLatest(GET_PDF_DOCUMENT.FETCH, params => apiSagaFunction(params.payload, correspondenceAction, GET_PDF_DOCUMENT, { timeout, isResponArray: true })),
  takeLatest(SEND_CORRESPONDENCE_DOC.FETCH, params => apiSagaFunction(params.payload, correspondenceAction, SEND_CORRESPONDENCE_DOC, { timeout })),
  takeLatest(GET_CORRESPONDENCE.FETCH, params => apiSagaFunction(params.payload, correspondenceAction, GET_CORRESPONDENCE, { timeout, isResponArray: true })),

  apiTakeLatest(GET_DOC_CATEGORY, { timeout, isResponArray: true }),
  apiTakeLatest(GET_DOC_BY_ID, { timeout, resAttribute: 'data' }),
  apiTakeLatest(GET_DOC_BASE64, { timeout, resAttribute: 'data' }),
  apiTakeLatest(SEND_DOC_BY_EMAIL, { timeout, resAttribute: 'data' }),
];
