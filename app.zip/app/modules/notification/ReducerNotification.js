import {
  TOTALNOTIFICATIONFETCH,
  TOTALNOTIFICATIONSUCCESS,
  TOTALNOTIFICATIONFAILED,
  LISTNOTIFICATIONFETCH,
  LISTNOTIFICATIONSUCCESS,
  LISTNOTIFICATIONFAILED,
  UPDATENOTIFICATIONFAILED,
  UPDATENOTIFICATIONFETCH,
  UPDATENOTIFICATIONSUCCESS,
} from './ConfigNotification';
import { RESET_ALL_STATE } from '../dashboard/ConfigDashboard';

const initialStateNotification = {
  fetchTotalNotification: false,
  fetchListNotification: false,
  fetchUpdateNotification: false,
  send: null,
  res: { listNotification: [] },
  err: null,
};

export function ReducerNotification(state = initialStateNotification, action) {
  switch (action.type) {
    case RESET_ALL_STATE: return initialStateNotification;
    case TOTALNOTIFICATIONFETCH:
      return {
        ...state,
        fetchTotalNotification: true,
        send: action.send,
        action: action.type,
      };

    case TOTALNOTIFICATIONSUCCESS:
      return {
        ...state,
        fetchTotalNotification: false,
        err: null,
        action: action.type,
      };

    case TOTALNOTIFICATIONFAILED:
      return {
        ...state,
        fetchTotalNotification: false,
        err: action.err,
        action: action.type,
      };

    case LISTNOTIFICATIONFETCH:
      return {
        ...state,
        fetchListNotification: true,
        send: action.send,
        action: action.type,
        res: {
          ...state.res,
          listNotification: action.send.isRefresh ? [] : state.res.listNotification,
        },
      };

    case LISTNOTIFICATIONSUCCESS:
      return {
        ...state,
        fetchListNotification: false,
        res: {
          ...state.res,
          listNotification: [...state.res.listNotification, ...action.res],
        },
        err: null,
        action: action.type,
      };

    case LISTNOTIFICATIONFAILED:
      return {
        ...state,
        fetchListNotification: false,
        err: action.err,
        action: action.type,
      };

    case UPDATENOTIFICATIONFETCH:
      return {
        ...state,
        fetchUpdateNotification: true,
        send: action.send,
        action: action.type,
      };

    case UPDATENOTIFICATIONSUCCESS:
      return {
        ...state,
        fetchUpdateNotification: false,
        res: {
          ...state.res,
          updateNotification: { status: action.res, id: parseInt(JSON.parse(state.send.params)[0], 0) },
        },
        action: action.type,
      };

    case UPDATENOTIFICATIONFAILED:
      return {
        ...state,
        fetchUpdateNotification: false,
        err: action.err,
        action: action.type,
      };

    default:
      return state;
  }
}
