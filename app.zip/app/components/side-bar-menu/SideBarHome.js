import React from 'react';
import PropTypes from 'prop-types';
import Communications from 'react-native-communications';
import { Image, TouchableOpacity, View } from 'react-native';
import { isTablet } from '../../utilities';
import { iconPhone, iconOffice, iconHospital } from '../../assets/images';
import Style from '../../styles';

const route = {
  OFFICE: 'ListPruAgentOfficeHome',
  HOSPITAL: 'ListPruHospitalHome',
};
const Icon = ({ onPress = () => {}, ...props }) => (
  <TouchableOpacity onPress={onPress} style={[Style.Main.ml20, Style.Main.mr20, Style.Main.padding15, Style.Main.center]}>
    <Image style={[Style.Main.setSize({ w: isTablet() ? 30 : 25, h: isTablet() ? 30 : 25 })]} {...props} />
  </TouchableOpacity>
);

const style = { backgroundColor: '#800106' };

class SideBarHome extends React.PureComponent {
  render() {
    if (!this.props.visible) return null;
    return (
      <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.borderRadius10, Style.Main.ph15,
        isTablet() ? [Style.Main.mb55, Style.Main.mt20] : [Style.Main.mb20, Style.Main.mt40], style]}
      >
        <Icon source={iconPhone} onPress={() => Communications.phonecall('1500085', true)} />
        <Icon
          onPress={this.props.navigation.state.routeName === route.OFFICE ? () => {} : () => this.props.navigation.replace(route.OFFICE)}
          source={iconOffice}
        />
        <Icon
          onPress={this.props.navigation.state.routeName === route.HOSPITAL ? () => {} : () => this.props.navigation.replace(route.HOSPITAL)}
          source={iconHospital}
        />
        {/* sementara di hide karena kasus sm agency, confirm ke PO udah boleh di buka atau belum */}
        {/* <OutlineIconButton
            label={_('Informasi')}
            onPress={() => Linking.openURL('https://prupartner-content.prudential.co.id/user_manual/usermanual-prufast.pdf')}
            iconImage={iconInfo}
          /> */}
      </View>
    );
  }
}

SideBarHome.propTypes = {
  visible: PropTypes.bool,
};

SideBarHome.defaultProps = {
  visible: true,
};

export default SideBarHome;
