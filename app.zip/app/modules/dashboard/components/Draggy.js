/* eslint-disable react/no-array-index-key */
/* eslint-disable react/no-unused-state */
import React, { Component } from 'react';
import { TouchableOpacity } from 'react-native';
import {
  Text, View, Icon, Thumbnail,
} from 'native-base';
import { Draggable, DropZone } from 'react-native-drag-drop-and-swap';
import Style from '../../../styles';
import _ from '../../../lang';
import { trackEvent } from '../../../utilities';


// Main component to render
class DraggyInner extends Component {
  render() {
    const mobileStyle = !this.props.isTablet && this.props.index >= 8 && this.props.index <= 11;
    const lainnya = this.props.isTablet ? 4 : 7;
    const draggyStyle = {
      height: mobileStyle ? 120 : 100,
      width: 100,
      alignItems: 'center',
      justifyContent: 'center',
    };

    return (
      <View style={[draggyStyle]}>
        <View style={Style.Main.container}>
          <View
            style={[
              Style.Main.alignCenter,
              Style.Main.itemCenter,
              this.props.isTablet && Style.Main.mt15,
              mobileStyle && Style.Main.mt20,
              (this.props.index === lainnya || this.props.disabled) && Style.Main.quarterOpacity,
            ]}
          >
            {
              this.props.index !== lainnya && this.props.onEdit && (
                <View style={[Style.Main.moveBadge]}>
                  <Icon
                    name="move"
                    type="Feather"
                    style={[Style.Main.textBlack, Style.Main.font18, Style.Main.container]}
                  />
                </View>
              )
            }
            {/* <Image
              source={this.props.data.iconImage}
              style={[Style.Main.alignCenter,
                Style.Main.outlineIconButton,
                Style.Main.resizeContain,
                Style.Main.borderRadius8,
                this.props.fillColor && [Style.Main.backgroundRed, Style.Main.quarterOpacity],
              ]}
            /> */}
            <Thumbnail
              source={this.props.data.iconImage}
              square
              style={[
                Style.Main.outlineIconButton,
                this.props.fillColor && [Style.Main.backgroundRed, Style.Main.quarterOpacity, Style.Main.borderRadius8],
              ]}
            />
          </View>
          <Text
            style={[Style.Main.textCenter, Style.Main.font11, Style.Main.mt3,
              Style.Main.textLineHeight15, Style.Main.fontAlbert, Style.Main.textAlmostBlack]}
          >
            {_(this.props.data.label)}
          </Text>
        </View>
      </View>
    );
  }
}

// Drag helper
class Draggy extends Component {
  handlePress = () => {
    if (this.props.disabled) return;
    if (this.props.data.isAnalytical) trackEvent(this.props.data.label, this.props.agentCode);
    this.props.data.onPress();
  }

  render() {
    const lainnya = this.props.isTablet ? 4 : 7;
    const borderGray = this.props.isTablet ? Style.Main.borderRightBrightGray : [Style.Main.borderBottomBrightGray, Style.Main.borderBottomWidth1];
    return (
      <View style={[
        !this.props.isTablet ? Style.Main.width25pr : Style.Main.height20pr,
        Style.Main.justifyCenter,
        Style.Main.itemCenter,
        this.props.borderGray && borderGray,
      ]}
      >
        {
          this.props.onEdit ? (
            <Draggable
              data={this.props.data}
              dragOn="onPressIn"
              disabled={this.props.index === lainnya}
            >
              <DropZone
                onLeave={this.props.onLeave}
                onDrop={e => this.props.onDrop(e)}
                onEnter={() => this.props.onHover(this.props.data, this.props.index)}
                disabled={this.props.index === lainnya}
              >
                <DraggyInner {...this.props} />
              </DropZone>
            </Draggable>
          )
            : (
              <TouchableOpacity onPress={this.handlePress}>
                <DraggyInner {...this.props} />
              </TouchableOpacity>
            )
        }
      </View>
    );
  }
}

export default (Draggy);
