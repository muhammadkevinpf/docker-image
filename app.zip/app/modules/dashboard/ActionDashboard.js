import {
  STORE_NEWS_BANNER, RESET_STATUS, RESET_ALL_STATE, UPDATE_DASHBOARD_ICONS,
} from './ConfigDashboard';

/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

export const dashboardAction = (action, value) => ({ type: action, payload: value });

// DASHBOARD - NEWS BANNER

export const storeNewsBanner = value => ({ type: STORE_NEWS_BANNER, payload: value });

export const firstBannerFetch = (action, value) => ({ type: action, payload: value });
export const secondBannerFetch = (action, value) => ({ type: action, payload: value });
export const thirdBannerFetch = (action, value) => ({ type: action, payload: value });

export const resetStatus = () => ({ type: RESET_STATUS });

// DASHBOARD - CAMPAIGN BANNER

export const campaignBannerFetch = (action, value) => ({ type: action, payload: value });
export const firstCampaignFetch = (action, value) => ({ type: action, payload: value });
export const secondCampaignFetch = (action, value) => ({ type: action, payload: value });
export const thirdCampaignFetch = (action, value) => ({ type: action, payload: value });

// SETTINGS

export const changePasswordFetch = (action, value) => ({ type: action, payload: value });
export const resetAllRedux = () => ({ type: RESET_ALL_STATE });

// UPDATE DASHBOARD ICONS

export const updateDashboardIcons = value => ({ type: UPDATE_DASHBOARD_ICONS, payload: value });
