import MainPersistency from './main-persistency';
import { PersistencyGroupUnit, PersistencyIndividu } from './persistency-details';
import PersistencyHistoryScreen from './persistency-history-detail';

export default {
  MainPersistency,
  PersistencyGroupUnit,
  PersistencyIndividu,
  PersistencyHistoryScreen,
};
