import {
  StyleSheet, View, SectionList, TouchableWithoutFeedback, Image,
} from 'react-native';
import React from 'react';
import PropTypes from 'prop-types';
import Style from '../../styles';
import { isEmpty, isTablet, requestStatus } from '../../utilities';
import { StyledText } from '../common-components';
import { MessageNoData, RenderFooter } from '../list-information';
import { NotFound } from '../../assets/images';
import Colors from '../../styles/Colors';
import _ from '../../lang';

const EmptyComponent = ({
  refreshing, ListEmptyImage, statusList, ListEmptyText,
}) => {
  if (refreshing) return <View />;
  return (
    <View style={[Style.Main.container, Style.Main.center, Style.Main.alignCenter]}>
      <Image
        resizeMode="contain"
        source={ListEmptyImage}
        style={[isTablet() ? Style.Main.height150 : Style.Main.height175, Style.Main.alignCenter]}
      />
      <MessageNoData style={Style.Main.mt5} text={statusList === requestStatus.FAILED ? _('Gagal mengambil data') : ListEmptyText} />
    </View>
  );
};

/**
 * @description A modified react-native SelectionList with a sidebar sections to scroll to a specific section
 * @augments {React.Component<Props, State>}
 */
class CustomSectionList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showSidebar: false,
      timer: null,
      loadMoreData: false,
      noMoreData: false,
    };
  }

  shouldComponentUpdate = (nextProps, nextState) => {
    if (nextProps.sections !== this.props.sections
      || nextProps.statusList !== this.props.isLoading
      || nextState.showSidebar !== this.state.showSidebar) return true;
    return false;
  }

  onHideSidebar = () => { this.setState({ timer: setTimeout(() => { this.setState({ showSidebar: false }); }, 3000) }); };

  onShowSidebar = () => this.setState({ showSidebar: true }, () => clearTimeout(this.state.timer))

  scrollTo = index => this.sectionList.scrollToLocation({ animated: true, itemIndex: 0, sectionIndex: index });

  renderFooter = () => (
    <RenderFooter
      isOnline
      isLastData={this.state.noMoreData}
      showIndicator={this.state.loadMoreData}
    />
  )

  render() {
    const { showSidebar } = this.state;
    const {
      sections, hideSideBar, onRefresh, refreshing, renderItem, renderSectionHeader, statusList, style,
      ListHeaderComponent, ListEmptyImage, ListEmptyText,
    } = this.props;
    const isDataEmpty = isEmpty(sections);
    return (
      <>
        <SectionList
          disableVirtualization
          initialNumToRender={30}
          maxToRenderPerBatch={30}
          windowSize={5}
          initialScrollIndex={0}
          contentContainerStyle={[Style.Main.pb15, isDataEmpty && Style.Main.container]}
          ref={(ref) => { this.sectionList = ref; }}
          keyExtractor={(item, index) => index}
          onScrollToIndexFailed={() => { }}
          onMoveShouldSetResponder={() => true}
          onResponderMove={this.onShowSidebar}
          onResponderEnd={this.onHideSidebar}
          onRefresh={onRefresh}
          refreshing={refreshing}
          renderItem={renderItem}
          sections={sections}
          renderSectionHeader={renderSectionHeader}
          style={style}
          ListFooterComponent={this.renderFooter}
          ListHeaderComponent={ListHeaderComponent}
          ListEmptyComponent={(
            <EmptyComponent statusList={statusList} ListEmptyImage={ListEmptyImage} ListEmptyText={ListEmptyText} refreshing={refreshing} />
          )}
        />
        {
          showSidebar && !isEmpty(sections) && sections.length > 5 && !hideSideBar &&
          <View style={styles.sidebarContainer}>
            <View style={styles.sidebar}>
              {
                sections.map((item, index) => (
                  <TouchableWithoutFeedback
                    key={index.toString()}
                    onPressOut={this.onHideSidebar}
                    onPressIn={this.onShowSidebar}
                    onPress={() => {
                      let lastItem = index;
                      if (this.sectionList) {
                        lastItem = Object.keys(this.sectionList._wrapperListRef._cellRefs).pop();
                        const lastSection = lastItem.slice(0, lastItem.indexOf(':'));
                        if (lastSection < index) return this.scrollTo(lastSection);
                      }
                      return this.scrollTo(index);
                    }}
                  >
                    <StyledText bold key={index.toString()} font={isTablet() ? 11 : 12} style={styles.sidebarItem}>{item.title}</StyledText>
                  </TouchableWithoutFeedback>
                ))
              }
            </View>
          </View>
        }
      </>
    );
  }
}

CustomSectionList.propTypes = {
  /**
   * ```js
   * sections = [{ title: '', data: [] }];
   * ```
   */
  sections: PropTypes.arrayOf(PropTypes.object).isRequired,
  hideSideBar: PropTypes.bool,
  statusList: PropTypes.string,
  renderItem: PropTypes.oneOfType([PropTypes.string, PropTypes.elementType, PropTypes.object]).isRequired,
  renderSectionHeader: PropTypes.oneOfType([PropTypes.string, PropTypes.elementType, PropTypes.object]).isRequired,
  ListEmptyText: PropTypes.oneOfType([PropTypes.string, PropTypes.elementType, PropTypes.object]),
  ListEmptyImage: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

CustomSectionList.defaultProps = {
  hideSideBar: false,
  statusList: requestStatus.IDLE,
  ListEmptyText: null,
  ListEmptyImage: NotFound,
};

const styles = StyleSheet.create({
  sidebarContainer: {
    height: '100%',
    position: 'absolute',
    display: 'flex',
    justifyContent: 'center',
    alignContent: 'center',
    right: 0,
    padding: 5,
  },
  sidebar: {
    opacity: 0.8,
    borderRadius: 15,
    backgroundColor: Colors.ee,
    paddingVertical: 2,
  },
  sidebarItem: {
    paddingHorizontal: 5,
    paddingVertical: isTablet() ? 2 : 5,
    textAlign: 'center',
  },
});

export default CustomSectionList;
