/* eslint-disable react-native/no-inline-styles */
/* eslint-disable no-console */


import React, { Component } from 'react';
import ImagePicker from 'react-native-image-picker';
import RNTextDetector from 'react-native-text-detector';
import {
  BackHandler, StyleSheet, Dimensions, Alert,
} from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { RNCamera } from 'react-native-camera';
import {
  Container, Button, Text, View, Content,
} from 'native-base';
import BarcodeMask from 'react-native-barcode-mask';
import moment from 'moment';
import {
  LoadingModal, InputFieldNew, DatePickerNew, RadioListCard, DropdownNew, AutoCompleteNew,
} from '../../../components';
import Style from '../../../styles';
import Colors from '../../../styles/Colors';
import _ from '../../../lang';
import {
  getGender, getReligion, isIndonesian, getRtRw, getNIK, getInformationFromNIK, getName, getMaritalStatus,
} from '../utilities/OcrFunction';
import { ConfigProduct } from '../../sqs-spaj/config';
import { ConfigProductSPAJ } from '../../spaj/configs';
import NavigationService from '../../../bootstrap/NavigationService';

class OcrResearch extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      openCamera: false,
      genderMatching: '',
      religion: '',
      isWNI: null,
      rt: '',
      rw: '',
      nik: '',
      birthday: null,
      gender: '',
      name: '',
      data: {},
      provinsi: '',
      kecamatan: '',
      kota: '',
      maritalStatus: '',
      isInvalidNIK: '',
    };
  }

  componentDidMount = () => {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => { this.goBack(); return true; });
  }

  componentWillUnmount = () => {
    this.backHandler.remove();
  }

  goBack = () => NavigationService.gotoDashboard()

  proccessData = async (data) => {
    const size = this.state.data;
    console.log('PROCESSING DATA...');
    const { rt, rw } = getRtRw(data);
    const name = await getName(data, size.width, size.height);
    const nik = await getNIK(data, size.width, size.height);
    const genderMatching = getGender(data);
    const maritalStatus = getMaritalStatus(data);
    const religion = getReligion(data, size.width);
    const isWNI = isIndonesian(data, size.width);
    const {
      birthday, gender, provinsi, kecamatan, kota, isInvalidNIK,
    } = getInformationFromNIK(nik);
    if (isInvalidNIK) {
      Alert.alert(_('Peringatan'), _('NIK tidak valid. Silakan foto KTP kembali'));
    }
    return this.setState({
      genderMatching, religion, isWNI, rt, rw, nik, birthday, gender, name, provinsi, kecamatan, kota, maritalStatus, isInvalidNIK, isLoading: false,
    }, () => {
      console.log('THIS STATE : ', this.state);
    });
  }

  detectText = async () => {
    this.setState({ isLoading: true });
    try {
      const options = {
        quality: 0.8,
        cameraType: 'back',
        mediaType: 'photo',
        base64: true,
        skipProcessing: true,
      };
      let visionResp = '';
      await ImagePicker.launchCamera(options, async (response) => {
        if (response.didCancel) console.log('cancelled');
        else if (response.error) console.log('ImagePicker error: ', response.error);
        else if (response.customButton) console.log('ImagePicker custom button: ', response.customButton);
        try {
          visionResp = await RNTextDetector.detectFromUri(response.uri);
          await this.proccessData(visionResp);
          this.setState({ isLoading: false });
          console.log(visionResp);
        } catch (e) {
          Alert.alert('Warning', e);
          this.setState({ isLoading: false });
        }
      });
    } catch (e) {
      Alert.alert('Warning', e);
      this.setState({ isLoading: false });
    }
  };

  takePicture = async () => {
    if (this.camera) {
      try {
        const options = {
          quality: 0.8,
          base64: true,
          skipProcessing: true,
          pauseAfterCapture: true,
          orientation: 'portrait',
        };
        const data = await this.camera.takePictureAsync(options);
        console.log(data);
        this.setState({ openCamera: false, isLoading: true, data });
        try {
          const visionResp = await RNTextDetector.detectFromUri(data.uri);
          this.proccessData(visionResp);
          console.log(visionResp);
        } catch (e) {
          Alert.alert('Warning', e);
          this.setState({ isLoading: false });
        }
      } catch (e) {
        Alert.alert('Warning', e);
      }
    } else { console.log('Camera not ready'); }
  };

  closeCam = () => this.setState({ openCamera: false });

  onEditName = name => this.setState({ name });

  onGenderChange = gender => this.setState({ gender });

  onMaritalStatusChange = maritalStatus => this.setState({ maritalStatus });

  onReligionChange = religion => this.setState({ religion });

  onBirthdayChange = date => this.setState({ birthday: moment(date).format('DD-MM-YYYY') });

  onNIKChange = nik => this.setState({ nik });

  onRTChange = rt => this.setState({ rt });

  onRWChange = rw => this.setState({ rw });

  onKecamatanChange = kecamatan => this.setState({ kecamatan });

  onKotaChange = kota => this.setState({ kota });

  onProvinceChange = provinsi => this.setState({ provinsi })

  render() {
    const type = 'rn';
    if (type === 'rn') {
      return (
        <Container>
          {
            this.state.openCamera ?
              <View style={styles.container}>
                <RNCamera
                  ref={(ref) => {
                    this.camera = ref;
                  }}
                  style={styles.preview}
                  captureAudio={false}
                  onPictureTaken={() => this.setState({ isLoading: true })}
                  type={RNCamera.Constants.Type.back}
                  androidCameraPermissionOptions={{
                    title: 'Permission to use camera',
                    message: 'We need your permission to use your camera',
                    buttonPositive: 'Ok',
                    buttonNegative: 'Cancel',
                  }}
                >
                  <Text style={[Style.Main.mt30, Style.Main.fontAlbert1, Style.Main.textWhite]}>{_('Sesuaikan KTP dengan area foto')}</Text>
                  <BarcodeMask
                    width={Dimensions.get('window').width * 0.9}
                    height={Dimensions.get('window').width * 0.9 * 235 / 370}
                    // width={370}
                    // height={230}
                    edgeColor={Colors.red}
                    showAnimatedLine={false}
                    edgeBorderWidth={1}
                  />
                  <View style={{
                    position: 'absolute',
                    height: '100%',
                    width: '100%',
                    justifyContent: 'center',
                  }}
                  >
                    <View style={{
                      marginTop: -((Dimensions.get('window').width * 0.9 * 235 / 370) * 17 / 27),
                      marginLeft: (Dimensions.get('window').width * 0.05) + (Dimensions.get('window').width * 0.9 * 20 / 85),
                      height: (Dimensions.get('window').width * 0.9 * 235 / 370) * 35 / 530,
                      width: (Dimensions.get('window').width * 0.9 * 40 / 85),
                      borderWidth: 1,
                      borderColor: Colors.red,
                    }}
                    />
                  </View>
                  <View style={{
                    position: 'absolute',
                    height: '100%',
                    width: '100%',
                    justifyContent: 'center',
                  }}
                  >
                    <View style={{
                      marginTop: ((Dimensions.get('window').width * 0.9 * 235 / 370) * 4 / 53),
                      marginLeft: (Dimensions.get('window').width * 0.05) + (Dimensions.get('window').width * 0.9 * 22 / 85),
                      height: (Dimensions.get('window').width * 0.9 * 235 / 370) * 33 / 54,
                      width: (Dimensions.get('window').width * 0.9 * 38 / 85),
                      borderWidth: 1,
                      borderColor: Colors.red,
                    }}
                    />
                  </View>
                </RNCamera>
                <View style={{ flex: 0, flexDirection: 'row', justifyContent: 'center' }}>
                  <TouchableOpacity onPress={this.closeCam} style={styles.capture}>
                    <Text style={{ fontSize: 14 }}> CLOSE </Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={this.takePicture} style={styles.capture}>
                    <Text style={{ fontSize: 14 }}> SNAP </Text>
                  </TouchableOpacity>
                </View>
              </View> :
              <Content style={[Style.Main.containerWithPadding12]}>
                <Button
                  block
                  style={Style.Main.btnPrimary}
                  onPress={() => { this.setState({ openCamera: true }); }}
                >
                  <Text>
                    {_('Ambil Gambar')}
                  </Text>
                </Button>
                <View style={[Style.Main.mb30]}>
                  <InputFieldNew
                    value={this.state.name}
                    label={_('Nama Lengkap')}
                    onChangeText={this.onEditName}
                  />
                  <InputFieldNew
                    value={this.state.nik}
                    label={_('NIK')}
                    type="phone"
                    onChangeText={this.onNIKChange}
                    maxLength={16}
                    editable
                  />
                  <DatePickerNew
                    defaultDate={this.state.birthday ? moment(this.state.birthday, 'DD-MM-YYYY').toDate() : null}
                    maximumDate={new Date()}
                    locale="id"
                    timeZoneOffsetInMinutes={undefined}
                    modalTransparent={false}
                    animationType="fade"
                    androidMode="spinner"
                    label={_('Tanggal Lahir')}
                    onDateChange={this.onBirthdayChange}
                    style={[Style.Main.fullWidth]}
                  />
                  <RadioListCard
                    title="Jenis Kelamin"
                    itemList={ConfigProduct.gender}
                    selectedValue={this.state.gender || this.state.genderMatching}
                    onSelect={this.onGenderChange}
                    isDoubleCol
                  />
                  <AutoCompleteNew
                    onPress={this.onProvinceChange}
                    selectedValue={this.state.provinsi}
                    label={_('Provinsi')}
                    dropdownData={ConfigProductSPAJ.provinces}
                    styleTextInput={[Style.Main.borderBottomBlurGray, Style.Main.borderBottomWidth1]}
                    isProvince
                  />
                  <InputFieldNew
                    value={this.state.kecamatan}
                    label={_('Kecamatan')}
                    onChangeText={this.onKecamatanChange}
                  />
                  <InputFieldNew
                    value={this.state.kota}
                    label={_('Kota')}
                    onChangeText={this.onKotaChange}
                  />
                  <InputFieldNew
                    value={this.state.rt}
                    label={_('RT')}
                    maxLength={3}
                    onChangeText={this.onRTChange}
                    keyboardType="default"
                    type="postCode"
                  />
                  <InputFieldNew
                    value={this.state.rw}
                    label={_('RW')}
                    maxLength={3}
                    onChangeText={this.onRWChange}
                    keyboardType="default"
                    type="postCode"
                  />
                  <DropdownNew
                    mode="dialog"
                    iosIcon="angle-down"
                    dropdownData={ConfigProduct.maritals}
                    selectedValue={this.state.maritalStatus}
                    onValueChange={this.onMaritalStatusChange}
                    label="Status Pernikahan"
                  />
                  <DropdownNew
                    mode="dialog"
                    iosIcon="angle-down"
                    dropdownData={ConfigProductSPAJ.religionList}
                    selectedValue={this.state.religion}
                    onValueChange={this.onReligionChange}
                    label="Agama"
                  />
                  {/* <Text style={[Style.Main.fontAlbert11, Style.Main.my5]}>genderMatching: {this.state.genderMatching}</Text>
                  <Text style={[Style.Main.fontAlbert11, Style.Main.my5]}>religion: {this.state.religion}</Text>
                  <Text style={[Style.Main.fontAlbert11, Style.Main.my5]}>isWNI: {String(this.state.isWNI)}</Text>
                  <Text style={[Style.Main.fontAlbert11, Style.Main.my5]}>rt: {this.state.rt}</Text>
                  <Text style={[Style.Main.fontAlbert11, Style.Main.my5]}>rw: {this.state.rw}</Text>
                  <Text style={[Style.Main.fontAlbert11, Style.Main.my5]}>nik: {this.state.nik}</Text>
                  <Text style={[Style.Main.fontAlbert11, Style.Main.my5]}>birthday: {this.state.birthday}</Text>
                  <Text style={[Style.Main.fontAlbert11, Style.Main.my5]}>gender: {String(this.state.gender)}</Text>
                  <Text style={[Style.Main.fontAlbert11, Style.Main.my5]}>name: {this.state.name}</Text>
                  <Text style={[Style.Main.fontAlbert11, Style.Main.my5]}>province: {this.state.provinsi}</Text>
                  <Text style={[Style.Main.fontAlbert11, Style.Main.my5]}>kecamatan: {this.state.kecamatan}</Text>
                  <Text style={[Style.Main.fontAlbert11, Style.Main.my5]}>kota: {this.state.kota}</Text>
                  <Text style={[Style.Main.fontAlbert11, Style.Main.my5]}>status pernikahan: {this.state.maritalStatus}</Text> */}
                </View>
              </Content>
          }
          <LoadingModal show={this.state.isLoading} size="large" color="white" />
          {/* <Modal
            animationType="fade"
            visible={this.state.openCamera}
            onRequestClose={() => { this.setState({ openCamera: false }); }}
          >

          </Modal> */}
        </Container>
      );
    }
    return (
      <Container>
        <Content style={[Style.Main.containerWithPadding12]}>
          <View style={[Style.Main.mt12, Style.Main.container]}>
            <RNCamera
              ref={(ref) => { this.camera = ref; }}
              style={[Style.Main.container]}
              type={RNCamera.Constants.Type.back}
              flashMode={RNCamera.Constants.FlashMode.off}
              androidCameraPermissionOptions={{
                title: 'Permission to use camera',
                message: 'We need your permission to use your camera',
                buttonPositive: 'Ok',
                buttonNegative: 'Cancel',
              }}
              captureAudio={false}
            >
              <BarcodeMask width={300} height={100} edgeColor={Colors.red} showAnimatedLine={false} transparency={0.8} />
            </RNCamera>
          </View>
          <Button
            block
            style={Style.Main.btnPrimary}
            onPress={this.takePicture}
          >
            <Text>
              {_('Ambil Gambar')}
            </Text>
          </Button>
          <View style={[Style.Main.mt12]}>
            <Text style={[Style.Main.fontAlbert11, Style.Main.my5]}>NIK: {this.state.nik}</Text>
          </View>
        </Content>
        <LoadingModal show={this.state.isLoading} size="large" color="white" />
      </Container>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: Colors.black,
  },
  preview: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  capture: {
    flex: 0,
    backgroundColor: Colors.white,
    borderRadius: 5,
    padding: 15,
    paddingHorizontal: 20,
    alignSelf: 'center',
    margin: 20,
  },
});

export default OcrResearch;
