import {
  UPDATE_FUND_MASTER,
} from '../actions/types';

const initialFund = [
  {
    fundRisk: 'konservatif',
    fundList: [],
    percent: 0,
    percentTopUp: 0,
  }, {
    fundRisk: 'moderat',
    fundList: [],
    percent: 0,
    percentTopUp: 0,
  }, {
    fundRisk: 'agresif',
    fundList: [],
    percent: 0,
    percentTopUp: 0,
  },
];

export function fundReducer(state = initialFund, action) {
  switch (action.type) {
    case UPDATE_FUND_MASTER:
      return action.payload;
    default:
      return state;
  }
}
