import moment from 'moment';
// import Analytics from 'appcenter-analytics';
import CryptoJS from 'crypto-js';
import SQLiteUtils from '../../../utilities/SQLiteUtils';
import Database from '../../../config/Database';

const { paymentCredential } = Database.pruSmart.tables;

const querySelect = `SELECT * FROM ${paymentCredential.name} WHERE method = ? and agentCode = ?`;
const querySelectByKey = `SELECT * FROM ${paymentCredential.name} WHERE method = ? and agentCode = ? and proposalCode = ?`;
const queryDelete = `DELETE FROM ${paymentCredential.name} WHERE method = ? and agentCode = ? and proposalCode = ?`;
const queryUpdateByKey = `UPDATE ${paymentCredential.name} SET data = ?, createDate = ? where method = ? and agentCode = ? and proposalCode = ?`;
const queryInsert = `INSERT INTO ${paymentCredential.name} VALUES (?,?,?,?,?)`;
const serviceName = 'PaymentStorageService';

const openDatabase = () => new Promise(async (resolve, reject) => {
  try {
    const dbName = Database.pruSmart.name;
    const db = await SQLiteUtils.openDatabase(dbName, 'default');
    resolve(db);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const getAll = (db, agentCode) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(
      db,
      querySelect,
      [paymentCredential.method, agentCode],
    );
    const data = [];
    for (let i = 0; i < res.rows.length; i += 1) {
      data.push(JSON.parse(CryptoJS.AES.decrypt(res.rows.item(i).data, SQLiteUtils.DBKEY).toString(CryptoJS.enc.Utf8)));
    }
    resolve(data);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const getByCode = (db, param) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(
      db,
      querySelectByKey,
      [paymentCredential.method, param.agentCode, param.proposalCd],
    );
    if (res.rows.length > 0) {
      resolve(JSON.parse(CryptoJS.AES.decrypt(res.rows.item(0).data, SQLiteUtils.DBKEY).toString(CryptoJS.enc.Utf8)).invocationResult);
    } else {
      resolve(res.rows.length);
    }
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const deleteByCode = (db, param) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeTransaction(
      db,
      queryDelete,
      [paymentCredential.method, param.agentCode, param.proposalCd],
    );
    resolve(res);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const upsert = (db, param) => new Promise(async (resolve, reject) => {
  try {
    let data = {};
    data.invocationResult = param.data;
    data.agentId = param.agentCode;
    data.proposalCd = param.proposalCd;
    data.retrieveDate = new Date();
    let queryToProcess = queryInsert;
    let parameterToInput = [
      paymentCredential.method,
      param.agentCode,
      param.proposalCd,
      CryptoJS.AES.encrypt(JSON.stringify(data), SQLiteUtils.DBKEY).toString(),
      moment(new Date()).format('DD/MM/YYYY HH:mm'),
    ];
    const res = await SQLiteUtils.executeQuery(
      db,
      querySelectByKey,
      [paymentCredential.method, param.agentCode, param.proposalCd],
    );
    if (res.rows.length > 0) {
      data = JSON.parse(CryptoJS.AES.decrypt(res.rows.item(0).data, SQLiteUtils.DBKEY).toString(CryptoJS.enc.Utf8));
      data.invocationResult = param.data;
      data.proposalCd = param.proposalCd;
      queryToProcess = queryUpdateByKey;
      parameterToInput = [
        CryptoJS.AES.encrypt(JSON.stringify(data), SQLiteUtils.DBKEY).toString(),
        moment(new Date()).format('DD/MM/YYYY HH:mm'),
        paymentCredential.method,
        param.agentCode,
        param.proposalCd,
      ];
    }
    const resUpsert = await SQLiteUtils.executeTransaction(db, queryToProcess, parameterToInput);
    resolve(`UPSERT ${resUpsert}`);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

export default {
  openDatabase,
  getAll,
  getByCode,
  deleteByCode,
  upsert,
};
