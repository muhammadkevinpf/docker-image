import MainTodoList from './main-todo-list';
import PendingProposal from './pending-proposal';
import CustomerBirthday from './customer-birthday';
import MainDueDate from './main-due-date';
import AfterDueDateList from './main-due-date/AfterDueDateList';
import FollowUpDetails from './follow-up-details';
import FundHistoryDetails from './fund-history-details';
import CustomerInformation from './customer-information';
import PolicyDetail from './main-due-date/PolicyDetail';
import ClaimHistoryDetail from './main-due-date/ClaimHistoryDetail';
import InsuranceBenefits from './main-due-date/InsuranceBenefits';
import MedicalLetterPDF from './follow-up-details/MedicalLetterPDF';
import DocumentViewer from './document-viewer';

export default {
  MainTodoList,
  PendingProposal,
  CustomerBirthday,
  MainDueDate,
  AfterDueDateList,
  FollowUpDetails,
  FundHistoryDetails,
  CustomerInformation,
  PolicyDetail,
  ClaimHistoryDetail,
  InsuranceBenefits,
  MedicalLetterPDF,
  DocumentViewer,
};
