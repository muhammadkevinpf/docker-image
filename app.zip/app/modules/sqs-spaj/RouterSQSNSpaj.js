/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import ViewsSQSNSpaj from './views';

export default {
  LandingPageSQSNSpaj: { screen: ViewsSQSNSpaj.LandingPage },
  ExistingPolicySQSNSpaj: { screen: ViewsSQSNSpaj.ExistingPolicy },
  QuestionnaireSQSNSpaj: { screen: ViewsSQSNSpaj.Questionnaire },
  MainInsuredSQSNSpaj: { screen: ViewsSQSNSpaj.MainInsured },
  InvestmentGoalsSQSNSpaj: { screen: ViewsSQSNSpaj.InvestmentGoals },
  CustomerDataSQSNSpaj: { screen: ViewsSQSNSpaj.CustomerData },
  Withdrawal: { screen: ViewsSQSNSpaj.Withdrawal },
  Substandard: { screen: ViewsSQSNSpaj.Substandard },
  AdditionalCustomerDataSQSNSpaj: { screen: ViewsSQSNSpaj.AdditionalCustomerData },
  BenefitsSQSNSpaj: { screen: ViewsSQSNSpaj.Benefits },
  CalculationSQSNSpaj: { screen: ViewsSQSNSpaj.Calculation },
  QuickQuoteSQSNSpaj: { screen: ViewsSQSNSpaj.QuickQuote },
  IllustrationSQSNSpaj: { screen: ViewsSQSNSpaj.Illustration },
  SignatureSQSNSpaj: { screen: ViewsSQSNSpaj.Signature },
};
