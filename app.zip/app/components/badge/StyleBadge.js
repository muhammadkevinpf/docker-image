/**
 * @author: ahmdichsanb@gmail.com
*/

import { StyleSheet } from 'react-native';
import Styles from '../../styles';

const Style = StyleSheet.create({
  badgeCore: {
    width: 28,
    height: 28,
    borderWidth: 1,
    borderRadius: 75,
    justifyContent: 'center',
  },
  defaultBadge: {
    backgroundColor: Styles.Color.white,
    borderColor: Styles.Color.red,
  },
  primaryBadge: {
    backgroundColor: Styles.Color.blue,
    borderColor: Styles.Color.blue,
  },
  successBadge: {
    backgroundColor: Styles.Color.lightGreen,
    borderColor: Styles.Color.lightGreen,
  },
  infoBadge: {
    backgroundColor: Styles.Color.lightBlue,
    borderColor: Styles.Color.lightBlue,
  },
  warningBadge: {
    backgroundColor: Styles.Color.yellow,
    borderColor: Styles.Color.yellow,
  },
  dangerBadge: {
    backgroundColor: Styles.Color.red,
    borderColor: Styles.Color.red,
  },
  defaultFontStyle: {
    textAlign: 'center',
    color: Styles.Color.red,
    fontSize: 12,
  },
  nonDefaultFontStyle: {
    textAlign: 'center',
    color: Styles.Color.white,
    fontSize: 12,
  },
});

export default Style;
