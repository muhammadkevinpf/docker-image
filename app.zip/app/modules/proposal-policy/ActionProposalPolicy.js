export const proposalPolicyAction = (action, value) => ({ type: action, payload: value });
