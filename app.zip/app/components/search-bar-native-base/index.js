import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {
  View, Input, Item, Icon,
} from 'native-base';
import { isEmpty } from '../../utilities';
import Style from '../../styles';
import _ from '../../lang';

/** @augments {React.PureComponent<Props, State>} */
export default class SearchNativeBase extends Component {
  render() {
    return (
      <View style={[Style.Main.centerVertical, Style.Main.mb10, this.props.style]}>
        <Item style={[Style.Main.searchItem, Style.Main.rowDirectionSpaceBetween, this.props.searchStyle]}>
          <>
            <Icon active name="search" type="Ionicons" style={[Style.Main.font14]} />
            <Input
              disabled={this.props.disabled}
              ref={(ref) => { this._Input = ref; }}
              placeholder={_(this.props.placeholder)}
              keyboardAppearance="default"
              keyboardType="default"
              returnKeyType="done"
              style={[Style.Main.fontAlbert, this.props.disabled && Style.Main.halfOpacity]}
              maxLength={this.props.maxLength}
              onChangeText={this.props.onChangeText}
              onBlur={() => this.props.onInputBlur(this.props.value)}
              value={this.props.value}
            />
          </>
          {
            this.props.onClear && !isEmpty(this.props.value) &&
            <Icon
              onPress={this.props.onClear}
              type="MaterialCommunityIcons"
              name="close"
              style={[Style.Main.font14, Style.Main.padding5, Style.Main.pr0]}
            />
          }
        </Item>
      </View>
    );
  }
}

SearchNativeBase.propTypes = {
  placeholder: PropTypes.string,
  maxLength: PropTypes.number,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  searchStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  onChangeText: PropTypes.func,
  onInputBlur: PropTypes.func,
  onClear: PropTypes.func,
  value: PropTypes.string,
};

SearchNativeBase.defaultProps = {
  placeholder: 'Search',
  maxLength: 35,
  style: null,
  searchStyle: null,
  onChangeText: () => {},
  onInputBlur: () => {},
  onClear: null,
  value: null,
};
