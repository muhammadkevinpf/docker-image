/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import {
  View, Text, TouchableOpacity, Alert,
} from 'react-native';
import {
  Container, Content, Thumbnail,
} from 'native-base';
import { Row, Col, Grid } from 'react-native-easy-grid';
import { connect } from 'react-redux';
import Icon from 'react-native-vector-icons/FontAwesome';
import {
  USERPROFILESUCCESS, USERPROFILEFAILED,
  USERAVATARSUCCESS, USERAVATARFAILED,
  SIGNOUTSUCCESS, SIGNOUTFAILED,
} from '../../modules/auth/ConfigAuth';
import { userProfileFetch, userAvatarFetch, signOutFetch } from '../../modules/auth/ActionAuth';

import profile from '../../assets/images/dummy-profile.png';

import _ from '../../lang';
import Style from '../../styles';
import StyleDrawer from './StyleDrawerBurgerHeader';

import LoadingModal from '../loading_modal';

class SideBar extends Component {
  constructor(props) {
    super(props);

    this
      .state = {
        showLoadingModal: false,
        action: this.props.action,
        err: this.props.err,
        res: this.props.res,
        menu: [
          {
            icon: 'home',
            title: _('Beranda'),
            link: 'MainDashboard',
          },
          {
            icon: 'user-plus',
            title: _('Rekrutmen'),
            link: 'LandingPageRecruitment',
          },
          {
            icon: 'newspaper-o',
            title: _('Berita Terbaru'),
            link: '',
          },
          {
            icon: 'certificate',
            title: _('Pencapaian'),
            link: '',
          },
          {
            icon: 'info-circle',
            title: _('Informasi'),
            link: '',
          },
          {
            icon: 'laptop',
            title: _('E-SQS & E-SPAJ'),
            link: 'LandingPageSQSNSpaj',
          },
          {
            icon: 'trophy',
            title: _('Kontes'),
            link: '',
          },
          {
            icon: 'graduation-cap',
            title: _('Training'),
            link: '',
          },
          {
            icon: 'line-chart',
            title: _('Laporan Pendapatan'),
            link: '',
          },
          {
            icon: 'tachometer',
            title: _('Dashboard'),
            link: '',
          },
          {
            icon: 'star',
            title: _('Campaign'),
            link: '',
          },
          {
            icon: 'question-circle',
            title: _('Bantuan'),
            link: '',
          },
          {
            icon: 'cog',
            title: _('Pengaturan'),
            link: '',
          },
          {
            icon: 'sign-out',
            title: _('Keluar'),
            link: '',
          },
        ],
      };
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.action !== prevState.action) {
      let nextErr = prevState.err;
      if (nextProps.action === USERPROFILEFAILED || nextProps.action === USERAVATARFAILED) nextErr = nextProps.err;

      let nextRes = prevState.res;
      if (nextProps.action === USERPROFILESUCCESS || nextProps.action === USERAVATARSUCCESS) nextRes = nextProps.res;

      return {
        action: nextProps.action,
        err: nextErr,
        res: nextRes,
      };
    }

    return null;
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.action !== this.state.action) {
      if (this.state.action === USERPROFILEFAILED) {
        const data = {
          headers: [
            {
              keyHeader: 'X-CSRF-Token',
              valueHeader: `Bearer ${this.state.res.access_token}`,
            },
          ],
        };
        this.props.dispatchUserProfile(data);
      }

      if (this.state.action === USERAVATARFAILED) {
        const data = {
          headers: [
            {
              keyHeader: 'X-CSRF-Token',
              valueHeader: `Bearer ${this.state.res.access_token}`,
            },
          ],
          params: `[
          "${this.state.res.username}",
          "${this.state.res.userProfile.agentCode}",
          "Image_${this.state.res.userProfile.agentCode}.jpg",
          "agentProfile"
        ]`,
        };
        this.props.dispatchUserAvatar(data);
      }

      if (this.state.action === SIGNOUTFAILED) {
        Alert.alert(
          _('Error'),
          this.state.err,
          [
            {
              text: _('Oke'),
              onPress: () => {
                this.setState({ showLoadingModal: false });
              },
            },
          ],
        );
      }

      if (this.state.action === SIGNOUTSUCCESS) {
        this.props.navigation.navigate('MainHome');
      }
    }
  }

  handleSignOut = () => {
    this.setState({ showLoadingModal: true }, () => {
      if (this.profileState().profile !== undefined) {
        const data = {
          params: `["${this.profileState().profile.agentCode}"]`,
          headers: [
            {
              keyHeader: 'X-CSRF-Token',
              valueHeader: `Bearer ${this.state.res.access_token}`,
            },
          ],
        };
        this.props.dispatchSignOut(data);
      } else {
        Alert.alert(
          _(''),
          _('Masih loading data Profile, silakan coba beberapa menit lagi.'),
          [
            {
              text: _('Oke'),
              onPress: () => {
                this.setState({ showLoadingModal: false });
              },
            },
          ],
        );
      }
    });
  }

  renderItems = data => data.map((item, i) => {
    let rowStyle = [StyleDrawer.containerItem];
    let link = () => this.props.close(item.link);

    if (item.icon === 'star') rowStyle = [...rowStyle, StyleDrawer.separator];
    if (item.icon === 'sign-out') link = this.handleSignOut;

    return (
    /* eslint-disable react/no-array-index-key */
      <Grid key={i}>
        <Row style={rowStyle}>
          <Col size={23} style={StyleDrawer.left}>
            <Icon
              name={item.icon}
              style={Style.Main.textRed}
            />
          </Col>
          <Col size={77} style={StyleDrawer.right}>
            <TouchableOpacity onPress={link}>
              <Text>{item.title}</Text>
            </TouchableOpacity>
          </Col>
        </Row>
      </Grid>
    /* eslint-enable react/no-array-index-key */
    );
  });

  profileState = () => {
    let userProfile;
    let userAvatar;

    if (this.state.res !== null) {
      if (this.state.res.userProfile !== undefined) ({ userProfile } = this.state.res);
      if (this.state.res.userAvatar !== undefined) ({ userAvatar } = this.state.res);
    }

    return {
      profile: userProfile,
      avatar: userAvatar,
    };
  }

  render() {
    return (
      <View style={StyleDrawer.areaSave}>
        <Container>
          <Content style={StyleDrawer.sideBarStyle} keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
            <Grid>
              <Row>
                <Col style={Style.Main.mb15}>

                  <Grid style={Style.Main.mb10}>
                    <Row style={[StyleDrawer.containerHeader]}>
                      <Col size={23} style={StyleDrawer.left}>
                        <Thumbnail
                          small
                          source={
                            this.profileState().avatar === undefined ?
                              profile
                              :
                              { uri: this.profileState().avatar.text }
                          }
                          style={StyleDrawer.image}
                        />
                      </Col>
                      <Col size={77} style={StyleDrawer.right}>
                        <Text>
                          {
                            this.profileState().profile === undefined ?
                              _('Agent Account')
                              :
                              this.profileState().profile.adsName
                          }
                        </Text>
                      </Col>
                    </Row>
                  </Grid>

                  {this.renderItems(this.state.menu)}

                </Col>
              </Row>
            </Grid>
          </Content>

          <LoadingModal
            show={this.state.showLoadingModal}
            size="large"
            color="white"
          />
        </Container>
      </View>
    );
  }
}

const mapStateToProps = state => ({
  fetch: state.auth.fetchSignOut,
  res: state.auth.res,
  err: state.auth.err,
  action: state.auth.action,
});

const mapDispatchToProps = dispatch => ({
  dispatchUserProfile: value => dispatch(userProfileFetch(value)),
  dispatchUserAvatar: value => dispatch(userAvatarFetch(value)),
  dispatchSignOut: value => dispatch(signOutFetch(value)),
});

export default connect(mapStateToProps, mapDispatchToProps)(SideBar);
