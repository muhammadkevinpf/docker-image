/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import {
  View, Switch, Text,
} from 'react-native';
import {
  Container, Content, Header, Icon,
} from 'native-base';
import _ from '../../../lang';
import Style from '../../../styles';

class SettingWidgetDashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      valueNews: false,
      valueProposal: false,
      valuePolis: false,
      valueUbahPolis: false,
      valueRekrutmen: false,
      valueKontes: false,
      valueKlaim: false,
      valueBilling: false,
      valueUlangTahun: false,
      valueInformasi: false,
      valuePRUAchiever: false,
      valueTraining: false,
      valueCPD: false,
      valueSekretaris: false,
      pushNotif: false,
      showSetting: false,
    };
  }

  render() {
    return (
      <Container>
        <Header noShadow>
          <Text
            style={[Style.Main.font16, Style.Main.textWhite, Style.Main.ml6,
              Style.Main.pt15, Style.Main.textLeft, Style.Main.fontAlbert]}
            onPress={() => this.props.navigation.goBack()}
          >
            &lt; &nbsp; {_('Pengaturan Notifikasi')}
          </Text>
        </Header>
        <Content keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
          <View style={[Style.Main.padding12, Style.Main.rowDirectionSpaceBetween]}>
            <Text
              style={[Style.Main.flexGrow, Style.Main.fontAlbert]}
            >{_('Push Notification')}
            </Text>
            <Switch
              thumbColor="#ffffff"
              trackColor={{ false: '#a7a8aa', true: '#089600' }}
              value={this.state.pushNotif}
              onValueChange={(pushNotif) => {
                if (pushNotif) {
                  this.setState({
                    pushNotif,
                    showSetting: true,
                    valueNews: true,
                    valueProposal: true,
                    valuePolis: true,
                    valueUbahPolis: true,
                    valueRekrutmen: true,
                    valueKontes: true,
                    valueKlaim: true,
                    valueBilling: true,
                    valueUlangTahun: true,
                    valueInformasi: true,
                    valuePRUAchiever: true,
                    valueTraining: true,
                    valueCPD: true,
                    valueSekretaris: true,
                  });
                } else {
                  this.setState({
                    pushNotif,
                    showSetting: false,
                    valueNews: false,
                    valueProposal: false,
                    valuePolis: false,
                    valueUbahPolis: false,
                    valueRekrutmen: false,
                    valueKontes: false,
                    valueKlaim: false,
                    valueBilling: false,
                    valueUlangTahun: false,
                    valueInformasi: false,
                    valuePRUAchiever: false,
                    valueTraining: false,
                    valueCPD: false,
                    valueSekretaris: false,
                  });
                }
              }}
            />
          </View>
          <View style={[Style.Main.padding12, Style.Main.rowDirectionSpaceBetween]}>
            <Text style={[Style.Main.flexGrow, Style.Main.fontAlbert]}>{_('Notifikasi Fitur')}</Text>
            <Icon
              name="chevron-right"
              type="MaterialIcons"
              style={[Style.Main.textColor3f3,
                (this.state.showSetting)
                  ? Style.Main.displayNone
                  : Style.Main.displayFlex,
              ]}
              onPress={() => {
                if (this.state.pushNotif) {
                  if (this.state.showSetting) {
                    this.setState({
                      showSetting: false,
                    });
                  } else {
                    this.setState({
                      showSetting: true,
                    });
                  }
                }
              }}
            />
            <Icon
              name="keyboard-arrow-down"
              type="MaterialIcons"
              style={[Style.Main.textColor3f3,
                (this.state.showSetting)
                  ? Style.Main.displayFlex
                  : Style.Main.displayNone,
              ]}
            />
          </View>
          <View
            style={[Style.Main.pl12,
              (this.state.showSetting)
                ? Style.Main.displayFlex
                : Style.Main.displayNone,
            ]}
          >
            <View style={[Style.Main.padding12, Style.Main.rowDirectionSpaceBetween]}>
              <Text
                style={[Style.Main.flexGrow, Style.Main.fontAlbert]}
              >{_('Berita Terbaru')}
              </Text>
              <Switch
                thumbColor="#ffffff"
                trackColor={{ false: '#a7a8aa', true: '#089600' }}
                value={this.state.valueNews}
                onValueChange={valueNews => this.setState({ valueNews })}
              />
            </View>
            <View style={[Style.Main.padding12, Style.Main.rowDirectionSpaceBetween]}>
              <Text
                style={[Style.Main.flexGrow, Style.Main.fontAlbert]}
              >{_('Kontes')}
              </Text>
              <Switch
                thumbColor="#ffffff"
                trackColor={{ false: '#a7a8aa', true: '#089600' }}
                value={this.state.valueKontes}
                onValueChange={valueKontes => this.setState({ valueKontes })}
              />
            </View>
            <View style={[Style.Main.padding12, Style.Main.rowDirectionSpaceBetween]}>
              <Text
                style={[Style.Main.flexGrow, Style.Main.fontAlbert]}
              >{_('Klaim')}
              </Text>
              <Switch
                thumbColor="#ffffff"
                trackColor={{ false: '#a7a8aa', true: '#089600' }}
                value={this.state.valueKlaim}
                onValueChange={valueKlaim => this.setState({ valueKlaim })}
              />
            </View>
            <View style={[Style.Main.padding12, Style.Main.rowDirectionSpaceBetween]}>
              <Text
                style={[Style.Main.flexGrow, Style.Main.fontAlbert]}
              >{_('Pending Billing')}
              </Text>
              <Switch
                thumbColor="#ffffff"
                trackColor={{ false: '#a7a8aa', true: '#089600' }}
                value={this.state.valueBilling}
                onValueChange={valueBilling => this.setState({ valueBilling })}
              />
            </View>
            <View style={[Style.Main.padding12, Style.Main.rowDirectionSpaceBetween]}>
              <Text
                style={[Style.Main.flexGrow, Style.Main.fontAlbert]}
              >{_('Pending Proposal')}
              </Text>
              <Switch
                thumbColor="#ffffff"
                trackColor={{ false: '#a7a8aa', true: '#089600' }}
                value={this.state.valueProposal}
                onValueChange={valueProposal => this.setState({ valueProposal })}
              />
            </View>
            <View style={[Style.Main.padding12, Style.Main.rowDirectionSpaceBetween]}>
              <Text
                style={[Style.Main.flexGrow, Style.Main.fontAlbert]}
              >{_('Polis Jatuh Tempo')}
              </Text>
              <Switch
                thumbColor="#ffffff"
                trackColor={{ false: '#a7a8aa', true: '#089600' }}
                value={this.state.valuePolis}
                onValueChange={valuePolis => this.setState({ valuePolis })}
              />
            </View>
            <View style={[Style.Main.padding12, Style.Main.rowDirectionSpaceBetween]}>
              <Text
                style={[Style.Main.flexGrow, Style.Main.fontAlbert]}
              >{_('Perubahan Polis')}
              </Text>
              <Switch
                thumbColor="#ffffff"
                trackColor={{ false: '#a7a8aa', true: '#089600' }}
                value={this.state.valueUbahPolis}
                onValueChange={valueUbahPolis => this.setState({ valueUbahPolis })}
              />
            </View>
            <View style={[Style.Main.padding12, Style.Main.rowDirectionSpaceBetween]}>
              <Text
                style={[Style.Main.flexGrow, Style.Main.fontAlbert]}
              >{_('Rekrutmen')}
              </Text>
              <Switch
                thumbColor="#ffffff"
                trackColor={{ false: '#a7a8aa', true: '#089600' }}
                value={this.state.valueRekrutmen}
                onValueChange={valueRekrutmen => this.setState({ valueRekrutmen })}
              />
            </View>
            <View style={[Style.Main.padding12, Style.Main.rowDirectionSpaceBetween]}>
              <Text
                style={[Style.Main.flexGrow, Style.Main.fontAlbert]}
              >{_('Ulang Tahun')}
              </Text>
              <Switch
                thumbColor="#ffffff"
                trackColor={{ false: '#a7a8aa', true: '#089600' }}
                value={this.state.valueUlangTahun}
                onValueChange={valueUlangTahun => this.setState({ valueUlangTahun })}
              />
            </View>
            <View style={[Style.Main.padding12, Style.Main.rowDirectionSpaceBetween]}>
              <Text
                style={[Style.Main.flexGrow, Style.Main.fontAlbert]}
              >{_('Informasi')}
              </Text>
              <Switch
                thumbColor="#ffffff"
                trackColor={{ false: '#a7a8aa', true: '#089600' }}
                value={this.state.valueInformasi}
                onValueChange={valueInformasi => this.setState({ valueInformasi })}
              />
            </View>
            <View style={[Style.Main.padding12, Style.Main.rowDirectionSpaceBetween]}>
              <Text
                style={[Style.Main.flexGrow, Style.Main.fontAlbert]}
              >{_('PRUAchiever')}
              </Text>
              <Switch
                thumbColor="#ffffff"
                trackColor={{ false: '#a7a8aa', true: '#089600' }}
                value={this.state.valuePRUAchiever}
                onValueChange={valuePRUAchiever => this.setState({ valuePRUAchiever })}
              />
            </View>
            <View style={[Style.Main.padding12, Style.Main.rowDirectionSpaceBetween]}>
              <Text
                style={[Style.Main.flexGrow, Style.Main.fontAlbert]}
              >{_('Training')}
              </Text>
              <Switch
                thumbColor="#ffffff"
                trackColor={{ false: '#a7a8aa', true: '#089600' }}
                value={this.state.valueTraining}
                onValueChange={valueTraining => this.setState({ valueTraining })}
              />
            </View>
            <View style={[Style.Main.padding12, Style.Main.rowDirectionSpaceBetween]}>
              <Text
                style={[Style.Main.flexGrow, Style.Main.fontAlbert]}
              >{_('Sekretaris')}
              </Text>
              <Switch
                thumbColor="#ffffff"
                trackColor={{ false: '#a7a8aa', true: '#089600' }}
                value={this.state.valueSekretaris}
                onValueChange={valueSekretaris => this.setState({ valueSekretaris })}
              />
            </View>
            <View style={[Style.Main.padding12, Style.Main.rowDirectionSpaceBetween]}>
              <Text
                style={[Style.Main.flexGrow, Style.Main.fontAlbert]}
              >{_('CPD')}
              </Text>
              <Switch
                thumbColor="#ffffff"
                trackColor={{ false: '#a7a8aa', true: '#089600' }}
                value={this.state.valueCPD}
                onValueChange={valueCPD => this.setState({ valueCPD })}
              />
            </View>
          </View>
        </Content>
      </Container>
    );
  }
}

export default SettingWidgetDashboard;
