/**
 * @author
 * ahmdichsanb@gmail.com
 */

import { StyleSheet } from 'react-native';
import Styles from '../../styles';

const Style = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Styles.Color.overlay,
  },
});

export default Style;
