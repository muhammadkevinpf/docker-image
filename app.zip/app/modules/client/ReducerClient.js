import moment from 'moment';
import { requestStatus } from '../../utilities/ApiConnection';
import { RESET_ALL_STATE } from '../dashboard/ConfigDashboard';
import { CLIENT_LIST, CLIENT_VIP_INFO_LIST } from './ConfigClient';

const initialState = {
  viplistStatus: requestStatus.IDLE,
  listStatus: requestStatus.IDLE,
  lastUpdate: null,
  list: [],
  error: null,
  send: null,
};

export function ReducerClient(state = initialState, action) {
  switch (action.type) {
    case RESET_ALL_STATE: return initialState;

    case CLIENT_LIST.RESET: return { ...state, listStatus: requestStatus.IDLE, list: [] };
    case CLIENT_LIST.FETCH: return { ...state, listStatus: requestStatus.FETCH, send: action.payload };
    case CLIENT_LIST.FAILED: return { ...state, listStatus: requestStatus.FAILED, error: action.payload };
    case CLIENT_LIST.SUCCESS:
      return {
        ...state,
        listStatus: requestStatus.SUCCESS,
        lastUpdate: moment(new Date()).format('LLL'),
        list: state.list.length ? [...state.list, ...action.payload.filter(x => !state.list.some(item => item.clientNumber === x.clientNumber))]
          : action.payload,
      };

    case CLIENT_VIP_INFO_LIST.FETCH: return { ...state, viplistStatus: requestStatus.FETCH, send: action.payload };
    case CLIENT_VIP_INFO_LIST.FAILED: return { ...state, viplistStatus: requestStatus.FAILED, error: action.payload };
    case CLIENT_VIP_INFO_LIST.SUCCESS: {
      const temp = action.payload && action.payload.length ? state.list.map((x) => {
        if (action.payload.find(y => x.clientNumber === y.clientId)) {
          return { ...x, ...action.payload.find(y => x.clientNumber === y.clientId) };
        } return x;
      }) : state.list;
      return {
        ...state,
        viplistStatus: requestStatus.SUCCESS,
        list: temp,
      };
    }

    default: return state;
  }
}
