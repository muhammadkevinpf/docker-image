/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import ViewsDashboard from './views';

export default {
  MainDashboard: { screen: ViewsDashboard.MainDashboard },

  SettingWidgetDashboard: { screen: ViewsDashboard.SettingWidgetDashboard },
  MyAccount: { screen: ViewsDashboard.MyAccount },
  MyAccountDetail: { screen: ViewsDashboard.MyAccountDetail },
  MyAccountSecretQuestion: { screen: ViewsDashboard.MyAccountSecretQuestion },
  MyAccountChangePassword: { screen: ViewsDashboard.MyAccountChangePassword },

  EditEmergencyContact: { screen: ViewsDashboard.EditEmergencyContact },
  CPDDetail: { screen: ViewsDashboard.CPDDetail },
};
