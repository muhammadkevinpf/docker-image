import { StyleSheet } from 'react-native';
import Styles from '../../styles';

const Style = StyleSheet.create({
  stylePickerView: {
    borderBottomColor: Styles.Color.gray,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  stylePickerBody: {
    width: '100%',
  },
});

export default Style;
