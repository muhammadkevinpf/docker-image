import Views from './views';

export default {
  OcrResearch: { screen: Views.OcrResearch },
};
