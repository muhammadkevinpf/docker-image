/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { PureComponent } from 'react';
import { View, Text } from 'react-native';
import PropTypes from 'prop-types';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { Row, Col } from 'react-native-easy-grid';
import Style from '../../styles';

class OutlineRadio extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  render() {
    const unCheck = <Icon
      name="radio-button-unchecked"
      type="MaterialIcons"
      style={[Style.Main.font20, Style.Main.gray83]}
      onPress={this.props.onPress}
    />;
    const check = <Icon
      name="radio-button-checked"
      type="MaterialIcons"
      style={[Style.Main.font20, Style.Main.textRed]}
      onPress={this.props.onPress}
    />;
    return (
      <View>
        <Row>
          <Col size={1}>
            {(this.props.checked)
              ? check
              : unCheck }
          </Col>
          <Col size={10}>
            <Text
              onPress={this.props.onPress}
              style={[Style.Main.fontAlbert, Style.Main.font14, Style.Main.textJustify, Style.Main.textColor3f3]}
            >
              {this.props.label}
            </Text>
          </Col>
        </Row>
      </View>
    );
  }
}

OutlineRadio.propTypes = {
  label: PropTypes.string,
  checked: PropTypes.bool,
  onPress: PropTypes.func,
};

OutlineRadio.defaultProps = {
  label: '',
  checked: false,
  onPress: () => {},
};

export default OutlineRadio;
