export const todayEvent = [
  { trainingName: 'My First Case', sessionTime: '13.30 - 16.30 WIB' },
  { trainingName: 'PRUCritical Benefit 88', sessionTime: '13.30 - 16.30 WIB' },
];

export const onProgressTraining = [
  {
    trainingName: 'Sertifikasi PRUCorporate',
    trainingType: 'ONLINE',
    startDate: '01-Okt-2020',
    endDate: '01-Des-2020',
    startTime: '13:30',
    endTime: '16:30',
    learningProgress: [
      { title: 'Mulai', status: 'done' },
      { title: 'Materi', status: 'done' },
      { title: 'Test', status: 'last' },
    ],
  }, {
    trainingName: 'Sertifikasi PRUCorporate',
    trainingType: 'CLASSROOM',
    startDate: '01-Okt-2020',
    venue: 'PRUDENTIAL CENTER',
    cityName: 'Jakarta',
    startTime: '13:30',
    endTime: '16:30',
    learningProgress: [
      { title: 'Daftar', status: 'done' },
      { title: 'Sesi', status: 'last' },
      { title: 'Test', status: 'undone' },
    ],
  }, {
    trainingName: 'Tutorial Ujian AASI',
    trainingType: 'ONLINE',
    startDate: '01-Okt-2020',
    endDate: '01-Des-2020',
    venue: 'Zoom Application - ID/Password',
    startTime: '13:30',
    endTime: '16:30',
    learningProgress: [
      { title: 'Daftar', status: 'done' },
      { title: 'Sesi', status: 'done' },
    ],
  },
];

export const upcomingTraining = [
  {
    trainingName: 'PRULeads',
    trainingType: 'CLASSROOM',
    startDate: '01-Okt-2020',
    endDate: '01-Des-2020',
    venue: 'PRUDENTIAL CENTER',
    cityName: 'Jakarta',
  }, {
    trainingName: 'PRULeads',
    trainingType: 'ONLINE',
    startDate: '01-Okt-2020',
    endDate: '01-Des-2020',
    venue: 'Zoom Meeting - PRULeads',
    cityName: 'Jakarta',
  }, {
    trainingName: 'Sertifikasi PRUCorporate',
    trainingType: 'CLASSROOM',
    startDate: '01-Okt-2020',
    venue: 'PRUDENTIAL CENTER',
    cityName: 'Jakarta',
  }, {
    trainingName: 'PRULeads',
    trainingType: 'ONLINE',
    startDate: '01-Okt-2020',
    endDate: '01-Des-2020',
    venue: 'Zoom Meeting - PRULeads',
    cityName: 'Jakarta',
  }, {
    trainingName: 'Sertifikasi PRUCorporate',
    trainingType: 'CLASSROOM',
    startDate: '01-Okt-2020',
    venue: 'PRUDENTIAL CENTER',
    cityName: 'Jakarta',
  }, {
    trainingName: 'PRULeads',
    trainingType: 'ONLINE',
    startDate: '01-Okt-2020',
    endDate: '01-Des-2020',
    venue: 'PRUDENTIAL CENTER',
    cityName: 'Jakarta',
  }, {
    trainingName: 'Sertifikasi PRUCorporate',
    trainingType: 'ONLINE',
    startDate: '01-Okt-2020',
    venue: 'PRUDENTIAL CENTER',
    cityName: 'Jakarta',
  }, {
    trainingName: 'PRULeads',
    trainingType: 'CLASSROOM',
    startDate: '01-Okt-2020',
    endDate: '01-Des-2020',
    venue: 'PRUDENTIAL CENTER',
    cityName: 'Jakarta',
  },
];

export const cpdDummy = {
  AAJI: {
    registeredPoint: [
      { cpdCode: 'PRUTop', point: 1 },
      { cpdCode: 'Sertifikat Program Wakaf Prudential', point: 1 },
      { cpdCode: 'My First Journey (Modul 1)', point: 1 },
      { cpdCode: 'My First Journey (Modul 2)', point: 1 },
    ],
    training: [],
  },
  AASI: {
    training: [
      { cpdCode: 'PRUTop', point: 1 },
      { cpdCode: 'Sertifikat Program Wakaf Prudential', point: 1 },
      { cpdCode: 'My First Journey (Modul 1)', point: 1 },
      { cpdCode: 'My First Journey (Modul 2)', point: 1 },
    ],
    registeredPoint: [],
  },
};

export const postTest = [
  {
    question: '1. Berapa minimum kepesertaan bagi perusahaan untuk dapat mengikuti program Asuransi kumpulan SME dari Prudential Indonesia?',
    answer: [
      { value: 'A', label: 'A. 10 Peserta' },
      { value: 'B', label: 'B. 10 Karyawan' },
      { value: 'C', label: 'C. 5 Peserta' },
      { value: 'D', label: 'A. 5 Karyawan' },
    ],
  },
  {
    question: '2. Berapa minimum kepesertaan bagi perusahaan untuk dapat mengikuti program Asuransi kumpulan SME dari Prudential Indonesia?',
    answer: [
      { value: 'A', label: 'A. 10 Peserta' },
      { value: 'B', label: 'B. 10 Karyawan' },
      { value: 'C', label: 'C. 5 Peserta' },
      { value: 'D', label: 'A. 5 Karyawan' },
    ],
  },
  {
    question: '3. Berapa minimum kepesertaan bagi perusahaan untuk dapat mengikuti program Asuransi kumpulan SME dari Prudential Indonesia?',
    answer: [
      { value: 'A', label: 'A. 10 Peserta' },
      { value: 'B', label: 'B. 10 Karyawan' },
      { value: 'C', label: 'C. 5 Peserta' },
      { value: 'D', label: 'A. 5 Karyawan' },
    ],
  },
];

export const videoDummy = [{
  title: 'We Are Number One',
  description: 'Lagu Prudential - We Are Number One 2018',
  url: 'ibJW6o8VdPI',
  type: 'SUPPORT',
}, {
  title: 'Anual Report',
  description: 'Laporan Tahunan Unit Link',
  url: 'GeQlX6A52-w',
  type: 'SUPPORT',
}, {
  title: 'Ayo Kita Cekatan PRUCinta',
  description: 'Training online Ayo Kita Cekatan PRUCinta',
  url: 'zhq4Q53n7PQ',
}];

export const catalogDummy = [{
  label: 'Leader Training',
  type: 'LEADER_TRAINING',
  list: [{
    img: 'https://lh3.googleusercontent.com/vzLao0lRV1-ic-Irs6y1vKr4foXZcYxQuiEmVZfTPbv2k2BQx-0JKMN4z6q5VcEZhkoL=w412-h220-rw',
    title: 'FSC Training',
    type: 'CLASSROOM',
    desc: 'FSC Training ini menyediakan berbagai modul training',
  }, {
    img: 'https://lh3.googleusercontent.com/BN95HST-PuxH30rOIzSBLmxgqaUnxY-Ta8d6_Ym-Yq9ePiX2OIaoFi-pEoaJW6wYJLo=w1366-h586-rw',
    title: 'Leadership',
    type: 'CLASSROOM',
    desc: 'Leadership ini menyediakan berbagai modul Leadership',
  }, {
    img: 'https://lh3.googleusercontent.com/7S0RKXU2tMQqOs8BHS83OPIC8-hosl051tP48t4FEmHG-bxp8mpSCABhndWT59KfzA=w1366-h586-rw',
    title: 'The Three Month',
    type: 'ONLINE',
    desc: 'Modul ini menyediakan berbagai katalog',
  }, {
    img: 'https://lh3.googleusercontent.com/BN95HST-PuxH30rOIzSBLmxgqaUnxY-Ta8d6_Ym-Yq9ePiX2OIaoFi-pEoaJW6wYJLo=w1366-h586-rw',
    title: 'Fun Fact',
    type: 'ONLINE',
    desc: 'Fun Fact adalah materi berhubungan fakta menarik',
  }, {
    img: 'https://lh3.googleusercontent.com/vzLao0lRV1-ic-Irs6y1vKr4foXZcYxQuiEmVZfTPbv2k2BQx-0JKMN4z6q5VcEZhkoL=w412-h220-rw',
    title: 'Elegance Standing',
    type: 'CLASSROOM',
    desc: 'Elegance but being remembered',
  }, {
    img: 'https://lh3.googleusercontent.com/7S0RKXU2tMQqOs8BHS83OPIC8-hosl051tP48t4FEmHG-bxp8mpSCABhndWT59KfzA=w1366-h586-rw',
    title: 'Leadership',
    type: 'ONLINE',
    desc: 'Leadership ini menyediakan berbagai modul Leadership',
  }, {
    img: 'https://lh3.googleusercontent.com/BN95HST-PuxH30rOIzSBLmxgqaUnxY-Ta8d6_Ym-Yq9ePiX2OIaoFi-pEoaJW6wYJLo=w1366-h586-rw',
    title: 'Fun Fact',
    type: 'CLASSROOM',
    desc: 'Fun Fact adalah materi berhubungan fakta menarik',
  }, {
    img: 'https://lh3.googleusercontent.com/vzLao0lRV1-ic-Irs6y1vKr4foXZcYxQuiEmVZfTPbv2k2BQx-0JKMN4z6q5VcEZhkoL=w412-h220-rw',
    title: 'FSC Training',
    type: 'CLASSROOM',
    desc: 'FSC Training ini menyediakan berbagai modul training',
  }, {
    img: 'https://lh3.googleusercontent.com/BN95HST-PuxH30rOIzSBLmxgqaUnxY-Ta8d6_Ym-Yq9ePiX2OIaoFi-pEoaJW6wYJLo=w1366-h586-rw',
    title: 'The Three Month',
    type: 'ONLINE',
    desc: 'Modul ini menyediakan berbagai katalog',
  }, {
    img: 'https://lh3.googleusercontent.com/7S0RKXU2tMQqOs8BHS83OPIC8-hosl051tP48t4FEmHG-bxp8mpSCABhndWT59KfzA=w1366-h586-rw',
    title: 'The Three Month',
    type: 'CLASSROOM',
    desc: 'Modul ini menyediakan berbagai katalog',
  }, {
    img: 'https://lh3.googleusercontent.com/BN95HST-PuxH30rOIzSBLmxgqaUnxY-Ta8d6_Ym-Yq9ePiX2OIaoFi-pEoaJW6wYJLo=w1366-h586-rw',
    title: 'Fun Fact',
    type: 'ONLINE',
    desc: 'Fun Fact adalah materi berhubungan fakta menarik',
  }, {
    img: 'https://lh3.googleusercontent.com/vzLao0lRV1-ic-Irs6y1vKr4foXZcYxQuiEmVZfTPbv2k2BQx-0JKMN4z6q5VcEZhkoL=w412-h220-rw',
    title: 'Elegance Standing',
    type: 'ONLINE',
    desc: 'Elegance but being remembered',
  }],
}, {
  label: 'Soft Skill Training',
  type: 'SOFT_SKILL_TRAINING',
  list: [{
    img: 'https://lh3.googleusercontent.com/7S0RKXU2tMQqOs8BHS83OPIC8-hosl051tP48t4FEmHG-bxp8mpSCABhndWT59KfzA=w1366-h586-rw',
    title: 'Leadership',
    type: 'ONLINE',
    desc: 'Leadership ini menyediakan berbagai modul Leadership',
  }, {
    img: 'https://lh3.googleusercontent.com/BN95HST-PuxH30rOIzSBLmxgqaUnxY-Ta8d6_Ym-Yq9ePiX2OIaoFi-pEoaJW6wYJLo=w1366-h586-rw',
    title: 'Fun Fact',
    type: 'ONLINE',
    desc: 'Fun Fact adalah materi berhubungan fakta menarik',
  }, {
    img: 'https://lh3.googleusercontent.com/vzLao0lRV1-ic-Irs6y1vKr4foXZcYxQuiEmVZfTPbv2k2BQx-0JKMN4z6q5VcEZhkoL=w412-h220-rw',
    title: 'FSC Training',
    type: 'ONLINE',
    desc: 'FSC Training ini menyediakan berbagai modul training',
  }, {
    img: 'https://lh3.googleusercontent.com/BN95HST-PuxH30rOIzSBLmxgqaUnxY-Ta8d6_Ym-Yq9ePiX2OIaoFi-pEoaJW6wYJLo=w1366-h586-rw',
    title: 'The Three Month',
    type: 'CLASSROOM',
    desc: 'Modul ini menyediakan berbagai katalog',
  }],
}];
