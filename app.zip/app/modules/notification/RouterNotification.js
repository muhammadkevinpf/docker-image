import ViewsNotification from './views';

export default {
  MainNotification: { screen: ViewsNotification.MainNotification },
};
