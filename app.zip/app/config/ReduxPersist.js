/**
 * @author: dwi.setiyadi@gmail.com
*/

// import AsyncStorage from '@react-native-community/async-storage';
import FileSystemStorage from 'redux-persist-filesystem-storage';
import createEncryptor from 'redux-persist-transform-encrypt';
import { createBlacklistFilter } from 'redux-persist-transform-filter';
import autoMergeLevel2 from 'redux-persist/lib/stateReconciler/autoMergeLevel2';

const encryptor = createEncryptor({
  secretKey: 'bang-pake-sambel-jangan-banyak-banyak-nanti-sutan-atit-peyut-201901221119',
  onError(error) {
    console.log('createEncryptor error ', error); // eslint-disable-line no-console
  },
});

const saveAuthSubsetBlacklistFilter = createBlacklistFilter();

const REDUX_PERSIST = {
  active: true,
  reducerVersion: '1.0',
  storeConfig: {
    key: 'root',
    storage: FileSystemStorage,
    whitelist: ['auth', 'dashboard', 'estimatedCommission', 'incomeStatement'],
    transforms: [
      saveAuthSubsetBlacklistFilter, encryptor,
    ],
    timeout: null,
    stateReconciler: autoMergeLevel2,
  },
};

export default REDUX_PERSIST;
