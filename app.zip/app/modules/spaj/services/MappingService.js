/* eslint-disable */
import moment from 'moment';
import { ConfigProduct } from '../../sqs-spaj/config';
import UtilitiesIllustration from '../../sqs-spaj/views/illustration/service/UtilitiesIllustration';
import UtilityPdfViewer from '../../sqs-spaj/components/pdf-view/UtilityPdfViewer';
import NewQuotationStorageService from '../../sqs-spaj/services/NewQuotationStorageService';
import SqsSpajService from './SqsSpajService';
import OutputStorageService from '../../sqs-spaj/services/OutputStorageService';
import _ from 'lodash';
import Caches from '../../../utilities/Caches';

const productTerm = {
  PAA: {
    risk_age: '99',
    risk_term: '00',
    prem_age: '99',
    prem_term: '00',
  },
  ROP: {
    risk_age: '88',
    risk_term: '00',
    prem_age: '88',
    prem_term: '00',
  },
};

const premTermMapRop = {
  1: '01',
  5: '05',
  10: '10',
  15: '15',
};

const prodPrefix = 'PRU';
const versionSQS = '2.0.0';
const effDocid = '20171117';
const docIdIlustration = '17060307';
const docIdRp = '17060334';
const docIdBackdate = '17060306';

const mapping = async (spajData, agentCode, agentName, isSIOFullUW, counterOffer, sqsCO, outputCO) => {
  const sqsData = spajData.sqs;
  const quickQuote = sqsData.sqs.quickQuote.find(x => x.isMainQuotation);
  const quickQuoteIndex = !sqsCO ? sqsData.sqs.quickQuote.findIndex(x => x.isMainQuotation) : 0;
  const sqs = {};
  let sqsReport = {};
  let sqsPdf = {};
  const yearlyPremium = Math.round(quickQuote.yearlyPremium);
  const pruSaver = quickQuote.pruSaver ? quickQuote.pruSaver : 0;
  const pruSaverBerkala = Math.round(parseInt(pruSaver, 0) / parseInt(quickQuote.billFreq === '00' ? '01' : quickQuote.billFreq, 0)).toFixed(2) * 100;
  const totalPremiWithSaver = parseInt(yearlyPremium, 0) + parseInt(pruSaver, 0);
  const totalPremi = parseInt(totalPremiWithSaver, 0) * parseInt(quickQuote.premAge, 0);
  const productType = ConfigProduct.checkProductType(quickQuote.productCode);
  const agentChannel = spajData.policy.sob.channel;
  const coStatus = sqsCO ? 'add' : '';
  const productCode = SqsSpajService.getProductCode(spajData);
  let outputId = sqsData.sqs.quotationCd;
  if (!sqsCO && !outputCO && counterOffer) {
    outputId = spajData.policy.originProposalCd.replace('P', 'Q')
  }
  const outputStorageData = await OutputStorageService.getByCode(global.database.pruSmart, { agentCode, outputId });

  const createIlustrationPerDocId = async () => {
    try {
      console.log('tes');
      const resultPropertiesDocId = await UtilitiesIllustration.PreparationCreateDocDefinition(
        sqsCO ? sqsCO : sqsData, agentName, agentChannel, agentCode, coStatus, quickQuoteIndex, outputCO ? outputCO : outputStorageData,
        UtilitiesIllustration.GenerateType.DOCID,
      );

      resultPropertiesDocId.chartBase64 = sqsCO ? sqsCO.sqs.chartBase64 : sqsData.sqs.chartBase64;
      resultPropertiesDocId.prop_no = spajData.policy.prop_no;

      // save prop_no to sqs
      sqsData.sqs.prop_no = spajData.policy.prop_no;
      // await NewQuotationStorageService.upsert(global.database.pruSmart, { data: sqsData, agentCode, quotationCode: sqsData.sqs.quotationCd });

      const ddOutput = await UtilitiesIllustration.CreateDocDefinition(resultPropertiesDocId, agentChannel);
      console.log('ddOutput SPAJ perDOCID: ', ddOutput)

      const { pdfData } = ddOutput;
      const illustrations = [];
      for (let illustrationIndex = 0; illustrationIndex < pdfData.length; illustrationIndex += 1) {
        const val = pdfData[illustrationIndex];
        const { docDefPDF, type, docId } = val;
        const base64 = await UtilityPdfViewer.createPdf(docDefPDF);
        illustrations.push({ base64, type, docId });
      }

      // const illustrations = pdfData.map(async val => {
      //   const { docDefPDF, type, docId } = val;
      //   try {
      //     const base64 = await UtilityPdfViewer.createPdf(docDefPDF);
      //     const illustration = {
      //       base64,
      //       type,
      //       docId,
      //     };
      //     console.log(`pdf - ${type} - generated`)
      //     return illustration;
      //   } catch (error) {
      //     console.log(`error: pdf - ${type} - ${error}`);
      //   }
      // });
      // const _illustrations = await Promise.all(illustrations);
      return illustrations;
    } catch (error) {
      console.log(error);
    }
  }

  const leftPad = (n, width, z) => {
    // eslint-disable-next-line no-param-reassign
    z = z || '0';
    // eslint-disable-next-line no-param-reassign
    n += '';
    return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
  };

  const setSubstandard = (subStandard) => {
    const result = [{
      sub_code: '',
      sub_class: '',
      role: '',
    }];
    if (subStandard.length) {
      subStandard.forEach((x) => {
        x.Data_sub.forEach((y) => {
          result.push({
            sub_code: y.subCode,
            sub_class: y.subTypeCode,
            role: y.role,
          });
        });
      });
    }
    return result;
  };

  const setRefund = bank => ({
    bank_name: bank.name || '',
    bank_branch: bank.branch || '',
    bank_account: bank.acc_no || '',
    currency: bank.curr || '',
    name: bank.acc_holder || '',
  });

  const setDataForComponentInCoverageComponents = (
    component, // 1
    descriptionInd, // 2
    fund, // 3
    role, // 4
    riskAge, // 5
    riskTerm, // 6
    premAge, // 7
    premTerm, // 8
    premium, // 9
    firstPremium, // 10
    instPremBasic, // 11
    instPremRider, // 12
    sar, // 13
    unitPrumed, // 14
    planHs, // 15
    planPphPlus, // 16
    sumAssured, // 17
    deductible, // 18
  ) => ({
    component,
    desc_component: descriptionInd,
    risk_age: riskAge,
    risk_term: riskTerm,
    prem_age: premAge,
    prem_term: premTerm,
    mort_cls: getOccpClassLAByRole(role, productCode),
    premium,
    first_premi: firstPremium,
    inst_prem_basic: instPremBasic,
    inst_prem_rider: instPremRider,
    prod_prefix: prodPrefix,
    sar,
    unit_prumed: unitPrumed,
    plan_hs: planHs,
    fund,
    plan_pphplus: planPphPlus,
    sum_assured: sumAssured,
    deductible,
  });

  const getOccpClassLAByRole = (role, productCode) => {
    let clazz = 'N';
    const client = spajData.client.lifeAss.find(x => x.role === role);
    if (!ConfigProduct.sqsProductSinglePremi.includes(productCode)) {
      if (client) {
        clazz = client.occp.mort_cls;
      }
    }
    if (['T2U'].includes(productCode)) {
      clazz = 'X'
    }
    return clazz;
  };

  const setComponentsForCoverage = async (role) => {
    const obj = [];
    const term = productTerm[productType];
    const riskTermByProd = {
      T2U: '20',
      H2I: '10'
    }
    const sar = productCode === 'H2I' ? quickQuote.coverageHCPInput[parseInt(role, 0) - 1].inputValue : quickQuote.premium
    if (quickQuote.mainCoverage.main) {
      let mainCoverage = _.cloneDeep(Caches.get('coverage').COVERAGE[quickQuote.mainCoverage.main]);
      if (quickQuote.mainCoverage.GIO && !isSIOFullUW) {
        const mainCoverage2 = _.cloneDeep(Caches.get('coverage').COVERAGE[quickQuote.mainCoverage.GIO]);
        if (mainCoverage2) {
          mainCoverage = mainCoverage2;
        } else {
          mainCoverage.coverageCode = quickQuote.mainCoverage.GIO;
        }
      }
      if (role === '01') {
        obj.push(setDataForComponentInCoverageComponents(
          mainCoverage.coverageCode, // 1
          mainCoverage.longDescription,  // 2
          sqs.fund, // 3
          role, // 4
          ['E2E', 'T2U', 'H2I'].includes(productCode) ? '00' : (['L2H', 'L2I'].includes(productCode) ? '99' : (productCode === 'R2A' ? quickQuote.usiaPensiun : term.risk_age)), // 5
          ['T2U', 'H2I'].includes(productCode) ? riskTermByProd[productCode] : term.risk_term, // 6
          ['E2E', 'T2U', 'H2I'].includes(productCode) ? '00' : (['L2H', 'L2I'].includes(productCode) ? '99' : term.prem_age), // 7
          ['T2U', 'R2A', 'H2I'].includes(productCode) ? quickQuote.premAge : term.prem_term, // 8
          (parseFloat(quickQuote.premiBerkala).toFixed(2) * 100).toFixed(0) === '0' ? '00' : (quickQuote.premiBerkala * 100).toFixed(0), // 9
          '', // first Premium  // 10
          '', // 11
          '', // 12
          (parseFloat(sar).toFixed(2) * 100).toFixed(0) === '0' ? '00' : (parseFloat(sar).toFixed(2) * 100).toFixed(0),  // 13
          '', // 14
          '', // 15
          '', // 16
          '', // 17
          '', // 18
        ));
      }
      if (productCode === 'H2I' && role !== '01') {
        obj.push(setDataForComponentInCoverageComponents(
          mainCoverage.coverageCode, // 1
          mainCoverage.longDescription,  // 2
          sqs.fund, // 3
          role, // 4
          ['E2E', 'T2U', 'H2I'].includes(productCode) ? '00' : (['L2H', 'L2I'].includes(productCode) ? '99' : (productCode === 'R2A' ? quickQuote.usiaPensiun : term.risk_age)), // 5
          ['T2U', 'H2I'].includes(productCode) ? riskTermByProd[productCode] : term.risk_term, // 6
          ['E2E', 'T2U', 'H2I'].includes(productCode) ? '00' : (['L2H', 'L2I'].includes(productCode) ? '99' : term.prem_age), // 7
          ['T2U', 'R2A', 'H2I'].includes(productCode) ? quickQuote.premAge : term.prem_term, // 8
          (parseFloat(quickQuote.premiBerkala).toFixed(2) * 100).toFixed(0) === '0' ? '00' : (quickQuote.premiBerkala * 100).toFixed(0), // 9
          '', // first Premium  // 10
          '', // 11
          '', // 12
          (parseFloat(sar).toFixed(2) * 100).toFixed(0) === '0' ? '00' : (parseFloat(sar).toFixed(2) * 100).toFixed(0),  // 13
          '', // 14
          '', // 15
          '', // 16
          '', // 17
          '', // 18
        ));
      }
    }

    if (quickQuote.mainCoverage.topup) {
      const topupCoverage = Caches.get('coverage').COVERAGE[quickQuote.mainCoverage.topup];
      if (role === '01') {
        if (pruSaverBerkala) {
          obj.push(setDataForComponentInCoverageComponents(
            topupCoverage.coverageCode,
            topupCoverage.longDescription,
            sqs.fundTopup,
            role,
            productCode === 'E2E' ? '00' : term.risk_age,
            term.risk_term,
            productCode === 'E2E' ? '00' : term.prem_age,
            premTermMapRop[quickQuote.premAge] || '00',
            (pruSaverBerkala).toFixed(0) === '0' ? '00' : (pruSaverBerkala).toFixed(0),
            '',
            '',
            '',
            (parseFloat(quickQuote.premium).toFixed(2) * 100).toFixed(0) === '0' ? '00' : (parseFloat(quickQuote.premium).toFixed(2) * 100).toFixed(0),
            '',
            '',
            '',
            '',
            '',
          ));
        }
      }
    }

    quickQuote.coverage.forEach((x) => {
      x.custList.filter(z => z.role === role).forEach((y) => {
        let sioCode = outputStorageData.quickQuote[sqsData.sqs.selectedQuickQuote].output.GIOCODE[x.coverageCd];
        const coverageDetail = Caches.get('coverage').COVERAGE[x.coverageCd];
        const valueName = y.itemInput[0];
        let value = y[`value${valueName}`];

        // Get Client
        if (value !== 'N') {
          const data = setDataForComponentInCoverageComponents(
            !isSIOFullUW ? (productCode === 'R2A' ? coverageDetail.TERMLIFEASIA[y.sar] : sioCode) : coverageDetail.TERMLIFEASIA[y.sar],
            coverageDetail.longDescription,
            [],
            role,
            productCode === 'R2A' ? '00' : y.sar,
            term.risk_term,
            productCode === 'R2A' ? term.prem_age : y.sar,
            productCode === 'R2A' ? premTermMapRop[quickQuote.premAge] : term.prem_term,
            '',
            '',
            '',
            '',
            '',
            '',
            productCode === 'R2A' ? '' : value,
            '',
            '',
            '',
          );

          data.sar = productCode === 'R2A' ? '00' : (parseFloat(value).toFixed(2) * 100).toFixed(0);
          // data.unit_prumed = '';
          // data.plan_hs = '';

          if (coverageDetail.ITEM_INPUT[0] === 'INPUTUNIT') {
            data.sar = '';
            data.unit_prumed = leftPad(value, 2);
            data.plan_hs = '';
          }

          if (coverageDetail.ITEM_INPUT[0] === 'PLANOPTION1') {
            data.sar = '';
            data.unit_prumed = '00';
            data.plan_hs = value;
          }

          if (['PHS', 'PHC'].includes(coverageDetail.ITEM_INPUT[0])) {
            const valuePPH = y[`inputNested${valueName}`];
            const valuePPS = y[`inputAdvance${valueName}`];
            const inputPPH = valuePPH.split(',');
            const inputPPS = valuePPS.split(',');
            value = inputPPH[1].trim();
            // eslint-disable-next-line prefer-destructuring
            data.component = inputPPS[0];
            data.sar = (parseFloat(value).toFixed(2) * 100).toFixed(0);
            data.unit_prumed = '';
            data.plan_hs = '';
          }

          if (['PHSP', 'PHCP'].includes(coverageDetail.ITEM_INPUT[0])) {
            const valuePPH = y[`inputNested${valueName}`];
            const valuePPS = y[`inputAdvance${valueName}`];
            let valueFixAmount = y.fixAmount;
            const inputPPH = valuePPH.split(',');
            const inputPPS = valuePPS.split(',');
            const inputFixAmount = valueFixAmount.split(',');
            value = inputPPH[1].trim();
            valueFixAmount = inputFixAmount[1].trim();
            // Prime Saver
            if (inputPPS[1].trim().toLowerCase() === 'tidak dipilih' || inputPPS[1].trim() === '') {
              data.deductible = 'N';
            } else {
              data.deductible = 'Y';
            }
            data.sar = (parseFloat(valueFixAmount).toFixed(2) * 100).toFixed(0);
            data.plan_pphplus = value;
            data.sum_assured = valueFixAmount;
            data.unit_prumed = '';
            data.plan_hs = '';
          }

          if (coverageDetail.ITEM_INPUT[0] === 'PLANOPTION3') {
            data.sar = '';
            data.unit_prumed = '';
            data.plan_hs = value;
          }

          if (coverageDetail.ITEM_INPUT[0] === 'PLANOPTION4') {
            data.sar = '';
            data.plan_hs = value.substr(0, 1);
          }

          if (coverageDetail.ITEM_INPUT[0] === 'YESNOOPTION') {
            let amount = '0';
            if (y[`value${coverageDetail.ITEM_INPUT[0]}`] === 'Y') {
              if (y[`value1${coverageDetail.ITEM_INPUT[0]}`]) {
                const currency = y[`value1${coverageDetail.ITEM_INPUT[0]}`].substr(0, 3);
                // eslint-disable-next-line max-len
                amount = (Number(y[`value1${coverageDetail.ITEM_INPUT[0]}`].replace(/,/g, '').replace(`${currency} `, '').replace('.', '')) * 100).toString();
              }
            }
            data.risk_age = y.sar;
            data.prem_age = y.sar;
            data.sar = amount;
            data.unit_prumed = '';
            data.plan_hs = '';
          }
          obj.push(data);
        }
      });
    });
    return obj;
  };

  const setCoverage = async () => {
    const coverage = await quickQuote.client.lifeAss.map(async x => ({
      role: x.role,
      components: await setComponentsForCoverage(x.role),
    }));
    return Promise.all(coverage);
  };

  const getFundProfile = (arr) => {
    const groupedFund = _.mapValues(_.groupBy(arr, 'type_fund'),
                          fundList => fundList.map(fu => _.omit(fu, 'type_fund')));

    console.log("Grouped Fund: ", groupedFund);

    let normalizedFund = [];

    for (let fundType in groupedFund) {
      let total = 0;
      groupedFund[fundType].forEach(x => {
        total += parseInt(x.percent);
      })

      normalizedFund.push({typeFund: fundType, percent: total});
    }

    normalizedFund = normalizedFund.sort((a,b) => (a.percent < b.percent) ? 1 : -1);
    const highest = normalizedFund[0].percent;
    normalizedFund = normalizedFund.filter(x => x.percent === highest);
    
    console.log("Fund Normalized: ", normalizedFund);
    let highestFund;
    if (normalizedFund.length > 1) {
      highestFund = normalizedFund.find(x=> x.typeFund === 'agresif')?.typeFund;
      if (!highestFund) {
        highestFund = normalizedFund.find(x=> x.typeFund === 'moderat')?.typeFund;
        if (highestFund) {
          highestFund = normalizedFund.find(x=> x.typeFund === 'konservatif')?.typeFund;
        }
      }
    } else {
      highestFund = normalizedFund[0]?.typeFund;
    }

    console.log("Highest Fund: ", highestFund);
    const investmentFundString = groupedFund[highestFund].map(x => `${x.type} ${parseInt(x.percent)}%`).toString();

    return { profile: highestFund, fund: investmentFundString }
  }

  const setSqsReport = () => {
    const productList = quickQuote.recommendation.product.map(x => ({
      ...x,
      rider: x.rider.map(y => ({
        code: y.coverageCode,
        desc_rider: y.longDescription,
      }))
    }));

    const productChoice = productList.find(x => x.productCode === quickQuote.productCode);

    const recProdString = productList.map(x => x.productDesc).toString();
    const choiceProdString = productChoice.productDesc;

    let recRiderList = [];
    productList.forEach(x => {
      recRiderList = recRiderList.concat(x.rider.map(y => y.desc_rider));
    });

    const recRiderString = recRiderList.filter((v, i, a) => a.indexOf(v) === i).toString();

    let choiceRiderString = "";
    if (quickQuote.coverage.length > 0) {
      quickQuote.coverage.forEach(x => {
        choiceRiderString += Caches.get('coverage').COVERAGE[x.coverageCd].longDescription;
        // choiceRiderString += productChoice.rider.filter(z=> z.code === x.coverageCd).map(y => y.desc_rider).toString();
        choiceRiderString += ", ";
      })
    }
    

    let sqsFund = {};
    if (sqs.fund.length) {
      sqsFund = getFundProfile(sqs.fund);
    }
    
    let sqsFundTopup = { fund: "", profile: "" }
    if (spajData.policy.topUp[0].fund.length > 0) {
      sqsFundTopup = getFundProfile(spajData.policy.topUp[0].fund);
    }

    
    return {
      rpResult: sqsData.sqs.rp.result,
      existingPolis: sqsData.sqs.existingPolicyProtection.join(','),
      existingInvestment: sqsData.sqs.investment.join(','),
      recommendationReason: quickQuote.reason,
      isFundSuitability: quickQuote.fund.some(x => x.type.toLowerCase() === sqsData.sqs.rp.result.toLowerCase()), //make lowercase
      isProductSuitability: true,
      isAgreeRecommendation: false,
      productRec: productList,
      productChoice,
      financialPlan: quickQuote.goal.toString(),
      recProdString,
      recRiderString,
      choiceProdString,
      choiceRiderString,
      investmentProfile: sqsFund.profile,
      investmentFundString: sqsFund.fund,
      investmentTopupProfile: sqsFundTopup.profile,
      investmentTopupFundString: sqsFundTopup.fund,
      paymentFreq: Caches.get('paymentFrequency').PAYMENT_FREQUENSI[quickQuote.billFreq].descriptionInd,
    }
  };

  const convertPersenValue = (percent) => {
    let conPercent = percent.toString();
    if (conPercent) {
      if (conPercent.length < 3) {
        conPercent = '0' + conPercent;
        return convertPersenValue(conPercent);
      } else {
        return conPercent;
      }
    } else {
      return '000'
    }
  }

  const mapSqsDataForSpajSubmit = async () => {
    try {
      const productChosen = quickQuote.recommendation.product.find(x => x.productCode === quickQuote.productCode);
      sqs.doc = [];
      sqs.doc.push({
        id: sqsData.sqs.doc.id,
        eff_docid: effDocid,
        type: 'QSTA',
        ver: versionSQS,
      });
      sqs.doc.push({
        id: docIdIlustration,
        eff_docid: effDocid,
        type: 'SKAA',
        ver: versionSQS,
      });
      if (quickQuote.backDate) {
        // BackDate
        sqs.doc.push({
          id: docIdBackdate,
          eff_docid: effDocid,
          type: 'SKAA',
          ver: versionSQS,
        });
      }
      sqs.doc.push({
        id: docIdRp,
        eff_docid: effDocid,
        type: 'SKAB',
        ver: versionSQS,
      });
      sqs.prop_no = spajData.policy.prop_no;
      sqs.agent_code = agentCode;
      sqs.fundTopup = [];
      sqs.fund = [];
      if (quickQuote.fundRp.length) {
        sqs.isFundRp = true;
        quickQuote.fundRp.forEach((x) => {
          const fund = Caches.get('fund').FUND[x.fundCd];
          sqs.fund.push({
            type_fund: x.type,
            type: x.fundCd,
            desc_fund: fund.descriptionInd,
            percent: convertPersenValue(x.percent),
          });
          if (x.percentTopUp) {
            sqs.fundTopup.push({
              type_fund: x.type,
              type: x.fundCd,
              desc_fund: fund.descriptionInd,
              percent: convertPersenValue(x.percentTopUp),
            });
          }
        });
      } else {
        sqs.isFundRp = false;
        quickQuote.fund.forEach((x) => {
          const fund = Caches.get('fund').FUND[x.fundCd];
          sqs.fund.push({
            type_fund: x.type,
            type: x.fundCd,
            desc_fund: fund.descriptionInd,
            percent: convertPersenValue(x.percent),
          });
          if (x.percentTopUp) {
            sqs.fundTopup.push({
              type_fund: x.type,
              type: x.fundCd,
              desc_fund: fund.descriptionInd,
              percent: (x.percentTopUp),
            });
          }
        });
      }
      sqs.backDate = quickQuote.backDate || "";
      sqs.timestamp = moment(sqsData.quotationDate).format('YYYY/MM/DD HH:mm:ss');
      sqs.sign = [];
      const spajSignClient = spajData.policy.sign.find(x => x.role === 'OW') || { location: null };
      sqs.sign[0] = {
        loc: sqsData.sqs.sign.ph.location || spajSignClient.location,
        date: sqsData.sqs.sign.ph.date ?
          moment(sqsData.sqs.sign.ph.date, 'DD-MMM-YYYY hh:mm:ss').format('YYYYMMDD')
          : moment(spajSignClient.date, 'DD-MMM-YYYY hh:mm:ss').format('YYYYMMDD'),
        value: sqsData.sqs.sign.ph.byte || spajSignClient.value,
        role: 'OW',
        name: spajData.client.ph.name,
      };
      const spajSignAgent = spajData.policy.sign.find(x => x.role === 'AG');
      sqs.sign[1] = {
        loc: sqsData.sqs.sign.agent.location || spajSignAgent.location,
        date: sqsData.sqs.sign.agent.date ?
          moment(sqsData.sqs.sign.agent.date, 'DD-MMM-YYYY hh:mm:ss').format('YYYYMMDD')
          : moment(spajSignAgent.date, 'DD-MMM-YYYY hh:mm:ss').format('YYYYMMDD'),
        value: sqsData.sqs.sign.agent.byte || spajSignAgent.value,
        role: 'AG',
        name: agentName,
      };
      sqs.budget = quickQuote.budget;
      sqs.budgetTerm = quickQuote.budgetTerm;
      sqs.data = {
        type: quickQuote.tipe,
        product_code: agentChannel === 'UOB' && productChosen.productCode === 'U2N' && quickQuote.mainCoverage.GIO ? 'U2L' : productChosen.productCode,
        product_type: Caches.get('coverage').COVERAGE[quickQuote.productCodeHPX].type,
        desc_product: productChosen.productDesc,
        prod_prefix: prodPrefix,
        coverage: await setCoverage(),
        substandard: setSubstandard(quickQuote.substandard),
        refund: sqsData.refund ? sqsData.refund : setRefund(spajData.policy.bank),
        period_plan: quickQuote.premAge,
        total_prem: totalPremi,
      };
      sqs.fixVersion = '';
      sqs.countPdf = 0;
      sqs.prospectData = sqsData.prospectData;
      sqsReport = setSqsReport();
      // sqsPdf = sqsData.sqs.illustration;
      sqsPdf = await createIlustrationPerDocId();
      console.log('sqsPdf: ', sqsPdf);
      return { sqs, sqsReport, sqsPdf };
    } catch (error) {
      console.log(error);
      throw error;
    }
  };

  return mapSqsDataForSpajSubmit();
};
export default { mapping };
