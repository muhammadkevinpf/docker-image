import Analytics from 'appcenter-analytics';
import moment from 'moment';
import RNDI from 'react-native-device-info';
import { Platform } from 'react-native';

const trackEvent = (name, agentCode) => {
  setTimeout(() => {
    Analytics.trackEvent(
      `[${name}]`,
      {
        date: moment().format('Do MMMM YYYY, HH:mm:ss').toString(),
        agentCode,
        platform: Platform.OS,
        osVersion: RNDI.getSystemVersion(),
        model: RNDI.getModel(),
        appVersion: RNDI.getVersion(),
      },
    );
  }, 3000);
};

export { trackEvent };
