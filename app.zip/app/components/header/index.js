/**
 * @author Dwi Setiyadi
 */

import React from 'react';
// import { View, Text } from 'react-native';
import { View, Text } from 'native-base';
import { Grid, Row, Col } from 'react-native-easy-grid';
import Styles from '../../styles';
import StyleHeader from './StyleHeader';
import { SubMenu } from '../sub-menu';
import { isTablet, isEmpty } from '../../utilities';
import { StatusBarDefault } from './MyStatusBar';

class Header extends React.Component {
  render() {
    const borderBottom = (this.props.borderBottom === false || this.props.headerColor) ? StyleHeader.borderNone : StyleHeader.borderHair;

    return (
      <View>
        {!isEmpty(this.props.headerColor) && <StatusBarDefault backgroundColor={this.props.headerColor} />}
        <View style={[StyleHeader.container, borderBottom,
          { backgroundColor: this.props.headerColor || Styles.Color.red, color: Styles.Color.white }]}
        >
          <Grid>
            <Row>
              <Col size={this.props.leftWidth}>
                {this.props.leftContent}
              </Col>
              <Col size={this.props.bodyWidth}>
                <View style={Styles.Main.textWrap}>
                  {this.props.bodyContent}
                </View>
              </Col>
              <Col size={this.props.rightWidth}>
                <View style={Styles.Main.textWrap}>
                  {this.props.rightContent}
                </View>
              </Col>
            </Row>
          </Grid>
        </View>
        {((this.props.subMenus !== undefined && !isTablet()) || this.props.showSubMenu) && <SubMenu {...this.props} /> }
        {
          this.props.subHeader !== undefined ?
            <View style={[Styles.Main.padding15, this.props.styledSubHeader ? StyleHeader.subHeader : Styles.Main.pb3]}>
              <Text
                style={[Styles.Main.fontAlbert, Styles.Main.textRed]}
                onPress={this.props.subHeaderPress}
              >
                {this.props.subHeader !== undefined && this.props.subHeader}
              </Text>
            </View>
            :
            <View />
        }

        {
          this.props.subHeaderContent !== undefined ?
            <View style={StyleHeader.subHeaderContent}>
              <Grid>
                <Row>
                  {this.props.subHeaderContent !== undefined && this.props.subHeaderContent}
                </Row>
              </Grid>
            </View>
            :
            <View />
        }

      </View>
    );
  }
}

export default Header;
