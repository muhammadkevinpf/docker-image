import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Modal, TouchableOpacity, SafeAreaView } from 'react-native';
import {
  View, Icon, Button, Text,
} from 'native-base';
import { FlatList } from 'react-native-gesture-handler';
import Style from '../../styles';
import _ from '../../lang';

export default class SortFilter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showSortModal: false,
      showFilterModal: false,
      sortBy: this.props.sortBy,
      filterBy: this.props.filterBy,
    };
  }

  onFilterValueChange = (value) => {
    this.setState({ filterBy: value }, () => this.onFilterModalClosed());
  }

  onSortValueChange = (value) => {
    this.setState({ sortBy: value }, () => this.onSortModalClosed());
  }

  onFilterModalClosed = () => {
    this.setState({ showFilterModal: false });
    this.props.onFilterSelected(this.state.filterBy);
  }

  onSortModalClosed = () => {
    this.setState({ showSortModal: false });
    this.props.onSortSelected(this.state.sortBy);
  }

  render() {
    return (
      <View style={this.props.additionalButton && [Style.Main.rowDirection, Style.Main.fullWidth]}>
        <View
          style={[
            Style.Main.margin3,
            Style.Main.dialogBtnCnt, Style.Main.radius8, Style.Main.boxShadow,
            Style.Main.backgroundWhite, Style.Main.height40, Style.Main.flexGrow,
            this.props.sortFilterStyle]}
        >
          {
            this.props.showSort &&
            <View style={[Style.Main.flex3, this.props.showFilter ? Style.Main.sortBtn : [Style.Main.rowDirection, Style.Main.justifyCenter]]}>
              <Button
                iconLeft
                transparent
                style={[Style.Main.height40]}
                onPress={() => this.setState({ showSortModal: true })}
              >
                <Icon
                  name="sort"
                  style={[Style.Main.textColor3f3, Style.Main.font16]}
                  type="MaterialIcons"
                />
                <Text style={[Style.Main.textColor3f3, Style.Main.font14]}>
                  {_('Sort')}
                </Text>
              </Button>
              <Modal
                animationType="fade"
                visible={this.state.showSortModal}
                onRequestClose={this.onSortModalClosed}
              >
                <SafeAreaView style={[Style.Main.flex1]}>
                  <View style={[Style.Main.mt15]}>
                    <View style={[Style.Main.grayBorderBottom, Style.Main.pb10]}>
                      <Button small transparent iconLeft onPress={this.onSortModalClosed}>
                        <Icon name="close" type="MaterialIcons" style={[Style.Main.textColor3f3]} />
                        <Text style={[Style.Main.textColor3f3]}>{_('Urutkan')}</Text>
                      </Button>
                    </View>
                  </View>
                  <FlatList
                    contentContainerStyle={[Style.Main.pb60]}
                    data={this.props.showDefaultSort ?
                      [{ [this.props.labelSort]: 'Default Sort', [this.props.valueSort]: '' }, ...this.props.sortItems] : this.props.sortItems}
                    keyExtractor={(item, index) => index.toString()}
                    renderItem={({ item }) => (
                      <View style={[Style.Main.grayBorderBottom, Style.Main.padding12, Style.Main.rowDirectionSpaceBetween]}>
                        <Text
                          style={[Style.Main.flexGrow]}
                          onPress={() => this.onSortValueChange(item[this.props.valueSort])}
                        >{_(item[this.props.labelSort])}
                        </Text>
                        <Icon
                          name="check"
                          type="MaterialIcons"
                          style={[Style.Main.textRed,
                            (this.state.sortBy === item[this.props.valueSort])
                              ? Style.Main.displayFlex
                              : Style.Main.displayNone,
                          ]}
                        />
                      </View>
                    )}
                  />
                </SafeAreaView>
              </Modal>
            </View>
          }
          {
            this.props.showSort && this.props.showFilter &&
            <View style={[Style.Main.container]}>
              <View style={[Style.Main.alignCenter, Style.Main.separator]} />
            </View>
          }
          {
            this.props.showFilter &&
            <TouchableOpacity style={[Style.Main.flex3]} onPress={() => this.setState({ showFilterModal: true })}>
              <Button
                iconLeft
                transparent
                style={[Style.Main.height40]}
                onPress={() => this.setState({ showFilterModal: true })}
              >
                <Icon
                  name="filter"
                  type="FontAwesome"
                  style={[Style.Main.textColor3f3, Style.Main.font16]}
                />
                <Text style={[Style.Main.textColor3f3, Style.Main.font14]}>
                  {_(this.props.customLabel || 'Filter')}
                </Text>
              </Button>
              <Modal
                animationType="fade"
                visible={this.state.showFilterModal}
                onRequestClose={this.onFilterModalClosed}
              >
                <SafeAreaView style={[Style.Main.flex1]}>
                  <View style={[Style.Main.mt15]}>
                    <View style={[Style.Main.grayBorderBottom, Style.Main.pb10]}>
                      <Button small transparent iconLeft onPress={this.onFilterModalClosed}>
                        <Icon name="close" type="MaterialIcons" style={[Style.Main.textColor3f3]} />
                        <Text style={[Style.Main.textColor3f3]}>{_('Filter')}</Text>
                      </Button>
                    </View>
                    <FlatList
                      contentContainerStyle={[Style.Main.pb60]}
                      data={this.props.showDefaultFilter ?
                        [{ [this.props.labelFilter]: 'Tampilkan Semua', [this.props.valueFilter]: '' }, ...this.props.filterItems]
                        : this.props.filterItems}
                      keyExtractor={(item, index) => index.toString()}
                      renderItem={({ item }) => (
                        <View style={[Style.Main.grayBorderBottom, Style.Main.padding12, Style.Main.rowDirectionSpaceBetween]}>
                          <Text
                            style={[Style.Main.flexGrow]}
                            onPress={() => this.onFilterValueChange(item[this.props.valueFilter])}
                          >{_(item[this.props.labelFilter])}
                          </Text>
                          <Icon
                            name="check"
                            type="MaterialIcons"
                            style={[Style.Main.textRed,
                              (this.state.filterBy === item[this.props.valueFilter])
                                ? Style.Main.displayFlex
                                : Style.Main.displayNone,
                            ]}
                          />
                        </View>
                      )}
                    />
                  </View>
                </SafeAreaView>
              </Modal>
            </TouchableOpacity>
          }
        </View>
        {this.props.additionalButton}
      </View>
    );
  }
}

SortFilter.propTypes = {
  showSort: PropTypes.bool,
  showFilter: PropTypes.bool,
  showDefaultSort: PropTypes.bool,
  showDefaultFilter: PropTypes.bool,
  sortItems: PropTypes.arrayOf(PropTypes.object),
  filterItems: PropTypes.arrayOf(PropTypes.object),
  sortFilterStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  filterBy: PropTypes.oneOfType([PropTypes.string, PropTypes.number, PropTypes.array, PropTypes.arrayOf(PropTypes.string)]),
  sortBy: PropTypes.oneOfType([PropTypes.string, PropTypes.number, PropTypes.arrayOf(PropTypes.string)]),
  onFilterSelected: PropTypes.func,
  onSortSelected: PropTypes.func,
  labelFilter: PropTypes.string,
  labelSort: PropTypes.string,
  valueFilter: PropTypes.string,
  valueSort: PropTypes.string,
};

SortFilter.defaultProps = {
  showSort: true,
  showFilter: true,
  showDefaultSort: true,
  showDefaultFilter: true,
  sortItems: [],
  filterItems: [],
  sortFilterStyle: null,
  filterBy: '',
  sortBy: '',
  onFilterSelected: () => { },
  onSortSelected: () => { },
  labelFilter: 'label',
  labelSort: 'label',
  valueFilter: 'value',
  valueSort: 'value',
};
