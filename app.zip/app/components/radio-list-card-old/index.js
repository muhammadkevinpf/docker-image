/* eslint-disable react/no-array-index-key */
/* eslint-disable no-console */
/**
 * @author:
 * definite maji arsana
*/

import React, { Component } from 'react';
import {
  Text,
  Radio,
  View,
} from 'native-base';
import PropTypes from 'prop-types';
import { Platform } from 'react-native';
import Style from '../../styles';
import _ from '../../lang';

class RadioListCardOld extends Component {
  shouldComponentUpdate = (prevProps) => {
    if (JSON.stringify(this.props) === JSON.stringify(prevProps)) return false;
    return true;
  }

  renderItems = (items) => {
    let oddItems = [];
    let evenItems = [];
    items.map((item, index) => {
      if (index % 2 === 0) evenItems = [...evenItems, item];
      else if (index % 2 !== 0) oddItems = [...oddItems, item];
      return { evenItems, oddItems };
    });
    return { evenItems, oddItems };
  }

  isIncluded = (value) => {
    if (this.props.disabledValues && this.props.disabledValues.find(val => val === value)) return true;
    return false;
  }

  handleOnPress = (obj) => {
    if (this.props.disabled) return {};
    if (this.isIncluded(obj.value)) return {};
    return this.props.onSelect(obj);
  }

  renderList = (item, index) => (
    <View
      style={[
        Style.Main.fullWidth,
        Style.Main.rowDirectionFlexStart,
        this.props.listStyle,
        this.isIncluded(item.value) && Style.Main.halfOpacity,
        this.props.disabled && Style.Main.halfOpacity]}
      key={index}
    >
      <Radio
        standardStyle
        disabled={this.isIncluded(item.value)}
        onPress={() => this.handleOnPress(item)}
        selectedColor={Style.Color.red}
        color="lightgrey"
        style={[Style.Main.padding5, this.props.radioStyle]}
        selected={item[this.props.valueProperty] === this.props.selectedValue || item === this.props.selectedValue || false}
      />
      <Text
        onPress={() => this.handleOnPress(item)}
        style={[
          Style.Main.flexWrap,
          Style.Main.textWrap,
          Style.Main.padding5,
          Style.Main.fullWidth,
          Style.Main.font14,
          Style.Main.textColor3f3,
          Style.Main.fontAlbert,
          Style.Main.ml12,
          Platform.OS === 'ios' && Style.Main.pt8,
          this.props.labelStyle]}
      >{_(item[this.props.labelProperty] || item)}
      </Text>
    </View>
  )

  render() {
    return (
      <View style={[Style.Main.mt15, Style.Main.fontAlbert, Style.Main.gray83, this.props.style]}>
        <Text style={[Style.Main.fontAlbert, Style.Main.textColor3f3, Style.Main.font14, Style.Main.mb12, this.props.titleStyle]}>
          {_(this.props.title)}
        </Text>
        {
          !this.props.isDoubleCol &&
          <View style={[this.props.oneRowStyle]}>
            {this.props.itemList.map((item, index) => (
              <View key={index} style={[Style.Main.flex1]}>
                {this.renderList(item, index)}
              </View>
            ))}

          </View>

        }
        {
          this.props.isDoubleCol &&
          <View style={Style.Main.rowDirectionFlexStart}>
            <View style={[Style.Main.flex3, Style.Main.columnDirectionJustifyCenter]}>
              {
              this.renderItems(this.props.itemList).evenItems.map((item, index) => (
                <View key={index}>
                  {this.renderList(item, index)}
                </View>
              ))
            }
            </View>
            <View style={[Style.Main.flex3, Style.Main.columnDirectionJustifyCenter]}>
              {
              this.renderItems(this.props.itemList).oddItems.map((item, index) => (
                <View key={index}>
                  {this.renderList(item, index)}
                </View>
              ))
            }
            </View>
          </View>
        }
        {this.props.isRequired && (this.props.selectedValue === null || this.props.selectedValue === '') && (
          <Text style={[Style.Main.fontAlbert, Style.Main.textRed, Style.Main.font10, this.props.errorStyle]}>
            {this.props.errorMsg}
          </Text>
        )}
      </View>
    );
  }
}

RadioListCardOld.propTypes = {
  onSelect: PropTypes.func.isRequired,
  itemList: PropTypes.arrayOf(PropTypes.object).isRequired,
  selectedValue: PropTypes.oneOfType([PropTypes.number, PropTypes.string, PropTypes.bool]),
  isDoubleCol: PropTypes.bool,
  isRequired: PropTypes.bool,
  errorMsg: PropTypes.string,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  labelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  titleStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  errorStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  title: PropTypes.oneOfType([PropTypes.object, PropTypes.string]),
  valueProperty: PropTypes.string,
  labelProperty: PropTypes.string,
  disabledValues: PropTypes.arrayOf(PropTypes.oneOfType([
    PropTypes.number, PropTypes.string, PropTypes.bool,
  ])),
  disabled: PropTypes.bool,
  oneRowStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
};

RadioListCardOld.defaultProps = {
  selectedValue: null,
  isDoubleCol: false,
  errorMsg: 'Wajib Dipilih',
  style: null,
  labelStyle: null,
  titleStyle: null,
  errorStyle: null,
  title: '',
  isRequired: true,
  valueProperty: 'value',
  labelProperty: 'label',
  disabledValues: null,
  disabled: false,
  oneRowStyle: null,
};

export default RadioListCardOld;
