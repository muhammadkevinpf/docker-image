/**
 * @author: ahmdichsanb@gmail.com
*/

import React, { PureComponent } from 'react';
import {
  TouchableOpacity, Text, View,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import PropTypes from 'prop-types';
import Badge from '../badge';
import StyleButtonCustom from './StyleButtonCustom';

class ButtonCustom extends PureComponent {
  render() {
    const {
      buttonStyle, buttonLabel, buttonLabelStyle, activeOpacity,
      badge, badgeValue, badgeType, badgeStyleProps, badgeWrapper,
      iconName, iconSize, iconColor, iconStyle,
      onPress, disabled,
    } = this.props;

    return (
      <TouchableOpacity
        style={[buttonStyle]}
        onPress={onPress}
        activeOpacity={activeOpacity}
        disabled={disabled}
      >
        {
          iconName !== null && (
            <Icon name={iconName} size={iconSize} color={iconColor} style={[iconStyle]} />
          )
        }
        {
          buttonLabel !== null && (
            <Text style={[buttonLabelStyle]}>{buttonLabel}</Text>
          )
        }

        <View style={[badgeWrapper]}>
          {
            badge && badgeValue > 0 && (
              <Badge badgeType={badgeType} badgeValue={badgeValue} badgeStyleProps={badgeStyleProps} />
            )
          }
        </View>
      </TouchableOpacity>
    );
  }
}


ButtonCustom.propTypes = {
  badge: PropTypes.bool,
  badgeValue: PropTypes.number,
  badgeType: PropTypes.string,
  onPress: PropTypes.func.isRequired,
  activeOpacity: PropTypes.number,
  buttonLabel: PropTypes.string,
  buttonStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  iconName: PropTypes.string,
  buttonLabelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  badgeStyleProps: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  badgeWrapper: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  iconSize: PropTypes.number,
  iconColor: PropTypes.string,
  iconStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  disabled: PropTypes.bool,
};

ButtonCustom.defaultProps = {
  badge: false,
  badgeValue: 0,
  badgeType: 'default',
  activeOpacity: 0.5,
  buttonLabel: null,
  buttonStyle: StyleButtonCustom.defaultButtonStyle,
  iconName: null,
  iconColor: 'white',
  iconSize: 30,
  iconStyle: null,
  buttonLabelStyle: null,
  badgeStyleProps: null,
  badgeWrapper: null,
  disabled: false,
};

export default ButtonCustom;
