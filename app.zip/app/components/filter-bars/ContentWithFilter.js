import { View } from 'react-native';
import React from 'react';
import PropTypes from 'prop-types';
import Style from '../../styles';
import FilterBars from './FilterBars';
import { isEmpty, isTablet } from '../../utilities';
import { ContentAdjusted } from '../common-components';

/** @augments {React.PureComponent<Props, State>} */
class ContentWithFilter extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      selectedKeys: [],
    };
  }

  render() {
    const { list } = this.props;
    const { selectedKeys } = this.state;
    const contents = isEmpty(selectedKeys) ? list : list.filter(obj => selectedKeys.some(key => key === obj.key));
    const median = Math.ceil(contents.length / 2);
    const leftList = contents.slice(0, median);
    const rightList = contents.length > 1 ? contents.slice(median) : null;
    if (!isEmpty(selectedKeys)) leftList.push(...list.filter(obj => !selectedKeys.some(key => key === obj.key)));
    return (
      <ContentAdjusted {...this.props} childStyle={[Style.Main.containerWithPadding12, Style.Main.pt0]}>
        <FilterBars onChange={keys => this.setState({ selectedKeys: keys })} {...this.props} />
        <View style={[Style.Main.container, isTablet() && Style.Main.rowDirectionSpaceBetween]}>
          <View style={[Style.Main.container, isTablet() && Style.Main.mr12]}>
            {leftList.map(obj => (
              <View key={obj.key} style={[!isEmpty(selectedKeys) && !selectedKeys.some(x => x === obj.key) && Style.Main.hide]}>
                {obj.component}
              </View>
            ))}
          </View>
          <View style={[Style.Main.container]}>
            {!isEmpty(rightList) && rightList.map(obj => <View key={obj.key}>{obj.component}</View>)}
          </View>
        </View>
      </ContentAdjusted>
    );
  }
}

ContentWithFilter.propTypes = {
  /** Array of filter: { key: numericacalKey, label: someLabel, component: someComponnent } */
  list: PropTypes.arrayOf(PropTypes.object).isRequired,
  /** Does the filter list need to be sorted based on whether it's active or not? */
  sortList: PropTypes.bool,
  /** Maximum number of filters shown. (default: 4 for mobile, 6 for tablet) */
  maxBars: PropTypes.number,
  maxHeight: PropTypes.number,
};

ContentWithFilter.defaultProps = {
  maxBars: isTablet() ? 6 : 4,
  maxHeight: null,
  sortList: false,
};

export default ContentWithFilter;
