import {
  ConfigIntegration,
} from './config';

const {
  LISTPROPOSALFETCH,
  LISTPROPOSALSUCCESS,
  LISTPROPOSALFAILED,
  STOREILLUSTRATIONDATA,
} = ConfigIntegration;

const initialState = {
  fetchListProposal: false,
  send: null,
  res: null,
  err: null,
};

export function ReducerSQSNSpaj(state = initialState, action) {
  switch (action.type) {
    case LISTPROPOSALFETCH:
      return {
        ...state,
        fetchListProposal: true,
        send: action.send,
        err: null,
        action: action.type,
      };
    case LISTPROPOSALSUCCESS:
      return {
        ...state,
        fetchSignIn: false,
        res: {
          ...state.res,
          listProposal: action.res.content.draftList,
        },
        err: null,
        action: action.type,
      };
    case LISTPROPOSALFAILED:
      return {
        ...state,
        fetchListProposal: false,
        err: action.err,
        action: action.type,
      };
    default:
      return state;
  }
}

const initialStateIllustration = {
  quickQuoteCd: '',
  chartBase64: '',
  pdfData: [],
  countPdf: 0,
};

export function ReducerIllustration(state = initialStateIllustration, action) {
  switch (action.type) {
    case STOREILLUSTRATIONDATA:
      return {
        ...state,
        chartBase64: action.data.chartBase64,
        quickQuoteCd: action.data.quickQuoteCd,
        pdfData: action.data.pdfData,
        countPdf: action.data.countPdf,
      };
    default:
      return state;
  }
}
