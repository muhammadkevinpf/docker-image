/* eslint-disable no-console */
import React, { PureComponent } from 'react';
import { View } from 'native-base';
import PropTypes from 'prop-types';
import SearchNativeBase from '../search-bar-native-base';
import SortFilter from '../sort-and-filter';
import Style from '../../styles';

export class SearchSortFilter extends PureComponent {
  render() {
    return (
      <View style={[Style.Main.fullWidth]}>
        <View style={this.props.advanceSearch && [Style.Main.rowDirection, Style.Main.fullWidth]}>
          {
            this.props.showSearchBar &&
            <SearchNativeBase
              searchStyle={this.props.searchStyle}
              placeholder={this.props.searchPlaceholder}
              onChangeText={this.props.onSearch}
              onInputBlur={value => this.props.onSearchBlur(value)}
              value={this.props.value}
            />
          }
          {this.props.advanceSearch}
        </View>
        {
          this.props.showSortAndFilter &&
          <SortFilter {...this.props} />
        }
        {
          this.props.children !== undefined &&
          <View style={[Style.Main.fullWidth]}>
            {this.props.children}
          </View>
        }
      </View>
    );
  }
}

SearchSortFilter.propTypes = {
  showTopBar: PropTypes.bool,
  searchPlaceholder: PropTypes.string,
  subHeader: PropTypes.string,
  showSearchBar: PropTypes.bool,
  showSortAndFilter: PropTypes.bool,
  filterBy: PropTypes.oneOfType([PropTypes.string, PropTypes.number, PropTypes.array, PropTypes.arrayOf(PropTypes.string)]),
  sortBy: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  onFilterSelected: PropTypes.func,
  onSortSelected: PropTypes.func,
  sortItems: PropTypes.arrayOf(PropTypes.object),
  filterItems: PropTypes.arrayOf(PropTypes.object),
  showSort: PropTypes.bool,
  showFilter: PropTypes.bool,
  showFooter: PropTypes.bool,
  footerButtonLabel: PropTypes.string,
  onPressFooter: PropTypes.func,
  onSearch: PropTypes.func,
  onSearchBlur: PropTypes.func,
};

SearchSortFilter.defaultProps = {
  showTopBar: true,
  searchPlaceholder: 'Search',
  subHeader: undefined,
  showSearchBar: true,
  showSortAndFilter: true,
  filterBy: '',
  sortBy: '',
  onFilterSelected: () => { },
  onSortSelected: () => { },
  sortItems: [],
  filterItems: [],
  showSort: true,
  showFilter: true,
  showFooter: false,
  footerButtonLabel: '',
  onPressFooter: () => { },
  onSearch: () => { },
  onSearchBlur: () => { },
};
