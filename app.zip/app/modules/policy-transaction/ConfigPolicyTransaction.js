/* eslint-disable max-len */
import React from 'react';
import { CoverageText, StyledText } from '../../components';
import { API_ACTION_TYPES } from '../../utilities';
import Disclaimer from './PolicyTransactionDisclaimer';
import Colors from '../../styles/Colors';
import Style from '../../styles';
import _ from '../../lang';

const offshoreFunds = [
  // 'PRGM', 'PRGV', 'PRNV', // OFFSHORE - IDR
  // 'PDGM', 'PDGV', 'PDNV', 'PDIF', 'PDFI', // OFFSHORE - USD
  'PDAE', 'PDGM', 'PDGV', 'PDNV', 'PSAE',
];

const fscSwitchingStatement = [
  <StyledText><StyledText italic>Financial Service Consultant</StyledText> (FSC) (selanjutnya disebut “Saya”) menyatakan bahwa Saya mengetahui Pemegang Polis mengajukan dan menyetujui pengajuan melalui formulir ini.</StyledText>,
  <StyledText>Saya mengetahui dan sudah memberikan penjelasan kepada Pemegang Polis bahwa pengajuan Pengalihan Unit (<StyledText italic>Switching</StyledText>) dan Perubahan Penempatan Porsi Investasi (
    <StyledText italic>Redirection</StyledText>)  yang diterima dalam masa perpanjangan penerimaan dokumen yaitu Paling lambat pukul 16.00 WIB (Waktu Indonesia Bagian Barat) akan mengikuti ketentuan sebagai berikut:
    <StyledText bold> Pembentukan/pembatalan unit ditentukan berdasarkan Harga Unit pada Tanggal Perhitungan.</StyledText>
  </StyledText>,
  <StyledText>Saya sudah memberikan penjelasan kepada Pemegang Polis bahwa kondisi tersebut tidak sesuai dengan ketentuan tenggat waktu yang berlaku di Prudential sebagaimana tercantum dalam Polis dan/atau FORMULIR PENGALIHAN UNIT (<StyledText italic>SWITCHING</StyledText>) DAN PERUBAHAN PENEMPATAN PORSI INVESTASI (
    <StyledText italic>REDIRECTION</StyledText>) POLIS PRULink NON SYARIAH/SYARIAH, yaitu:
    <StyledText bold> Pembentukan/pembatalan unit ditentukan berdasarkan Harga Unit pada Tanggal Perhitungan.</StyledText>
  </StyledText>,
];

const fscTopupStatement = [
  <StyledText><StyledText italic>Financial Service Consultant</StyledText> (FSC) (selanjutnya disebut “Saya”) menyatakan bahwa Saya mengetahui Pemegang Polis mengajukan dan menyetujui pengajuan melalui formulir ini.</StyledText>,
  <StyledText>Saya mengetahui dan sudah memberikan penjelasan kepada Pemegang Polis bahwa pengajuan Penambahan Dana Investasi (<StyledText italic>Top-up</StyledText>) yang diterima dalam masa perpanjangan penerimaan dokumen yaitu Paling lambat pukul 16.00 WIB (Waktu Indonesia Bagian Barat) akan mengikuti ketentuan sebagai berikut:
    <StyledText bold> Pembentukan/pembatalan unit ditentukan berdasarkan Harga Unit pada Tanggal Perhitungan.</StyledText>
  </StyledText>,
  <StyledText>Saya sudah memberikan penjelasan kepada Pemegang Polis bahwa kondisi tersebut tidak sesuai dengan ketentuan tenggat waktu yang berlaku di Prudential sebagaimana tercantum dalam Polis dan/atau FORMULIR PENAMBAHAN DANA (<StyledText italic>TOP-UP</StyledText>) POLIS PRULink NON SYARIAH/SYARIAH, yaitu:
    <StyledText bold> Pembentukan/pembatalan unit ditentukan berdasarkan Harga Unit pada Tanggal Perhitungan.</StyledText>
  </StyledText>,
];

const topupAnnotation = [
  'Harus kelipatan 5% dengan total 100%. Jika pilihan tidak diisi maka otomatis akan diproses sesuai penempatan Porsi Investasi yang terakhir tercatat pada Prudential.',
  'Dana Investasi Luar Negeri Tertentu, berlaku Ketentuan nomor 14 yang tertera pada Formulir, yaitu untuk: ',
];

const switchingAnnotation = [
  'Pengajuan pengalihan Unit akan diproses sesuai dengan bentuk (nominal/%) yang dipilih.',
  [
    'Penulisan nominal atau presentase sebagai berikut: Untuk bilangan bulat ditulis tanpa tanda baca. (contoh: 1000000; dibaca Satu Juta). Untuk bilangan dengan desimal ditulis menggunakan tanda titik (.) (contoh; 1000000.50; dibaca Satu Juta koma Lima Puluh).',
    'Pengalihan Unit Polis Non Syariah hanya dapat dialihkan ke jenis dana investasi Non Syariah dengan mata uang yang sama, sedangkan pengalihan Unit Polis Syariah hanya dapat dialihkan ke jenis dana investasi Syariah dengan mata uang yang sama.',
  ],
  'Pembagian jenis dana investasi yang dituju harus dalam kelipatan 5% dengan total dana investasi sebesar 100%.',
  'Dana Investasi Luar Negeri Tertentu, berlaku Ketentuan Umum nomor 5 yang tertera pada Formulir, yaitu untuk: ',
];

const offshoreAnnotation = [
  // use hardcode until PDAE fund is included in product condig
  // ...offshoreFunds.map((code, i) => <CoverageText key={i.toString()} desc={`${DatabaseUtils.getFundDesc(code)}`} pruStyle={[Style.Main.textRed]} style={[Style.Main.setFontAlbert(12, Colors.gray83)]} />),
  <CoverageText desc="PRULink Rupiah Global Emerging Market Equity Fund" pruStyle={[Style.Main.textRed]} style={[Style.Main.setFontAlbert(12, Colors.gray83)]} />,
  <CoverageText desc="PRULink Rupiah Global Low Volatility Equity Fund" pruStyle={[Style.Main.textRed]} style={[Style.Main.setFontAlbert(12, Colors.gray83)]} />,
  <CoverageText desc="PRULink Rupiah Multi Assets Navigator Fund" pruStyle={[Style.Main.textRed]} style={[Style.Main.setFontAlbert(12, Colors.gray83)]} />,
  <CoverageText desc="PRULink US Dollar Global Emerging Markets Equity Fund" pruStyle={[Style.Main.textRed]} style={[Style.Main.setFontAlbert(12, Colors.gray83)]} />,
  <CoverageText desc="PRULink US Dollar Global Low Volatility Equity Fund" pruStyle={[Style.Main.textRed]} style={[Style.Main.setFontAlbert(12, Colors.gray83)]} />,
  <CoverageText desc="PRULink US Dollar Multi Assets Navigator Fund" pruStyle={[Style.Main.textRed]} style={[Style.Main.setFontAlbert(12, Colors.gray83)]} />,
  <CoverageText desc="PRULink US Dollar Multi Assets Income Fund" pruStyle={[Style.Main.textRed]} style={[Style.Main.setFontAlbert(12, Colors.gray83)]} />,
  <CoverageText desc="PRULink US Dollar Heritage Conservative Income Fund" pruStyle={[Style.Main.textRed]} style={[Style.Main.setFontAlbert(12, Colors.gray83)]} />,
  <CoverageText desc="PRULink US Dollar Global Tech Equity Fund" pruStyle={[Style.Main.textRed]} style={[Style.Main.setFontAlbert(12, Colors.gray83)]} />,
];

const switchingDefinition = <StyledText color={Colors.gray83} style={[Style.Main.mV15]}>{_('Definisi pengalihan Unit (')}<StyledText color={Colors.gray83} italic>Switching</StyledText>{_(') adalah pemindahan sebagian atau seluruh Unit yang ada dari satu dana investasi ke dana investasi yang lain dalam satu jenis dana investasi dan mata uang yang sama dengan menggunakan Harga Unit pada Tanggal Perhitungan terdekat berikutnya.')}</StyledText>;

const switchingDisclaimer = [{
  title: (color = Colors.blue, font = 14) => <StyledText font={font} color={color}>Persyaratan dan Ketentuan Pengalihan Unit (<StyledText font={font} color={color} italic>Switching</StyledText>) dan Perubahan Penempatan Porsi Investasi (<StyledText font={font} color={color} italic>Redirection</StyledText>) Polis PRULink Non Syariah/Syariah</StyledText>,
  html: Disclaimer.styleHtml + Disclaimer.tncSwitching,
}, {
  title: () => 'Pernyataan Pemegang Polis (harap dibaca dengan teliti sebelum menandatangani Formulir)',
  html: Disclaimer.styleHtml + Disclaimer.phStatementSwitching,
}, {
  title: (color = Colors.blue, font = 14) => <StyledText font={font} color={color}>Pernyataan Pemegang Polis atas perpanjangan waktu penerimaan dokumen transaksi Pengalihan Dana Investasi (<StyledText font={font} color={color} italic>Switching</StyledText>) atau Perubahan Penempatan Porsi Investasi (<StyledText font={font} color={color} italic>Redirection</StyledText>)</StyledText>,
  html: Disclaimer.styleHtml + Disclaimer.transactionSwitching,
}];

const topupDisclaimer = [{
  title: () => 'Persyaratan dan Ketentuan Penambahan Dana (Top-up) Non Syariah/Syariah',
  html: Disclaimer.styleHtml + Disclaimer.tncTopup,
}, {
  title: () => 'Pernyataan Pemegang Polis/Calon Pemegang Polis (harap dibaca dengan teliti sebelum menandatangani Formulir ini)',
  html: Disclaimer.styleHtml + Disclaimer.phStatementTopup,
}, {
  title: (color = Colors.blue, font = 14) => <StyledText font={font} color={color}>Pernyataan Pemegang Polis atas perpanjangan waktu penerimaan dokumen transaksi Penambahan Dana Investasi (<StyledText font={font} color={color} italic>Top-up</StyledText>)</StyledText>,
  html: Disclaimer.styleHtml + Disclaimer.transactionTopup,
}];

const unitTypes = {
  NOMINAL: 'A',
  PERCENTAGE: 'P',
  UNIT: 'U',
};

const unitTypeOpt = [
  { value: unitTypes.NOMINAL, label: 'Nominal' },
  { value: unitTypes.PERCENTAGE, label: 'Persentase (%)' },
  { value: unitTypes.UNIT, label: 'Unit' }, // Unit opt will be hidden in production until approved
];

const subType = {
  TOPUP: 'TUP',
  SWITCHING: 'SWI',
  SNR: 'SNR',
  REDIRECTION: 'RED',
};

const docId = {
  TUP_INDV: '14010101',
  TUP_CORP: '14050102',
  SWI: '14020101',
  RED: '14030101',
  SNR_INDV: '14040101',
  SNR_CORP: '14040102',
};

const UPDATE_REDUCER = {
  ALL: 'UPDATE_POLICY_TRANSACTION_REDUCER',
  POLICY: 'UPDATE_POLICY_TRANSACTION_POLICY',
  TOPUP: 'UPDATE_POLICY_TRANSACTION_TOPUP',
  SWI: 'UPDATE_POLICY_TRANSACTION_SWI',
  SNR: 'UPDATE_POLICY_TRANSACTION_SNR',
  RESET: 'RESET_POLICY_TRANSACTION',
};

const payorRoles = {
  PH: 'OW',
  PY: 'PYR',
  TU: '01',
  T1: '02',
  T2: '03',
  OTHER: 'OTH',
};

const payorRoleOpt = [
  { label: 'Pemegang Polis', value: payorRoles.PH },
  { label: 'Pembayar/Kontribusi Polis', value: payorRoles.PY },
  { label: 'Tertanggung Utama/Peserta Utama Yang Diasuransikan', value: payorRoles.TU },
  { label: 'Tertanggung Tambahan 1/Peserta Tambahan 1 Yang Diasuransikan', value: payorRoles.T1 },
  { label: 'Tertanggung Tambahan 2/Peserta Tambahan 2 Yang Diasuransikan', value: payorRoles.T2 },
  { label: 'Lainnya', value: payorRoles.OTHER },
];

const occupConfirmation = [
  { label: 'Ya, Data Pekerjaan saya telah berubah dan belum melakukan perubahan.', value: 'Y' },
  { label: 'Tidak, Data Pekerjaan saya tidak berubah/saya telah melakukan perubahan Data Pekerjaan', value: 'N' },
];

const occupation = [
  { label: 'Wirausaha', value: 'B' },
  { label: 'Karyawan Pada Perusahaan Keuangan', value: 'JA' },
  { label: 'Karyawan Pada Perusahaan Non Keuangan', value: 'J' },
  { label: 'TNI/POLRI', value: 'H' },
  { label: 'Pegawai negeri sipi', value: 'K' },
  { label: 'Pejabat Pemerintah Pusat/Daerah/BUMN/BUMD/Lembaga Pemerintah Lainnya', value: 'O' },
  { label: 'Hakim/Jaksa/Panitera Pengadilan Lainnya', value: 'PG' },
  { label: 'Anggota Legislatif Pusat/Daerah', value: 'LN' },
  { label: 'Profesional', value: 'A' },
  { label: 'Lainnya', value: 'Z' },
];

const monthlyIncome = [{
  code: '2500000', value: '2500000', rangeInd: 'Kurang dari Rp 2,5juta',
}, {
  code: '3750000', value: '3750000', rangeInd: 'Rp 2,5juta s/d <Rp 5juta',
}, {
  code: '6250000', value: '6250000', rangeInd: 'Rp 5juta s/d <Rp 7,5juta',
}, {
  code: '8750000', value: '8750000', rangeInd: 'Rp 7,5juta s/d <Rp 10juta',
}, {
  code: '17500000', value: '17500000', rangeInd: 'Rp 10juta s/d <Rp 25juta',
}, {
  code: '37500000', value: '37500000', rangeInd: 'Rp 25juta s/d <Rp 50juta',
}, {
  code: '75000000', value: '75000000', rangeInd: 'Rp 50juta s/d <Rp 100juta',
}, {
  code: '175000000', value: '175000000', rangeInd: 'Rp 100juta s/d <Rp 250juta',
}, {
  code: '375000000', value: '375000000', rangeInd: 'Rp 250juta s/d <Rp 500juta',
}, {
  code: '750000000', value: '750000000', rangeInd: 'Rp 500juta s/d <Rp 1milyar',
}, {
  code: '1250000000', value: '1250000000', rangeInd: 'Rp 1milyar s/d <Rp 1,5milyar',
}, {
  code: '1750000000', value: '1750000000', rangeInd: 'Rp 1,5milyar s/d <Rp 2milyar',
}, {
  code: '2500000000', value: '2500000000', rangeInd: 'Rp 2milyar s/d <Rp 3milyar',
}, {
  code: '3500000000', value: '3500000000', rangeInd: 'Rp 3milyar s/d <Rp 4milyar',
}, {
  code: '4500000000', value: '4500000000', rangeInd: 'Rp 4milyar s/d <Rp 5milyar',
}, {
  code: '5000000000', value: '5000000000', rangeInd: 'Lebih dari/sama dengan Rp 5milyar',
}, {
  code: '0', value: '0', rangeInd: 'Tidak Berpenghasilan',
}];

const yearlyIncome = [{
  code: '10000000', value: '10000000', rangeInd: '< 10juta',
}, {
  code: '55000000', value: '55000000', rangeInd: '> Rp 10juta - Rp 100juta',
}, {
  code: '550000000', value: '550000000', rangeInd: '> Rp 100juta - Rp 1miliar',
}, {
  code: '3000000000', value: '3000000000', rangeInd: '> Rp 1miliar - 5miliar',
}, {
  code: '5000000000', value: '5000000000', rangeInd: '> Rp 5miliar',
}];

const monthlyIncomeSource = [
  {
    label: 'Gaji', value: 'G', isSelected: false, isTextInput: false,
  },
  {
    label: 'Orang Tua', value: 'J', isSelected: false, isTextInput: false,
  },
  {
    label: 'Investasi', value: 'E', isSelected: false, isTextInput: false,
  },
  {
    label: 'Komisi', value: 'N', isSelected: false, isTextInput: false,
  },
  {
    label: 'Laba Perusahaan', value: 'L', isSelected: false, isTextInput: false,
  },
  {
    label: 'Bonus', value: 'M', isSelected: false, isTextInput: false,
  },
  {
    label: 'Bisnis Pribadi', value: 'H', isSelected: false, isTextInput: false,
  },
  {
    label: 'Penghasilan Suami/Istri', value: 'I', isSelected: false, isTextInput: false,
  },
  {
    label: 'Lainnya', value: 'F', isSelected: false, isTextInput: false,
  },
  {
    label: 'Tidak Berpenghasilan', value: 'W', isSelected: false, isTextInput: false,
  },
];

// const monthlyIncomeSource = [{
//   label: 'Gaji', value: 'G', isSelected: false, isTextInput: false,
// }, {
//   label: 'Laba Perusahaan', value: 'L', isSelected: false, isTextInput: false,
// }, {
//   label: 'Bisnis Pribadi', value: 'H', isSelected: false, isTextInput: false,
// }, {
//   label: 'Hasil Investasi', value: 'K', isSelected: false, isTextInput: false,
// }, {
//   // label: 'Lainnya', value: 'F', isSelected: false, isTextInput: true, input: '', //Gajadi pake freetext
//   label: 'Lainnya', value: 'F', isSelected: false, isTextInput: false,
// }];

const yearlyIncomeSource = [{
  label: 'Bonus', value: 'M', isSelected: false, isTextInput: false,
}, {
  label: 'Hadiah/Warisan', value: 'P', isSelected: false, isTextInput: false,
}, {
  label: 'Komisi', value: 'N', isSelected: false, isTextInput: false,
}, {
  label: 'Hasil Investasi', value: 'K', isSelected: false, isTextInput: false,
}, {
  // label: 'Lainnya', value: 'F', isSelected: false, isTextInput: true, input: '', textType: 'default', //ga jadi pake freetext
  label: 'Lainnya', value: 'F', isSelected: false, isTextInput: false,
}, {
  label: 'Penjualan aset', value: 'O', isSelected: false, isTextInput: false,
}];

const topupReason = [{
  label: 'Tabungan', value: 'B', isSelected: false, isTextInput: false,
}, {
  label: 'Investasi', value: 'E', isSelected: false, isTextInput: false,
}, {
  label: 'Pendidikan', value: 'C', isSelected: false, isTextInput: false,
}, {
  label: 'Dana Pensiun', value: 'D', isSelected: false, isTextInput: false,
}, {
  // label: 'Lainnya', value: 'F', isSelected: false, isTextInput: true, input: '', textType: 'default', //Gajadi pake freetext
  label: 'Lainnya', value: 'F', isSelected: false, isTextInput: false,
}];

const documents = [{
  label: 'FOTO BUKTI BAYAR', value: '13010299', docType: 'Loosemails', mainDoc: 'BYRC',
}];

const minSwitching = (productCode, productCurr) => {
  if (productCurr === 'IDR') {
    if (productCode === 'U1E') return 10;
    if (productCode === 'U1V') return 100000;
    return 2000000;
  }
  const usdProducts = [
    'U1U', 'U1Z', 'U10', 'U15',
    'U2P', 'U2T', 'U2U', 'U2V', 'U2W', 'U2Y', 'U2Z', 'U20', 'U25',
    'U30', 'U4D', 'U4J', 'U4K',
  ];
  if (usdProducts.includes(productCode)) return 500;
  return 100;
};

const minRemaining = (productCode, productCurr) => {
  const products = ['U1U', 'U2T', 'U2U', 'U2V', 'U2W', 'U20', 'U25', 'U4D'];
  const idrProducts = ['U1E', 'U2X', 'U22', 'U24', 'U26'];
  if (products.includes(productCode) || (productCurr === 'IDR' && idrProducts.includes(productCode))) return 0;
  return minSwitching(productCode, productCurr);
};

const minTopup = (productCode, productCurr) => {
  if (productCurr === 'IDR') {
    const min100rb = ['U1V', 'U1W'];
    const min600rb = ['U1P', 'U1R', 'U15', 'U16'];
    const min1jt = [
      'U1A', 'U1B', 'U1E', 'U1G', 'U1H', 'U1J', 'U1K', 'U1L', 'U1M', 'U1S', 'U1U', 'U1Z', 'U10', 'U11',
      'U2A', 'U2B', 'U2E', 'U2G', 'U2H', 'U2J', 'U2K', 'U2L', 'U2M', 'U2N', 'U2O', 'U2P', 'U2R', 'U2T', 'U2U', 'U2W', 'U2X',
      'U20', 'U22', 'U23', 'U24', 'U25', 'U26',
      'U3A', 'U3G', 'U3H', 'U3L', 'U3M', 'U3Z', 'U30', 'U31',
      'U4B', 'U4D',
    ];
    const min1dot2jt = ['U2V'];
    const min5jt = ['U1Y', 'U2D', 'U2Y', 'U2Z', 'U21', 'U27', 'U28', 'U4J', 'U4K'];

    if (min100rb.includes(productCode)) return 100000;
    if (min600rb.includes(productCode)) return 600000;
    if (min1jt.includes(productCode)) return 1000000;
    if (min1dot2jt.includes(productCode)) return 1200000;
    if (min5jt.includes(productCode)) return 5000000;
    return 0;
  }

  const min100 = ['U1V'];
  const min250 = [
    'U1A', 'U1B', 'U1L', 'U1U', 'U1Z', 'U10',
    'U2A', 'U2B', 'U2J', 'U2K', 'U2L', 'U2N', 'U2O', 'U2P', 'U2T', 'U2U', 'U2W', 'U20', 'U25',
    'U3L', 'U30', 'U4D',
  ];
  const min300 = ['U2V'];
  const min500 = ['U2Y', 'U2Z', 'U4J', 'U4K'];

  if (min100.includes(productCode)) return 100;
  if (min250.includes(productCode)) return 250;
  if (min300.includes(productCode)) return 300;
  if (min500.includes(productCode)) return 500;
  return 0;
};

export const SUBMIT_PHS = API_ACTION_TYPES('SUBMIT_PHS', '');

export default {
  UPDATE_REDUCER,
  fscSwitchingStatement,
  fscTopupStatement,
  topupAnnotation,
  offshoreAnnotation,
  switchingAnnotation,
  switchingDefinition,
  switchingDisclaimer,
  topupDisclaimer,
  unitTypes,
  unitTypeOpt,
  subType,
  payorRoles,
  payorRoleOpt,
  occupConfirmation,
  occupation,
  monthlyIncome,
  yearlyIncome,
  monthlyIncomeSource,
  yearlyIncomeSource,
  topupReason,
  documents,
  docId,
  offshoreFunds,
  minSwitching,
  minRemaining,
  minTopup,
};
