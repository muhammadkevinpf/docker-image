/* eslint-disable react/no-array-index-key */
/* eslint-disable no-console */
import React, { Component } from 'react';
import {
  Text,
  Radio,
  View,
  Row,
} from 'native-base';
import PropTypes from 'prop-types';
import { Platform } from 'react-native';
import Style from '../../styles';
import _ from '../../lang';

class RadioListCard extends Component {
  shouldComponentUpdate = (prevProps) => {
    if (JSON.stringify(this.props) === JSON.stringify(prevProps)) return false;
    return true;
  }

  renderItems = (items) => {
    let oddItems = [];
    let evenItems = [];
    items.map((item, index) => {
      if (index % 2 === 0) evenItems = [...evenItems, item];
      else if (index % 2 !== 0) oddItems = [...oddItems, item];
      return { evenItems, oddItems };
    });
    return { evenItems, oddItems };
  }

  isIncluded = (value) => {
    if (this.props.disabledValues && this.props.disabledValues.find(val => val === value)) return true;
    return false;
  }

  handleOnPress = (obj) => {
    if (this.props.disabled) return {};
    if (this.isIncluded(obj.value)) return {};
    return this.props.onSelect(obj);
  }

  renderList = (item, index) => (
    <Row
      style={[
        Style.Main.fullWidth,
        this.props.listStyle,
        this.isIncluded(item.value) && Style.Main.halfOpacity,
        this.props.disabled && Style.Main.halfOpacity]}
      key={index}
    >
      <Radio
        disabled={this.isIncluded(item.value)}
        onPress={() => this.handleOnPress(item)}
        selectedColor={Style.Color.red}
        color="lightgrey"
        standardStyle
        style={[Style.Main.padding5, this.props.radioStyle]}
        selected={item[this.props.valueProperty] === this.props.selectedValue || item === this.props.selectedValue || false}
      />
      <Text
        onPress={() => this.handleOnPress(item)}
        style={[
          Style.Main.flexWrap,
          Style.Main.textWrap,
          Style.Main.padding5,
          Style.Main.fullWidth,
          Style.Main.font14,
          Style.Main.textAlmostBlack,
          Style.Main.fontAlbert,
          Platform.OS === 'ios' && Style.Main.pt8,
          this.props.labelStyle]}
      >{_(item[this.props.labelProperty] || item)}
      </Text>
    </Row>
  )

  render() {
    console.log('this radiolistcard being rendered');
    return (
      <View style={[Style.Main.mt15, this.props.style]}>
        {this.props.title !== '' && (
          <Text style={[
            Style.Main.excludeFontPadding,
            Style.Main.mb0,
            Style.Main.font11,
            Style.Main.textGray,
            Style.Main.fontAlbert,
            this.props.titleStyle]}
          >{_(this.props.title)}
          </Text>
        )}
        { !this.props.isDoubleCol && this.props.itemList.map((item, index) => (this.renderList(item, index)))}
        {
          this.props.isDoubleCol &&
          <View style={Style.Main.rowDirectionFlexStart}>
            {
              this.renderItems(this.props.itemList).evenItems.map((item, index) => (
                <View key={index} style={[Style.Main.flex3, Style.Main.columnDirectionJustifyCenter]}>
                  {this.renderList(item, index)}
                </View>
              ))
            }{
              this.renderItems(this.props.itemList).oddItems.map((item, index) => (
                <View key={index} style={[Style.Main.flex3, Style.Main.columnDirectionJustifyCenter]}>
                  {this.renderList(item, index)}
                </View>
              ))
            }
          </View>
        }
        {this.props.isRequired && (this.props.selectedValue === null || this.props.selectedValue === '') && (
          <Text style={[
            Style.Main.font10,
            Style.Main.ml15,
            Style.Main.textRed,
            Style.Main.fontAlbert,
            this.props.errorStyle]}
          >{this.props.errorMsg}
          </Text>
        )}
      </View>
    );
  }
}

RadioListCard.propTypes = {
  onSelect: PropTypes.func.isRequired,
  itemList: PropTypes.arrayOf(PropTypes.object).isRequired,
  selectedValue: PropTypes.oneOfType([PropTypes.number, PropTypes.string, PropTypes.bool]),
  isDoubleCol: PropTypes.bool,
  isRequired: PropTypes.bool,
  errorMsg: PropTypes.string,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  titleStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  errorStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  title: PropTypes.oneOfType([PropTypes.object, PropTypes.string]),
  valueProperty: PropTypes.string,
  labelProperty: PropTypes.string,
  disabledValues: PropTypes.arrayOf(PropTypes.oneOfType([
    PropTypes.number, PropTypes.string, PropTypes.bool,
  ])),
  disabled: PropTypes.bool,
};

RadioListCard.defaultProps = {
  selectedValue: null,
  isDoubleCol: false,
  errorMsg: 'Wajib Dipilih',
  style: null,
  titleStyle: null,
  errorStyle: null,
  title: '',
  isRequired: true,
  valueProperty: 'value',
  labelProperty: 'label',
  disabledValues: null,
  disabled: false,
};

export default RadioListCard;
