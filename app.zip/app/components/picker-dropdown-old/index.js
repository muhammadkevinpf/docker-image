/**
 * improve component dropdown picker from ahmdichsanb@gmail.com
 * modify by dennisindra22@gmail.com
 * use picker from native base
 * on Android one item picker is added in the first value to be used as a placeholder
 * @author: definite maji arsana
 */

import React, { Component } from 'react';
import { Platform } from 'react-native';
import {
  Picker, Label, Item, Text, View,
} from 'native-base';
import PropTypes from 'prop-types';
import StylePicker from './StylePicker';
import Icons from '../icon-native-base';
import Style from '../../styles';
import _ from '../../lang';

class PickerDropdownOld extends Component {
  constructor(props) {
    super(props);
    this.state = {
      errorMessage: this.props.errorMessage,
      label: '',
    };
  }

  shouldComponentUpdate = (prevProps) => {
    if (JSON.stringify(this.props) === JSON.stringify(prevProps)) return false;
    return true;
  };

  getRowData = (input) => {
    const { dropdownData } = this.props;
    const { valueProp } = this.props;
    let result;
    if (input) {
      result = dropdownData.find(element => element[valueProp] === input);
    } else {
      result = {};
    }
    return result;
  };

  dropdownValidation = (input) => {
    const { isRequired, onValueChange, label } = this.props;
    let errorMessage = '';
    if (!input) {
      if (isRequired) {
        errorMessage = 'Wajib dipilih';
      } else {
        errorMessage = '';
      }
    }

    this.setState({
      errorMessage, label,
    });

    if (onValueChange) {
      onValueChange(input, this.getRowData(input));
    }
  };

  invokeValidation = (errorMessage) => {
    this.dropdownValidation(this.props.selectedValue);
    if (errorMessage) {
      this.setState({
        errorMessage,
      });
    }
  };

  render() {
    const {
      mode,
      enabled,
      placeholder,
      iosIcon,
      stylePickerBody,
      stylePickerView,
      labelStyle,
      bottomLabelStyle,
      errorLabelStyle,
      textColor,
      valueProp,
      labelProp,
      bottomLabel,
      label,
      dropdownData,

      // add
      itemStyle,
      selectedValue,
    } = this.props;

    const {
      errorMessage,
    } = this.state;

    const dropdown = dropdownData
      ? dropdownData.map((item, index) => {
        const itemLabel = item[labelProp];
        const value = item[valueProp];
        const order = index;
        return (
          <Picker.Item
            key={order}
            label={itemLabel}
            value={value}
            color={textColor}
          />
        );
      })
      : null;

    const androidPicker = (
      <View style={[StylePicker.content, stylePickerView]}>
        <Text style={[labelStyle]}>{this.state.label}</Text>
        <Item>
          <Picker
            style={[Style.Main.pickerDropdownAndroid, Style.Main.fontAlbert, Style.Main.font14, Style.Main.textAlmostBlack,
              enabled ? null : Style.Main.textDisabled,
            ]}
            itemTextStyle={[Style.Main.fontAlbert, Style.Main.textAlmostBlack, Style.Main.font14]}
            itemStyle={[Style.Main.fontAlbert, Style.Main.font14]}
            textStyle={[Style.Main.fontAlbert, Style.Main.font14]}
            iosIcon={<Icons name={iosIcon} />}
            mode={mode}
            selectedValue={selectedValue}
            onValueChange={e => this.dropdownValidation(e)}
            enabled={enabled}
            placeholder={placeholder}
            placeholderStyle={[Style.Main.fontAlbert]}
          >
            {<Picker.Item label={placeholder} value="" />}
            {dropdown}
          </Picker>
        </Item>
        {errorMessage !== '' && (
          <Text
            style={[
              StylePicker.styleBottomLabel,
              Style.Main.fontAlbert,
              errorLabelStyle,
            ]}
          >
            {_(errorMessage)}
          </Text>
        )}
        {bottomLabel.length !== 0 &&
          bottomLabel.map(element => (
            <Text
              key={element.toString()}
              style={[
                StylePicker.styleBottomLabel,
                Style.Main.fontAlbert,
                bottomLabelStyle,
              ]}
            >
              {_(element)}
            </Text>
          ))}
      </View>
    );

    const iosPicker = (
      <View style={[StylePicker.content, stylePickerView]}>
        {label && (
          <Label
            numberOfLines={1}
            style={[
              StylePicker.styleTextLabel,
              Style.Main.fontAlbert,
              labelStyle,
            ]}
          >
            {_(label)}
          </Label>
        )}
        <Item style={[StylePicker.item, itemStyle]}>
          <Picker
            mode={mode}
            style={[
              selectedValue
                ? Style.Main.textAlmostBlack
                : StylePicker.placeholderColor,
              enabled ? null : Style.Main.textDisabled,
              Style.Main.fontAlbert,
              StylePicker.fieldStyle,
              stylePickerBody,
            ]}
            iosIcon={<Icons name={iosIcon} />}
            selectedValue={selectedValue}
            onValueChange={e => this.dropdownValidation(e)}
            enabled={enabled}
            placeholder={placeholder}
          >
            {dropdown}
          </Picker>
        </Item>
        {errorMessage !== '' && (
          <Text
            style={[
              StylePicker.styleBottomLabel,
              Style.Main.fontAlbert,
              errorLabelStyle,
            ]}
          >
            {_(errorMessage)}
          </Text>
        )}
        {bottomLabel.length !== 0 &&
          bottomLabel.map(element => (
            <Text
              key={element.toString()}
              style={[
                StylePicker.styleBottomLabel,
                Style.Main.fontAlbert,
                bottomLabelStyle,
              ]}
            >
              {_(element)}
            </Text>
          ))}
      </View>
    );

    return <View>{Platform.OS === 'ios' ? iosPicker : androidPicker}</View>;
  }
}

PickerDropdownOld.propTypes = {
  enabled: PropTypes.bool,
  placeholder: PropTypes.string,
  mode: PropTypes.string,
  iosIcon: PropTypes.string,
  selectedValue: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  dropdownData: PropTypes.arrayOf(PropTypes.object).isRequired,
  stylePickerBody: PropTypes.oneOfType([
    PropTypes.object,
    PropTypes.arrayOf(PropTypes.object),
  ]),
  stylePickerView: PropTypes.oneOfType([
    PropTypes.object,
    PropTypes.arrayOf(PropTypes.object),
  ]),
  labelStyle: PropTypes.oneOfType([
    PropTypes.object,
    PropTypes.arrayOf(PropTypes.object),
  ]),
  bottomLabelStyle: PropTypes.oneOfType([
    PropTypes.object,
    PropTypes.arrayOf(PropTypes.object),
  ]),
  errorLabelStyle: PropTypes.oneOfType([
    PropTypes.object,
    PropTypes.arrayOf(PropTypes.object),
  ]),
  labelProp: PropTypes.string,
  valueProp: PropTypes.string,
  isRequired: PropTypes.bool,
  errorMessage: PropTypes.string,
  bottomLabel: PropTypes.arrayOf(PropTypes.string),
  label: PropTypes.string,
  onValueChange: PropTypes.func,
  textColor: PropTypes.string,

  // add
  itemStyle: PropTypes.oneOfType([
    PropTypes.object,
    PropTypes.arrayOf(PropTypes.object),
  ]),
};

PickerDropdownOld.defaultProps = {
  enabled: true,
  placeholder: '',
  mode: 'dropdown',
  iosIcon: 'caret-down',
  selectedValue: null,
  stylePickerBody: null,
  stylePickerView: null,
  labelStyle: null,
  bottomLabelStyle: Style.Main.textRed,
  errorLabelStyle: Style.Main.textRed,
  labelProp: 'label',
  valueProp: 'value',
  isRequired: true,
  errorMessage: '',
  bottomLabel: [],
  label: null,
  onValueChange: () => {},
  textColor: Style.Color.gray,

  // add
  itemStyle: null,
};

export default PickerDropdownOld;
