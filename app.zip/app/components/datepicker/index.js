/**
 * @author: ahmdichsanb@gmail.com
*/

import React, { Component, Fragment } from 'react';
import {
  Platform,
} from 'react-native';
import PropTypes from 'prop-types';

import AndroidDatePicker from './datePicker.android';
import IosDatePicker from './datePicker.ios';

class DatePicker extends Component {
  render() {
    const {
      component, onDateChange, isDatePickerOpen, dateValue,
      maximumDate, minimumDate, modeIos, modeAndroid, onPress,
    } = this.props;
    return (
      <Fragment>
        {
          Platform.OS === 'ios' ? (
            <IosDatePicker
              component={component}
              isDatePickerOpen={isDatePickerOpen}
              onDateChange={e => onDateChange(e)}
              dateValue={dateValue}
              maximumDate={maximumDate}
              minimumDate={minimumDate}
              mode={modeIos}
              onPress={() => onPress()}
            />
          ) : (
            <AndroidDatePicker
              component={component}
              isDatePickerOpen={isDatePickerOpen}
              onDateChange={e => onDateChange(e)}
              dateValue={dateValue}
              maximumDate={maximumDate}
              minimumDate={minimumDate}
              mode={modeAndroid}
            />
          )
        }
      </Fragment>
    );
  }
}

DatePicker.propTypes = {
  component: PropTypes.element.isRequired,
  onDateChange: PropTypes.func.isRequired,
  isDatePickerOpen: PropTypes.bool.isRequired,
  dateValue: PropTypes.instanceOf(Date),
  maximumDate: PropTypes.instanceOf(Date),
  minimumDate: PropTypes.instanceOf(Date),
  modeIos: PropTypes.string.isRequired,
  modeAndroid: PropTypes.string.isRequired,
  onPress: PropTypes.func.isRequired, // past setState function to close the modal when user on IOS click on the transparent area of the modal
};

DatePicker.defaultProps = {
  maximumDate: new Date(4000, 12, 29),
  minimumDate: new Date(1000, 12, 29),
  dateValue: new Date(),
};

export default DatePicker;
