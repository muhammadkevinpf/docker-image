import {
  call, put, takeLatest,
} from 'redux-saga/effects';
import { resourceRequest } from '../../utilities/StoreApi';
import { sagaWatcherErrorHandling } from '../../utilities/ErrorHandling';
import {
  ConfigAOB,
} from './config';
import {
  listCandidateSuccess,
  listCandidateFailed,
} from './ActionRecruitment';

const {
  LISTCANDIDATEAPI,
  LISTCANDIDATEFETCH,
} = ConfigAOB;

function* workerSagaListCandidate(params) {
  try {
    const response = yield call(resourceRequest, LISTCANDIDATEAPI, 'post', params.send);
    console.log('response candidate: ', response); // eslint-disable-line no-console

    if (response.status === '200' || response.status === 200) {
      yield put.resolve(listCandidateSuccess(response.data));
    } else {
      yield put.resolve(listCandidateFailed(response.data.errorMessage));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(listCandidateFailed(parseError));
  }
}

export const watcherCandidate = [
  takeLatest(LISTCANDIDATEFETCH, workerSagaListCandidate),
];
