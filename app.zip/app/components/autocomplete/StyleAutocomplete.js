/**
 * @author: ahmdichsanb@gmail.com
*/

import { StyleSheet } from 'react-native';
import Styles from '../../styles';

const Style = StyleSheet.create({
  suggestionList: {
    padding: 6,
    fontSize: 12,
  },
  flatList: {
    maxHeight: 170,
    borderWidth: 1,
    elevation: 1,
    borderColor: Styles.Color.efefef,
  },
  styleTextInput: {
    borderBottomColor: Styles.Color.gray,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
});

export default Style;
