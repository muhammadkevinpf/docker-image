import React, { Component } from 'react';
import WebView from 'react-native-webview';
import { ScrollView } from 'react-native-gesture-handler';
import { ActivityIndicator, Image } from 'react-native';
import { connect } from 'react-redux';
import { View, Text } from 'native-base';
import { newsListFetch, newsListFailed } from '../../news-and-update/ActionNews';
import { requestStatus, isStringEmpty, isArrayEmpty } from '../../../utilities';
import {
  firstBannerFetch, secondBannerFetch, thirdBannerFetch, storeNewsBanner, resetStatus,
} from '../ActionDashboard';
import { FIRST_BANNER_FETCH, SECOND_BANNER_FETCH, THIRD_BANNER_FETCH } from '../ConfigDashboard';
import CarouselCard from '../../../components/carousel-card';
import emptyNews from '../../../assets/images/empty-news.png';
import Style from '../../../styles';
import _ from '../../../lang';

const defaultWidth = 220;

class NewsBanner extends Component {
  bannerHeight = this.props.width ? this.props.width * 1.5 : 330;

  width = !this.props.width ? defaultWidth : this.props.width;

  carouselWidth = { width: this.width };

  carouselHeight = Math.round(this.width / 2); // Set Image Banner 2:1

  fullImageStyle = {
    container: [Style.Main.cardShadow, Style.Main.mr12, this.carouselWidth, Style.Main.mb20, { height: this.bannerHeight }, Style.Main.ml4],
    img: [Style.Main.cardShadow, Style.Main.radius8, this.carouselWidth],
  };

  style = {
    container: [
      Style.Main.cardShadow, Style.Main.mr12, this.carouselWidth, Style.Main.ml4,
      Style.Main.mb20, Style.Main.backgroundWhite, { height: this.bannerHeight }, Style.Main.justifySpaceBetween,
    ],
    img: [Style.Main.topBorderRadius8, { height: this.carouselHeight }, Style.Main.fullWidth],
    title: [Style.Main.fontAlbert14, Style.Main.textColor3f3, Style.Main.pr12, Style.Main.pl12],
    button: [Style.Main.textRed, Style.Main.textAlignCenter, Style.Main.font12, Style.Main.mt5],
  };

  componentDidMount() {
    // if (isDataOutdated(this.props.lastFetch)) this.findNews();
    this.findNews();
  }

  componentDidUpdate = async (prevProps) => {
    if (prevProps.apiStatus !== this.props.apiStatus && this.props.apiStatus === requestStatus.SUCCESS) {
      if (!isArrayEmpty(this.props.newsList)) {
        if (!isArrayEmpty(this.props.newsStore)) {
          if (this.props.newsStore.some(x => this.props.newsList.filter((p, i) => i < 3).some(y => x.id !== y.id))) {
            this.props.resetStatus();
            this.props.storeNews(this.props.newsList.filter((x, i) => i < 3));
            this.getAllImage(this.props.newsList);
          } else if (isStringEmpty(this.props.firstBanner) || isStringEmpty(this.props.secondBanner) || isStringEmpty(this.props.thirdBanner)) {
            this.getAllImage(this.props.newsStore);
          }
        } else {
          this.props.storeNews(this.props.newsList.filter((x, i) => i < 3));
          this.getAllImage(this.props.newsList);
        }
      } else if (isArrayEmpty(this.props.newsList) && isArrayEmpty(this.props.newsStore)) {
        this.props.resetStatus();
        this.props.storeNews([]);
      }
    }
    if (this.props.resAuth && this.props.resAuth.userProfile
      // && isDataOutdated(this.props.lastFetch) && isArrayEmpty(this.props.newsStore)
      && (this.props.resAuth.userProfile !== prevProps.resAuth.userProfile || (this.props.isOnline !== prevProps.isOnline && this.props.isOnline))) {
      this.findNews();
      if (isStringEmpty(this.props.firstBanner) || isStringEmpty(this.props.secondBanner) || isStringEmpty(this.props.thirdBanner)) {
        if (!isArrayEmpty(this.props.newsList)) this.getAllImage(this.props.newsList);
        else { this.getAllImage(this.props.newsStore); }
      }
    }
  }

  findNews = () => {
    const { resAuth } = this.props;
    if (resAuth && resAuth.userProfile && resAuth.userProfile.agentCode && this.props.isOnline) {
      const data = {
        headers: [
          {
            keyHeader: 'X-CSRF-Token',
            valueHeader: `Bearer ${this.props.resAuth.access_token}`,
          },
        ],
        params: `[1, 3, "${resAuth.username}", "${resAuth.userProfile.agentCode}", "", "", "", "${resAuth.userProfile.agentType}"]`,
      };
      this.props.fetchNewsList(data);
    } else {
      this.props.stateFailed('Something is wwong');
    }
  }

  getImageList = (source = '', action) => {
    const list = source.split(':');
    const img = list[0].split('|');
    this.fetchBase64Image(img[1], action);
  }

  getAllImage = (source) => {
    if (source && source.length) {
      if (source[0] && !isStringEmpty(source[0].image_name)) this.getImageList(source[0].image_name, this.props.fetchFirstBanner);
      if (source[1] && !isStringEmpty(source[1].image_name)) this.getImageList(source[1].image_name, this.props.fetchSecondBanner);
      if (source[2] && !isStringEmpty(source[2].image_name)) this.getImageList(source[2].image_name, this.props.fetchThirdBanner);
    }
  }

  fetchBase64Image = (id, action) => {
    if (this.props.resAuth && this.props.resAuth.userProfile) {
      const data = {
        headers: [
          {
            keyHeader: 'X-CSRF-Token',
            valueHeader: `Bearer ${this.props.resAuth.access_token}`,
          },
        ],
        params: `["${id}", "newsUpdate"]`,
      };
      action(data);
    }
  }

  renderContent = (data) => {
    // if (isTablet()) return <View />;
    if (!isStringEmpty(data.description)) {
      return (
        <WebView
          style={[Style.Main.container]}
          scalesPageToFit={false}
          source={{
            html:
              `<style type="text/css">
                @font-face {
                  font-family: FSAlbert;
                  font-size: 12;
                  src: url(file:///android_asset/fonts/FSAlbertPro.otf);
                }
                .container {
                  overflow: hidden;
                  font-family: FSAlbert;
                  flex: 1;
                  display: flex;
                  flex-direction: column;
                  font-size: 12;
                  color: gray;
                  justify-content: flex-start;
                  align-content: flex-start;
                }
              </style>
              <meta name="viewport" content="width=device-width, initial-scale=1">
              <div class="container">
                ${data.description}
              </div>`,
          }}
        />
      );
    }
    return <View style={[Style.Main.displayNone]} />;
  }

  renderFailedData = type => (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} showsVerticalScrollIndicator={false}>
      {
        [{}, {}, {}].map((item, index) => (
          <CarouselCard
            key={index.toString()}
            containerStyle={this.style.container}
            content={(
              <View style={[Style.Main.alignCenter, Style.Main.fullHeight, Style.Main.justifyCenter]}>
                <Image source={emptyNews} style={[Style.Main.height65, Style.Main.alignCenter]} resizeMode="contain" />
                <Text style={[Style.Main.fontAlbert11, Style.Main.alignCenter, Style.Main.mt15]}>{
                  type === requestStatus.SUCCESS ? _('Data tidak tersedia') : _('Gagal Mengambil Data')}
                </Text>
              </View>
            )}
          />
        ))
      }
    </ScrollView>
  )

  renderOnLoading = () => (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} showsVerticalScrollIndicator={false}>
      {
        [{}, {}, {}].map((item, index) => (
          <CarouselCard
            key={index.toString()}
            containerStyle={this.style.container}
            content={(
              <View style={[Style.Main.alignCenter, Style.Main.justifyCenter, Style.Main.fullHeight]}>
                <View style={[Style.Main.height65, Style.Main.center]}>
                  <ActivityIndicator color="red" size="large" />
                </View>
                <Text style={[Style.Main.fontAlbert11, Style.Main.alignCenter, Style.Main.mt15]}>{_('Sedang Mengambil Data ...')}</Text>
              </View>
            )}
          />
        ))
      }
    </ScrollView>
  )

  renderImageSource = (index) => {
    if (Number(index) === 0) return this.props.firstBanner || '';
    if (Number(index) === 1) return this.props.secondBanner || '';
    return this.props.thirdBanner || '';
  }

  renderOnLoadingImg = (index) => {
    if ((Number(index) === 0 && this.props.firstBannerStatus === requestStatus.FETCH && isStringEmpty(this.props.firstBanner))
      || (Number(index) === 1 && this.props.secondBannerStatus === requestStatus.FETCH && isStringEmpty(this.props.secondBanner))
      || (Number(index) === 2 && this.props.thirdBannerStatus === requestStatus.FETCH && isStringEmpty(this.props.thirdBanner))) {
      return (
        <View style={[Style.Main.alignContentCenter, Style.Main.justifyCenter, { height: this.carouselHeight }]}>
          <ActivityIndicator color="red" size="large" style={[Style.Main.alignCenter]} />
        </View>
      );
    }
    return null;
  }

  renderSuccessData = data => (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} showsVerticalScrollIndicator={false}>
      {
        data && data.map((item, index) => {
          if (index < 3) {
            const isDescExist = !isStringEmpty(item.description);
            return (
              <CarouselCard
                key={index.toString()}
                contentStyle={Style.Main.container}
                containerStyle={!isDescExist ? this.fullImageStyle.container : this.style.container}
                imageStyle={!isDescExist ? this.fullImageStyle.img : this.style.img}
                imageSource={this.renderImageSource(index) === '' ? '' : { uri: `data:image/jpeg;base64,${this.renderImageSource(index)}` }}
                upperContent={this.renderOnLoadingImg(index)}
                title={isDescExist && item.title}
                titleStyle={isDescExist && this.style.title}
                buttonText={isDescExist && _('Info Lanjut')}
                buttonStyle={isDescExist && this.style.button}
                content={isDescExist && this.renderContent(item)}
                onPress={() => this.props.navigation.replace('NewsDetail', { id: item.id })}
              />
            );
          }
          return <View key={index.toString()} style={[Style.Main.displayNone]} />;
        })
      }
    </ScrollView>
  )

  render() {
    if (isArrayEmpty(this.props.newsStore)) {
      if (this.props.apiStatus === requestStatus.SUCCESS && !isArrayEmpty(this.props.newsList)) return this.renderSuccessData(this.props.newsList);
      if (this.props.apiStatus !== requestStatus.FETCH) return this.renderFailedData(this.props.apiStatus);
      return this.renderOnLoading();
    }
    return this.renderSuccessData(this.props.newsStore);
  }
}

const mapStateToProps = state => ({
  resAuth: state.auth.res,
  news: state.news,
  newsList: state.news.newsList,
  apiStatus: state.news.newsListStatus,
  firstBanner: state.dashboard.firstBanner,
  secondBanner: state.dashboard.secondBanner,
  thirdBanner: state.dashboard.thirdBanner,
  firstBannerStatus: state.dashboard.firstBannerStatus,
  secondBannerStatus: state.dashboard.secondBannerStatus,
  thirdBannerStatus: state.dashboard.thirdBannerStatus,
  newsStore: state.dashboard.newsBanner,
  isOnline: state.connectionStatus.isOnline,
  lastFetch: state.dashboard.lastFetchNews,
});

const mapDispatchToProps = dispatch => ({
  storeNews: value => dispatch(storeNewsBanner(value)),
  stateFailed: value => dispatch(newsListFailed(value)),
  fetchNewsList: value => dispatch(newsListFetch(value)),
  fetchFirstBanner: value => dispatch(firstBannerFetch(FIRST_BANNER_FETCH, value)),
  fetchSecondBanner: value => dispatch(secondBannerFetch(SECOND_BANNER_FETCH, value)),
  fetchThirdBanner: value => dispatch(thirdBannerFetch(THIRD_BANNER_FETCH, value)),
  resetStatus: () => dispatch(resetStatus()),
});

export default connect(mapStateToProps, mapDispatchToProps)(NewsBanner);
