/* eslint-disable react-native/no-color-literals */
/* eslint-disable react-native/no-inline-styles */
import React, { Component } from 'react';
import { BackHandler } from 'react-native';
import { View } from 'native-base';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { Row, Col } from 'react-native-easy-grid';
import { connect } from 'react-redux';
import moment from 'moment';
import Icon from 'react-native-vector-icons/FontAwesome';
import { CustomFlatList, StyledText, ContainerNonProduct } from '../../../components';
import { listNotificationFetch, updateNotificationFetch } from '../ActionNotification';
import {
  LISTNOTIFICATIONSUCCESS, TOTALNOTIFICATIONSUCCESS, UPDATENOTIFICATIONSUCCESS, LISTNOTIFICATIONFETCH,
} from '../ConfigNotification';
import { EmptyNotification } from '../../../assets/images';
import { isArrayEmpty } from '../../../utilities';
import Style from '../../../styles';
import _ from '../../../lang';

const availableNotif = ['INFO'];

class MainNotification extends Component {
  constructor(props) {
    super(props);
    this.state = {
      listNotification: [],
      page: 1,
      pageSize: 25,
      filterBy: 'All',
      showSpinner: false,
      totalNotification: 0,
      isRefresh: false,
    };

    this.handleLoadData = this.handleLoadData.bind(this);
    this.handleRefresh = this.handleRefresh.bind(this);
    this.handleDetailNotification = this.handleDetailNotification.bind(this);
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.action === LISTNOTIFICATIONSUCCESS) {
      return {
        ...prevState,
        listNotification: nextProps.resNotification.listNotification.filter(x => availableNotif.includes(x.payload.reqId)),
        page: prevState.page + 1,
        isRefresh: false,
        showSpinner: false,
        action: nextProps.action,
      };
    }
    if (nextProps.action === TOTALNOTIFICATIONSUCCESS) {
      return {
        ...prevState,
        totalNotification: nextProps.resNotification.totalNotification,
        action: nextProps.action,
      };
    }
    if (nextProps.action === UPDATENOTIFICATIONSUCCESS) {
      const updateList = prevState.listNotification.map((x) => {
        if (x.id === nextProps.resNotification.updateNotification.id) {
          // eslint-disable-next-line no-param-reassign
          x.opened = true;
        }
        return x;
      });
      return {
        ...prevState,
        listNotification: updateList,
        action: nextProps.action,
      };
    }
    return null;
  }

  componentDidMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleBack();
      return true;
    });

    if (this.props.resAuth && this.props.resAuth.userProfile && this.props.isOnline) this.getListNotification();
  }

  componentDidUpdate = (prevProps) => {
    if (this.props.isOnline !== prevProps.isOnline && this.props.isOnline) this.getListNotification();
  }

  handleLoadData = () => {
    this.setState({ showSpinner: true });
    this.getListNotification();
  }

  handleRefresh = () => {
    this.setState({ page: 1, isRefresh: true });
    this.getListNotification(true);
  }

  handleDetailNotification = (item) => {
    if (!item.opened) {
      const data = {
        headers: [
          {
            keyHeader: 'X-CSRF-Token',
            valueHeader: `Bearer ${this.props.resAuth.access_token}`,
          },
        ],
        params: `["${item.id}"]`,
      };
      this.props.dispatchUpdateNotification(data);
    }
  }

  handleBack = () => {
    this.props.navigation.replace(this.props.navigation.getParam('route'), {
      ...this.props.navigation.getParam('param', {}),
    });
    this.backHandler.remove();
  }

  getListNotification = (isRefresh = false) => {
    const data = {
      headers: [
        {
          keyHeader: 'X-CSRF-Token',
          valueHeader: `Bearer ${this.props.resAuth.access_token}`,
        },
      ],
      params: `["${this.props.resAuth.userProfile.agentCode}", "${this.state.filterBy}", ${this.state.pageSize}, ${this.state.page}]`,
      isRefresh,
    };
    this.props.dispatchListNotification(data);
  }

  getIcon = (id) => {
    let icon;
    switch (id.toUpperCase()) {
      case 'SIGN':
        icon = 'paperclip';
        break;
      case 'DOC':
      case 'CHANGEMANAGER':
      case 'CHANGERECRUITER':
      case 'DOC_AG':
      case 'MFC_CHECKLIST_CANDIDATE':
      case 'MFC_CHECKLIST_RECRUITER':
        icon = 'icon-notif_icons-font_document';
        break;
      case 'FS':
        icon = 'clock-o';
        break;
      case 'AAJI':
      case 'AAJI_FAIL':
      case 'MFC_FAIL':
        icon = 'calendar';
        break;
      case 'AG_DONE':
      case 'INFO':
        icon = 'bookmark';
        break;
      /* this start of batch notification */
      case 'NEWS_UPDATE':
        icon = 'wifi';
        break;
      case 'PENDING_PROSES_PROPOSAL':
      case 'PENDING_PROSES_KLAIM':
        icon = 'newspaper-o';
        break;
      case 'PENDING_PROSES_BILLING':
      case 'PENDING_PROSES_PERUBAHAN_POLIS':
      case 'POLIS_LEWAT_JATUH_TEMPO':
        icon = 'book';
        break;
      case 'BIRTH_DAY':
        icon = 'birthday-cake';
        break;
      case 'CONTEST_DETAIL':
      case 'CONTEST_ACHIEVED':
      case 'CONTEST_NOT_ACHIEVED':
      case 'UPLOAD_PRUACHIEVER':
        icon = 'trophy';
        break;
      case 'SCHEDULE_CHANGES':
      case 'SCHEDULE_CANCELLED':
      case 'SCHEDULE_REMINDER':
        icon = 'graduation-cap';
        break;
      default:
        icon = 'question';
        break;
    }
    return <Icon name={icon} style={[Style.Main.textRed, Style.Main.font20, Style.Main.alignCenter]} />;
  }

  render() {
    return (
      <ContainerNonProduct
        navigation={this.props.navigation}
        onBackClicked={this.handleBack}
        headerTitle="NOTIFIKASI"
        headerColor={Style.Color.white}
      >
        <CustomFlatList
          hideTopBar
          callEndReached
          emptyImage={EmptyNotification}
          contentContainerStyle={[Style.Main.mt0]}
          itemComponentStyle={[Style.Main.ml0, Style.Main.mr0]}
          showLoadingEmpty={(this.props.action === LISTNOTIFICATIONFETCH || this.props.isFetchingList) && !this.state.isRefresh}
          showLoadingFooter={this.props.action === LISTNOTIFICATIONFETCH && !isArrayEmpty(this.state.listNotification) && !this.state.isRefresh}
          listData={this.state.listNotification}
          itemComponent={({ item, index }) => (
            <View key={index} style={[!item.opened && { backgroundColor: '#FFF3F4' }]}>
              <TouchableOpacity
                activeOpacity={0.7}
                onPress={() => this.handleDetailNotification(item)}
                style={[Style.Main.margin15, Style.Main.mb0, Style.Main.pb15, Style.Main.borderBottomGray, Style.Main.borderBottomWidth1]}
              >
                <Row style={{ opacity: 2 }}>
                  <Col size={84}>
                    <StyledText bold={!item.opened} style={[Style.Main.mb3, { opacity: 1 }]}>{_(`${item.module_name}`)}</StyledText>
                    <StyledText bold={!item.opened} font={10} style={[Style.Main.mb3]}>{item.alert}</StyledText>
                    <StyledText bold={!item.opened} font={10} color={Style.Color.gray88}>
                      {moment(item.time_stamp).format('D MMMM YYYY HH:mm')}
                    </StyledText>
                  </Col>
                  {item.payload.reqId !== 'INFO' && (
                    <Col size={8} style={[Style.Main.justifyCenter, Style.Main.alignCenter]}>
                      <Icon
                        name="angle-right"
                        style={[Style.Main.textGray, Style.Main.font14, Style.Main.alignCenter]}
                      />
                    </Col>
                  )}
                </Row>
              </TouchableOpacity>
            </View>
          )}
          pageSize={this.state.pageSize}
          handleLoadData={this.handleLoadData}
          onRefresh={this.handleRefresh}
          refreshing={this.state.isRefresh}
        />
      </ContainerNonProduct>
    );
  }
}

const mapStateToProps = state => ({
  action: state.notification.action,
  resNotification: state.notification.res,
  isFetchingList: state.notification.fetchListNotification,
  resAuth: state.auth.res,
  isOnline: state.connectionStatus.isOnline,
});

const mapDispatchToProps = dispatch => ({
  dispatchListNotification: value => dispatch(listNotificationFetch(value)),
  dispatchUpdateNotification: value => dispatch(updateNotificationFetch(value)),
});

export default connect(mapStateToProps, mapDispatchToProps)(MainNotification);
