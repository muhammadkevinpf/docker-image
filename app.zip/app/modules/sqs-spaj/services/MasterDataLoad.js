import SQLite from 'react-native-sqlite-storage';
// import Analytics from 'appcenter-analytics';
import { Platform } from 'react-native';
import Database from '../../../config/Database';
import SQLiteUtils from '../../../utilities/SQLiteUtils';
import Caches from '../../../utilities/Caches';

const noDataJson = [
  'formula',
  // 'formulaPAA',
  'newSqsRate',
  'rule',
  // 'rulePAA',
  'zipCode',
  // 'magnum',
  'publish', 'reffMaster'];
// const noDataJsonBaSqs = ['formula', 'newSqsRate', 'rule', 'zipCode', 'publish'];

const serviceName = 'MasterDataLoad';

const start = (finish) => {
  global.database = {};
  let config = {
    name: Database.newSqs.name,
    createFromLocation: `/${Database.newSqs.name}`,
    location: 'Documents',
    readOnly: true,
  };
  if (Platform.OS === 'ios') {
    config = {
      name: Database.newSqs.name,
      createFromLocation: `/${Database.newSqs.name}`,
      location: 'Documents',
    };
  }
  SQLite.openDatabase(config,
    (ok) => {
      global.database.newSqs = ok;
      init().then(() => {
        finish();
        global.database.isLoaded = true;
        console.log('Database: ', global.database);
        console.log('Caches: ', Caches.dumpCache());
        SQLiteUtils.closeDatabase(ok);
      }); // eslint-disable-line no-console
    }, (error) => {
      // Analytics.trackEvent(serviceName, error);
    console.log(error); // eslint-disable-line
    });
};

const openAllDB = () => new Promise(async (resolve, reject) => {
  let errorMessage = '';
  const dbs = Object.keys(Database);
  for (let i = 0; i < dbs.length; i += 1) {
    const x = dbs[i];
    try {
      if (!(x.includes('newSqs'))) {
        // eslint-disable-next-line no-await-in-loop
        global.database[x] = await SQLiteUtils.openDatabase(Database[x].name, 'default');
      }
    } catch (error) {
      // Analytics.trackEvent(serviceName, error);
      errorMessage += error.message;
    }
  }
  if (errorMessage === '') {
    resolve('Open DB Success');
  } else {
    reject(new Error(`${serviceName} ${errorMessage}`));
  }
});

const getAllMasterDataWithDataJson = () => new Promise(async (resolve, reject) => {
  const errorMessage = '';
  const localDB = Database.newSqs;
  const tables = Object.keys(localDB.tables);
  for (let i = 0; i < tables.length; i += 1) {
    const x = tables[i];
    try {
      if (!noDataJson.includes(x)) {
        // eslint-disable-next-line no-await-in-loop
        const result = await SQLiteUtils.executeAdvanceQuery(global.database.newSqs, Database.newSqs.tables[x], 'data_json');
        // global.database[x] = JSON.parse(result);
        Caches.set(x, JSON.parse(result));
      }
    } catch (error) {
      // Analytics.trackEvent(serviceName, error);
      console.log({ table: Database.newSqs.tables[x], code: error.code, message: error.message });
    }
  }
  if (errorMessage.length < 1) {
    resolve('Get All Master Data With Data Json Success');
  } else {
    reject(new Error(`${serviceName} ${errorMessage}`));
  }
});

const getAllMasterDataNoDataJson = () => new Promise(async (resolve, reject) => {
  const errorMessage = '';
  const noDataJsonTable = noDataJson;
  for (let i = 0; i < noDataJsonTable.length; i += 1) {
    const x = noDataJsonTable[i];
    try {
      if (x !== 'newSqsRate') {
        let data = [];
        // eslint-disable-next-line no-await-in-loop
        const res = await SQLiteUtils.executeQuery(global.database.newSqs, `SELECT * FROM ${Database.newSqs.tables[x]}`, []);
        for (let j = 0; j < res.rows.length; j += 1) {
          if (x === 'formula' || x === 'formulaPAA') {
            data = [...data, JSON.parse(res.rows.item(j).string_formula)];
          } else if (x === 'rule' || x === 'rulePAA') {
            data = [...data, JSON.parse(res.rows.item(j).string_rule)];
          } else {
            data = [...data, res.rows.item(j)];
          }
        }
        // global.database[x] = data;
        Caches.set(x, data);
      }
    } catch (error) {
      // Analytics.trackEvent(serviceName, error);
      console.log(error);
    }
  }
  if (errorMessage === '') {
    resolve('Get All Master Data No Data Json Success');
  } else {
    reject(new Error(`${serviceName} ${errorMessage}`));
  }
});

const createAllTable = () => new Promise(async (resolve, reject) => {
  const errorMessage = '';
  try {
    const dbs = Object.keys(Database);
    for (let i = 0; i < dbs.length; i += 1) {
      const db = dbs[i];
      if (!(db.includes('newSqs'))) {
        const tables = Object.keys(Database[db].tables);
        for (let j = 0; j < tables.length; j += 1) {
          const table = Database[db].tables[tables[j]];
          let query = '';
          if (table.column) {
            query = `CREATE TABLE IF NOT EXISTS ${table.name || table} ${table.column}`;
          } else {
            // eslint-disable-next-line max-len
            query = `CREATE TABLE IF NOT EXISTS ${table.name || table} (agentCode, method, ${['paymentCredential', 'bootstrapMagnum'].includes(tables[j]) ? 'proposal' : tables[j]}Code, data, createDate)`;
          }
          // eslint-disable-next-line no-await-in-loop
          SQLiteUtils.executeTransaction(
            global.database[db],
            query,
            [],
          );
        }
      }
    }
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    console.log(error);
  }
  if (errorMessage === '') {
    resolve('Create Table Success');
  } else {
    reject(new Error(`${serviceName} ${errorMessage}`));
  }
});

const init = () => new Promise(async (resolve, reject) => {
  try {
    const a = await openAllDB();
    const b = await createAllTable();
    const c = await getAllMasterDataWithDataJson();
    const d = await getAllMasterDataNoDataJson();
    resolve(`${a} | ${b} | ${c} | ${d}`);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(error);
  }
});

// eslint-disable-next-line no-unused-vars
function distinctArray(array) {
  const obj = {};
  // eslint-disable-next-line no-return-assign
  array.forEach(o => obj[JSON.stringify(o)] = o);
  return Object.keys(obj).map(k => obj[k]);
}

export default { start };
