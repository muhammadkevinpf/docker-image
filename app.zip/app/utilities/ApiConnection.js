/* eslint-disable no-console */
import { WLClient } from 'react-native-ibm-mobilefirst';
import { call, put, takeLatest } from 'redux-saga/effects';
import { resourceRequest } from './StoreApi';
import { sagaWatcherErrorHandling } from './ErrorHandling';
import { defaultAction } from './Functions';

export const getConnectionStatus = SERVER_URL => new Promise(async (resolve, reject) => {
  try {
    if (!SERVER_URL) {
      // eslint-disable-next-line no-param-reassign
      SERVER_URL = await WLClient.getServerUrl();
      let index = SERVER_URL.lastIndexOf('pruforce');
      if (SERVER_URL.includes('https')) index = (SERVER_URL.lastIndexOf('api') - 1);
      // eslint-disable-next-line no-param-reassign
      SERVER_URL = SERVER_URL.substring(0, index);
    }
    const response = await fetch(SERVER_URL);
    // console.log(response);
    if (response.status === 200) {
      resolve(true);
    } else {
      resolve(false);
    }
  } catch (error) {
    reject(error);
  }
});

export const requestStatus = {
  IDLE: 'IDLE',
  FETCH: 'FETCH',
  SUCCESS: 'SUCCESS',
  FAILED: 'FAILED',
};

export const apiWithTokenAction = (type, params, token) => ({
  type,
  payload: {
    headers: [
      {
        keyHeader: 'X-CSRF-Token',
        valueHeader: `Bearer ${token}`,
      },
    ],
    params,
  },
});

export const apiMethod = {
  post: 'post',
  get: 'get',
  update: 'update',
  delete: 'delete',
};

export function* apiSaga(data, actionType, {
  isResponArray, resAttribute, timeout = 5000, method = apiMethod.post, errAttribute,
} = {}) {
  try {
    console.log(`PARAMS ${actionType.API}: `, {
      data, actionType, isResponArray, resAttribute, timeout, method, errAttribute,
    });
    const res = yield call(resourceRequest, actionType.API, method, data, timeout);
    console.log(`API ${actionType.API} RES: `, res);
    if (res.data && Number(res.status) === 200 && Number(res.data.statusCode) === 200) {
      if (isResponArray) {
        if (res.data.array && res.data.array.length) yield put.resolve(defaultAction(actionType.SUCCESS, res.data.array));
        else yield put.resolve(defaultAction(actionType.FAILED, errAttribute || res.data.errorMessage || res.data.error || res.data.statusReason));
      } else yield put.resolve(defaultAction(actionType.SUCCESS, resAttribute ? res.data[resAttribute] : res.data));
    } else {
      yield put.resolve(defaultAction(actionType.FAILED, errAttribute || res.data.statusReason || 'Unknown Error'));
    }
  } catch (error) {
    console.log(`API ${actionType.API} ERROR: `, error);
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(defaultAction(actionType.FAILED, parseError));
  }
}

export const apiTakeLatest = (actionType, {
  isResponArray, resAttribute, timeout, method, errAttribute,
} = {}) => takeLatest(actionType.FETCH, params => apiSaga(params.payload, actionType, {
  isResponArray, resAttribute, timeout, method, errAttribute,
}));

export const API_ACTION_TYPES = (action, apiPath) => ({
  API: apiPath,
  FETCH: `${action}_FETCH`,
  SUCCESS: `${action}_SUCCESS`,
  FAILED: `${action}_FAILED`,
  RESET: `${action}_RESET`,
});

export const isFetching = status => status === requestStatus.FETCH;
export const isFailed = status => status === requestStatus.FAILED;
export const isSuccess = status => status === requestStatus.SUCCESS;
