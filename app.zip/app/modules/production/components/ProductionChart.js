import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Card, View } from 'native-base';
import {
  VictoryChart, VictoryScatter, VictoryAxis, VictoryLabel, VictoryArea,
} from 'victory-native';
import moment from 'moment';
import {
  toCurrency, toFixedCurrency, toStringTwoDigit, toTitleCase,
} from '../../../utilities/String';
import { isEmpty, isTablet, wp } from '../../../utilities';
import {
  rowLayout, Skeleton, SkeletonText, StyledText,
} from '../../../components';
import Colors from '../../../styles/Colors';
import Style from '../../../styles';
import _ from '../../../lang';

class ProductionChart extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [{ x: '', y: null }],
    };
  }

  componentDidMount = () => {
    this.renderGraphData();
  }

  componentDidUpdate = (prevProps) => {
    if (prevProps.graph !== this.props.graph) this.renderGraphData();
  }

  getApeNet = (month) => {
    let y = 0; let val = 0;
    if (!isEmpty(this.props.graph)) {
      const monthData = this.props.graph.find(x => Number(x.periodMonth) === Number(month)) || {};
      val = monthData.apeNet || 0;
      y = val / 1000000;
    }
    return { y, val };
  }

  renderGraphData = () => {
    const data = [];
    if (this.props.isLoading || isEmpty(this.props.graph)) {
      for (let i = 1; i <= 12; i += 1) {
        data.push({ x: toStringTwoDigit(i), y: 0, apeNet: 0 });
      }
    } else {
      for (let i = 1; i <= 12; i += 1) {
        const { y, val } = this.getApeNet(i);
        data.push({ x: toStringTwoDigit(i), y, apeNet: val });
      }
    }
    this.setState({ data });
  }

  renderGraph = () => {
    const { data } = this.state;
    const isAvailable = data.length > 1;
    const yArray = isAvailable ? data.map(item => item.y) : [];
    const max = isAvailable ? Math.max(...yArray) : 10;

    const height = isTablet() ? wp(180) : wp(130);
    let width = isTablet() ? wp(865) : wp(300);
    if (isTablet()) width -= this.props.sideBarWidth;
    return (
      <Card style={[Style.Main.container, Style.Main.center, Style.Main.mb5, Style.Main.backgroundWhiteSmoke,
        isTablet() && Style.Main.mr12]}
      >
        <VictoryChart
          width={width}
          padding={{
            top: 15, bottom: 25, left: max > 999 ? 30 : 20, right: 20,
          }}
          minDomain={{ y: 0 }}
          maxDomain={{ y: max > 0 ? max * 1.2 : 10 }}
          height={height}
        >
          <VictoryAxis
            dependentAxis
            style={{
              axis: { stroke: Colors.nativeBaseBorderGray },
              tickLabels: { ...Style.Main.setFontAlbert(8), fill: Colors.gray83, padding: 3 },
            }}
            tickFormat={t => `${toCurrency(t)}`}
            tickCount={5}
          />
          <VictoryAxis
            style={{
              axis: { stroke: Colors.nativeBaseBorderGray },
              tickLabels: { ...Style.Main.setFontAlbert(8), fill: Colors.gray83, padding: 3 },
            }}
            tickFormat={t => moment(t, 'MM').format('MMM')}
          />
          <VictoryArea
            data={data}
            interpolation="monotoneX"
            style={{
              data: { fill: Colors.red, fillOpacity: 0.5, stroke: 'none' },
              labels: { ...Style.Main.setFontAlbert(8) },
            }}
          />
          <VictoryScatter
            data={data}
            size={({ datum }) => (datum.apeNet ? 1 : 0)}
            labels={({ datum }) => (datum.apeNet ? toCurrency(datum.y) : '')}
            labelComponent={<VictoryLabel dx={max > 999 ? 12 : 8} dy={3} />}
            style={{
              data: { fill: Colors.red },
              labels: { ...Style.Main.setFontAlbert(7), fill: Colors.gray83 },
            }}
          />
        </VictoryChart>
      </Card>
    );
  }

  renderNote = () => (
    <SkeletonText isLoading={this.props.isLoading} width="75%" font={10} color={Colors.gray83} textStyle={[Style.Main.textLeft]}>
      {_('Menampilkan grafik dalam satuan jutaan selama tahun')} {new Date().getFullYear()}
    </SkeletonText>
  )

  renderLastThree = () => {
    const { data } = this.state;
    const { isLoading } = this.props;
    const isAvailable = data.length > 1;

    let thisMonth = new Date().getMonth() + 1;
    if (thisMonth < 3) thisMonth = 3;
    const lastThreeData = isAvailable ? data.slice(thisMonth - 3, thisMonth) : [];

    return (
      <View style={isTablet() ? null : [Style.Main.container, Style.Main.flexWrap, Style.Main.rowDirectionSpaceBetween]}>
        {
          lastThreeData.map((item, index) => {
            if ((item.apeNet && item.apeNet !== 0) || isLoading) {
              return (
                <View
                  key={index.toString()}
                  style={[Style.Main.padding2, Style.Main.pv10, isTablet() ? Style.Main.mV5 : Style.Main.mt10,
                    Style.Main.setBorder(), Style.Main.borderRadius5, Style.Main.setSize({ w: isTablet() ? wp(180) : '32%' })]}
                >
                  <Skeleton
                    isLoading={isLoading}
                    layout={[rowLayout({ w: '50%', h: 7, alignSelf: 'center' }), rowLayout({ w: '80%', h: 7, alignSelf: 'center' })]}
                  >
                    <View style={[Style.Main.center]}>
                      <StyledText font={10} color={Colors.gray83}>{moment(item.x, 'MM').format('MMMM')}</StyledText>
                      <StyledText font={10} bold>Rp. {toFixedCurrency(Number(item.apeNet), 2)}</StyledText>

                    </View>
                  </Skeleton>
                </View>
              );
            } return null;
          })
        }
      </View>
    );
  }

  render() {
    const { data } = this.state;
    const { isLoading, lastUpdate } = this.props;
    const isAvailable = data.length > 1;
    return (
      <Card style={[Style.Main.padding12, Style.Main.container]}>
        <View style={[Style.Main.container, Style.Main.rowDirection, Style.Main.mb10]}>
          <StyledText bold>{_('RIWAYAT')}</StyledText>
          <View style={[Style.Main.horizontalLine, Style.Main.ml10, Style.Main.fullWidth]} />
        </View>
        <View style={[Style.Main.container]}>
          <StyledText>{toTitleCase(_(this.props.label))}</StyledText>
          <Skeleton isLoading={isLoading} layout={[rowLayout({ w: '70%', h: 7 })]}>
            <StyledText font={10} color={Colors.gray83}>
              {lastUpdate ? `Data diperbarui pada ${moment(lastUpdate).format('LLLL')}` : _('Data belum diperbarui')}
            </StyledText>
          </Skeleton>
          <View style={[Style.Main.horizontalLine, Style.Main.fullWidth, Style.Main.mV10]} />
          {
            isAvailable &&
            <View style={[Style.Main.container]}>
              <View style={[Style.Main.container, isTablet() && [Style.Main.mb5, Style.Main.rowDirectionSpaceBetween]]}>
                {this.renderGraph()}
                {!isTablet() && this.renderNote()}
                {this.renderLastThree()}
              </View>
              {isTablet() && this.renderNote()}
            </View>
          }
          <StyledText bold color={Colors.red} style={[Style.Main.pt18, Style.Main.pl25, Style.Main.timeStyle]} onPress={this.props.onPress}>
            {_('Lihat Rincian')}
          </StyledText>
        </View>
      </Card>
    );
  }
}

const mapStateToProps = state => ({
  sideBarWidth: state.bootstrap.sideBarWidth,
});

export default connect(mapStateToProps, null)(ProductionChart);
