import ViewsNews from './views';

export default {
  NewsList: { screen: ViewsNews.NewsList },
  NewsDetail: { screen: ViewsNews.NewsDetail },
  CommonPdf: { screen: ViewsNews.CommonPdf },
};
