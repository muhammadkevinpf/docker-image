/* eslint-disable no-console */
/* eslint-disable no-plusplus */

import moment from 'moment';
import { areaCodes } from '../configs';

// CONFIGS

export const genders = {
  MALE: 'M',
  FEMALE: 'F',
};

export const religions = {
  ISLAM: 'A',
  KRISTEN: 'B',
  KATOLIK: 'C',
  HINDU: 'D',
  BUDHA: 'E',
};

export const maritalStatus = {
  MENIKAH: 'M',
  BELUM_MENIKAH: 'S',
  CERAI: 'W',
};

// FUNCTIONS

export const converrtToItsNumber = (input) => {
  if (!input || (input && !input.match(/^[0-9]+$/))) {
    let newData = input.substring(0, input.indexOf('\n') === -1 ? input.length : input.indexOf('\n'));
    newData = newData.replace(/NIK|NI|IK|:| /g, '');
    newData = newData.replace(/i|I|l/g, '1');
    newData = newData.replace(/z|e/ig, '2');
    newData = newData.replace(/A|H/g, '4');
    newData = newData.replace(/s/ig, '5');
    newData = newData.replace(/b|h|L/g, '6');
    newData = newData.replace(/r|P|\?/g, '7');
    newData = newData.replace(/B/g, '8');
    newData = newData.replace(/g/g, '9');
    newData = newData.replace(/o|O|D/g, '0');
    return newData;
  }
  return input;
};

export const getGender = (ocrData) => {
  let temp = '';
  let gender = null;
  if (ocrData && ocrData.length) {
    for (let i = 0; i < ocrData.length; i++) {
      temp = ocrData[i].text.replace(/ /g, '');
      if (temp.match(/laki|aki-a|l-lak|ki-ak|lak-lak|laklak/ig) !== null) {
        gender = genders.MALE; break;
      } else if (temp.match(/peremp|empuan/ig) !== null) {
        gender = genders.FEMALE; break;
      }
    }
  }
  return gender;
};

export const getReligion = (ocrData, pictureHeight) => {
  let religion = null;
  if (ocrData && ocrData.length) {
    for (let i = 0; i < ocrData.length; i++) {
      if (Number(ocrData[i].bounding.top / pictureHeight) > 0.43) {
        if (ocrData[i].text.match(/isla|slam|ISLAM/ig) !== null) {
          religion = religions.ISLAM; break;
        } else if (ocrData[i].text.match(/kriste|isten|KRISTEN/ig) !== null) {
          religion = religions.KRISTEN; break;
        } else if (ocrData[i].text.match(/KATOLIK/ig) !== null) {
          religion = religions.KATOLIK; break;
        } else if (ocrData[i].text.match(/Hindu/ig) !== null) {
          religion = religions.HINDU; break;
        } else if (ocrData[i].text.match(/budha/ig) !== null) {
          religion = religions.BUDHA; break;
        }
      }
    }
  }
  return religion;
};

export const isIndonesian = (ocrData, pictureHeight) => {
  let isWNI = false;
  if (ocrData && ocrData.length) {
    for (let i = 0; i < ocrData.length; i++) {
      if (ocrData[i].text.match(/WNI|WNE|WNl|WNi/g) !== null && Number(ocrData[i].bounding.top / pictureHeight) > 0.45) {
        isWNI = true; break;
      }
    }
  }
  return isWNI;
};

export const getRtRw = (ocrData) => {
  let rt = null;
  let rw = null;
  let temp = '';
  if (ocrData && ocrData.length) {
    for (let i = 0; i < ocrData.length; i++) {
      temp = ocrData[i].text.replace(/ /g, '');
      if (temp.search('/0') !== -1) {
        const n = temp.search('/0');
        rt = converrtToItsNumber(temp.substring(n - 3, n));
        rw = converrtToItsNumber(temp.substring(n + 1, n + 4));
      }
    }
  }
  return { rt, rw };
};

export const setStringTwoDigit = (number) => {
  if (number && String(number).length < 2) return `0${number}`;
  return String(number);
};

export const getInformationFromNIK = (nik) => {
  let birthday = null;
  let isFemale = null;
  let provinsi = '';
  let kota = '';
  let kecamatan = '';
  let isInvalidNIK = null;
  let gender = '';
  if (!nik || (nik && nik.length < 16)) isInvalidNIK = true;
  if (nik && nik !== '') {
    const birthDate = Number(nik.substring(6, 8));
    isFemale = birthDate > 40;
    // Please update after 2027
    birthday = `${setStringTwoDigit(isFemale ? birthDate - 40 :
      birthDate)}-${nik.substring(8, 10)}-${Number(nik.substring(10, 12)) > Number(String(new Date().getFullYear() - 100).substring(2, 4)) ?
      '19' : '20'}${nik.substring(10, 11) === '1' ? `9${nik.substring(11, 12)}` : nik.substring(10, 12)}`;
    if (!moment(birthday, 'DD-MM-YYYY').isValid()) {
      birthday = null; isInvalidNIK = true;
    } else { gender = isFemale ? genders.FEMALE : genders.MALE; }

    const area = areaCodes.find(x => x.code === nik.substring(0, 2)) || {};
    if (!area.district || !area.value) {
      isInvalidNIK = true;
    } else {
      const district = area.district.filter(x => x.code.substring(3, 5) === nik.substring(2, 4));
      provinsi = area.value;
      console.log('AREA: ', area);
      if (district.find(x => x.type === 'kabupaten')) kota = district.find(x => x.type === 'kabupaten').name;
      if (district.find(x => x.type === 'kecamatan' && x.code.substring(6, 8) === nik.substring(4, 6))) {
        kecamatan = district.find(x => x.type === 'kecamatan' && x.code.substring(6, 8) === nik.substring(4, 6)).name;
      }
    }
    if (!kota || !kecamatan || kota === '' || kecamatan === '' || provinsi === '' || gender === '') isInvalidNIK = true;
  } else {
    isInvalidNIK = true;
  }
  return {
    birthday, gender, provinsi, kota, kecamatan, isInvalidNIK,
  };
};

export const getNIK = (data, pictureHeight, pictureWidth) => {
  let nik = null;
  if (data && data.length && pictureHeight) {
    for (let i = 0; i < data.length; i++) {
      const ratio = Number(data[i].bounding.top / pictureHeight);
      if (ratio >= 0.37 && ratio < 0.395 && Number(data[i].bounding.width / pictureWidth) > 0.2) {
        nik = converrtToItsNumber(data[i].text);
        break;
      }
    }
  }
  return nik;
};

export const getName = (data, pictureHeight, pictureWidth) => {
  let name = null;
  if (data && data.length && pictureHeight && pictureWidth) {
    for (let i = 0; i < data.length; i++) {
      const ratio = Number(data[i].bounding.top / pictureHeight);
      if (ratio >= 0.395 && ratio < 0.425 && Number(data[i].bounding.left / pictureWidth) > 0.2) {
        name = data[i].text.substring(0, data[i].text.indexOf('\n') === -1 ? data[i].text.length : data[i].text.indexOf('\n'));
        break;
      }
    }
  }
  return name;
};

export const getMaritalStatus = (ocrData) => {
  let status = null;
  let temp = '';
  if (ocrData && ocrData.length) {
    for (let i = 0; i < ocrData.length; i++) {
      temp = ocrData[i].text.replace(/ /g, '');
      if (temp.match(/CERAI/g) !== null) {
        status = maritalStatus.CERAI;
      } else if (temp.match(/KAWIN|KAWN/g) !== null) {
        if (temp.match(/BELUM|MKAWIN|UMKAW/g) !== null) {
          status = maritalStatus.BELUM_MENIKAH;
        } else status = maritalStatus.MENIKAH;
        break;
      }
    }
  }
  return status;
};
