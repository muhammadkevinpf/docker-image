/* eslint-disable max-len */
import React, { Component } from 'react';
import {
  Icon, Text, View,
} from 'native-base';
import { TouchableOpacity } from 'react-native-gesture-handler';
import Style from '../../../styles';
import _ from '../../../lang';

export class RedButton extends Component {
  render() {
    const item = this.props.data;
    return (
      <TouchableOpacity
        onPress={item.onClick}
        activeOpacity={0.5}
        style={[Style.Main.rowDirectionSpaceBetween, Style.Main.noBorder, Style.Main.backgroundRed, Style.Main.padding10, Style.Main.margin3, this.props.headerStyle]}
      >
        <View style={[Style.Main.rowDirectionFlexStart, Style.Main.fullHeight, Style.Main.justifyCenter]}>
          {item.icon !== undefined &&
            <Icon
              name={item.icon}
              type={item.iconType || 'FontAwesome'}
              style={[Style.Main.textWhite, Style.Main.font18, Style.Main.width40, this.props.iconStyle]}
            />
          }
          <Text style={[Style.Main.fontAlbert14, Style.Main.textWhite, this.props.headerTitleStyle]}>{_(item.text)}</Text>
        </View>
        <Icon
          name={this.props.iconRight ? this.props.iconRight : 'angle-right'}
          type={this.props.iconRightType ? this.props.iconRightType : 'FontAwesome'}
          style={[Style.Main.textWhite, Style.Main.font18, Style.Main.alignRight, this.props.iconRightStyle]}
        />
      </TouchableOpacity>
    );
  }
}
