import React from 'react';
import { View } from 'react-native';
import SkeletonContent from 'react-native-skeleton-content-nonexpo';
import Style from '../../styles';
import Colors from '../../styles/Colors';

/** @description Dinamic styling for Skeleton-Loader. The prop used is similar to the properties of the StyleSheet */
export const rowLayout = ({
  w = '100%', h = 9, mv = 3, br = 1, m, mh, ...props
} = {}) => ({
  width: w, height: h, marginVertical: mv, borderRadius: br, margin: m, marginHorizontal: mh, ...props,
});

export const Skeleton = ({
  children, isLoading, style, layout,
}) => {
  const Tag = isLoading ? SkeletonContent : View;
  return (
    <Tag
      style={[Style.Main.container, style]}
      containerStyle={[Style.Main.container, style]}
      isLoading={isLoading}
      boneColor={Colors.skeletonBone}
      highlightColor={Colors.whiteSmoke}
      layout={layout}
    >{children}
    </Tag>
  );
};
