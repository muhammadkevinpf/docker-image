import ConfigIntegration from './ConfigIntegration';
import ConfigProduct from './ConfigProduct';

export {
  ConfigIntegration,
  ConfigProduct,
};
