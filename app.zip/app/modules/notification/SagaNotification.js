import {
  call, put, takeLatest,
} from 'redux-saga/effects';

import {
  LISTNOTIFICATIONAPI,
  LISTNOTIFICATIONFETCH,

  TOTALNOTIFICATIONAPI,
  TOTALNOTIFICATIONFETCH,

  UPDATENOTIFICATIONAPI,
  UPDATENOTIFICATIONFETCH,
} from './ConfigNotification';

import {
  totalNotificationSuccess,
  totalNotificationFailed,

  listNotificationSuccess,
  listNotificationFailed,

  updateNotificationSuccess,
  updateNotificationFailed,
} from './ActionNotification';

import { resourceRequest } from '../../utilities/StoreApi';
import { sagaWatcherErrorHandling } from '../../utilities/ErrorHandling';

function* workerSagaTotalNotification(params) {
  try {
    const resTotalNotification = yield call(resourceRequest, TOTALNOTIFICATIONAPI, 'post', params.send);

    if (resTotalNotification.status === '200' || resTotalNotification.status === 200) {
      yield put.resolve(totalNotificationSuccess(resTotalNotification.data.total));
    } else {
      yield put.resolve(totalNotificationFailed(resTotalNotification.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(totalNotificationFailed(parseError));
  }
}

function* workerSagaListNotification(params) {
  try {
    const resListNotification = yield call(resourceRequest, LISTNOTIFICATIONAPI, 'post', params.send);
    if ((resListNotification.status === '200' || resListNotification.status === 200)
    && resListNotification.data.array.length) {
      yield put.resolve(listNotificationSuccess(resListNotification.data.array));
    } else {
      yield put.resolve(listNotificationFailed(resListNotification.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(listNotificationFailed(parseError));
  }
}

function* workerSagaUpdateNotification(params) {
  try {
    const resUpdateNotification = yield call(resourceRequest, UPDATENOTIFICATIONAPI, 'post', params.send);
    if ((resUpdateNotification.status === '200' || resUpdateNotification.status === 200)) {
      yield put.resolve(updateNotificationSuccess(resUpdateNotification.data.message));
    } else {
      yield put.resolve(updateNotificationFailed(resUpdateNotification.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(updateNotificationFailed(parseError));
  }
}

export const watcherNotification = [
  takeLatest(TOTALNOTIFICATIONFETCH, workerSagaTotalNotification),
  takeLatest(LISTNOTIFICATIONFETCH, workerSagaListNotification),
  takeLatest(UPDATENOTIFICATIONFETCH, workerSagaUpdateNotification),
];
