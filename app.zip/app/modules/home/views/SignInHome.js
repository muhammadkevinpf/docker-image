/* eslint-disable react/no-did-update-set-state */
/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import {
  Alert, YellowBox, TextInput, Image, KeyboardAvoidingView, BackHandler,
} from 'react-native';
import CryptoJS from 'crypto-js';
import {
  Container, Content,
  Button, Text, Icon, View, Footer,
} from 'native-base';
import { connect } from 'react-redux';
import moment from 'moment';
import {
  SIGNINSUCCESS, SIGNINFAILED,
} from '../../auth/ConfigAuth';
import {
  signInFetch, hashingPassword, updateOnlineDate, vaFetch, vaUpdate, updateSignInDate, vaSuccess, vaFailed,
} from '../../auth/ActionAuth';
import _ from '../../../lang';
import LoadingModal from '../../../components/loading_modal';
import Style from '../../../styles';
import { getVAParam, isTokenExpired } from '../../auth/ServiceAuth';
import bg from '../../../assets/images/bg.png';
import { MathExpression } from '../../sqs-spaj/services/math-expression/InitME';
import { resetAllRedux } from '../../dashboard/ActionDashboard';
import { pageType } from '../ConfigHome';
import {
  defaultAction, getBranchMasterFromLocalDB, getReferralFromLocalDB, trackEvent,
} from '../../../utilities';
import { UPDATE_DICTIONARY_FLAG } from '../../dashboard/ConfigDashboard';

YellowBox.ignoreWarnings(['Warning: ReactNative.createElement']);

class SignInHome extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userID: this.props.navigation.getParam('agentData', {}).salesforceId || '',
      // password: this.props.navigation.getParam('agentData', {}).password || '',
      password: '',
      showLoadingModal: false,
      action: this.props.action,
      err: this.props.err,
      res: this.props.res,
      dislayFooter: true,
      isSecure: true,
    };
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.action !== prevState.action) {
      let nextErr = prevState.err;
      let nextRes = prevState.res;

      if (nextProps.action === SIGNINFAILED) {
        nextErr = nextProps.err;
      }
      if (nextProps.action === SIGNINSUCCESS) {
        nextRes = nextProps.res;
      }

      return {
        action: nextProps.action,
        err: nextErr,
        res: nextRes,
      };
    }

    return null;
  }

  componentDidMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleBack();
      return true;
    });
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.action !== this.state.action) {
      if (this.state.action === SIGNINFAILED) {
        if (this.props.err.code === '000249') {
          Alert.alert(
            '',
            this.props.err.message,
            [{
              text: 'Ubah Password',
              onPress: () => this.props.navigation.replace('MyAccountChangePassword', {
                isPublic: true,
                username: this.state.userID,
                oldPassword: CryptoJS.SHA1(JSON.stringify(this.state.password)).toString(),
              }),
            }],
          );
          return;
        }
        if (this.props.res.access_token) {
          if (this.props.onlineDate === null
            || moment().diff(this.props.onlineDate, 'days') >= 30
            || (this.props.err.code === '999' && isTokenExpired(this.props.res.access_token))
          ) {
            Alert.alert('',
              _('Sesi offline Anda telah berakhir, silakan online dan login kembali'), [
                {
                  text: _('Tutup'),
                  onPress: () => {
                    this.setState({ showLoadingModal: false });
                  },
                },
              ],
              { cancelable: false });
          } else if (this.props.onlineDate !== undefined && CryptoJS.SHA1(JSON.stringify(this.state.password)).toString() === this.props.pwd
            && this.props.res && this.props.res.username && this.props.res.username.toLowerCase() === this.state.userID.toLowerCase()
            && !(this.props.res.agent_channelType === '1' || this.props.res.agent_channelType === 1) && this.props.err.code === '999') {
            // init data for ME
            // eslint-disable-next-line no-unused-vars
            const initME = new MathExpression.InitMasterData(this.state.channel);
            this.setState({ showLoadingModal: false }, () => {
              this.handleCheckAvailableVA();
              this.handleUpdateSignInDate();
              getBranchMasterFromLocalDB();
              getReferralFromLocalDB();
              this.props.setDictionaryFlag();
              this.props.navigation.replace('MainDashboard');
            });
          } else {
            Alert.alert(
              _(''),
              // eslint-disable-next-line max-len
              !this.props.err.message.includes('Unknown') ? _(this.props.err.message) : _('PRUFastID atau Password terakhir salah dan perangkat anda sedang dalam keadaan offline.'),
              [
                {
                  text: _('Tutup'),
                  onPress: () => {
                    this.setState({ showLoadingModal: false });
                  },
                },
              ],
              { cancelable: false },
            );
          }
        } else {
          Alert.alert(
            _(''),
            // eslint-disable-next-line max-len
            !this.props.err.message.includes('Unknown') ? _(this.props.err.message) : _('Tidak dapat terhubung ke server. Pastikan perangkat anda online.'),
            [
              {
                text: _('Tutup'),
                onPress: () => {
                  this.setState({ showLoadingModal: false });
                },
              },
            ],
            { cancelable: false },
          );
        }
      }

      if (this.state.action === SIGNINSUCCESS) {
        if (prevProps && prevProps.res
          && this.props.res
          && prevProps.res.username
          && prevProps.res.username.toLowerCase()
          !== this.state.userID.toLowerCase()) this.props.resetAll();
        // init data for ME
        // eslint-disable-next-line no-unused-vars
        const initME = new MathExpression.InitMasterData(this.state.channel);

        const VANumbers = [
          this.props.vaNumber.filter(x => x.isUsed).map(x => x.vaNumber),
          this.props.vaNumber.filter(x => !x.isUsed).map(x => x.vaNumber),
        ];
        const vaParams = getVAParam(VANumbers);
        const data = {
          params: `['${JSON.stringify(vaParams)}']`,
          headers: [
            {
              keyHeader: 'X-CSRF-Token',
              valueHeader: `Bearer ${this.props.res.access_token}`,
            },
          ],
        };
        this.props.dispatchVA(data);
        this.setState({ showLoadingModal: false }, () => { // eslint-disable-line
          this.props.hashingUserPassword(CryptoJS.SHA1(JSON.stringify(this.state.password)).toString());
          this.props.updateOnlineDate(moment(new Date()));
          this.handleUpdateSignInDate();
          // eslint-disable-next-line max-len
          trackEvent('LOGIN', this.props.res.username);
          this.props.setDictionaryFlag();
          this.props.navigation.replace('MainDashboard', { channel: this.state.channel });
        });
      }
    }
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  handleBack = () => {
    this.props.navigation.replace('MainHome');
  }

  handleSignIn = () => {
    if (!this.state.userID || !this.state.password) {
      let message = '';
      if (!this.state.userID && !this.state.password) message = 'Username dan Password wajib diisi!';
      else if (!this.state.userID) message = 'Username wajib diisi!';
      else if (!this.state.password) message = 'Password wajib diisi!';
      Alert.alert(_('Error'), _(message), [{ text: _('Tutup'), onPress: () => {} }], { cancelable: false });
    } else {
      this.setState({ showLoadingModal: true }, async () => {
        const data = {
          params: `["${this.state.userID}","${this.state.password}","agen"]`,
          headers: [
            {
              keyHeader: 'X-CSRF-Token',
              valueHeader: 'Bearer undefined',
            },
          ],
        };
        this.props.dispatchSignIn(data);
      });
    }
  }

  handleUpdateSignInDate = () => {
    this.props.updateSignInDate(moment(new Date()));
  }

  handleCheckAvailableVA = () => {
    const isVAAvailable = this.props.res.vaNumber.some(x => !x.isUsed);
    if (!isVAAvailable) {
      Alert.alert(_('Warning'), _('Nomor VA untuk e-SPAJ anda telah habis, silakan login kembali dengan keadaan online!'),
        [{ text: 'OK' }], { cancelable: false });
    }
  }

  render() {
    return (
      <Container>
        <Image source={bg} style={Style.Main.bgImage} />
        <View>
          <Button
            transparent
            iconLeft
            onPress={() => this.props.navigation.replace('MainHome')}
          >
            <Icon name="angle-left" type="FontAwesome" style={[Style.Main.textRed]} />
            <Text style={[Style.Main.textRed]}>{_('Back')}</Text>
          </Button>
        </View>
        <Content keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
          <Text
            style={[Style.Main.font44, Style.Main.textRed, Style.Main.mt64, Style.Main.textAlignCenter, Style.Main.fontBold, Style.Main.mb55]}
          >PRUFast
          </Text>
          {/* <Text
            style={[Style.Main.font18, Style.Main.textColor3f3, Style.Main.textAlignCenter]}
          >{_('Masuk ke PRUFast')}
          </Text> */}
          <View
            style={[Style.Main.container, Style.Main.mt30]}
          >
            <KeyboardAvoidingView>

              <TextInput
                style={[Style.Main.container,
                  Style.Main.grayBorderBottom,
                  Style.Main.pb5,
                  Style.Main.alignCenter,
                  Style.Main.width187,
                  Style.Main.fontAlbert]}
                keyboardAppearance="default"
                keyboardType="default"
                returnKeyType="done"
                maxLength={15}
                placeholder={_('PRUFast ID')}
                onChangeText={text => this.setState({ userID: text.trim() })}
                value={this.state.userID}
                onFocus={() => {
                  this.setState({
                    dislayFooter: false,
                  });
                }}
                onEndEditing={() => {
                  this.setState({
                    dislayFooter: true,
                  });
                }}
              />
            </KeyboardAvoidingView>
          </View>
          <View
            style={[Style.Main.container]}
          >
            <Text
              style={[Style.Main.timeStyle, Style.Main.font10, Style.Main.alignCenter, Style.Main.width187]}
              onPress={() => this.props.navigation.replace('MainRouteHome', { route: 'SignInHome', pageType: pageType.forgetPRUFastID })}
            >{_('Lupa PRUFast ID?')}
            </Text>
          </View>
          <View
            style={[Style.Main.container, Style.Main.mt30]}
          >
            <KeyboardAvoidingView>
              <View style={[Style.Main.container, Style.Main.fontAlbert, Style.Main.grayBorderBottom,
                Style.Main.alignCenter, Style.Main.width187, Style.Main.rowDirection]}
              >
                <TextInput
                  style={[Style.Main.container, Style.Main.fontAlbert,
                    Style.Main.pb5, Style.Main.alignCenter]}
                  keyboardAppearance="default"
                  keyboardType="default"
                  returnKeyType="done"
                  maxLength={15}
                  placeholder={_('Password')}
                  onChangeText={text => this.setState({ password: text.trim() })}
                  value={this.state.password}
                  autoCompleteType="password"
                  secureTextEntry={this.state.isSecure}
                  onFocus={() => {
                    this.setState({
                      dislayFooter: false,
                    });
                  }}
                  onEndEditing={() => {
                    this.setState({
                      dislayFooter: true,
                    });
                  }}
                />
                <Icon
                  style={[Style.Main.alignRight, Style.Main.mb8, Style.Main.textGray]}
                  type="Ionicons"
                  name={this.state.isSecure ? 'eye-off' : 'eye'}
                  onPress={() => this.setState(prevState => ({ isSecure: !prevState.isSecure }))}
                />
              </View>
            </KeyboardAvoidingView>
          </View>
          <View
            style={[Style.Main.container]}
          >
            <Text
              style={[Style.Main.timeStyle, Style.Main.font10, Style.Main.alignCenter, Style.Main.width187]}
              // onPress={() => this.props.navigation.replace('SecurityQuestions', { pageType: pageType.forgetPassword })}
              onPress={() => this.props.navigation.replace('MainRouteHome', { route: 'SignInHome', pageType: pageType.forgetSecurityQuestion })}
            >{_('Lupa Password?')}
            </Text>
          </View>
          {/* <View
            style={[Style.Main.container]}
          >
            <KeyboardAvoidingView>
              <Button
                rounded
                danger
                style={[Style.Main.alignCenter, Style.Main.backgroundRed, Style.Main.mt20,
                  Style.Main.width187, Style.Main.dialogBtnCnt, Style.Main.itemCenter]}
                onPress={() => this.setState({ channel: 'BUOI' }, () => this.handleSignIn())}
              >
                <Text
                  style={[Style.Main.textWhite]}
                >{_('Masuk UOB')}
                </Text>
              </Button>
            </KeyboardAvoidingView>
          </View> */}
          <View
            style={[Style.Main.container]}
          >
            <KeyboardAvoidingView>
              <Button
                rounded
                danger
                style={[Style.Main.alignCenter, Style.Main.backgroundRed, Style.Main.mt20,
                  Style.Main.width187, Style.Main.dialogBtnCnt, Style.Main.itemCenter]}
                // onPress={() => this.setState({ channel: 'SCB' }, () => this.handleSignIn())}
                onPress={this.handleSignIn}
              >
                <Text
                  style={[Style.Main.textWhite]}
                >{_('Masuk')}
                </Text>
              </Button>
            </KeyboardAvoidingView>
          </View>
        </Content>
        <Footer
          style={[Style.Main.backgroundF9,
            (this.state.dislayFooter)
              ? Style.Main.displayFlex
              : Style.Main.displayNone,
          ]}
        >
          <View
            style={[Style.Main.container, Style.Main.dialogBtnCnt, Style.Main.itemCenter]}
          >
            <Text
              style={[Style.Main.textCenter, Style.Main.container,
                Style.Main.font12]}
            >
              {_('Belum memiliki PRUFast ID? ')}
              <Text
                style={[Style.Main.font12, Style.Main.textRed]}
                onPress={() => this.props.navigation.replace('MainRouteHome', { route: 'SignInHome', pageType: pageType.createPRUFastID })}
              >{_('Daftar')}
              </Text>
            </Text>
          </View>
        </Footer>
        <LoadingModal
          show={this.state.showLoadingModal}
          size="large"
          color="white"
        />
      </Container>
    );
  }
}

const mapStateToProps = state => ({
  fetch: state.auth.fetchSignIn,
  res: state.auth.res,
  err: state.auth.err,
  action: state.auth.action,
  pwd: state.auth.pwd,
  onlineDate: state.auth.activeOn,
  vaNumber: state.auth.res.vaNumber,
});

const mapDispatchToProps = dispatch => ({
  dispatchSignIn: value => dispatch(signInFetch(value)),
  hashingUserPassword: value => dispatch(hashingPassword(value)),
  updateOnlineDate: value => dispatch(updateOnlineDate(value)),
  dispatchVA: value => dispatch(vaFetch(value)),
  dispatchUpdateVA: value => dispatch(vaUpdate(value)),
  updateSignInDate: value => dispatch(updateSignInDate(value)),
  resetAll: () => dispatch(resetAllRedux()),
  vaSuccess: val => dispatch(vaSuccess(val)),
  vaFailed: val => dispatch(vaFailed(val)),
  setDictionaryFlag: () => dispatch(defaultAction(UPDATE_DICTIONARY_FLAG, true)),
});

export default connect(mapStateToProps, mapDispatchToProps)(SignInHome);
