import React from 'react';
import moment from 'moment';
import DateTimePicker from '@react-native-community/datetimepicker';
import {
  Card, Text, View, Textarea, Icon, Button,
} from 'native-base';
import { StyleSheet, TouchableOpacity, Modal } from 'react-native';
import { isEmpty, isTablet } from '../../../utilities';
import {
  DropdownNew, DatePickerNew, InputFieldNew, ContentAdjusted,
} from '../../../components';
import Style from '../../../styles';
import Colors from '../../../styles/Colors';
import _ from '../../../lang';

const MessageRequired = ({ show = false }) => {
  if (show) return <Text style={[Style.Main.font10, Style.Main.fontAlbert, Style.Main.ml5, Style.Main.textRed]}>{_('Wajib diisi')}!</Text>;
  return null;
};

class LatestFeedback extends React.PureComponent {
  render() {
    const { data } = this.props;
    if (!isEmpty(data) && !isEmpty(data.logFeedback) && data.logFeedback.length > 1) {
      return (
        <Card style={[Style.Main.padding12]}>
          <Text style={[Style.Main.fontAlbert12, Style.Main.textRed]}>{data.fullname}</Text>
          <Text style={[Style.Main.fontAlbert12]}>{data.logFeedback[0].reason.feedback[0].description}</Text>
          <Text style={[Style.Main.fontAlbert12]}>{data.logFeedback[0].activityDate}</Text>
        </Card>
      );
    }
    return (
      <Card style={[Style.Main.padding12]}>
        <Text style={[Style.Main.fontAlbert12]}>{_('Tidak ada umpan balik yang ditemukan')}</Text>
      </Card>
    );
  }
}

class FeedbackDropdrown extends React.PureComponent {
  render() {
    return (
      <View style={[styles.mh2, Style.Main.container]}>
        <DropdownNew
          mode="dialog"
          iosIcon="angle-down"
          valueProp="id"
          labelProp="description"
          {...this.props}
        />
        <MessageRequired show={this.props.warning && this.props.selectedValue === undefined} />
      </View>
    );
  }
}

class FeedbackInputField extends React.PureComponent {
  render() {
    return (
      <View style={[styles.mh2, Style.Main.container]}>
        <InputFieldNew isRequired={false} {...this.props} />
        <MessageRequired show={this.props.warning && (this.props.value === undefined || this.props.value === '')} />
      </View>
    );
  }
}

class FeedbackNotes extends React.PureComponent {
  render() {
    return (
      <View style={[styles.mh2, Style.Main.mt15]}>
        <Text style={[Style.Main.fontAlbert11]}>{_('Catatan (Opsional)')}</Text>
        <Textarea
          {...this.props}
          style={[Style.Main.fontAlbert14, Style.Main.textAlmostBlack]}
          rowSpan={5}
          maxLength={500}
          bordered
        />
        <MessageRequired show={this.props.warning && isEmpty(this.props.value)} />
      </View>
    );
  }
}

class FeedbackLocation extends React.PureComponent {
  render() {
    return (
      <View style={[styles.mh2, Style.Main.mt15]}>
        <Text style={[Style.Main.fontAlbert11]}>{_('Lokasi')}<Text style={[Style.Main.fontAlbert11, Style.Main.textRed]}> *</Text></Text>
        <InputFieldNew {...this.props} isRequired={false} formStyle={styles.loc} />
        <MessageRequired show={this.props.warning && isEmpty(this.props.value)} />
      </View>
    );
  }
}

class FeedbackDatePicker extends React.PureComponent {
  render() {
    return (
      <View style={[styles.mh2, Style.Main.container, Style.Main.rowDirection]}>
        <View style={[Style.Main.container]}>
          <DatePickerNew maximumDate={moment().add('month', 3).toDate()} label="Tanggal" showIcon={false} {...this.props} />
        </View>
        <View style={styles.pickerBtn}>
          <Icon type="FontAwesome" name="calendar" style={[Style.Main.font12, Style.Main.mb5]} />
        </View>
      </View>
    );
  }
}

class FeedbackTimePicker extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      showPicker: false,
    };
  }

  onPickerChanged = (e, val) => {
    this.setState({ showPicker: false });
    if (val) this.props.onDateChange(val);
  }

  render() {
    return (
      <View style={[styles.mh2, Style.Main.mt15, Style.Main.container, this.props.style]}>
        <Text style={[Style.Main.fontAlbert11]}>{_(this.props.label)}</Text>
        <TouchableOpacity style={[styles.pickerBtn, Style.Main.container]} onPress={() => this.setState({ showPicker: true })}>
          <Text style={[Style.Main.font14, Style.Main.fontAlbert, Style.Main.textAlmostBlack]}>
            {moment(this.props.value).format('HH : mm')}
          </Text>
          <Icon type="FontAwesome" name="clock-o" style={[Style.Main.font14, Style.Main.ml10, Style.Main.mb3]} />
        </TouchableOpacity>
        {this.state.showPicker && <DateTimePicker onChange={this.onPickerChanged} mode="time" is24Hour {...this.props} />}
      </View>
    );
  }
}

class FeedbackConfirmation extends React.PureComponent {
  Item = ({ label, value }) => (
    <View style={[Style.Main.container, Style.Main.borderBottomNativeBase, Style.Main.mb12]}>
      <Text style={[Style.Main.fontAlbert12]}>{_(label)}</Text>
      <Text style={[Style.Main.fontAlbert14, Style.Main.textBlack, Style.Main.my7]}>{value}</Text>
    </View>
  )

  render() {
    const {
      data, visible, onCancel, onConfirm,
    } = this.props;
    const currency = data.currency === 'idr' ? 'Rp' : data.currency;
    return (
      <Modal transparent visible={visible} onRequestClose={onCancel}>
        <View style={[Style.Main.backgroundLightSmoke, Style.Main.center, Style.Main.container]}>
          <View style={[Style.Main.backgroundWhite, Style.Main.borderRadius5,
            Style.Main.padding12, isTablet() ? Style.Main.halfWidth : Style.Main.width80pr, Style.Main.height80Percent]}
          >
            <ContentAdjusted>
              <Text style={[Style.Main.fontAlbert12, Style.Main.mb24, Style.Main.textBlack, Style.Main.textAlignCenter]}>
                {_('Pastikan semua data yang Anda masukan sudah benar')}
              </Text>
              <this.Item label="Feedback" value={data.feedback.description} />
              <this.Item label="Alasan" value={data.reason.description} />
              {data.feedback.isCalendar &&
                <React.Fragment>
                  <this.Item label="Tanggal" value={moment(data.date).format('DD/MM/YYYY')} />
                  <this.Item label="Jam Mulai" value={moment(data.startTime).format('HH:mm')} />
                  <this.Item label="Jam Selesai" value={moment(data.endTime).format('HH:mm')} />
                  <this.Item label="Lokasi" value={data.location} />
                </React.Fragment>}
              {data.feedback.isAPE &&
                <this.Item label="Estimasi APE" value={`${currency} ${data.ape}`} />
              }
              {data.feedback.isSPAJ &&
                <this.Item label="Nomor SPAJ" value={data.spajNumber} />
              }
              {!isEmpty(data.note) && <this.Item label="Catatan" value={data.note} />}
            </ContentAdjusted>
            <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.mt12]}>
              <Button block style={[Style.Main.btnDisable, Style.Main.container]} onPress={onCancel}>
                <Text>{_('Tidak')} </Text>
              </Button>
              <Button block style={[Style.Main.btnPrimary, Style.Main.container, Style.Main.ml12]} onPress={onConfirm}>
                <Text>{_('Ya')} </Text>
              </Button>
            </View>
          </View>
        </View>
      </Modal>
    );
  }
}

export const AMFeedback = {
  Dropdown: FeedbackDropdrown,
  InputField: FeedbackInputField,
  Notes: FeedbackNotes,
  LatestInfo: LatestFeedback,
  DatePicker: FeedbackDatePicker,
  TimePicker: FeedbackTimePicker,
  Location: FeedbackLocation,
  ConfirmationModal: FeedbackConfirmation,
};

const styles = StyleSheet.create({
  mh2: {
    marginLeft: 2,
    marginRight: 2,
  },
  loc: {
    marginTop: 5,
    borderWidth: 1,
    borderColor: Colors.grayNearWhite,
  },
  pickerBtn: {
    paddingBottom: 3,
    borderBottomWidth: 1,
    borderBottomColor: Colors.grayNearWhite,
    flexDirection: 'row',
    justifyContent: 'space-between',
    ...Style.Main.alignEnd,
  },
});
