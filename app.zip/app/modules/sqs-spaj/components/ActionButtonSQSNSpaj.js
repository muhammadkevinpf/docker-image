import React, { PureComponent } from 'react';
import ActionButton from 'react-native-action-button';
import Icon from 'react-native-vector-icons/FontAwesome';
import Style from '../../../styles';

class ActionButtonSQSNSpaj extends PureComponent {
  render() {
    const { data } = this.props;
    if (!data || !data.child) return null;
    return (
      <ActionButton buttonColor={data.parentColor} hideShadow>
        {data.child.map(item => (
          <ActionButton.Item
            buttonColor={item.color}
            title={item.title}
            onPress={item.onPress}
            key={item.title}
            hideLabelShadow
          >
            <Icon name={item.icon} style={Style.Main.textWhite} />
          </ActionButton.Item>
        ))}
      </ActionButton>
    );
  }
}

export default ActionButtonSQSNSpaj;
