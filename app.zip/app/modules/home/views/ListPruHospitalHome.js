/* eslint-disable max-len */
/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import {
  TouchableOpacity, BackHandler, Image,
} from 'react-native';
import {
  Container,
  Body,
  Card, CardItem, Text,
  View,
} from 'native-base';
import Communications from 'react-native-communications';
import Icon from 'react-native-vector-icons/FontAwesome';
import { connect } from 'react-redux';
import _ from '../../../lang';
import Style from '../../../styles';
import {
  HeaderWithTodo, SortFilter, SearchNativeBase, ListEmpty, CustomFlatList,
} from '../../../components';
import OutlineCheckbox from '../../../components/outline-checkbox';
import { cityHospitalFetch, hospitalFetch, clearHospitalAndOfficeList } from '../ActionHome';
import {
  CITYHOSPITALSUCCESS, CITYHOSPITALFAILED, HOSPITALFAILED, HOSPITALSUCCESS, HOSPITALFETCH, // BRANCHOFFICEFETCH,
} from '../ConfigHome';
import { isTablet, isArrayEmpty } from '../../../utilities';
import { iconPHF } from '../../../assets/images';


class ListPruHospitalHome extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isHospitalFriend: true,
      pageSize: 30,
      page: 1,
      searchWord: '',
      selectedFilter: '',
      isRefresh: false,
      onEndReachedCalledDuringMomentum: true,
      filterItems: [],
      hospital: [],
    };
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.actionHome !== prevState.actionHome) {
      if (nextProps.actionHome === CITYHOSPITALFAILED) {
        return {
          ...prevState,
          // listToDoNewBusinessPending: [],
          filterItems: prevState.filterItems,
          page: prevState.page === 1 ? prevState.page : prevState.page - 1,
          isRefresh: false,
          actionHome: nextProps.actionHome,
        };
      }
      if (nextProps.actionHome === CITYHOSPITALSUCCESS) {
        return {
          ...prevState,
          filterItems: nextProps.resHome && nextProps.resHome.cityHospital && nextProps.resHome.cityHospital.length ?
            nextProps.resHome.cityHospital.map(item => ({ value: item.hospital_city, label: item.hospital_city })) : prevState.filterItems,
          isRefresh: false,
          actionHome: nextProps.actionHome,
        };
      }

      if (nextProps.actionHome === HOSPITALFAILED) {
        return {
          ...prevState,
          // listToDoNewBusinessPending: [],
          page: prevState.page === 1 ? prevState.page : prevState.page - 1,
          hospital: nextProps.resHome ? (nextProps.resHome.hospital || []) : prevState.hospital,
          isRefresh: false,
          actionHome: nextProps.actionHome,
        };
      }
      if (nextProps.actionHome === HOSPITALSUCCESS) {
        return {
          ...prevState,
          hospital: nextProps.resHome ? (nextProps.resHome.hospital || []) : prevState.hospital,
          isRefresh: false,
          actionHome: nextProps.actionHome,
        };
      }
      return {
        ...prevState,
        actionHome: nextProps.actionHome,
      };
    }

    return null;
  }

  componentDidMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleBack();
      return true;
    });

    // if (this.props.isOnline) {
    this.getFilter();
    this.getData();
    // } else {
    //   this.setState({ isRefresh: false });
    // }
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  onSearchBarValue = (val) => {
    this.setState({ searchWord: val, page: 1, isRefresh: true }, () => {
      this.props.clearList();
      this.getData();
    });
  }

  onSearchTyped = (searchWord) => {
    this.setState({ searchWord });
  }

  onValueChangeFilter = (value) => {
    this.setState({ selectedFilter: value, page: 1, isRefresh: true }, () => {
      this.props.clearList();
      this.getData();
    });
  }

  handleLoadData = () => {
    if (!this.state.onEndReachedCalledDuringMomentum && !this.props.home.fetchBranchOffice) {
      this.setState(prevState => ({ showSpinner: true, page: prevState.page + 1 }), () => this.getData());
    }
  }

  getData = () => {
    const item = {
      // eslint-disable-next-line max-len
      params: `[${this.state.page}, ${this.state.pageSize}, "${this.state.selectedFilter}", "${this.state.searchWord}", "${this.state.isHospitalFriend}"]`,
    };
    this.props.dispatchFetchHospital(item);
  }

  getFilter = () => {
    const item = {
      // eslint-disable-next-line max-len
      params: '[]',
    };
    this.props.dispatchFetchCityHospital(item);
  }

  handleRefresh = () => {
    this.setState({ page: 1, isRefresh: true }, () => {
      this.props.clearList();
      this.getData();
    });
  }

  handleBack = () => {
    this.props.navigation.replace('MainHome');
  }

  listEmpty = () => (
    <ListEmpty
      // showIndicator={(this.props.actionHome === BRANCHOFFICEFETCH || this.props.home.fetchBranchOffice)}
      isOnline={this.props.isOnline || !this.state.hospital || (this.state.hospital && this.state.hospital.length <= 0)}
    />
  )

  renderTopBar = () => (
    <View>
      <SearchNativeBase
        placeholder={_('Cari rumah sakit')}
        onInputBlur={value => this.onSearchBarValue(value)}
        value={this.state.searchWord}
        onChangeText={this.onSearchTyped}
      />
      <Card style={[Style.Main.mb10]}>
        <CardItem bordered>
          <Body>
            <View Style={Style.Main.textWrap}>
              <Text style={Style.Main.fontAlbert}>
                {_('PRUhospital friend hadir di rumah sakit untuk membantu pemegang kartu PRUprime Healthcare Plus, dalam semua urusan klaim di rumah sakit.')}
              </Text>
            </View>
          </Body>
        </CardItem>
      </Card>
      <View style={[Style.Main.mV10]}>
        <Text style={Style.Main.fontAlbert}>{ _('LOKASI RUMAH SAKIT') }</Text>
        <SortFilter
          onFilterSelected={this.onValueChangeFilter}
          filterItems={this.state.filterItems}
          filterBy={this.state.selectedFilter}
          showSort={false}
          customLabel={this.state.selectedFilter || 'Semua Kota'}
        />
      </View>
      <View style={[Style.Main.mV10]}>
        <OutlineCheckbox
          label="PRU hospital Friend"
          checked={this.state.isHospitalFriend}
          onPress={() => this.setState(prevState => ({ isHospitalFriend: !prevState.isHospitalFriend, isRefresh: true }), () => {
            this.props.clearList();
            this.getData();
          })}
        />
      </View>
    </View>
  );

  render() {
    const { hospital, pageSize, isRefresh } = this.state;
    return (
      <Container style={[isTablet() && Style.Main.rowDirection]}>
        <Container>
          <HeaderWithTodo
            {...this.props}
            headerTitle="RUMAH SAKIT REKANAN"
            isShowBackButton
            isShowRightButton={false}
            onBackClicked={() => this.props.navigation.replace('MainHome')}
          />
          <CustomFlatList
            ignoreOffline
            listData={hospital}
            showLoadingEmpty={(this.props.actionHome === HOSPITALFETCH || this.props.home.fetchHospital) && !this.state.isRefresh}
            showLoadingFooter={this.props.actionHome === HOSPITALFETCH && !isArrayEmpty(hospital) && !this.state.isRefresh}
            topBar={this.renderTopBar()}
            itemComponent={({ item, index }) => (
              <Card key={index} style={[Style.Main.padding15, Style.Main.rowDirection, Style.Main.flex15]}>
                <View style={Style.Main.flex5}>
                  <View style={Style.Main.textWrap}>
                    <Text style={[Style.Main.fontAlbert, Style.Main.textStrong]}>
                      {item.hospital_name}
                    </Text>
                  </View>
                  <View style={[Style.Main.textWrap, Style.Main.columnDirection]}>
                    <Text style={[Style.Main.fontAlbert, Style.Main.mb10]}>
                      {item.hospital_address1}
                    </Text>
                    {item.hospital_address2 ?
                      <Text style={[Style.Main.fontAlbert, Style.Main.mb10]}>
                        {`${item.hospital_address2}${item.hospital_address3 ? ',' : ''} ${item.hospital_address3}`}
                      </Text> :
                      null}
                  </View>
                  {item.hospital_postcode ?
                    <View style={Style.Main.textWrap}>
                      <Text style={[Style.Main.fontAlbert, Style.Main.textStrong]}>
                        {item.hospital_postcode}
                      </Text>
                    </View> :
                    null}
                  {item.hospital_phone1 ?
                    <TouchableOpacity
                      style={Style.Main.textWrap}
                      onPress={() => Communications.phonecall(item.hospital_phone1, true)}
                    >
                      <Icon
                        name="phone"
                        style={[Style.Main.textBlue, Style.Main.font16, Style.Main.pt5]}
                      />
                      <Text
                        style={[Style.Main.fontAlbert, Style.Main.textBlue, Style.Main.ml4]}
                      >
                        {item.hospital_phone1}
                      </Text>
                    </TouchableOpacity>
                    : null
                  }
                </View>
                {item.hospital_mark_as &&
                <View style={[Style.Main.columnDirectionJustifyCenter, Style.Main.flex1]}>
                  {/* eslint-disable-next-line react-native/no-inline-styles */}
                  <Image source={iconPHF} style={[{ height: 35, width: 35, alignSelf: 'flex-end' }]} />
                </View>}
              </Card>
            )}
            pageSize={pageSize}
            handleLoadData={this.handleLoadData}
            onRefresh={this.handleRefresh}
            refreshing={isRefresh}
            statusList={this.props.apiStatus}
            onMomentumScrollBegin={() => this.setState({ onEndReachedCalledDuringMomentum: false })}
          />
        </Container>
      </Container>
    );
  }
}

const mapStateToProps = state => ({
  isOnline: state.connectionStatus.isOnline,
  actionHome: state.home.action,
  resHome: state.home.res,
  home: state.home,
});

const mapDispatchToProps = dispatch => ({
  dispatchFetchCityHospital: value => dispatch(cityHospitalFetch(value)),
  dispatchFetchHospital: value => dispatch(hospitalFetch(value)),
  clearList: () => dispatch(clearHospitalAndOfficeList()),
});

export default connect(mapStateToProps, mapDispatchToProps)(ListPruHospitalHome);
