
import { CLIENT_LIST, CLIENT_VIP_INFO_LIST } from './ConfigClient';
import { apiTakeLatest } from '../../utilities';

export const watcherClient = [
  apiTakeLatest(CLIENT_LIST, { isResponArray: true }),
  apiTakeLatest(CLIENT_VIP_INFO_LIST, { resAttribute: 'body' }),
];
