/* eslint-disable no-console */
import {
  call, put, takeLatest,
} from 'redux-saga/effects';
import { resourceRequest } from '../../utilities/StoreApi';
import { sagaWatcherErrorHandling } from '../../utilities/ErrorHandling';
import {
  NEWS_LIST_API, NEWS_LIST_FETCH, NEWS_DETAIL_API, NEWS_DETAIL_FETCH, FILE_BASE_64_API, FILE_BASE_64_FETCH,
} from './ConfigNews';
import {
  newsListSuccess, newsListFailed, newsDetailSuccess, newsDetailFailed, fileBase64Success, fileBase64Failed,
} from './ActionNews';

function* workerSagaNewsList(params) {
  try {
    const res = yield call(resourceRequest, NEWS_LIST_API, 'post', params.send);
    if (res.data && (res.status === '200' || res.status === 200)) {
      yield put.resolve(newsListSuccess(res.data.array));
    } else {
      yield put.resolve(newsListFailed(res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(newsListFailed(parseError));
  }
}

function* workerSagaNewsDetail(params) {
  try {
    const res = yield call(resourceRequest, NEWS_DETAIL_API, 'post', params.send);
    if (res.data && (res.status === '200' || res.status === 200)) {
      yield put.resolve(newsDetailSuccess(res.data.content));
    } else {
      yield put.resolve(newsDetailFailed(res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(newsDetailFailed(parseError));
  }
}

function* workerSagaBase64(params) {
  try {
    const res = yield call(resourceRequest, FILE_BASE_64_API, 'post', params.send);
    if (res.data && (res.status === '200' || res.status === 200)) {
      yield put.resolve(fileBase64Success(res.data.content));
    } else {
      yield put.resolve(fileBase64Failed(res.data.statusReason));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(fileBase64Failed(parseError));
  }
}

export const watcherNews = [
  takeLatest(NEWS_LIST_FETCH, workerSagaNewsList),
  takeLatest(NEWS_DETAIL_FETCH, workerSagaNewsDetail),
  takeLatest(FILE_BASE_64_FETCH, workerSagaBase64),
];
