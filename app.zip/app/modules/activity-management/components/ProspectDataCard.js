/* eslint-disable max-len */
import React from 'react';
import {
  Card, Thumbnail, View, Text, Icon,
} from 'native-base';
import { Linking, Alert } from 'react-native';
import { iconMyAccount } from '../../../assets/images';
import { isEmpty } from '../../../utilities';
import Style from '../../../styles';
import _ from '../../../lang';
// import NavigationService from '../../../bootstrap/NavigationService';
import { ConfigProductSPAJ } from '../../spaj/configs';
import { dataProposal } from '../ConfigActivity';

const styles = {
  icon: [Style.Main.font16, Style.Main.textRed, Style.Main.padding5],
  textBlack: [Style.Main.fontAlbert12, Style.Main.textBlack],
};

export class ProspectDataCard extends React.PureComponent {
  TextProspect = ({ item }) => {
    const { data } = this.props;
    let text = '-';
    if (!isEmpty(data) && !isEmpty(data[item])) text = data[item];
    return <Text style={styles.textBlack}>{text}</Text>;
  }

  Item = ({ label, item }) => (
    <Card style={[Style.Main.padding12, Style.Main.mt0, Style.Main.mb0]}>
      <Text style={[Style.Main.fontAlbert12]}>{label}</Text>
      {this.TextProspect({ item })}
    </Card>
  )

  goToSQS = () => {
    const { data } = this.props;
    if (!data.customerSign || !data.customerSignDate || data.customerSignLocation === '') {
      Alert.alert('', _('Mohon untuk melengkapi data tanda tangan nasabah terlebih dahulu sebelum membuat proposal baru'), [{ text: 'Ok' }]);
    } else {
      this.props.navigation.replace('ExistingPolicySQSNSpaj', {
        dataProspect: dataProposal(data),
        referral: data,
      });
      this.props.resetData();
    }
  }

  render() {
    const { data = {} } = this.props;
    return (
      <React.Fragment>
        <Card style={[Style.Main.padding12, Style.Main.mb10]}>
          <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.pb10]}>
            <View style={[Style.Main.rowDirection, Style.Main.flex5]}>
              <Thumbnail
                source={!isEmpty(data.customerPhoto) && data.customerPhoto !== 'http' ? { uri: `data:image/jpeg;base64,${data.customerPhoto}` } : iconMyAccount}
                style={[Style.Main.width40, Style.Main.height40, Style.Main.alignCenter]}
              />
              <View style={[Style.Main.ml20, Style.Main.alignCenter]}>
                <Text style={[Style.Main.fontAlbert14, Style.Main.textBlack]}>{data.customerName || 'N/A'}</Text>
                <Text style={[Style.Main.fontAlbert12]}>{data.phoneNumber ? `${data.phoneArea}${data.phoneNumber}` : '-'}</Text>
              </View>
            </View>
            <View style={[Style.Main.rowDirectionSpaceAround, Style.Main.flex3, Style.Main.alignCenter]}>
              <Icon name="phone" type="FontAwesome" style={styles.icon} onPress={() => Linking.openURL(`tel:${data.phoneArea}${data.phoneNumber}`)} />
              <Icon name="file-text" type="FontAwesome" style={styles.icon} onPress={this.goToSQS} />
              <Icon name="pencil" type="FontAwesome" style={styles.icon} onPress={() => this.props.navigation.replace('AddProspect', { data, dataParam: this.props.navigation.getParam('data') })} />
            </View>
          </View>
        </Card>
        <View>
          <this.Item label="No. CIF" item="noCif" />
          {
            ConfigProductSPAJ.agentChannelBnc.includes(this.props.resAuth.userProfile.agentChannel) ? (
              <React.Fragment>
                <this.Item label="Rel. ID" item="relId" />
                <this.Item label="RMP SID" item="rmPsid" />
                <this.Item label="Master Number" item="masterNumber" />
                <this.Item label="Product Account Number" item="prodAccountNumber" />
              </React.Fragment>
            ) : (
              <React.Fragment>
                <this.Item label="Segmen" item="segment" />
              </React.Fragment>
            )
          }
          <this.Item label="Tanggal Lahir" item="dob" />
          <this.Item label="Kode Cabang" item="bankBranchCode" />
          <this.Item label="Cabang Bank" item="bankBranchName" />
          <this.Item label="Kode Referensi" item="refCode" />
          <this.Item label="Nama Staf Bank" item="bankStafName" />
        </View>
      </React.Fragment>
    );
  }
}
