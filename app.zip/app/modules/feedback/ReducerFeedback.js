/* eslint-disable max-len */
import { requestStatus } from '../../utilities/ApiConnection';
import {
  GET_ALL_FEEDBACK, GET_SUB_TRANSACTION_TYPE, CLEAR_ALL_FEEDBACK, CLEAR_SUB_TRANSACTION_TYPE, GET_DETAIL_FEEDBACK, GET_FILE_BASE64, CLEAR_DETAIL_FEEDBACK, FIND_TRANSACTION_TYPE, FIND_SUB_TRANSACTION_TYPE, GET_AGENT_DATA, SUBMIT_FEEDBACK,
} from './ConfigFeedback';

const initialStateFeedback = {
  // status
  feedbackListStatus: requestStatus.IDLE,
  feedbackFilterStatus: requestStatus.IDLE,
  feedbackDetailStatus: requestStatus.IDLE,
  feedbackBase64Status: requestStatus.IDLE,
  transactionTypeStatus: requestStatus.IDLE,
  subTransactionTypeStatus: requestStatus.IDLE,
  agentDataStatus: requestStatus.IDLE,
  submitStatus: requestStatus.IDLE,

  // result
  feedbackList: [],
  feedbackFilter: [],
  feedbackDetail: {},
  feedbackBase64: {},
  transactionType: [],
  subTransactionType: [],
  agentData: {},
  submit: {},

  error: null,
  send: null,
};

export function ReducerFeedback(state = initialStateFeedback, action) {
  switch (action.type) {
    case GET_ALL_FEEDBACK.FETCH: return { ...state, feedbackListStatus: requestStatus.FETCH, send: action.payload };
    case GET_ALL_FEEDBACK.SUCCESS: return {
      ...state,
      feedbackListStatus: requestStatus.SUCCESS,
      feedbackList: state.feedbackList.length ? [...state.feedbackList, ...action.payload.filter(x => !state.feedbackList.some(item => item === x))]
        : action.payload,
    };
    case GET_ALL_FEEDBACK.FAILED: return { ...state, feedbackListStatus: requestStatus.FAILED, error: action.payload };
    case CLEAR_ALL_FEEDBACK: return { ...state, feedbackListStatus: requestStatus.IDLE, feedbackList: [] };

    case GET_SUB_TRANSACTION_TYPE.FETCH: return { ...state, feedbackFilterStatus: requestStatus.FETCH, send: action.payload };
    case GET_SUB_TRANSACTION_TYPE.SUCCESS: return {
      ...state,
      feedbackFilterStatus: requestStatus.SUCCESS,
      feedbackFilter: action.payload,
    };
    case GET_SUB_TRANSACTION_TYPE.FAILED: return { ...state, feedbackFilterStatus: requestStatus.FAILED, error: action.payload };
    case CLEAR_SUB_TRANSACTION_TYPE: return { ...state, feedbackFilterStatus: requestStatus.IDLE, feedbackFilter: [] };

    case GET_DETAIL_FEEDBACK.FETCH: return { ...state, feedbackDetailStatus: requestStatus.FETCH, send: action.payload };
    case GET_DETAIL_FEEDBACK.SUCCESS: return {
      ...state,
      feedbackDetailStatus: requestStatus.SUCCESS,
      feedbackDetail: action.payload,
    };
    case GET_DETAIL_FEEDBACK.FAILED: return { ...state, feedbackDetailStatus: requestStatus.FAILED, error: action.payload };

    case GET_FILE_BASE64.FETCH: return { ...state, feedbackBase64Status: requestStatus.FETCH, send: action.payload };
    case GET_FILE_BASE64.SUCCESS: return {
      ...state,
      feedbackBase64Status: requestStatus.SUCCESS,
      feedbackBase64: action.payload,
    };
    case GET_FILE_BASE64.FAILED: return { ...state, feedbackBase64Status: requestStatus.FAILED, error: action.payload };


    case FIND_TRANSACTION_TYPE.FETCH: return { ...state, transactionTypeStatus: requestStatus.FETCH, send: action.payload };
    case FIND_TRANSACTION_TYPE.SUCCESS: return {
      ...state,
      transactionTypeStatus: requestStatus.SUCCESS,
      transactionType: action.payload,
    };
    case FIND_TRANSACTION_TYPE.FAILED: return { ...state, transactionTypeStatus: requestStatus.FAILED, error: action.payload };

    case FIND_SUB_TRANSACTION_TYPE.FETCH: return { ...state, subTransactionTypeStatus: requestStatus.FETCH, send: action.payload };
    case FIND_SUB_TRANSACTION_TYPE.SUCCESS: return {
      ...state,
      subTransactionTypeStatus: requestStatus.SUCCESS,
      subTransactionType: action.payload,
    };
    case FIND_SUB_TRANSACTION_TYPE.FAILED: return { ...state, subTransactionTypeStatus: requestStatus.FAILED, error: action.payload };

    case GET_AGENT_DATA.FETCH: return { ...state, agentDataStatus: requestStatus.FETCH, send: action.payload };
    case GET_AGENT_DATA.SUCCESS: return {
      ...state,
      agentDataStatus: requestStatus.SUCCESS,
      agentData: action.payload,
    };
    case GET_AGENT_DATA.FAILED: return { ...state, agentDataStatus: requestStatus.FAILED, error: action.payload };

    case SUBMIT_FEEDBACK.FETCH: return { ...state, submitStatus: requestStatus.FETCH, send: action.payload };
    case SUBMIT_FEEDBACK.SUCCESS: return {
      ...state,
      submitStatus: requestStatus.SUCCESS,
      submit: action.payload,
    };
    case SUBMIT_FEEDBACK.FAILED: return { ...state, submitStatus: requestStatus.FAILED, error: action.payload };

    case CLEAR_DETAIL_FEEDBACK: return {
      ...state,
      feedbackDetailStatus: requestStatus.IDLE,
      feedbackBase64Status: requestStatus.IDLE,
      transactionTypeStatus: requestStatus.IDLE,
      subTransactionTypeStatus: requestStatus.IDLE,
      feedbackDetail: {},
      feedbackBase64: {},
      transactionType: [],
      subTransactionType: [],
    };
    default:
      return state;
  }
}
