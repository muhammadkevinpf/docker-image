import RNExitApp from 'react-native-exit-app';
import VersionCheck from 'react-native-version-check';
import { Platform, Linking, Alert } from 'react-native';
import AppJson from '../../../app.json';

const versionCheck = () => {
  if (AppJson.environtment === 'PROD') {
    VersionCheck.needUpdate({
      country: 'ID',
    })
      .then((res) => {
        if (res.isNeeded) {
          Alert.alert(
            'Pembaruan',
            // eslint-disable-next-line max-len
            `Yth. Tenaga Pemasar.\nAplikasi terbaru tersedia di ${Platform.OS === 'android' ? 'Play' : 'App'} Store dan silakan melakukan pembaruan.\nTerimakasih.`,
            [{ text: 'Perbarui', onPress: () => { Linking.openURL(res.storeUrl); RNExitApp.exitApp(); } }],
            { cancelable: false },
          );
        }
      }).catch(err => console.log('needUpdateErr', err));
  }
};

export { versionCheck };
