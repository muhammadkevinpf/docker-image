/* eslint-disable max-len */
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import {
  Accordion, Icon, Text, View, Card,
} from 'native-base';
import Style from '../../styles';
import _ from '../../lang';
import { isText } from '../../utilities';

export default class CustomAccordion extends PureComponent {
  renderHeader = (item, expanded) => (
    <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.noBorder, Style.Main.backgroundRed, Style.Main.padding10, this.props.headerStyle]}>
      <View style={[Style.Main.rowDirectionFlexStart, Style.Main.fullHeight, Style.Main.justifyCenter]}>
        { item.icon !== undefined &&
          <Icon
            name={item.icon}
            type={item.iconType || 'FontAwesome'}
            style={[Style.Main.textWhite, Style.Main.font18, Style.Main.width40, Style.Main.center, this.props.iconStyle]}
          />
        }
        <Text style={[Style.Main.fontAlbert14, Style.Main.textWhite, this.props.headerTitleStyle]}>{isText(item.title) ? _(item.title) : item.title}</Text>
      </View>
      {
        expanded
          ? <Icon name={item.iconExpandLess || 'minus'} type={item.iconExpandType || 'FontAwesome'} style={[Style.Main.textWhite, Style.Main.font18, Style.Main.alignRight, this.props.actionIconStyle]} />
          : <Icon name={item.iconExpandMore || 'plus'} type={item.iconExpandType || 'FontAwesome'} style={[Style.Main.textWhite, Style.Main.font18, Style.Main.alignRight, this.props.actionIconStyle]} />
      }
    </View>
  );

  renderContent = item => (
    <View style={[Style.Main.padding10, Style.Main.noBorder, Style.Main.textAlmostBlack, Style.Main.fontAlbert, this.props.contentStyle]}>
      {item.content}
    </View>
  )

  renderAccordion = () => (
    <Accordion
      style={this.props.noCard && [Style.Main.margin3, this.props.accordionStyle]}
      animation={this.props.animation}
      expanded={this.props.expanded}
      dataArray={this.props.dataArray}
      renderContent={this.renderContent}
      renderHeader={this.renderHeader}
    />
  )

  render() {
    if (this.props.noCard) return this.renderAccordion();
    return <Card style={[Style.Main.mt3, Style.Main.mb3, this.props.accordionStyle]}>{this.renderAccordion()}</Card>;
  }
}

CustomAccordion.propTypes = {
  headerStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  accordionStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  iconStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  headerTitleStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  contentStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  actionIconStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  animation: PropTypes.bool,
  noCard: PropTypes.bool,
  expanded: PropTypes.number,
  dataArray: PropTypes.arrayOf(PropTypes.object).isRequired,
};

CustomAccordion.defaultProps = {
  headerStyle: null,
  accordionStyle: null,
  iconStyle: null,
  headerTitleStyle: null,
  contentStyle: null,
  actionIconStyle: null,
  animation: true,
  noCard: false,
  expanded: null,
};

// NOTES:
// dataArray should contain 'title' and 'content' object
// EXAMPLE:
// dataArray = [{ title: 'Header Title', content: 'View' }]
// for custom icon (either its name or its type), add 'icon' and/or 'iconType in dataArray
// EXAMPLE WITH CUSTOM ICON:
// dataArray = [{ title: 'Header Title', content: 'View', icon: 'user', iconType: 'Ionics' }]
