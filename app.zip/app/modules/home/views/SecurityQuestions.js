/* eslint-disable react-native/no-inline-styles */
/* eslint-disable react-native/no-color-literals */
/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import { View, Button, Text } from 'native-base';
import { connect } from 'react-redux';
import { BackHandler, Alert } from 'react-native';
import _ from '../../../lang';

import Style from '../../../styles';
import { authAction, verifyBancaAction } from '../ActionHome';
import {
  pageType, FORGOT_PASSWORD, GET_SECURITY_QUESTIONS, CHECK_AGENT_BANCA_BY_SALES_FORCE_ID, VERIFY_SECQUEST,
} from '../ConfigHome';
import { requestStatus } from '../../../utilities';
import LoadingModal from '../../../components/loading_modal';
import { InputFieldNew, DropdownNew } from '../../../components';
import HomeScreen from '../components/HomeScreen';

const headers = [
  {
    keyHeader: 'X-CSRF-Token',
    valueHeader: 'Bearer undefined',
  },
];
class SecurityQuestions extends Component {
  constructor(props) {
    super(props);
    this.onValueChangeQuestionOne = this.onValueChangeQuestionOne.bind(this);
    this.onValueChangeQuestionTwo = this.onValueChangeQuestionTwo.bind(this);
    this.state = {
      questionOne: 1,
      questionTwo: 4,
      prufastId: '',
      answerOne: '',
      answerTwo: '',
      isLoading: false,
      isBancaVerified: false,
      isNewInput: false,
      agentData: {},
    };
  }

  componentDidMount() {
    const page = this.props.navigation.getParam('pageType', '');
    const agentData = this.props.navigation.getParam('agentData', {});
    const isNewInput = page === pageType.createPRUFastID || page === pageType.createPRUFastIDNoSFA;
    this.setState({ isNewInput, agentData });
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleBack();
      return true;
    });
    this.getSecurityQuestions();
  }

  componentDidUpdate(prevProps) {
    if (this.props !== prevProps) {
      if (this.props.status !== prevProps.status && this.props.status === requestStatus.FETCH) { this.handleLoading(true); }
      if ((this.props.status !== prevProps.status && this.props.status === requestStatus.FETCH)
        || (this.props.checkAgentTypeStatus !== prevProps.checkAgentTypeStatus && this.props.checkAgentTypeStatus === requestStatus.FETCH)
        || (this.props.verifySqStatus !== prevProps.verifySqStatus && this.props.verifySqStatus === requestStatus.FETCH)) {
        this.handleLoading(true);
      }

      if ((this.props.checkAgentTypeStatus !== prevProps.checkAgentTypeStatus)
        && (this.props.checkAgentTypeStatus === requestStatus.SUCCESS)) {
        if (!this.props.verifyBancaData.isBanca) {
          if (this.props.verifyBancaData.responseMessage === 'Data not found') {
            Alert.alert(
              '',
              'Data yang Anda masukkan tidak sesuai dengan database kami. Silakan hubungi Agency Administration Support.',
              [{ text: 'Ok', onPress: () => this.handleLoading(false) }],
              { cancelable: false },
            );
            return;
          }
          Alert.alert(
            '',
            'Saat ini PRUFast hanya dapat di akses oleh tenaga pemasar Bancassurance',
            [{ text: 'Ok', onPress: () => { this.handleLoading(false); } }],
            { cancelable: false },
          );
          return;
        }
        if (!this.state.isBancaVerified) {
          // eslint-disable-next-line react/no-did-update-set-state
          this.setState({ isBancaVerified: this.props.verifyBancaData.isBanca }, () => {
            this.onVerify();
          });
        }
      }

      if (this.props.status !== prevProps.status && this.props.status === requestStatus.SUCCESS) {
        this.handleLoading(false, () => {
          if (this.props.forgotPassword.respCode === 200) {
            this.props.navigation.replace('SignUpAgent', { route: 'SecurityQuestions', username: this.state.prufastId });
          } else {
            Alert.alert(
              '',
              'Data yang Anda masukkan tidak sesuai dengan database kami. Silakan hubungi Agency Administration Support.',
              [{ text: 'Ok', onPress: () => { this.setState({ isBancaVerified: false }); } }],
              { cancelable: false },
            );
          }
        });
      }

      if (this.props.verifySqStatus !== prevProps.verifySqStatus && this.props.verifySqStatus === requestStatus.SUCCESS) {
        this.handleLoading(false, () => {
          if (this.props.verifySq.respCode === 200) {
            Alert.alert('', 'Pertanyaan Rahasia berhasil didaftarkan', [{
              text: 'OK',
              onPress: () => this.props.navigation.replace('SignInHome', { agentData: this.state.agentData }),
            }]);
          } else {
            Alert.alert(
              '',
              'Data yang Anda masukkan tidak sesuai dengan database kami. Silakan hubungi Agency Administration Support.',
              [{ text: 'Ok', onPress: () => { this.setState({ isBancaVerified: false }); } }],
              { cancelable: false },
            );
          }
        });
      }

      if ((this.props.status !== prevProps.status && this.props.status === requestStatus.FAILED)
        || (this.props.verifySqStatus !== prevProps.verifySqStatus && this.props.verifySqStatus === requestStatus.FAILED)
        || (this.props.checkAgentTypeStatus !== prevProps.status && this.props.checkAgentTypeStatus === requestStatus.FAILED)) {
        this.handleLoading(false, () => {
          Alert.alert('', 'Gagal memanggil service', [{ text: 'Ok', onPress: () => { } }]);
        });
      }
    }
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  onValueChangeQuestionOne(value) {
    this.setState({
      questionOne: value,
    });
  }

  onValueChangeQuestionTwo(value) {
    this.setState({
      questionTwo: value,
    });
  }

  getSecurityQuestions = () => {
    const data = { headers, params: '[]' };
    this.props.getQuestions(data);
  }

  handleLoading = (val, func) => {
    const callbackFunc = func || (() => { });
    this.setState({ isLoading: val }, callbackFunc);
  }

  handleBack = () => {
    this.props.navigation.replace('SignInHome');
  }

  onVerify = () => {
    const {
      prufastId, questionOne, questionTwo, answerOne, answerTwo, isNewInput,
    } = this.state;
    const id = isNewInput ? this.state.agentData.salesforceId : prufastId;

    const dataParam = {
      headers,
      params: `["${questionOne}", "${answerOne}", "${questionTwo}", "${answerTwo}", "${id}"]`,
    };

    if ((!isNewInput && prufastId === '') || questionOne === '' || questionTwo === '' || answerOne === '' || answerTwo === '') {
      Alert.alert('', 'Mohon mengisi semua kolom isian', [{ text: 'Ok', onPress: () => { } }]);
    } else if (isNewInput) {
      this.props.inputQuestions(dataParam);
    } else {
      // eslint-disable-next-line no-lonely-if
      if (!this.state.isBancaVerified) {
        const data = { headers, params: `["${prufastId}"]` };
        this.props.verifyBanca(data);
      } else {
        this.props.verifyForgotPassword(dataParam);
      }
    }
  }

  secQuestData = () => {
    if (this.props.sequrityQuestions && this.props.sequrityQuestions.length) {
      const data = [];
      this.props.sequrityQuestions.map(item => (
        data.push({ value: item.aobsystemcodeid, label: item.aobdescriptionind, aobitem: item.aobitem })
      ));
      return data;
    }
    return [];
  }


  render() {
    const { isNewInput } = this.state;
    const questLabel = isNewInput ? 'Pilih ' : '';
    return (
      <React.Fragment>
        <HomeScreen
          title={isNewInput ? 'Pertanyaan Rahasia' : 'Lupa Password'}
          onBackClicked={this.handleBack}
          content={
            <View style={[Style.Main.width300, Style.Main.alignCenter]}>
              {
                !isNewInput && (
                  <InputFieldNew
                    value={this.state.prufastId}
                    label={_('Masukkan PRUFast ID')}
                    onChangeText={(value) => { this.setState({ prufastId: value }); }}
                    isRequired={false}
                  />
                )
              }
              <DropdownNew
                mode="dialog"
                iosIcon="angle-down"
                dropdownData={this.secQuestData().filter(x => x.aobitem === 'SQ1')}
                selectedValue={this.state.questionOne}
                onValueChange={this.onValueChangeQuestionOne}
                label={`${questLabel}Pertanyaan Rahasia Pertama`}
                labelProp="label"
                valueProp="value"
              />
              <InputFieldNew
                value={this.state.answerOne}
                label={_('Jawaban Pertanyaan Pertama')}
                onChangeText={(value) => { this.setState({ answerOne: value }); }}
                isRequired={false}
              />
              <DropdownNew
                mode="dialog"
                iosIcon="angle-down"
                dropdownData={this.secQuestData().filter(x => x.aobitem === 'SQ2')}
                selectedValue={this.state.questionTwo}
                onValueChange={this.onValueChangeQuestionTwo}
                label={`${questLabel}Pertanyaan Rahasia Kedua`}
                labelProp="label"
                valueProp="value"
              />
              <InputFieldNew
                value={this.state.answerTwo}
                label={_('Jawaban Pertanyaan Kedua')}
                onChangeText={(value) => { this.setState({ answerTwo: value }); }}
                isRequired={false}
              />
              <Button
                rounded
                danger
                style={[Style.Main.mt35, Style.Main.buttonRed]}
                onPress={this.onVerify}
              >
                <Text style={[Style.Main.fontAlbert14, Style.Main.textWhite]}>{_(isNewInput ? 'LANJUT' : 'VERIFIKASI')}</Text>
              </Button>
              <Text
                onPress={() => {
                  if (isNewInput) {
                    this.props.navigation.replace('SignInHome', { agentData: this.state.agentData });
                  } else {
                    this.props.navigation.replace('MainRouteHome', { route: 'SecurityQuestions', pageType: pageType.forgetSecurityQuestion });
                  }
                }}
                style={[Style.Main.textAlmostBlack, Style.Main.textCenter, Style.Main.font11, Style.Main.mb15, Style.Main.mt5]}
              >
                {isNewInput ? 'Lewati Sekarang' : 'Lupa pertanyaan rahasia?'}
              </Text>
            </View>
          }
        />
        <LoadingModal
          show={this.state.isLoading}
          size="large"
          color="white"
        />
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  isOnline: state.connectionStatus.isOnline,
  forgotPassword: state.home.forgotPassword,
  status: state.home.forgotPasswordStatus,
  checkAgentTypeStatus: state.home.checkAgentTypeStatus,
  sequrityQuestions: state.home.sequrityQuestions,
  verifyBancaData: state.home.verifyBanca,
  verifySq: state.home.verifySq,
  verifySqStatus: state.home.verifySqStatus,
});

const mapDispatchToProps = dispatch => ({
  verifyForgotPassword: value => dispatch(authAction(FORGOT_PASSWORD.FETCH, value)),
  getQuestions: value => dispatch(authAction(GET_SECURITY_QUESTIONS.FETCH, value)),
  verifyBanca: value => dispatch(verifyBancaAction(CHECK_AGENT_BANCA_BY_SALES_FORCE_ID.FETCH, value)),
  inputQuestions: value => dispatch(authAction(VERIFY_SECQUEST.FETCH, value)),
});

export default connect(mapStateToProps, mapDispatchToProps)(SecurityQuestions);
