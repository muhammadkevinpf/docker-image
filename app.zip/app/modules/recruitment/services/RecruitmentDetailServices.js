import moment from 'moment';
import SQLiteUtils from '../../../utilities/SQLiteUtils';
import Database from '../../../config/Database';

const { recruitmentDetail } = Database.pruForce.tables;

const querySelectAll = `SELECT * FROM ${recruitmentDetail.name} WHERE method = ? and agentCode = ?`;
const querySelectPerPage = `SELECT * FROM ${recruitmentDetail.name} WHERE method = ? and agentCode = ? and AND page = ?`;
const queryReplace = `REPLACE INTO ${recruitmentDetail.name} VALUES(?,?,?,?,?)`;
const queryInsert = `INSERT INTO ${recruitmentDetail.name} VALUES (?,?,?,?,?)`;
const queryUpdate = `UPDATE ${recruitmentDetail.name} SET data = ?,createDate = ? WHERE method = ? and agentCode = ? and page = ?`;

const openDatabase = () => new Promise(async (resolve, reject) => {
  try {
    const db = await SQLiteUtils.openDatabase(recruitmentDetail.name, 'default');
    resolve(db);
  } catch (error) {
    reject(error);
  }
});

const getAll = (db, agentCode) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(db, querySelectAll, [recruitmentDetail.AllListCandidate.method, agentCode]);
    const data = [];
    for (let i = 0; i < res.rows.length; i += 1) {
      data.push(JSON.parse(res.rows.item(i).data));
    }
    resolve(data);
  } catch (error) {
    reject(error);
  }
});

const getPerPage = (db, agentCode, page) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(db, querySelectPerPage, [recruitmentDetail.getListCandidate.method, agentCode, page]);
    const data = [];
    for (let i = 0; i < res.rows.length; i += 1) {
      data.push(JSON.parse(res.rows.item(i).data));
    }
    resolve(data);
  } catch (error) {
    reject(error);
  }
});

const deleteById = (db, param) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(db, querySelectAll, [recruitmentDetail.allListCandidate.method, param.agentCode]);
    const resToUpdate = [];
    if (res.rows.length > 0) {
      const resToStore = JSON.parse(res.rows.item(0).data);

      for (let i = 0; i < resToStore.length; i += 1) {
        if (param.data.id !== resToStore[i].id) {
          resToUpdate.push(resToStore[i]);
        }
      }
    }
    const parameterToInput = [recruitmentDetail.AllListCandidate.method,
      param.agentCode,
      0,
      JSON.stringify(resToUpdate),
      moment().format('DD/MM/YYYY HH:mm'),
    ];

    const resReplace = await SQLiteUtils.executeTransaction(
      db,
      queryReplace,
      parameterToInput,
    );
    resolve(`REPLACE ${resReplace}`);
  } catch (error) {
    reject(error);
  }
});

const upsert = (db, param) => new Promise(async (resolve, reject) => {
  try {
    const data = param;
    const res = await SQLiteUtils.executeQuery(db, querySelectAll, [recruitmentDetail.AlListCandidate.method, param.agentCode]);
    const resToUpdate = [];
    let queryToProcess = queryInsert;
    if (res.rows.length > 0) {
      const resToStore = JSON.parse(res.rows.item(0).data);

      for (let i = 0; i < resToStore.length; i += 1) {
        if (param.data.id === resToStore[i].id) {
          resToStore[i] = data;
        } else if (param.data.id === undefined) {
          data.id = resToStore.length + 1;
          resToStore.push(param.data);
          break;
        }
      }
      queryToProcess = queryUpdate;
    } else {
      data.id = 1;
    }

    const parameterToInput = [recruitmentDetail.AllListCandidate.method,
      param.agentCode,
      0,
      JSON.stringify(resToUpdate),
      moment().format('DD/MM/YYYY HH:mm'),
    ];

    const resReplace = await SQLiteUtils.executeTransaction(
      db,
      queryToProcess,
      parameterToInput,
    );
    resolve(`UPSERT ${resReplace}`);
  } catch (error) {
    reject(error);
  }
});

export default {
  openDatabase,
  getAll,
  getPerPage,
  deleteById,
  upsert,

};
