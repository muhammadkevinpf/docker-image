/**
 * @author dwi.setiyadi@gmail.com
 */

const translation = [
];

export default translation;
