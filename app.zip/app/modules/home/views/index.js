/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import MainHome_ from './MainHome';

import SignInHome_ from './SignInHome';
import MainRouteHome_ from './MainRouteHome';
import AgentDataVerification_ from './AgentDataVerification';
import ForgotPruIDNonAgentHome_ from './ForgotPruIDNonAgentHome';
import SecurityQuestions_ from './SecurityQuestions';

import SignUpHome_ from './SignUpHome';
import SignUpAgentHome_ from './SignUpAgentHome';
import SignUpAgentSFARegHome_ from './SignUpAgentSFARegHome';
import SignUpNonAgentHome_ from './SignUpNonAgentHome';


import ListPruHospitalHome_ from './ListPruHospitalHome';
import ListPruAgentOfficeHome_ from './ListPruAgentOfficeHome';

import PrivacyPolicyHome_ from './PrivacyPolicyHome';

import SMSVerification_ from './SMSVerification';
import SignUpAgent_ from './SignUpAgent';

const MainHome = MainHome_;

const SignInHome = SignInHome_;
const MainRouteHome = MainRouteHome_;
const AgentDataVerification = AgentDataVerification_;
const ForgotPruIDNonAgentHome = ForgotPruIDNonAgentHome_;
const SecurityQuestions = SecurityQuestions_;

const SignUpHome = SignUpHome_;
const SignUpAgentHome = SignUpAgentHome_;
const SignUpAgentSFARegHome = SignUpAgentSFARegHome_;
const SignUpNonAgentHome = SignUpNonAgentHome_;

const ListPruHospitalHome = ListPruHospitalHome_;
const ListPruAgentOfficeHome = ListPruAgentOfficeHome_;

const PrivacyPolicyHome = PrivacyPolicyHome_;

const SMSVerification = SMSVerification_;
const SignUpAgent = SignUpAgent_;


export default {
  MainHome,

  SignInHome,
  MainRouteHome,
  AgentDataVerification,
  ForgotPruIDNonAgentHome,
  SecurityQuestions,

  SignUpHome,
  SignUpAgentHome,
  SignUpAgentSFARegHome,
  SignUpNonAgentHome,

  ListPruHospitalHome,
  ListPruAgentOfficeHome,

  PrivacyPolicyHome,

  SMSVerification,
  SignUpAgent,

};
