/**
 * @author: dwi.setiyadi@gmail.com
*/

import { adapter } from '../../config';

export const SIGNINAPI = 'adapters/HTTPAdapterAuth/getToken';
export const SIGNINFETCH = 'SIGNINFETCH';
export const SIGNINSUCCESS = 'SIGNINSUCCESS';
export const SIGNINFAILED = 'SIGNINFAILED';

export const USERPROFILEAPI = 'adapters/HTTPAdapterAuth/getDetailProfile';
export const USERPROFILEFETCH = 'USERPROFILEFETCH';
export const USERPROFILESUCCESS = 'USERPROFILESUCCESS';
export const USERPROFILEFAILED = 'USERPROFILEFAILED';

export const USERAVATARAPI = 'adapters/HTTPAdapterInquiry/downloadImageAgentProfile';
export const USERAVATARFETCH = 'USERAVATARFETCH';
export const USERAVATARSUCCESS = 'USERAVATARSUCCESS';
export const USERAVATARFAILED = 'USERAVATARFAILED';

export const SIGNOUTAPI = 'adapters/HTTPAdapterAuth/getLogout';
export const SIGNOUTFETCH = 'SIGNOUTFETCH';
export const SIGNOUTSUCCESS = 'SIGNOUTSUCCESS';
export const SIGNOUTFAILED = 'SIGNOUTFAILED';

export const VAFETCH = 'VAFETCH';
export const VASUCCESS = 'VASUCCESS';
export const VAFAILED = 'VAFAILED';
export const VAUPDATE = 'VAUPDATE';
export const VAAPI = `${adapter.COMMON}/getListVA`;

export const GETBRANCHMASTERAPI = `${adapter.COMMON}/getBranchMaster`;

export const GETREFERRALAPI = `${adapter.COMMON}/getReferralData`;

// Added

export const HASHINGPASSWORD = 'HASHINGPASSWORD';
export const UPDATEONLINEDATE = 'UPDATEONLINEDATE';
export const UPDATESIGNINDATE = 'UPDATESIGNINDATE';
// Connection
export const CONNECTIONONLINE = 'CONNECTION_ONLINE';
export const CONNECTIONOFFLINE = 'CONNECTION_OFFLINE';
// export const CONNECTIONONLINE = 'CONONLINE';
// export const CONNECTIONOFFLINE = 'CONOFFLINE';
