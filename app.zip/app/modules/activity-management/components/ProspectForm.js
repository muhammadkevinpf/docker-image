import React from 'react';
import { View } from 'native-base';
import {
  InputFieldNew, DropdownNew, DatePickerNew, AutoCompleteNew,
} from '../../../components';
import { ConfigProductSPAJ } from '../../spaj/configs';
import { isEmpty, DatabaseUtils } from '../../../utilities';
import _ from '../../../lang';
import Style from '../../../styles';
import { segmentList } from '../ConfigActivity';

export const ProspectForm = ({
  data = {}, disableName = false, onDataChange = () => { }, isBanca = false,
}) => (
  <React.Fragment>
    <InputFieldNew
      type="name"
      label={_('Nama Nasabah')}
      editable={!disableName}
      value={data.fullName}
      onChangeText={fullName => onDataChange({ fullName })}
    />
    <InputFieldNew value={data.cif} label={_('No. CIF')} isRequired={false} onChangeText={cif => onDataChange({ cif })} keyboardType="phone-pad" />
    {isBanca && (
    <React.Fragment>
      <InputFieldNew
        label={_('REL ID')}
        value={data.relID}
        minLength={13}
        maxLength={13}
        onFocus={() => (isEmpty(data.relID) ? onDataChange({ relID: '01i' }) : {})}
        onChangeText={relID => onDataChange({ relID })}
        isRequired={false}
      />
      <InputFieldNew
        label={_('RMP SID')}
        value={data.rmPsid}
        // minLength={13}
        maxLength={15}
        onFocus={() => (isEmpty(data.rmPsid) ? onDataChange({ rmPsid: '' }) : {})}
        onChangeText={rmPsid => onDataChange({ rmPsid })}
        isRequired={false}
      />
      <InputFieldNew value={data.masterNo} label={_('Master Number')} isRequired={false} onChangeText={masterNo => onDataChange({ masterNo })} />
      <InputFieldNew
        value={data.productNo}
        label={_('Product Account Number')}
        isRequired={false}
        onChangeText={productNo => onDataChange({ productNo })}
      />
    </React.Fragment>
    )}
    {!isBanca && (
    <DropdownNew
      label="Segmen"
      selectedValue={data.segment}
      onValueChange={segment => onDataChange({ segment })}
      dropdownData={segmentList}
      isRequired={false}
    />
    )}
    <View style={[Style.Main.rowDirection]}>
      <View style={[Style.Main.flex3, Style.Main.mr12]}>
        <AutoCompleteNew
          onPress={telCode => onDataChange({ telCode })}
          selectedValue={!isEmpty(data.telCode) ? data.telCode.countryCd : null}
          placeholder={_('Kode')}
          labelProp="descCountry"
          valueProp="countryCd"
          dropdownData={DatabaseUtils.formattedTelCodes()}
          isRequired={false}
        />
      </View>
      <View style={[Style.Main.flex5]}>
        <InputFieldNew
          type="phone"
          label={_('No. Telp')}
          minLength={9}
          maxLength={13}
          value={data.phoneNumber}
          onChangeText={phoneNumber => onDataChange({ phoneNumber })}
          isRequired={false}
        />
      </View>
    </View>
    <DatePickerNew
      defaultDate={data.dob}
      // add minimum date 99 year before requested by mba Astri
      minimumDate={new Date(new Date().getFullYear() - 99, 0, 1)}
      maximumDate={new Date()}
      placeHolderText={!data.dob && 'Tanggal Lahir'}
      label="Tanggal Lahir"
      onDateChange={dob => onDataChange({ dob })}
    />
    <DropdownNew
      label="Pendidikan Formal Terakhir"
      selectedValue={data.edu}
      onValueChange={edu => onDataChange({ edu })}
      dropdownData={ConfigProductSPAJ.eduList}
    />
  </React.Fragment>
);
