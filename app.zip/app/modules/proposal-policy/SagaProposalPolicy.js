/* eslint-disable no-console */
import { takeLatest } from 'redux-saga/effects';
import { apiSagaFunction } from '../../utilities/Functions';
import { proposalPolicyAction } from './ActionProposalPolicy';
import {
  PROPOSAL_POLICY, PROPOSAL_POLICY_FILTER, PROPOSAL_POLICY_UNIT, PROPOSAL_POLICY_UNIT_FILTER,
  PROPOSAL_GRAPH, POLICY_GRAPH, PROPOSAL_POLICY_UPDATED_DATE,
} from './ConfigProposalPolicy';

export const watcherProposalPolicy = [
  takeLatest(PROPOSAL_GRAPH.FETCH, params => apiSagaFunction(params.payload, proposalPolicyAction, PROPOSAL_GRAPH)),
  takeLatest(POLICY_GRAPH.FETCH, params => apiSagaFunction(params.payload, proposalPolicyAction, POLICY_GRAPH)),
  takeLatest(PROPOSAL_POLICY_UPDATED_DATE.FETCH, params => apiSagaFunction(params.payload, proposalPolicyAction, PROPOSAL_POLICY_UPDATED_DATE)),
  takeLatest(PROPOSAL_POLICY.FETCH, params => apiSagaFunction(params.payload, proposalPolicyAction, PROPOSAL_POLICY, { isResponArray: true })),
  takeLatest(PROPOSAL_POLICY_FILTER.FETCH,
    params => apiSagaFunction(params.payload, proposalPolicyAction, PROPOSAL_POLICY_FILTER, { isResponArray: true })),
  takeLatest(PROPOSAL_POLICY_UNIT.FETCH,
    params => apiSagaFunction(params.payload, proposalPolicyAction, PROPOSAL_POLICY_UNIT, { isResponArray: true })),
  takeLatest(PROPOSAL_POLICY_UNIT_FILTER.FETCH,
    params => apiSagaFunction(params.payload, proposalPolicyAction, PROPOSAL_POLICY_UNIT_FILTER, { isResponArray: true })),
];
