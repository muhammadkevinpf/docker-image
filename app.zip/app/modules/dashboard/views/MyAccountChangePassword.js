/* eslint-disable no-console */
/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import CryptoJS from 'crypto-js';
import { connect } from 'react-redux';
import {
  Text, TextInput, Alert, Modal, BackHandler,
} from 'react-native';
import {
  Container, Content,
  Button, View, Icon, Card,
} from 'native-base';
import { CHANGE_PASSWORD_FETCH } from '../ConfigDashboard';
import { changePasswordFetch } from '../ActionDashboard';
import _ from '../../../lang';
import Style from '../../../styles';
import LoadingModal from '../../../components/loading_modal';
import { hashingPassword } from '../../auth/ActionAuth';
import { HeaderWithTodo, SideBarMenu } from '../../../components';
import { requestStatus } from '../../../utilities/ApiConnection';
import { isTablet } from '../../../utilities';

class MyAccountChangePassword extends Component {
  constructor(props) {
    super(props);
    this.state = {
      sandiLama: true,
      currentOldPassword: '',
      // oldPassword: 'A',
      hideOldPassword: true,
      oldPasswordIcon: 'eye-slash',
      newPassword: '',
      hideNewPassword: true,
      newPasswordIcon: 'eye-slash',
      confirmPassword: '',
      hideConfirmPassword: true,
      confirmPasswordIcon: 'eye-slash',
      showConfirm: false,
      isNewPasswordSame: true,
      floatingOldPassword: false,
      oldPasswordPlaceHolder: _('Masukkan Kata Sandi Lama'),
      floatingNewPassword: false,
      newPasswordPlaceHolder: _('Masukkan Kata Sandi Baru'),
      floatingConfirmPassword: false,
      confirmPasswordPlaceHolder: _('Ulangi Kata Sandi Baru'),
      isLoading: false,
    };
  }

  componentDidMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.goBack();
      return true;
    });
  }


  componentWillUnmount() {
    this.backHandler.remove();
  }

  setShowConfirm(visible) {
    this.setState({ showConfirm: visible });
  }

  stopLoading = callback => this.setState({ isLoading: false }, callback);

  changePassword = () => {
    const isPublic = this.props.navigation.getParam('isPublic', false);
    const userName = this.props.navigation.getParam('username', '');
    if (this.props.isOnline || isPublic) {
      if ((this.props.resAuth !== null && this.props.resAuth.userProfile !== undefined) || isPublic) {
        const data = {
          headers: [
            {
              keyHeader: 'X-CSRF-Token',
              valueHeader: `Bearer ${isPublic ? 'undefined' : this.props.resAuth.access_token}`,
            },
          ],
          params: `["${!isPublic ? this.props.resAuth.username : userName}", "${this.state.newPassword}", "${this.state.currentOldPassword}"]`,
        };
        this.props.changePasswordFetch(data);
        this.setState({ isLoading: true });
      } else {
        Alert.alert(_('Peringatan'), _('User profile tidak tersedia'));
      }
    } else {
      Alert.alert(_('Peringatan'), _('Jaringan tidak tersedia. Silakan periksa kembali.'));
    }
  }

  componentDidUpdate = (prevProps) => {
    if (prevProps.apiStatus !== this.props.apiStatus && this.props.apiStatus !== requestStatus.FETCH) {
      this.stopLoading(() => {
        if (this.props.apiStatus === requestStatus.FAILED) Alert.alert(_('Error'), this.props.setting.changePasswordError);
        if (this.props.apiStatus === requestStatus.SUCCESS) {
          this.props.hashingUserPassword(CryptoJS.SHA1(JSON.stringify(this.state.newPassword)).toString());
          Alert.alert('', 'Password berhasil diganti!', [{
            text: 'OK',
            onPress: () => this.goBack(),
          }]);
        }
      });
    }
  }

  goBack = () => {
    const isPublic = this.props.navigation.getParam('isPublic', false);
    if (isPublic) this.props.navigation.replace('SignInHome');
    else if (isTablet()) this.props.navigation.replace('MainDashboard');
    else this.props.navigation.replace('MyAccount');
  }

  checkOldPassword = () => {
    const isPublic = this.props.navigation.getParam('isPublic', false);
    const oldPassword = this.props.navigation.getParam('oldPassword', '');
    if (!isPublic) {
      return this.props.auth.pwd !== CryptoJS.SHA1(JSON.stringify(this.state.currentOldPassword)).toString();
    }
    return oldPassword !== CryptoJS.SHA1(JSON.stringify(this.state.currentOldPassword)).toString();
  }

  render() {
    const ContentTag = isTablet() ? Card : View;
    return (
      <Container style={[isTablet() && Style.Main.rowDirection]}>
        <SideBarMenu visible={isTablet()} navigation={this.props.navigation} />
        <View style={[Style.Main.container]}>
          <LoadingModal show={this.state.isLoading} size="large" color="white" />
          <Modal
            animationType="slide"
            visible={this.state.showConfirm}
            transparent
          >
            <View style={[Style.Main.modalOverlay, Style.Main.justifyCenter]}>
              <View style={[Style.Main.margin10, Style.Main.backgroundWhite,
                Style.Main.borderRadius5, Style.Main.pl12, Style.Main.pr12, Style.Main.pb15, Style.Main.pt15]}
              >
                <View style={[Style.Main.pt0, Style.Main.pl10, Style.Main.pr10, Style.Main.mb12, Style.Main.mt30]}>
                  <Text style={[Style.Main.textAlignCenter, Style.Main.fontAlbert]}>
                    {_('Kata sandi Anda akan berganti dengan kata sandi yang terbaru, apakah anda yakin?')}
                  </Text>
                </View>
                <View style={[Style.Main.dialogBtnCnt, Style.Main.mb10, Style.Main.mt15]}>
                  <Button
                    bordered
                    danger
                    block
                    style={[Style.Main.dialogOutlineBtn, Style.Main.ml12]}
                    onPress={() => {
                      this.setShowConfirm(false);
                    }}
                  >
                    <Text style={[Style.Main.textRed]}>{_('Tidak')}</Text>
                  </Button>
                  <Button
                    style={[Style.Main.btnLanjutkan, Style.Main.dialogBtnwidth]}
                    block
                    onPress={() => {
                      this.setShowConfirm(false);
                      this.changePassword();
                      // this.props.navigation.navigate('MyAccount');
                    }}
                  >
                    <Text style={[Style.Main.font16, Style.Main.textWhite]}>{_('Ya')}</Text>
                  </Button>
                </View>
              </View>
            </View>
          </Modal>
          <HeaderWithTodo
            {...this.props}
            isShowRightButton={false}
            onBackClicked={this.goBack}
            headerTitle="Ubah Password"
          />
          <Content
            style={[isTablet() ? Style.Main.containerWithPaddingTablet : Style.Main.padding12]}
            keyboardDismissMode="on-drag"
            enableResetScrollToCoords={false}
          >
            <ContentTag style={[isTablet() && Style.Main.padding12]}>
              <Text
                style={[Style.Main.gray83, Style.Main.fontAlbert,
                  (this.state.floatingOldPassword)
                    ? Style.Main.displayFlex
                    : Style.Main.displayNone,
                ]}
              >{_('Masukkan Kata Sandi Lama')}
              </Text>
              <View
                style={[Style.Main.rowDirectionSpaceBetween, Style.Main.mt12,
                  (this.state.sandiLama)
                    ? Style.Main.grayBorderBottom
                    : Style.Main.wrongInput,
                ]}
              >
                <TextInput
                  placeholder={this.state.oldPasswordPlaceHolder}
                  style={[Style.Main.padding0, Style.Main.fontAlbert, Style.Main.flexGrow]}
                  secureTextEntry={this.state.hideOldPassword}
                  onChangeText={text => this.setState({ currentOldPassword: text })}
                  onFocus={() => {
                    this.setState({
                      floatingOldPassword: true,
                      oldPasswordPlaceHolder: '',
                    });
                  }}
                  onBlur={() => {
                    if (this.state.currentOldPassword === '') {
                      this.setState({
                        floatingOldPassword: false,
                        oldPasswordPlaceHolder: _('Masukkan Kata Sandi Lama'),
                      });
                    }
                  }}
                />
                <Icon
                  name={this.state.oldPasswordIcon}
                  type="FontAwesome"
                  style={[Style.Main.pickerIcon, Style.Main.mt5]}
                  onPress={() => {
                    if (this.state.hideOldPassword) {
                      this.setState({
                        hideOldPassword: false,
                        oldPasswordIcon: 'eye',
                      });
                    } else {
                      this.setState({
                        hideOldPassword: true,
                        oldPasswordIcon: 'eye-slash',
                      });
                    }
                  }}
                />
              </View>
              <Text
                style={[Style.Main.textRed, Style.Main.font10,
                  (this.state.sandiLama)
                    ? Style.Main.displayNone
                    : Style.Main.displayFlex,
                ]}
              >{_('Kata sandi yang anda masukkan salah. Silakan coba kembali.')}
              </Text>
              <Text
                style={[Style.Main.gray83, Style.Main.mt20, Style.Main.fontAlbert,
                  (this.state.floatingNewPassword)
                    ? Style.Main.displayFlex
                    : Style.Main.displayNone,
                ]}
              >{_('Masukkan Kata Sandi Baru')}
              </Text>
              <View
                style={[Style.Main.rowDirectionSpaceBetween, Style.Main.mt12, Style.Main.grayBorderBottom,
                  (this.state.floatingNewPassword)
                    ? Style.Main.mt0
                    : Style.Main.mt20,
                ]}
              >
                <TextInput
                  placeholder={this.state.newPasswordPlaceHolder}
                  style={[Style.Main.padding0, Style.Main.fontAlbert, Style.Main.flexGrow]}
                  secureTextEntry={this.state.hideNewPassword}
                  onChangeText={text => this.setState({ newPassword: text })}
                  onFocus={() => {
                    this.setState({
                      floatingNewPassword: true,
                      newPasswordPlaceHolder: '',
                    });
                  }}
                  onBlur={() => {
                    if (this.state.newPassword === '') {
                      this.setState({
                        floatingNewPassword: false,
                        newPasswordPlaceHolder: _('Masukkan Kata Sandi Baru'),
                      });
                    }
                  }}
                />
                <Icon
                  name={this.state.newPasswordIcon}
                  type="FontAwesome"
                  style={[Style.Main.pickerIcon, Style.Main.mt5]}
                  onPress={() => {
                    if (this.state.hideNewPassword) {
                      this.setState({
                        hideNewPassword: false,
                        newPasswordIcon: 'eye',
                      });
                    } else {
                      this.setState({
                        hideNewPassword: true,
                        newPasswordIcon: 'eye-slash',
                      });
                    }
                  }}
                />
              </View>
              <Text
                style={[Style.Main.gray83, Style.Main.mt20, Style.Main.fontAlbert,
                  (this.state.floatingConfirmPassword)
                    ? Style.Main.displayFlex
                    : Style.Main.displayNone,
                ]}
              >{_('Ulangi Kata Sandi Baru')}
              </Text>
              <View
                style={[Style.Main.rowDirectionSpaceBetween, Style.Main.mt12, Style.Main.grayBorderBottom,
                  (this.state.floatingConfirmPassword)
                    ? Style.Main.mt0
                    : Style.Main.mt20,
                  (this.state.isNewPasswordSame)
                    ? Style.Main.grayBorderBottom
                    : Style.Main.wrongInput,
                ]}
              >
                <TextInput
                  placeholder={this.state.confirmPasswordPlaceHolder}
                  style={[Style.Main.padding0, Style.Main.fontAlbert, Style.Main.flexGrow]}
                  secureTextEntry={this.state.hideConfirmPassword}
                  onChangeText={text => this.setState({ confirmPassword: text })}
                  onFocus={() => {
                    this.setState({
                      floatingConfirmPassword: true,
                      confirmPasswordPlaceHolder: '',
                    });
                  }}
                  onBlur={() => {
                    if (this.state.confirmPassword === '') {
                      this.setState({
                        floatingConfirmPassword: false,
                        confirmPasswordPlaceHolder: _('Ulangi Kata Sandi Baru'),
                      });
                    }
                  }}
                />
                <Icon
                  name={this.state.confirmPasswordIcon}
                  type="FontAwesome"
                  style={[Style.Main.pickerIcon, Style.Main.mt5]}
                  onPress={() => {
                    if (this.state.hideConfirmPassword) {
                      this.setState({
                        hideConfirmPassword: false,
                        confirmPasswordIcon: 'eye',
                      });
                    } else {
                      this.setState({
                        hideConfirmPassword: true,
                        confirmPasswordIcon: 'eye-slash',
                      });
                    }
                  }}
                />
              </View>
              <Text
                style={[Style.Main.textRed, Style.Main.font10,
                  (this.state.isNewPasswordSame)
                    ? Style.Main.displayNone
                    : Style.Main.displayFlex,
                ]}
              >{_('Kata sandi yang anda masukkan salah. Silakan coba kembali.')}
              </Text>
              <View style={[Style.Main.mt30]}>
                <Button
                  style={[Style.Main.radius8,
                    // eslint-disable-next-line no-nested-ternary
                    (this.state.newPassword === '' || this.state.confirmPassword === '')
                      ? Style.Main.backgroundGrayCe
                      : (this.state.newPassword !== '' && this.state.newPassword !== this.state.confirmPassword)
                        ? Style.Main.backgroundGrayCe
                        : Style.Main.backgroundRed,
                  ]}
                  block
                  onPress={() => {
                    if (this.checkOldPassword()) {
                      this.setState({
                        sandiLama: false,
                      });
                    } else {
                      this.setState({
                        sandiLama: true,
                      });
                      if (this.state.newPassword === '' || this.state.confirmPassword === '') {
                        Alert.alert(_('Peringatan'), _('Password baru wajib diisi'));
                      } else if (this.state.newPassword !== this.state.confirmPassword) {
                        this.setState({
                          isNewPasswordSame: false,
                        });
                      } else {
                        this.setState({
                          showConfirm: true,
                        });
                      }
                    }
                  }}
                >
                  <Text
                    style={[Style.Main.textWhite]}
                  >{_('SIMPAN')}
                  </Text>
                </Button>
              </View>
            </ContentTag>
          </Content>
        </View>
      </Container>
    );
  }
}

const mapStateToProps = state => ({
  auth: state.auth,
  resAuth: state.auth.res,
  apiStatus: state.setting.changePasswordStatus,
  isOnline: state.connectionStatus.isOnline,
  setting: state.setting,
});

const mapDispatchToProps = dispatch => ({
  changePasswordFetch: value => dispatch(changePasswordFetch(CHANGE_PASSWORD_FETCH, value)),
  hashingUserPassword: value => dispatch(hashingPassword(value)),
});

export default connect(mapStateToProps, mapDispatchToProps)(MyAccountChangePassword);
