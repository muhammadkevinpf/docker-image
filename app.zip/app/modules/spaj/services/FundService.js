import { Alert } from 'react-native';
import Caches from '../../../utilities/Caches';

function getFundList(agent, category, product, currency, func) {
  let fundList = [];
  const fundMaster = Caches.get('fund').FUND;
  try {
    if (agent && category && product) {
      let curr = '';
      if (!currency) {
        curr = 'IDR';
      } else {
        curr = currency;
      }
      const fundTypes = Caches.get('channel').CHANNEL[agent].PRODUCT_CATEGORY
        .find(item => item.code === category).PRODUCT
        .find(item => item.code === product).CURRENCY
        .find(item => item.code === curr).FUND;
      fundTypes.map((item) => {
        if (fundMaster[item]) {
          fundList = [...fundList, {
            code: fundMaster[item].code,
            descriptionInd: fundMaster[item].descriptionInd,
            type: fundMaster[item].fundRisk,
            choosedTopUp: false,
            choosed: false,
            value: 0,
            valueTopUp: 0,
          }];
        }
        return fundList;
      });
    }
  } catch (error) {
    Alert.alert('Kesalahan', 'Terjadi kesalahan saat mencari data FUND!', [{ text: 'Tutup', onPress: func }], { cancelable: false });
  }
  return fundList;
}

function getFundMaster(agent, category, product, currency, func) {
  let curr = '';
  if (!currency) {
    curr = 'IDR';
  } else {
    curr = currency;
  }
  const fundList = getFundList(agent, category, product, curr, func);
  const fundModerat = fundList.filter(item => item.type === 'moderat');
  const fundKonservatif = fundList.filter(item => item.type === 'konservatif');
  const fundAgresif = fundList.filter(item => item.type === 'agresif');
  const fundMaster = [
    {
      fundRisk: 'konservatif',
      fundList: fundKonservatif,
      percent: 0,
      percentTopUp: 0,
    }, {
      fundRisk: 'moderat',
      fundList: fundModerat,
      percent: 0,
      percentTopUp: 0,
    }, {
      fundRisk: 'agresif',
      fundList: fundAgresif,
      percent: 0,
      percentTopUp: 0,
    },
  ];
  return fundMaster;
}

export default {
  getFundList,
  getFundMaster,
};
