import FeedbackHistoryList from './feedback-history/FeedbackHistoryList';
import FeedbackHistoryDetail from './feedback-history/FeedbackHistoryDetail';
import AttachmentPreview from './feedback-history/AttachmentPreview';

export default {
  FeedbackHistoryList,
  FeedbackHistoryDetail,
  AttachmentPreview,
};
