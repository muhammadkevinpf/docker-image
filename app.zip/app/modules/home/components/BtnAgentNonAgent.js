/* eslint-disable import/no-cycle */
/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import {
  Container,
  Content, Button, Text, Title,
} from 'native-base';
import { Grid, Row, Col } from 'react-native-easy-grid';
import Header from '../../../components/header';
import Btn from '../../../components/header/Btn';
import _ from '../../../lang';
import Style from '../../../styles/index';

class BtnAgentNonAgent extends Component {
  render() {
    return (
      <Container style={Style.Main.backgroundRed}>

        <Header
          borderBottom={false}
          leftContent={
            <Btn
              icon="angle-left"
              link={this.props.backLink}
              iconStyle={Style.Main.iconHeaderLeft}
            />
            // <Button transparent onPress={this.props.backLink} style={[Style.Main.textLeft, Style.Main.pb0]}>
            //   <Icon name="angle-left" style={[Style.Main.iconHeaderLeft, Style.Main.textWhite, Style.Main.mt5]} />
            // </Button>
            }
          bodyContent={
            <Title style={Style.Main.textCenter}>
              {this.props.title}
            </Title>
          }
        />

        <Content keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
          <Grid>
            <Row>
              {/* <ComponentsHome.LogoForm /> */}
            </Row>

            <Row>
              <Col>
                <Button
                  block
                  onPress={this.props.agentLink}
                  style={[Style.Main.btnSecondary, Style.Main.mt15, Style.Main.mr30, Style.Main.ml30]}
                >
                  <Text style={[Style.Main.fontRegular, Style.Main.textRed]}>
                    {_('AGEN')}
                  </Text>
                </Button>
              </Col>
            </Row>
            <Row>
              <Col>
                <Button
                  block
                  onPress={this.props.nonAgentLink}
                  style={[Style.Main.btnSecondary, Style.Main.mt15, Style.Main.mr30, Style.Main.ml30]}
                >
                  <Text style={[Style.Main.fontRegular, Style.Main.textRed]}>
                    {_('CALON AGEN')}
                  </Text>
                </Button>
              </Col>
            </Row>
          </Grid>
        </Content>
      </Container>
    );
  }
}

export default BtnAgentNonAgent;
