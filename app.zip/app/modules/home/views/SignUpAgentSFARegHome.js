/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import {
  TextInput, Image, View, KeyboardAvoidingView, BackHandler,
} from 'react-native';
import {
  Container,
  Content, Button, Text, DatePicker, Icon,
} from 'native-base';
import _ from '../../../lang';
import Style from '../../../styles';
// import ornamen from '../../../assets/images/ornamen.png';
import bg from '../../../assets/images/bg.png';

class SignUpAgentSFARegHome extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
    this.setDate = this.setDate.bind(this);
  }

  componentDidMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleBack();
      return true;
    });
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  setDate() {
    this.setState({ });
  }

  handleBack = () => {
    this.props.navigation.replace('SignUpAgentHome');
  }

  render() {
    return (
      <Container>
        <Image source={bg} style={Style.Main.bgImage} />
        <View>
          <Button
            transparent
            iconLeft
            onPress={() => this.props.navigation.replace('SignUpAgentHome')}
          >
            <Icon name="angle-left" type="FontAwesome" style={[Style.Main.textRed]} />
            <Text style={[Style.Main.textRed]}>{_('Back')}</Text>
          </Button>
        </View>
        <Content keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
          <Text
            style={[Style.Main.font44, Style.Main.textRed, Style.Main.mt64, Style.Main.textAlignCenter, Style.Main.fontBold, Style.Main.mb55]}
          >PRUFast
          </Text>
          <Text
            style={[Style.Main.font18, Style.Main.textColor3f3, Style.Main.textAlignCenter]}
          >{_('Verifikasi Data Agen')}
          </Text>
          <View
            style={[Style.Main.container, Style.Main.mt30]}
          >
            <KeyboardAvoidingView>
              <TextInput
                style={[Style.Main.container, Style.Main.grayBorderBottom, Style.Main.pb5, Style.Main.alignCenter, Style.Main.width187]}
                keyboardAppearance="default"
                keyboardType="default"
                returnKeyType="done"
                maxLength={15}
                placeholder={_('Kode Agen')}
                value={this.state.userID}
              />
            </KeyboardAvoidingView>
          </View>
          <View
            style={[Style.Main.grayBorderBottom, Style.Main.width187, Style.Main.alignCenter, Style.Main.mt30]}
          >
            <DatePicker
              defaultDate={new Date().setFullYear(new Date().getFullYear() - 17)}
              maximumDate={new Date().setFullYear(new Date().getFullYear() - 17)}
              locale="id"
              timeZoneOffsetInMinutes={undefined}
              modalTransparent={false}
              animationType="fade"
              androidMode="spinner"
              placeHolderText="Tanggal Lahir"
              textStyle={[Style.Main.container, Style.Main.font14, Style.Main.pb0, Style.Main.pt0,
                Style.Main.pl0, Style.Main.pr0, Style.Main.textBrightGray, Style.Main.width187]}
              placeHolderTextStyle={[Style.Main.container, Style.Main.font14, Style.Main.pb0, Style.Main.pt0,
                Style.Main.pl0, Style.Main.pr0, Style.Main.textBrightGray, Style.Main.width187]}
              disabled={false}
            />
          </View>
          <View
            style={[Style.Main.container, Style.Main.mt30]}
          >
            <KeyboardAvoidingView>
              <TextInput
                style={[Style.Main.container, Style.Main.grayBorderBottom, Style.Main.pb5, Style.Main.alignCenter, Style.Main.width187]}
                keyboardAppearance="default"
                keyboardType="number-pad"
                returnKeyType="done"
                maxLength={15}
                placeholder={_('Nomor KTP')}
                value={this.state.userID}
              />
            </KeyboardAvoidingView>
          </View>
          <View
            style={[Style.Main.container, Style.Main.mt30]}
          >
            <TextInput
              style={[Style.Main.container, Style.Main.grayBorderBottom, Style.Main.pb5, Style.Main.alignCenter, Style.Main.width187]}
              keyboardAppearance="default"
              keyboardType="phone-pad"
              returnKeyType="done"
              maxLength={14}
              placeholder={_('Nomor Handphone Terdaftar')}
              value={this.state.userID}
            />
          </View>
          <View
            style={[Style.Main.container]}
          >
            <Button
              rounded
              danger
              style={[Style.Main.alignCenter, Style.Main.backgroundRed, Style.Main.mt20,
                Style.Main.width187, Style.Main.dialogBtnCnt, Style.Main.itemCenter]}
              onPress={this.handleNavigation}
            >
              <Text
                style={[Style.Main.textWhite]}
              >{_('Masuk')}
              </Text>
            </Button>
          </View>
        </Content>
      </Container>
    );
  }
}

export default SignUpAgentSFARegHome;
