/**
 * @author:
 * ahmdichsanb@gmail.com
*/

import React, { PureComponent } from 'react';
import {
  Modal,
  TouchableOpacity,
} from 'react-native';
import PropTypes from 'prop-types';

import StyleModalCustom from './StyleModalCustom';

class ModalCustom extends PureComponent {
  render() {
    const {
      isVisible, content, animationType,
    } = this.props;
    return (
      <Modal
        transparent
        visible={isVisible}
        animationType={animationType}
      >
        <TouchableOpacity
          style={[StyleModalCustom.container]}
          onPress={() => this.props.onPress()}
          activeOpacity={1}
        >
          {content}
        </TouchableOpacity>
      </Modal>
    );
  }
}

ModalCustom.propTypes = {
  content: PropTypes.element.isRequired,
  animationType: PropTypes.string.isRequired,
  isVisible: PropTypes.bool.isRequired,
  onPress: PropTypes.func.isRequired, // required to close the modal by clicking on the transparent area, just past setState to close the modal
};

export default ModalCustom;
