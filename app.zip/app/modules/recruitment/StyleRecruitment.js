/**
 * @author:
 * ecomindo
*/


import { StyleSheet, Platform } from 'react-native';
import { dimensions } from '../../config/Platform';
import Styles from '../../styles';

let PickerInput = {};
switch (Platform.OS) {
  case 'ios':
    PickerInput = {
      width: dimensions.screenWidth - 15,
      marginLeft: -15,
    };
    break;

  case 'android':
    PickerInput = {
      width: dimensions.screenWidth - 43,
      marginLeft: -8,
      marginRight: -15,
      color: Styles.Color.lightGray,
    };
    break;

  default:
    break;
}

export default StyleSheet.create({
  leftIconFooter: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  rightTitleFooter: {
    justifyContent: 'center',
  },
  flex1: {
    flex: 1,
  },
  borderRadius0: {
    borderRadius: 0,
  },
  PickerInput,
  iOSPickerIcon: {
    marginRight: 0,
    fontSize: 14,
  },
  leftCardHeader: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  contentCardHeader: {
    justifyContent: 'center',
  },
  subHeader: {
    backgroundColor: Styles.Color.darkWhite,
    padding: 15,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderStyle: 'solid',
    borderBottomColor: Styles.Color.lightGray,
  },
});
