import CarouselDashboard_ from './CarouselDashboard';
import SegmentAccorProduction_ from './SegmentAccorProduction';
import GaugeChartDashboard_ from './GaugeChartDashboard';
import LineChartPHDashboard_ from './LineChartPHDashboard';

const CarouselDashboard = CarouselDashboard_;
const SegmentAccorProduction = SegmentAccorProduction_;
const GaugeChartDashboard = GaugeChartDashboard_;
const LineChartPHDashboard = LineChartPHDashboard_;

export default {
  CarouselDashboard,
  SegmentAccorProduction,
  GaugeChartDashboard,
  LineChartPHDashboard,
};
