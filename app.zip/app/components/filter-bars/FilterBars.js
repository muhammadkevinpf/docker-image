import { Icon, Text } from 'native-base';
import {
  StyleSheet, TouchableOpacity, View, Modal, SafeAreaView,
} from 'react-native';
import React from 'react';
import PropTypes from 'prop-types';
import Style from '../../styles';
import { isEmpty } from '../../utilities';
import { StyledText } from '../common-components';
import _ from '../../lang';

/**
 * A PRUFast component to filter data through a set of filter bars.
 * Usage example:
 * ``` js
 * <FilterBars onChange={(activeKeys, activeFilters) => this.setState({ activeFilters })} list={[{ key: 0, label: 'Some Label' }]}/>
 * ```
 *
 * @augments {React.PureComponent<Props, State>}
 */

class FilterBars extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      activeBars: [],
      showModal: false,
    };
  }

  onModalDismiss = () => this.setState({ showModal: false });

  onChange = (obj, isActive) => {
    this.setState((prevState) => {
      let selected = prevState.activeBars;
      if (isActive) selected = selected.filter(y => y !== obj.key);
      else {
        const unsortActiveBars = isEmpty(selected) ? [obj.key] : [...selected, obj.key];
        selected = unsortActiveBars.sort((a, b) => b - a);
      }
      return { activeBars: selected };
    }, () => this.props.onChange(this.state.activeBars, this.props.list.filter(item => this.state.activeBars.some(key => key === item.key))));
  }

  renderFilters = (filters, isModal) => {
    const { activeBars } = this.state;
    const { maxHeight } = this.props;
    return (
      <View style={[isModal ? Style.Main.autoHeight : Style.Main.container, Style.Main.rowDirection, Style.Main.flexWrap,
        maxHeight && !isModal && [Style.Main.overflowHide, Style.Main.mb5, { maxHeight }]]}
      >
        <TouchableOpacity
          style={[styles.bar, Style.Main.ml0, !isEmpty(activeBars) && styles.activeBar, isModal && Style.Main.mb15]}
          onPress={() => (
            isModal ? this.setState({ activeBars: [] }, () => this.props.onChange(this.state.activeBars, this.props.list))
              : this.setState({ showModal: true })
          )}
        >
          {isEmpty(activeBars) && <Icon type="FontAwesome5" name="ellipsis-v" style={[Style.Main.mr5, styles.text, Style.Main.font9]} />}
          <Text style={[styles.text, !isEmpty(activeBars) && styles.activeText]}>{!isEmpty(activeBars) ? `${activeBars.length} ` : ''}Filter</Text>
        </TouchableOpacity>
        {
          filters.map((x) => {
            const isActive = !isEmpty(activeBars) && activeBars.includes(x.key);
            return (
              <TouchableOpacity
                key={x.key}
                style={[styles.bar, isActive && styles.activeBar, isModal && Style.Main.mb15]}
                onPress={() => this.onChange(x, isActive)}
              >
                <Text style={[styles.text, isActive && styles.activeText]}>{x.label}</Text>
              </TouchableOpacity>
            );
          })
        }
      </View>
    );
  }

  render() {
    const { activeBars } = this.state;
    const { list, maxBars, sortList } = this.props;
    const sortedList = sortList && !isEmpty(activeBars) ?
      list.sort((a, b) => activeBars.findIndex(x => x === b.key) - activeBars.findIndex(x => x === a.key) || a.key - b.key) : list;
    const filters = sortedList.length > maxBars ? sortedList.slice(0, maxBars) : sortedList;
    return (
      <View style={[Style.Main.container]}>
        {this.renderFilters(filters)}
        <Modal animationType="fade" transparent visible={this.state.showModal} onRequestClose={this.onModalDismiss}>
          <SafeAreaView style={Style.Main.container}>
            <TouchableOpacity onPress={this.onModalDismiss} style={[Style.Main.container, Style.Main.justifyBottom, Style.Main.backgroundLightSmoke]}>
              <TouchableOpacity
                onPress={() => {}}
                activeOpacity={1}
                style={[Style.Main.backgroundWhiteSmoke, Style.Main.autoHeight, Style.Main.padding12, Style.Main.pb30]}
              >
                <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.mb20]}>
                  <StyledText font={14} bold style={[Style.Main.mb3]}>{_('Menu Lainnya')}</StyledText>
                  <View style={[Style.Main.horizontalLine, Style.Main.ml15]} />
                  <Icon type="MaterialCommunityIcons" name="close" onPress={this.onModalDismiss} font={12} style={[Style.Main.pl15]} />
                </View>
                {this.renderFilters(list, true)}
              </TouchableOpacity>
            </TouchableOpacity>
          </SafeAreaView>
        </Modal>
      </View>
    );
  }
}

FilterBars.propTypes = {
  /** Array of filter: { key: numericacalKey, label: someLabel } */
  list: PropTypes.arrayOf(PropTypes.object).isRequired,
  /** Does the filter list need to be sorted based on whether it's active or not? */
  sortList: PropTypes.bool,
  /** Maximum number of filters shown. (default: 4 for mobile, 6 for tablet) */
  maxBars: PropTypes.number,
  maxHeight: PropTypes.number,
  /** Consists of two arguments, namely an array of selected keys and an array of selected objects. Example:
   * ```js
   * onChange = (selectedKeys, selectedObjects) => console.log("Filters selected: ", selectedObjects);
   * ```
   */
  onChange: PropTypes.func,
};

FilterBars.defaultProps = {
  maxBars: 4,
  maxHeight: null,
  sortList: false,
  onChange: (selectedKeys, selectedObjects) => console.log('Filters selected: ', selectedObjects),
};

const styles = StyleSheet.create({
  bar: {
    ...Style.Main.backgroundWhite,
    ...Style.Main.rowDirection,
    ...Style.Main.center,
    ...Style.Main.mb5,
    ...Style.Main.mr5,
    ...Style.Main.ph15,
    ...Style.Main.pv5,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: Style.Color.nativeBaseBorderGray,
  },
  text: {
    ...Style.Main.fontAlbert11,
    ...Style.Main.textAlignVerticalCenter,
    color: Style.Color.gray83,
  },
  activeBar: {
    backgroundColor: Style.Color.ffe2e5,
    borderColor: Style.Color.red,
  },
  activeText: {
    ...Style.Main.textRed,
  },
});

export default FilterBars;
