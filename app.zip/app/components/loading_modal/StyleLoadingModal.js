/**
 * @author: dwi.setiyadi@gmail.com
*/

import { StyleSheet, Dimensions } from 'react-native';
import Style from '../../styles';

const dimensions = Dimensions.get('screen');

export default StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Style.Color.lightSmoke,
    minHeight: (dimensions.height >= dimensions.width ? dimensions.height : dimensions.width),
  },
  loading: {
    width: 120,
    height: 120,
  },
  containerSpinner: {
    position: 'absolute',
    zIndex: 999,
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Style.Color.lightModal,
    minHeight: (dimensions.height >= dimensions.width ? dimensions.height : dimensions.width),
  },
});
