/* eslint-disable react/no-array-index-key */
import React from 'react';
import PropTypes from 'prop-types';
import {
  TouchableOpacity, Modal, SafeAreaView, Platform,
} from 'react-native';
import { DragContainer } from 'react-native-drag-drop-and-swap';
import { connect } from 'react-redux';
import {
  View, Thumbnail, Text, Icon,
} from 'native-base';
import {
  iconProduction, iconPersistency, iconSqs, iconStatus, iconClientList, iconIncome, iconCounterOffer,
  iconCommision, iconOthers, iconTodo, iconRss, iconOCR, iconRecrutmen, iconFeedback, iconCorrespondence, iconLeads, iconPruexpertModule,
  iconDictionary,
} from '../../assets/images';
import { isTablet, isMenuActive } from '../../utilities';
import { dimensions } from '../../config/Platform';
import { tabSizeRef, AgentScopes } from '../../config/Constants';
import { trackerAddStack } from '../../modules/todo-list/ActionTodoList';
import { updateDashboardIcons } from '../../modules/dashboard/ActionDashboard';
import Draggy from '../../modules/dashboard/components/Draggy';
import MyAccount from '../../modules/dashboard/views/MyAccount';
import LoadingModal from '../loading_modal';
import OutlineIconButton from '../outline-iconbutton';
import myAccount from '../../assets/images/icon-account.png';
import Style from '../../styles';
import _ from '../../lang';
import { setSidebarWidth } from '../../bootstrap/container/ActionContainer';
import NavigationService from '../../bootstrap/NavigationService';

const route = {
  PRODUCTION: 'MainProduction',
  PERSISTENCY: 'MainPersistency',
  SQS: 'LandingPageSQSNSpaj',
  STATUS: 'MainProposalPolicy',
  CLIENT: 'ClientList',
  INCOME: 'MainIncomeStatement',
  COMMISSION: 'MainCommissionEstimation',
  TODO: 'MainTodoList',
  NEWS: 'NewsList',
  OCR: 'OcrResearch',
  RECRUITMEN: 'LandingPageRecruitment',
  FEEDBACK: 'FeedbackHistoryList',
  CORRESPONDENCE: 'CorrespondenceList',
  ACTIVITY: 'ProspectList',
  PRUEXPERT: 'MainPruexpert',
  DICTIONARY: 'Dictionary',
};


const deviceHeight = isTablet() && dimensions.height > dimensions.width ? dimensions.width : dimensions.height;

class SideBarMenu extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      showMyAccount: false,
      showModal: false,
    };
  }

  componentDidMount = () => this.checkDashboardIcons()

  checkDashboardIcons = async () => {
    // if you want to add new icons, don't forget to regist another properties (label, image, route)
    // go to func renderDashboardIcons
    const initialDashboardIcons = [
      { id: 0, code: '0' },
      { id: 1, code: '1' },
      { id: 2, code: '2' },
      { id: 3, code: '3' },
      { id: 4, code: '4' },
      { id: 8, code: '8' },
      { id: 12, code: '12' },
      { id: 7, code: '7' },
      { id: 5, code: '5' },
      // { id: 6, code: '6' },
      { id: 10, code: '10' },
      { id: 11, code: '11' },
      { id: 9, code: '9' },
      { id: 13, code: '13' },
      { id: 14, code: '14' },
      { id: 15, code: '15' },
      { id: 16, code: '16' },
      { id: 17, code: '17' },
    ];

    if (!this.props.dashboard.dashboardIcons || this.props.dashboard.dashboardIcons.length === 0) {
      this.props.updateDashboardIcons(initialDashboardIcons);
    } else if (initialDashboardIcons.length > this.props.dashboard.dashboardIcons.length) {
      const iconArray = [...this.props.dashboard.dashboardIcons];
      const newIcons = initialDashboardIcons.filter(x => !this.props.dashboard.dashboardIcons.map(y => y.code).includes(x.code));

      iconArray.push(...newIcons);
      this.props.updateDashboardIcons(iconArray);
    } else if (initialDashboardIcons.length < this.props.dashboard.dashboardIcons.length) {
      const iconArray = this.props.dashboard.dashboardIcons.filter(x => initialDashboardIcons.map(y => y.code).includes(x.code));
      this.props.updateDashboardIcons(iconArray);
    }
  }

  isIndividu = () => {
    if (this.props.resAuth && (this.props.resAuth.agent_scope === AgentScopes.individu
      // Please delete this condition if PS is ready
      || !this.props.resAuth.agent_scope)) return true;
    return false;
  }

  isUserProfileExist = () => {
    if (this.props.resAuth && this.props.resAuth.userProfile) return true;
    return false;
  }

  renderDashboardIcons = () => {
    const { dashboardIcons } = this.props.dashboard;
    const isUserProfileExist = this.isUserProfileExist();
    const newIcons = dashboardIcons.map((item) => {
      let label = '';
      let iconImage = '';
      let onPress = () => { };
      let disable = false;
      let isAnalytical = true;
      switch (item.code) {
        case '0':
          disable = !isUserProfileExist || !isMenuActive(this.props.resAuth.mobileMenu, 'PD_MODULE_PRODUCTION');
          label = 'Produksi';
          iconImage = iconProduction;
          onPress = this.props.navigation.state.routeName === route.PRODUCTION ? () => { } : () => {
            this.props.trackerAddStack({
              route: route.PRODUCTION,
            });
            NavigationService.resetTo(route.PRODUCTION);
          };
          break;
        case '1':
          disable = !isUserProfileExist || !isMenuActive(this.props.resAuth.mobileMenu, 'PD_MODULE_PERSISTENCY');
          label = 'Persistensi';
          iconImage = iconPersistency;
          onPress = this.props.navigation.state.routeName === route.PERSISTENCY ? () => { } : () => {
            this.props.trackerAddStack({
              route: route.PERSISTENCY,
            });
            NavigationService.resetTo(route.PERSISTENCY);
          };
          break;
        case '2':
          disable = !isUserProfileExist || !isMenuActive(this.props.resAuth.mobileMenu, 'PD_MODULE_NEW_SQS');
          label = 'e-SQS & e-SPAJ';
          iconImage = iconSqs;
          onPress = this.props.navigation.state.routeName === route.SQS ? () => { } : () => {
            // this.props.trackerAddStack({
            //   route: route.SQS,
            // });
            NavigationService.resetTo(route.SQS);
          };
          break;
        case '3':
          disable = !isUserProfileExist || !isMenuActive(this.props.resAuth.mobileMenu, 'PD_MODULE_POLICY_DASHBOARD');
          label = 'Status';
          iconImage = iconStatus;
          onPress = this.props.navigation.state.routeName === route.STATUS ? () => { } : () => {
            this.props.trackerAddStack({
              route: route.STATUS,
            });
            NavigationService.resetTo(route.STATUS);
          };
          break;
        case `${isTablet() ? 7 : 4}`:
          disable = !isUserProfileExist || !isMenuActive(this.props.resAuth.mobileMenu, 'PD_MODULE_CLIENT_LIST');
          label = 'Daftar Nasabah';
          iconImage = iconClientList;
          onPress = this.props.navigation.state.routeName === route.CLIENT ? () => { } : () => {
            this.props.trackerAddStack({
              route: route.CLIENT,
            });
            NavigationService.resetTo(route.CLIENT);
          };
          break;
        case '5':
          disable = !isUserProfileExist || !isMenuActive(this.props.resAuth.mobileMenu, 'PD_MODULE_ACHIEVEMENT');
          label = 'Pendapatan';
          iconImage = iconIncome;
          onPress = this.props.navigation.state.routeName === route.INCOME ? () => { } : () => {
            this.props.trackerAddStack({
              route: route.INCOME,
            });
            NavigationService.resetTo(route.INCOME);
          };
          break;
        case '6':
          disable = !isUserProfileExist || !isMenuActive(this.props.resAuth.mobileMenu, 'PD_MODULE_COMMISSION_ESTIMATION');
          label = 'Estimasi Komisi';
          iconImage = iconCommision;
          onPress = this.props.navigation.state.routeName === route.COMMISSION ? () => { } : () => {
            this.props.trackerAddStack({
              route: route.COMMISSION,
            });
            NavigationService.resetTo(route.COMMISSION);
          };
          break;
        case `${isTablet() ? 4 : 7}`:
          label = 'Lainnya';
          iconImage = iconOthers;
          onPress = () => { this.setState({ showModal: true }); };
          isAnalytical = false;
          break;
        case '8':
          disable = !isUserProfileExist || !isMenuActive(this.props.resAuth.mobileMenu, 'PD_MODULE_TODO');
          label = 'Daftar Tugas';
          iconImage = iconTodo;
          onPress = this.props.navigation.state.routeName === route.TODO ? () => { }
            : () => {
              const { trackerTodo = [] } = this.props;
              const trackerFilltered = trackerTodo.filter(x => x.route === this.props.navigation.state.routeName);
              // if (trackerFilltered.length < 1) {
              //   this.props.trackerAddStack({
              //     route: this.props.navigation.state.routeName,
              //   });
              // } else
              if (trackerFilltered.length > 0) {
                if (trackerFilltered[trackerFilltered.length - 1].param) {
                  this.props.trackerAddStack({
                    route: this.props.navigation.state.routeName,
                    param: trackerFilltered[trackerFilltered.length - 1].param,
                  });
                }
              } else {
                this.props.trackerAddStack({
                  route: this.props.navigation.state.routeName,
                });
              }
              if (this.props.navigation.state.params) {
                this.props.trackerAddStack({
                  route: route.TODO,
                  param: {
                    ...this.props.navigation.state.params,
                  },
                });
              } else {
                this.props.trackerAddStack({
                  route: route.TODO,
                });
              }
              NavigationService.resetTo(route.TODO);
            };
          break;
        case '9':
          disable = !isUserProfileExist || !isMenuActive(this.props.resAuth.mobileMenu, 'PD_MODULE_NEWS_UPDATE');
          label = 'Berita Terbaru';
          iconImage = iconRss;
          onPress = this.props.navigation.state.routeName === route.NEWS ? () => { } : () => {
            this.props.trackerAddStack({
              route: route.NEWS,
            });
            NavigationService.resetTo(route.NEWS);
          };
          break;
        case '10':
          disable = true;
          label = 'Simulasi OCR';
          iconImage = iconOCR;
          onPress = this.props.navigation.state.routeName === route.OCR ? () => { } : () => {
            this.props.trackerAddStack({
              route: route.OCR,
            });
            NavigationService.resetTo(route.OCR);
          };
          break;
        case '11':
          disable = !isUserProfileExist || !isMenuActive(this.props.resAuth.mobileMenu, 'PD_MODULE_RECRUITMENT');
          label = 'Rekrutmen';
          iconImage = iconRecrutmen;
          onPress = this.props.navigation.state.routeName === route.RECRUITMEN ? () => { } : () => {
            this.props.trackerAddStack({
              route: route.RECRUITMEN,
            });
            NavigationService.resetTo(route.RECRUITMEN);
          };
          break;
        case '12':
          disable = !isUserProfileExist || !isMenuActive(this.props.resAuth.mobileMenu, 'PD_MODULE_FEEDBACK_FORM');
          label = 'Pertanyaan dan Masukan';
          iconImage = iconFeedback;
          onPress = this.props.navigation.state.routeName === route.FEEDBACK ? () => { } : () => {
            this.props.trackerAddStack({
              route: route.FEEDBACK,
            });
            NavigationService.resetTo(route.FEEDBACK);
          };
          break;
        case '13':
          disable = !isUserProfileExist || !isMenuActive(this.props.resAuth.mobileMenu, 'PD_MODULE_CORRESPONDENCE');
          label = 'Dokumen';
          iconImage = iconCorrespondence;
          // eslint-disable-next-line max-len
          onPress = this.props.navigation.state.routeName === route.CORRESPONDENCE ? () => { } : () => {
            this.props.trackerAddStack({
              route: route.CORRESPONDENCE,
            });
            NavigationService.resetTo(route.CORRESPONDENCE);
          };
          break;
        case '14':
          disable = !isUserProfileExist || !isMenuActive(this.props.resAuth.mobileMenu, 'PD_MODULE_ACTIVITY_MANAGEMENT');
          label = 'Leads';
          iconImage = iconLeads;
          // eslint-disable-next-line max-len
          onPress = this.props.navigation.state.routeName === route.ACTIVITY ? () => { } : () => {
            this.props.trackerAddStack({
              route: route.ACTIVITY,
            });
            NavigationService.resetTo(route.ACTIVITY);
          };
          break;
        case '15':
          disable = !isUserProfileExist || !isMenuActive(this.props.resAuth.mobileMenu, 'PD_MODULE_COUNTER_OFFER');
          label = 'Dokumen Susulan';
          iconImage = iconCounterOffer;
          // eslint-disable-next-line max-len
          onPress = this.props.navigation.state.routeName === route.SQS ? () => { } : () => {
            // this.props.trackerAddStack({
            //   route: route.SQS,
            // });
            NavigationService.resetTo(route.SQS, { isCounterOffer: true });
          };
          break;
        case '16':
          disable = !isUserProfileExist || !isMenuActive(this.props.resAuth.mobileMenu, 'PD_MODULE_PRUEXPERT');
          label = _('PRUExpert');
          iconImage = iconPruexpertModule;
          onPress = this.props.navigation.state.routeName === route.PRUEXPERT ? () => { } : () => {
            // this.props.trackerAddStack({
            //   route: route.PRUEXPERT,
            // });
            NavigationService.resetTo(route.PRUEXPERT);
          };
          break;
        case '17':
          // disable = !isUserProfileExist || !isMenuActive(this.props.resAuth.mobileMenu, 'PD_MODULE_PRUEXPERT');
          label = _('Glosarium');
          iconImage = iconDictionary;
          onPress = this.props.navigation.state.routeName === route.DICTIONARY ? () => { } : () => {
            this.props.trackerAddStack({
              route: route.DICTIONARY,
            });
            NavigationService.resetTo(route.DICTIONARY);
          };
          break;
        default:
          console.log('code not found!');
          break;
      }

      return {
        ...item, label, iconImage, onPress, disable, isAnalytical,
      };
    });

    return newIcons;
  }

  onDrop = async (data) => {
    const { dashboardIcons } = this.props.dashboard;
    const newDashboardIcons = dashboardIcons.map((item) => {
      if (item.id === data.id) {
        return this.state.hoverDataIndex !== -1 ? this.state.hoverData : data;
      }
      if (item.id === this.state.hoverData.id) {
        return data;
      }
      return item;
    });
    await this.props.updateDashboardIcons(newDashboardIcons);
    this.setState({ hoverData: {}, hoverDataIndex: -1 });
  }

  onHover = (hoverData, hoverDataIndex) => {
    this.setState({ hoverData, hoverDataIndex });
  }

  handleDropAnywhere = () => this.setState({ hoverData: {}, hoverDataIndex: -1 })

  renderHeaderArt = () => {
    if (isTablet()) return null;
    return <View style={[Style.Main.headerArt]} />;
  }

  renderModalTitle = () => {
    const tabletStyle = [
      Style.Main.rowDirectionSpaceBetween, Style.Main.mb20,
      Style.Main.mt10, Style.Main.mt30, Style.Main.mr10,
    ];

    return (
      <View style={isTablet() ? tabletStyle : null}>
        {
          isTablet() && (
            <View style={[Style.Main.flex3]}>
              <TouchableOpacity
                onPress={() => this.setState({ showModal: false, onEditIcons: false })}
              >
                <Icon name="angle-left" type="FontAwesome" style={[Style.Main.textRed, Style.Main.ml12]} />
              </TouchableOpacity>
            </View>
          )
        }
        <View style={[isTablet() && Style.Main.flex3]}>
          <Text style={[Style.Main.mb5, Style.Main.textAlignCenter, Style.Main.font12, Style.Main.textRed]}>{_('Main Dashboard')}</Text>
        </View>
        <View style={[
          Style.Main.rowDirectionFlexEnd,
          !isTablet() && Style.Main.mr30,
          !isTablet() && Style.Main.mb20,
          isTablet() && Style.Main.flex3,
        ]}
        >
          <Icon
            name={this.state.onEditIcons ? 'check' : 'edit'}
            type={this.state.onEditIcons ? 'Octicons' : 'MaterialIcons'}
            style={[Style.Main.font18, Style.Main.textRed]}
          />
          <Text
            style={[
              // Style.Main.textAlignCenter,
              Style.Main.font12, Style.Main.textRed,
            ]}
            onPress={() => this.setState((prevState => ({ onEditIcons: !prevState.onEditIcons })))}
          >{this.state.onEditIcons ? _('  Simpan') : _('  Edit')}
          </Text>
        </View>
      </View>
    );
  }

  renderMenuModal = () => (
    <Modal
      animationType="slide"
      transparent
      visible={!isTablet() && this.state.showModal}
      presentationStyle="overFullScreen"
      onShow={() => { }}
    >
      <SafeAreaView style={[Style.Main.flex1]}>
        <View style={[Style.Main.calcModal]}>
          <TouchableOpacity style={[Style.Main.modalWidget]} onPress={() => this.setState({ showModal: false })} />
          <View style={[Style.Main.editDashbordIcons, Style.Main.fullHeight]}>
            <TouchableOpacity
              // onPressIn={() => this.setState((prevState => ({ fullModal: !prevState.fullModal })))}
              onPress={() => this.setState({ showModal: false, onEditIcons: false })}
            >
              <View style={[Style.Main.modalSeparator]}>
                {Platform.OS === 'android' ?
                  <Text
                    style={[Style.Main.textCenter, Style.Main.calcSeparator, Style.Main.quarterOpacity]}
                  />
                  :
                  <View style={[Style.Main.textCenter, Style.Main.calcSeparator, Style.Main.quarterOpacity, Style.Main.pt15]} />
                }
              </View>
            </TouchableOpacity>
            {this.renderModalTitle()}
            <DragContainer
              style={[
                Style.Main.rowDirectionSpaceBetween,
                Style.Main.mb10,
                Style.Main.container,
                Style.Main.alignContentCenter,
                Style.Main.flexWrap,
                Style.Main.pl20,
                Style.Main.pr20,
              ]}
              onDrop={this.state.hoverDataIndex !== 1}
              dropAnywhere={this.handleDropAnywhere}
            >
              <View style={[Style.Main.dragStyle]}>
                {this.renderDashboardIcons().map((item, i) => (
                  <Draggy
                    key={i}
                    data={item}
                    onHover={this.onHover}
                    onDrop={this.onDrop}
                    // onLeave={this.onLeave}
                    index={i}
                    borderGray={i > 3 && i <= 7}
                    disabled={item.disable}
                    fillColor={this.state.hoverDataIndex === i}
                    onEdit={this.state.onEditIcons}
                    agentCode={this.props.resAuth.userProfile ? this.props.resAuth.userProfile.agentCode : ''}
                  />
                ))}
              </View>
            </DragContainer>
          </View>
        </View>
      </SafeAreaView>
    </Modal>
  )

  onLayout = e => this.props.setWidth(e.nativeEvent.layout.width);

  renderMenu = () => {
    const totalIconShowned = isTablet() ? 4 : 7;
    const mobileContainerStyle = [Style.Main.cardShadow, Style.Main.mr12, Style.Main.ml12, Style.Main.pt15, Style.Main.px10];
    const mobileMenusStyle = [Style.Main.width25pr, Style.Main.mt10];
    const iconUri = this.props.resAuth && this.props.resAuth.userAvatar && Number(this.props.resAuth.userAvatar.statusCode) === 200
      ? this.props.resAuth.userAvatar.text : null;
    const multiplier = deviceHeight > 700 ? 482 : 650;
    return (
      <React.Fragment>
        <LoadingModal show={this.state.loading} size="large" color="white" />
        {this.renderHeaderArt()}
        <View onLayout={this.onLayout} style={[isTablet() ? { height: deviceHeight } : null, Style.Main.rowDirection]}>
          <View style={[Style.Main.columnDirectionJustifyCenter,
            isTablet() ? [Style.Main.ph12, Style.Main.borderRightBrightGray, Style.Main.mb45] : mobileContainerStyle]}
          >
            {isTablet() &&
              <TouchableOpacity
                disabled={!this.isUserProfileExist()}
                onPress={() => this.setState(prevState => ({ showMyAccount: !prevState.showMyAccount }))}
                style={[Style.Main.container, Style.Main.center, Style.Main.mt10]}
              >
                <Thumbnail
                  source={iconUri ? { uri: iconUri } : myAccount}
                  style={[Style.Main.height40, Style.Main.resizeContain, Style.Main.alignCenter]}
                />
                <Text style={[Style.Main.fontAlbert14]}>{_('Akun Saya')}</Text>
              </TouchableOpacity>}
            <View style={[isTablet() ? [Style.Main.mt15, { width: 70 }] : Style.Main.rowDirectionSpaceBetween, Style.Main.mb10, Style.Main.flex7,
              Style.Main.alignContentCenter, Style.Main.flexWrap]}
            >
              {
                this.renderDashboardIcons().map((val, idx) => {
                  if (idx <= totalIconShowned) {
                    return (
                      <View key={idx} style={[isTablet() ? Style.Main.container : mobileMenusStyle, Style.Main.justifyCenter, Style.Main.itemCenter]}>
                        <OutlineIconButton
                          label={val.label}
                          disable={val.disable}
                          // onPressIn={val.label !== _('Lainnya') ? () => this.setState({ loading: true }) : () => { }}
                          // onPressOut={() => this.setState({ loading: false })}
                          onPress={val.onPress}
                          iconImage={val.iconImage}
                        />
                      </View>
                    );
                  } return null;
                })
              }
            </View>
          </View>
          {isTablet() && this.state.showMyAccount &&
            <View style={{
              width: Math.round(deviceHeight * multiplier / tabSizeRef.width),
            }}
            >
              <MyAccount isComponent navigation={this.props.navigation} />
            </View>}
        </View>
        {this.renderMenuModal()}
      </React.Fragment>
    );
  }

  renderMenuLainTab = () => (
    <View onLayout={this.onLayout} style={[isTablet() ? { height: deviceHeight } : null, Style.Main.pr12, Style.Main.borderRightBrightGray]}>
      {this.renderModalTitle()}
      <DragContainer style={[Style.Main.flex7, Style.Main.columnDirectionSpaceBetween,
      // eslint-disable-next-line react-native/no-inline-styles
        Style.Main.alignContentCenter, Style.Main.flexWrap, Style.Main.fullHeight, { justifyContent: 'flex-start' }, { marginBottom: 65 }]}
      >
        {
          this.renderDashboardIcons().map((item, i) => (
            <Draggy
              key={i}
              data={item}
              onHover={this.onHover}
              onDrop={this.onDrop}
              // onLeave={this.onLeave}
              index={i}
              borderGray={i <= 4}
              disabled={i === 4 || item.disable}
              fillColor={this.state.hoverDataIndex === i}
              onEdit={this.state.onEditIcons}
              isTablet={isTablet()}
              agentCode={this.props.resAuth.userProfile ? this.props.resAuth.userProfile.agentCode : ''}
            />
          ))
        }
      </DragContainer>
    </View>
  )

  render() {
    if (this.props.visible) {
      if (isTablet() && this.state.showModal) return this.renderMenuLainTab();
      return this.renderMenu();
    }
    return null;
  }
}

SideBarMenu.propTypes = {
  visible: PropTypes.bool,
};

SideBarMenu.defaultProps = {
  visible: true,
};

const mapStateToProps = state => ({
  resAuth: state.auth.res,
  dashboard: state.dashboard,
  trackerTodo: state.todo.trackerTodo,
});

const mapDispatchToProps = dispatch => ({
  trackerAddStack: value => dispatch(trackerAddStack(value)),
  updateDashboardIcons: value => dispatch(updateDashboardIcons(value)),
  setWidth: value => dispatch(setSidebarWidth(value)),
});

export default connect(mapStateToProps, mapDispatchToProps)(SideBarMenu);
