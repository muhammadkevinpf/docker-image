/**
 * @author: ahmdichsanb@gmail.com
*/

import { StyleSheet } from 'react-native';
import Styles from '../../styles';

const Style = StyleSheet.create({
  styleTextLabel: {
    flex: 1,
    marginTop: 4,
    fontSize: 11,
    color: Styles.Color.almostBlack,
  },
  styleTextLabelValEmpty: {
    color: Styles.Color.gray,
  },
  styleBottomLabel: {
    // marginBottom: 15,
    color: Styles.Color.red,
    fontSize: 10,
    marginLeft: 15,
  },
  input: {
    // lineHeight: 50,
    // textDecorationColor: Styles.Color.red,
  },
  item: {
    marginLeft: 0,
    paddingLeft: 0,
    paddingBottom: 15,
    // backgroundColor: Styles.Color.yellow,
    height: 45,
  },
  pb0: {
    paddingBottom: 0,
  },
  withoutLabel: {
    height: 30,
    paddingBottom: 0,
    paddingTop: 0,
    marginBottom: 0,
  },
  formStyle: {
    marginLeft: 0,
    paddingLeft: 0,
    marginTop: 15,
  },
});

export default Style;
