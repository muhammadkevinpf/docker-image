/**
 * @author: dwi.setiyadi@gmail.com
*/

import { isEmpty, defaultTo } from 'lodash';

// capitalize only first letter in a phrase
export const ucFirst = string => string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();

// capitalize every first letter in every word of a phrase
export const toTitleCase = string => string.split(' ').map(word => ucFirst(word)).join(' ');

export const findJsonInString = (string) => {
  let toObj = string.toString().match(/\{(?:[^{}]|(\?R))*\}/g);

  if (toObj === null) return string;
  toObj = JSON.parse(toObj[0]);
  return toObj;
};

export function toCurrency(number, currencySymbol) {
  if (!number || number.toString() === '0' || number === 0) return 0;
  const curr = `${String(number).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')}`;
  return `${currencySymbol ? `${currencySymbol} ` : ''}${curr}`;
}

export function toFixedCurrency(number, decimal, currencySymbol) {
  let curr = number ? Number(number) : 0;
  if (decimal) curr = curr.toFixed(Number(decimal));
  curr = toCurrency(curr, currencySymbol);
  return curr;
}

export function toCurrencyWithTwoDecimal(number) {
  const curr = toCurrency(number);
  return `${curr}.00`;
}

export function getThisMonthMM() { return (Number(new Date().getMonth())) < 9 ? `0${new Date().getMonth() + 1}` : `${new Date().getMonth() + 1}`; }

export function toStringTwoDigit(number) { return String(number).length < 2 ? `0${number}` : `${number}`; }

/**
 * @description the costumized defaultTo function of lodash to handle empty strings as well
 */
export const toDefault = (value, defaultFormat) => {
  if (typeof value === 'string' && isEmpty(value)) { return defaultFormat; }
  return defaultTo(value, defaultFormat);
};

export const numberToDecimal = (number, decimalDigit, isCurrency) => {
  const numString = String(number);
  let num = numString.slice(0, numString.length - decimalDigit);
  const decimal = numString.slice(numString.length - decimalDigit);
  if (isCurrency) { num = toFixedCurrency(num); }

  return `${num}.${decimal}`;
};

/**
 * @description take out every non-numeric character and change the input string to a number
 */
export const stripNonNum = (input = '') => Number(input.replace(/[^0-9]/gi, ''));

export const stringToFloat = (string = '', {
  maxFractionDigit = 2, invokeBlur, separator = '.',
}) => {
  let regex = new RegExp(`[^0-9${separator}]`, 'g');
  let str = string.replace(regex);
  if (str.length > 1) {
    str = str.replace(/^00+/, '0');
  }

  regex = new RegExp(`^\\d+\\${separator}\\d{1,${maxFractionDigit}}$`, 'g');
  if (str.indexOf(separator) >= 0 && !(regex.test(str))) {
    str = str.replace(/\./g, (c, i, text) => (text.indexOf(c) === i ? c : ''));
    if (!str.endsWith(separator)) str = str.slice(0, str.indexOf(separator) + 1 + maxFractionDigit);
  }

  if (invokeBlur) {
    if (str.endsWith(separator)) str = str.slice(0, str.length - 1);
    if (str.startsWith(separator)) str = `0${str}`;
  }
  return str;
};

/**
 * @description change number to "{maximumValue}+" if the number exceeds the specified limit.
 * @returns a string
 */
export const setUpTo = (value = 0, maximumValue = 99) => {
  if (!value) return '0';
  if (Number(value) > Number(maximumValue)) return `${maximumValue}+`;
  return String(value);
};
