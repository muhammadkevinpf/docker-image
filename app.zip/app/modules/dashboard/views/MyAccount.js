/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component, Fragment } from 'react';
import {
  Image, BackHandler, Linking, FlatList, TouchableOpacity,
} from 'react-native';
import {
  Container, Content,
  Button, Icon, Text, View, Footer, FooterTab, Card,
} from 'native-base';
import { connect } from 'react-redux';
import moment from 'moment';
import { TouchableHighlight } from 'react-native-gesture-handler';
import { Grid, Row, Col } from 'react-native-easy-grid';
import Communications from 'react-native-communications';
import RNDI from 'react-native-device-info';
import Share from 'react-native-share';
import _ from '../../../lang';
import Style from '../../../styles';
import HeaderWithTodo from '../../../components/header-with-todo-and-notification';
import ModalCustom from '../../../components/modal-custom';
import { version } from '../../../../package.json';
import plus from '../../../assets/images/plus.png';
import myAccount from '../../../assets/images/icon-account.png';
import { updateSignInDate } from '../../auth/ActionAuth';
import { MagnumService } from '../../spaj/services';
// import { AgentScopes } from '../../../config/Constants';
import { isTablet, isMenuActive } from '../../../utilities';
import Caches from '../../../utilities/Caches';

const cardStyle = [Style.Main.cardShadow, Style.Main.backgroundWhite, isTablet() ? Style.Main.mt10 : Style.Main.mt15,
  Style.Main.ml12, Style.Main.mr12];
const itemStyle = [Style.Main.rowDirectionSpaceBetween, isTablet() ? Style.Main.padding10 : Style.Main.padding12];
const justify = [{ textAlign: justify }];
const faqSquare = { height: '55%', width: '90%' };
const contactCardSquare = { height: '45%', width: '90%' };

class MyAccount extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isVisible: false,
      content: '',
    };
  }

  componentDidMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleBack();
      return true;
    });
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  handleBack = () => {
    this.props.navigation.replace('MainDashboard');
  }

  getAgentType = () => {
    if (this.props.resAuth) {
      if (this.props.resAuth.userProfile) {
        const { agentType } = this.props.resAuth.userProfile;
        return agentType;
      }
    }
    return 'UNKNOWN';
  }

  renderHeader = () => {
    if (!isTablet()) {
      return <HeaderWithTodo {...this.props} headerTitle="Akun Saya" isShowBackButton={false} />;
    } return <View style={Style.Main.mb15} />;
  }

  renderFAQ = () => {
    const dataFAQ = [
      {
        question: 'Jika ada masalah dalam akses ke prufast?',
        answer: '',
        answerStep: [
          'Menu "Lupa Password" tersedia',
          'Menu "Lupa PRUFast ID" tersedia',
          // eslint-disable-next-line max-len
          'Email ke prudigitalfriend@prudential.co.id atau hubungi 021-2995 8585 lalu tekan 5 untuk permasalahan apapun terkait aplikasi penjualan Prudential',
        ],
      },
      {
        question: 'Bagaimana jika akun saya kadaluwarsa?',
        // eslint-disable-next-line max-len
        answer: 'Jika Anda lupa password SFA, atau password Anda kadaluwarsa, email ke sfa.helpdesk@prudential.co.id untuk permintaan reset ID/password dengan menyebutkan kode agen Anda!',
        answerStep: [],
      },
    ];
    const TextItem = ({
      label, firstStyle, secondStyle, textStyle, onPress,
    }) => (
      <View style={firstStyle}>
        <View style={secondStyle}>
          <Text
            style={textStyle}
            onPress={onPress}
          >{_(label)}
          </Text>
        </View>
      </View>
    );
    return (
      <Card style={[Style.Main.ml15, Style.Main.mr15, Style.Main.borderRadius10, faqSquare]}>
        <TouchableOpacity
          style={[Style.Main.container, Style.Main.fullHeight, Style.Main.fullWidth]}
          activeOpacity={1}
          onPress={() => {}}
        >
          <Text
            style={[
              Style.Main.alignCenter,
              Style.Main.textRed,
              Style.Main.font30,
              Style.Main.fontBold,
              Style.Main.pt30,
            ]}
          >FAQ
          </Text>
          <Card style={[Style.Main.borderRadius10, Style.Main.container, Style.Main.backgroundWhiteSmoke]}>
            <FlatList
              data={dataFAQ}
              keyExtractor={(x, i) => i.toString()}
              renderItem={({ item, index }) => (
                <Fragment>
                  <TextItem
                    label={item.question}
                    firstStyle={cardStyle}
                    secondStyle={[Style.Main.grayBorderBottom, itemStyle]}
                    textStyle={[Style.Main.container, Style.Main.fontAlbert14, justify]}
                    onPress={() => this.setState(prevState => ({ [`show${index}`]: !prevState[`show${index}`] }))}
                  />
                  {(this.state[`show${index}`] && item.answer) ? (
                    <TextItem
                      label={item.answer}
                      firstStyle={[Style.Main.ml12, Style.Main.mr12]}
                      secondStyle={itemStyle}
                      textStyle={[Style.Main.container, Style.Main.fontAlbert14, justify]}
                      onPress={() => {}}
                    />
                  ) : (<React.Fragment />) }
                  { (this.state[`show${index}`] && item.answerStep.length) ? item.answerStep.map((y, iy) => (
                    <TextItem
                      label={`${iy + 1}. ${y}`}
                      firstStyle={[Style.Main.ml12, Style.Main.mr12]}
                      secondStyle={[Style.Main.ml15, Style.Main.mr15, Style.Main.mt5, Style.Main.mb5]}
                      textStyle={[Style.Main.fontAlbert14, justify]}
                      onPress={() => {}}
                    />
                  )) : (<React.Fragment />)}
                </Fragment>
              )}
            />
          </Card>
        </TouchableOpacity>
      </Card>
    );
  }

  renderContactCenter = () => {
    const dataContact = [
      {
        label: '(021) - 29958585 ext 5',
        onPress: () => Communications.phonecall('021 29958585', true),
        icon: 'phone',
      },
      {
        label: 'www.prudential.co.id',
        onPress: () => Communications.web('https://prudential.co.id/'),
        icon: 'globe',
      },
      {
        label: 'prudigitalfriend@prudential.co.id',
        onPress: () => Communications.email(['prudigitalfriend@prudential.co.id'], null, null, '', ''),
        icon: 'envelope',
      },
      {
        label: 'Customer Care Centre, Prudential Tower',
        onPress: () => Communications.web('https://goo.gl/maps/MufkfuAt9zwiDwj9A'),
        icon: 'building',
      },
    ];
    return (
      <Card style={[Style.Main.ml15, Style.Main.mr15, Style.Main.height252, Style.Main.borderRadius10, contactCardSquare]}>
        <TouchableOpacity
          style={[Style.Main.container, Style.Main.fullHeight, Style.Main.fullWidth]}
          activeOpacity={1}
          onPress={() => {}}
        >
          <Text
            style={[
              Style.Main.alignCenter,
              Style.Main.textRed,
              Style.Main.font30,
              Style.Main.fontBold,
              Style.Main.pt30,
              Style.Main.mb20,
            ]}
          >Hubungi Kami
          </Text>
          {dataContact.map((x, i) => (
            <Grid key={i.toString()}>
              <Row style={[Style.Main.ml20]}>
                <Col size={10}>
                  <Icon name={x.icon} type="FontAwesome" style={[Style.Main.font20, Style.Main.mt4]} />
                </Col>
                <Col size={90}>
                  <View style={Style.Main.textWrap}>
                    <Text
                      style={[Style.Main.textBlue]}
                      onPress={x.onPress}
                    >
                      {_(x.label)}
                    </Text>
                  </View>
                </Col>
              </Row>
            </Grid>
          ))}
        </TouchableOpacity>
      </Card>
    );
  }

  renderSQSOfflinePopUp = () => (
    // eslint-disable-next-line react-native/no-inline-styles
    <Card style={[Style.Main.ml15, Style.Main.mr15, Style.Main.height252, Style.Main.borderRadius10, { ...contactCardSquare, height: '15%' }]}>
      <TouchableOpacity
        style={[Style.Main.container, Style.Main.fullHeight, Style.Main.fullWidth]}
        activeOpacity={1}
        onPress={() => { }}
      >
        <Grid>
          <Row style={[Style.Main.ml20, Style.Main.mt15]}>
            <Col>
              <View style={Style.Main.textWrap}>
                <Text
                  style={[Style.Main.textBlue]}
                  onPress={() => {
                    Linking
                      .openURL('https://prupartner-content.prudential.co.id/sqsoffline_installer/sqsuob.exe')
                      .finally(() => this.setState({ isVisible: false }));
                  }}
                >
                  {_('Buka Link...')}
                </Text>
              </View>
            </Col>
          </Row>
          <Row style={[Style.Main.ml20]}>
            <Col>
              <View style={Style.Main.textWrap}>
                <Text
                  style={[Style.Main.textBlue]}
                  onPress={this.shareSQSOfflineInstaller}
                >
                  {_('Bagikan Link...')}
                </Text>
              </View>
            </Col>
          </Row>
        </Grid>
      </TouchableOpacity>
    </Card>
  )

  shareSQSOfflineInstaller = () => {
    Share.open({
      url: 'https://prupartner-content.prudential.co.id/sqsoffline_installer/sqsuob.exe',
      title: 'SQS Offline Installer',
      showAppsToView: true,
    }).finally(() => this.setState({ isVisible: false }));
  }

  renderModal = () => {
    let ModalContent = Fragment;
    if (this.state.content === 'FAQ') ModalContent = this.renderFAQ;
    else if (this.state.content === 'CONTACT') ModalContent = this.renderContactCenter;
    else if (this.state.content === 'SQSOffline') ModalContent = this.renderSQSOfflinePopUp;
    return (
      <ModalCustom
        isVisible={this.state.isVisible}
        onPress={() => this.setState({ isVisible: false })}
        content={<ModalContent />}
        animationType="fade"
      />
    );
  }

  rightArrow = ({ style }) => <Icon name="chevron-right" type="MaterialIcons" style={[Style.Main.textColor3f3, Style.Main.font16, style]} />

  cardText = ({ label, style, onPress }) => <Text onPress={onPress} style={[Style.Main.container, Style.Main.fontAlbert14, style]}>{_(label)}</Text>

  aboutAppText = ({ label, value, style }) => (
    <Text style={[Style.Main.timeStyle, Style.Main.fontAlbert14, Style.Main.mr12, Style.Main.mb5, isTablet() && Style.Main.textWhite, style]}>
      {_(label)}: {value}
    </Text>
  )

  render() {
    const { userAvatar, userProfile, mobileMenu } = this.props.resAuth;
    const dbVersion = Caches.get('dbVersion').version;
    const iconUri = userAvatar && Number(userAvatar.statusCode) === 200 ? this.props.resAuth.userAvatar.text : null;
    return (
      <Container style={[isTablet() ? Style.Main.backgroundRed : Style.Main.backgroundColorEe]}>
        {this.renderHeader()}
        <Content keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
          <View>
            <View style={[Style.Main.headerArt]} />
            <View style={[cardStyle, isTablet() ? Style.Main.padding10 : Style.Main.padding12, Style.Main.mt0]}>
              <View style={[Style.Main.rowDirectionFlexStart, !isTablet() && Style.Main.mb10]}>
                {!isTablet() &&
                  <TouchableHighlight style={[Style.Main.ml8, Style.Main.square80, Style.Main.borderRadius40, Style.Main.overflowHide]}>
                    <Image
                      source={iconUri ? { uri: iconUri } : myAccount}
                      style={[Style.Main.square80, Style.Main.borderRadius40, Style.Main.resizeContain]}
                    />
                  </TouchableHighlight>
                }
                <View style={[Style.Main.flex3, !isTablet() && Style.Main.pl12, Style.Main.pr12]}>
                  {/* Request Pras & User to change the displayed name from adsName to clientName */}
                  <Text style={[isTablet() ? Style.Main.font20 : Style.Main.font22]}>{userProfile.clientName || ''}</Text>
                  <Text style={[Style.Main.textBrightGray, isTablet() && Style.Main.fontAlbert14]}>{userProfile.agentCode || ''}
                  </Text>
                  <Text style={[Style.Main.textBrightGray, isTablet() && Style.Main.fontAlbert14]}>
                    {_('Bergabung sejak ')}{userProfile.joinDate ? moment(userProfile.joinDate, 'YYYY-MM-DD').format('MMMM YYYY') : ''}
                  </Text>
                  <Text
                    style={[Style.Main.textRed, isTablet() && Style.Main.fontAlbert14]}
                    onPress={() => this.props.navigation.replace('MyAccountDetail')}
                  >{_('Lihat Profil')}
                  </Text>
                </View>
              </View>
            </View>
          </View>
          <View style={cardStyle}>
            <View style={[Style.Main.grayBorderBottom, itemStyle]}>
              <this.cardText
                label="FAQ"
                onPress={() => Linking.openURL('https://prupartner-content.prudential.co.id/user_manual/prufast-userguide-april.pdf')}
              />
              <this.rightArrow />
            </View>
            <View style={[Style.Main.grayBorderBottom, itemStyle]}>
              <this.cardText
                label="Panduan Pengguna"
                onPress={() => Linking.openURL('https://prupartner-content.prudential.co.id/user_manual/prufast-userguide.pdf')}
              />
              <this.rightArrow />
            </View>
            <View style={itemStyle}>
              <this.cardText label="Hubungi Kami" onPress={() => this.setState({ isVisible: true, content: 'CONTACT' })} />
              <this.rightArrow />
            </View>
          </View>
          <View style={cardStyle}>
            <View style={[Style.Main.grayBorderBottom, itemStyle]}>
              <this.cardText
                label="Ubah Password"
                onPress={() => this.props.navigation.replace('MyAccountChangePassword')}
              />
              <this.rightArrow />
            </View>
            <View style={[Style.Main.grayBorderBottom, itemStyle]}>
              <this.cardText
                label="Ubah Pertanyaan Rahasia"
                // onPress={() => this.props.navigation.replace('MyAccountSecretQuestion')}
              />
              <this.rightArrow />
            </View>
            <View style={itemStyle}>
              <this.cardText
                label="Pengaturan Notifikasi"
                // onPress={() => this.props.navigation.replace('SettingWidgetDashboard')}
              />
              <this.rightArrow />
            </View>
          </View>

          {/* cuma untuk dev purpose */}
          {isMenuActive(mobileMenu, 'PD_MODULE_MAGNUM_LOG') && (
          <View style={[cardStyle, itemStyle]}>
            <Icon
              name="md-document"
              type="Ionicons"
              style={[Style.Main.pr12, Style.Main.textColor3f3]}
              onPress={() => MagnumService.writeToFile()}
            />
            <this.cardText label="Generate Magnum Log Records" onPress={() => MagnumService.writeToFile()} />
          </View>
          )}

          {this.props.resAuth.userProfile.agentChannel === 'UOB' && (
          <View style={[cardStyle, itemStyle]}>
            <Icon
              name="cog-outline"
              type="Ionicons"
              style={[Style.Main.pr12, Style.Main.textColor3f3]}
              onPress={() => this.setState({ isVisible: true, content: 'SQSOffline' })}
            />
            <this.cardText
              label="SQS Offline Installer"
              onPress={() => this.setState({ isVisible: true, content: 'SQSOffline' })}
            />
          </View>
          )}

          <View style={[cardStyle, itemStyle]}>
            <Icon
              name="log-out"
              type="Ionicons"
              style={[Style.Main.pr12, Style.Main.textColor3f3]}
              onPress={() => {
                this.props.updateSignInDate();
                this.props.navigation.replace('MainHome');
              }}
            />
            <this.cardText
              label="Keluar"
              onPress={() => {
                this.props.updateSignInDate();
                this.props.navigation.replace('MainHome');
              }}
            />
          </View>
          <this.aboutAppText label="Channel" value={this.props.resAuth.userProfile.agentChannel} style={Style.Main.mt15} />
          {/* versi biar gampang inspeknya kalo ada issue */}
          <this.aboutAppText label="Version" value={`${RNDI.getVersion()}`} />
          <this.aboutAppText label="DB Version" value={dbVersion} />
          <this.aboutAppText label="Code Version" value={version} />
          <View Style={[Style.Main.mb30]} />
          <this.renderModal />
        </Content>
        {!isTablet() &&
          <Footer>
            <FooterTab>
              <Button
                vertical
                onPress={() => this.props.navigation.replace('MainDashboard')}
              >
                <Icon name="home" type="MaterialIcons" />
                <Text>{_('Beranda')}</Text>
              </Button>
              {
                // this.props.resAuth && this.props.resAuth.agent_scope === AgentScopes.individu &&
                isMenuActive(mobileMenu, 'PD_MODULE_NEW_SQS') &&
                <Button
                  vertical
                  onPress={() => this.props.navigation.replace('ExistingPolicySQSNSpaj', { previousScreen: 'MainDashboard' })}
                  style={[Style.Main.mb20]}
                >
                  <Image
                    source={plus}
                    style={[Style.Main.width75, Style.Main.height75]}
                  />
                </Button>
              }
              <Button vertical>
                <Icon name="person" type="Ionicons" style={[Style.Main.textRed]} />
                <Text style={[Style.Main.textRed]}>{_('Akun Saya')}</Text>
              </Button>
            </FooterTab>
          </Footer>
        }
      </Container>
    );
  }
}

const mapStateToProps = state => ({
  resAuth: state.auth.res,
});

const dispatchMapToProps = dispatch => ({
  updateSignInDate: () => dispatch(updateSignInDate(null)),
});

export default connect(mapStateToProps, dispatchMapToProps)(MyAccount);
