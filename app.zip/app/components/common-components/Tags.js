import React from 'react';
import {
  TouchableOpacity, KeyboardAvoidingView, Image, Linking, RefreshControl,
} from 'react-native';
import {
  View, Card, Text, Icon, Content, Container, Row,
} from 'native-base';
import { isArray } from 'lodash';
import { DotIndicator } from 'react-native-indicators';
import { isText, isTablet, isEmpty } from '../../utilities';
import { SideBarMenu } from '../side-bar-menu';
import { UpdateDate } from '../list-information';
import { rowLayout, Skeleton } from '../skeleton-loading';
import HeaderWithTodo from '../header-with-todo-and-notification';
import LoadingModal from '../loading_modal';
import Style from '../../styles';
import Colors from '../../styles/Colors';
import _ from '../../lang';

class CardRedHeader extends React.PureComponent {
  render() {
    return (
      <Card style={[Style.Main.mb12, this.props.style]}>
        <View style={[Style.Main.backgroundRed, Style.Main.padding12, Style.Main.borderRadius2]}>
          {
            isText(this.props.header) ?
              <Text style={[Style.Main.fontAlbert16, Style.Main.textWhite, this.props.textHeaderStyle]}>
                {_(this.props.header)}
              </Text> : this.props.header
          }
          <UpdateDate
            visible={!isEmpty(this.props.lastUpdate) && !this.props.hideDate}
            date={this.props.lastUpdate}
            containerStyle={[Style.Main.mt0, Style.Main.mb0]}
            textStyle={[Style.Main.textWhite]}
          />
        </View>
        <View style={this.props.childStyle}>
          {this.props.children}
        </View>
      </Card>
    );
  }
}

const TouchableArrow = ({
  children, onPress, style, iconStyle, containerStyle = [Style.Main.container], iconType, iconName = 'chevron-forward', isLoading = false, ...props
}) => {
  const Tag = onPress && !isLoading ? TouchableOpacity : View;
  return (
    <Tag {...props} onPress={onPress} style={[Style.Main.rowDirectionSpaceBetween, style]}>
      <View style={containerStyle}>
        {children}
      </View>
      <View style={[Style.Main.alignCenter]}>
        <View style={[Style.Main.rowDirection]}>
          {isLoading && <DotIndicator color={Style.Color.gray97} size={5} count={3} style={[Style.Main.mr14]} />}
          {
            onPress && !isLoading &&
            <Icon
              name={iconName}
              type={iconType}
              style={[Style.Main.textGray, Style.Main.font18, Style.Main.ml12, Style.Main.alignCenter, iconStyle]}
            />
          }
        </View>
      </View>
    </Tag>
  );
};

const TouchableArrow2 = ({
  label, value, style, labelStyle, skeletonLayout, valueStyle, labelWidth = '45%', skeletonWidth = '90%', onPress = null, isLoading = false,
  showArrow = true, onExpand = null, isExpanded = true, bold = true, info, infoStyle,
}) => {
  const Tag = (onPress || onExpand) && !isLoading ? TouchableOpacity : View;
  const isValueText = isText(value);
  const isInfoText = isText(info);
  return (
    <View style={[Style.Main.container, Style.Main.rowDirectionSpaceBetween, style]}>
      <View style={[Style.Main.mr20, Style.Main.pv5, { width: labelWidth }]}>
        {
          isText(label) || isEmpty(label) ?
            <View style={[Style.Main.textWrap, isInfoText && Style.Main.pt5]}>
              <StyledText color={Colors.black} style={labelStyle}>{_(label)}</StyledText>
            </View>
            : label
        }
      </View>
      <Tag
        onPress={onPress || onExpand}
        style={[Style.Main.pv5, Style.Main.container, Style.Main.rowDirectionSpaceBetween, isInfoText && Style.Main.columnDirectionFlexEnd]}
      >
        <Skeleton
          isLoading={isLoading}
          layout={skeletonLayout || [rowLayout({ h: 9, w: skeletonWidth })]}
          style={[Style.Main.container, isValueText && Style.Main.textWrap]}
        >
          {isValueText || isEmpty(value) ? <StyledText bold={bold} style={valueStyle}>{value || '-'}</StyledText> : value}
        </Skeleton>
        {isInfoText || isEmpty(info) ? <StyledText font={11} style={infoStyle}>{info}</StyledText> : info}
        {onPress && showArrow && !isLoading && <Icon name="chevron-forward" style={[Style.Main.textColor3f3, Style.Main.font14, valueStyle]} />}
        {onExpand && showArrow && !isLoading &&
        <Icon name={`chevron-${isExpanded ? 'up' : 'down'}`} style={[Style.Main.textColor3f3, Style.Main.font14, valueStyle]} />}
      </Tag>
    </View>
  );
};

const ImageHeader = ({ source = '', style, resizeMode = 'stretch' }) => (
  <View>
    <Image resizeMode={resizeMode} source={source} style={[Style.Main.headerArt, Style.Main.backgroundTransparent, style]} />
  </View>
);

class ContainerNonProduct extends React.PureComponent {
  render() {
    const {
      navigation, children, isLoading,
    } = this.props;
    return (
      <Container style={[isTablet() && Style.Main.rowDirection]}>
        <SideBarMenu visible={isTablet()} navigation={navigation} />
        <View style={[Style.Main.container]}>
          <HeaderWithTodo {...this.props} />
          {children}
        </View>
        {isLoading !== undefined && <LoadingModal show={isLoading} size="large" color="white" />}
      </Container>
    );
  }
}

const ContentAdjusted = ({
  imgHeader, imgHeaderStyle, childStyle, children, onRefresh, refreshing = false, isLoading = false, ...props
}) => (
  <Content
    refreshControl={onRefresh ? <RefreshControl onRefresh={onRefresh} refreshing={refreshing} /> : null}
    keyboardDismissMode="on-drag"
    enableResetScrollToCoords={false}
    {...props}
  >
    {imgHeader && !isLoading && <ImageHeader {...props} style={imgHeaderStyle} source={imgHeader} />}

    <View style={childStyle}>{children}</View>
    <View style={[Style.Main.mb30]} />
    {isLoading && <LoadingModal show={isLoading} size="large" color="white" />}
  </Content>
);
class ContentCentered extends React.PureComponent {
  render() {
    return (
      <ContentAdjusted {...this.props}>
        <View style={[isTablet() ? Style.Main.containerWithPaddingTablet : Style.Main.containerWithPadding12, this.props.containerStyle]}>
          {this.props.children}
        </View>
      </ContentAdjusted>
    );
  }
}

class ContentWithKeyboard extends React.PureComponent {
  render() {
    if (isTablet()) {
      return (
        <ContentAdjusted {...this.props}>
          {this.props.children}
        </ContentAdjusted>
      );
    }
    return (
      <KeyboardAvoidingView behavior={this.props.keyboardBehavior || 'padding'} style={[Style.Main.container, this.props.KeyboardAvoidingStyle]}>
        <ContentAdjusted {...this.props}>
          {this.props.children}
        </ContentAdjusted>
      </KeyboardAvoidingView>
    );
  }
}

const StyledText = ({
  color = Style.Color.f3f, italic, bold, font = 12, lineHeight, style, children, ...props
}) => (
  <Text
    {...props}
    style={[bold ? Style.Main.setFontAlbertBold(font, color) : Style.Main.setFontAlbert(font, color), italic && Style.Main.italic,
      { lineHeight }, style]}
  >{children}
  </Text>
);

/** Styled Text with skeleton loader */
const SkeletonText = ({
  color, italic, bold, font = 12, lineHeight, style, children, isLoading, layout, width = '70%', textStyle, ...props
}) => (
  <Skeleton isLoading={isLoading} style={[Style.Main.textWrap, style]} layout={layout || [rowLayout({ h: font - 3, w: width })]}>
    <StyledText color={color} bold={bold} italic={italic} font={font} lineHeight={lineHeight} style={textStyle} {...props}>{children}</StyledText>
  </Skeleton>
);

/** Styled Text with {Linking.opernURL(url)} */
const LinkedTest = ({
  style, children, url, font = 12,
}) => (
  <StyledText style={style} font={font} color={Colors.blue} onPress={() => Linking.openURL(url)}>{children}</StyledText>
);


const convertIndex = (i, type) => {
  if (type === 'alphabet') return Number(i + 10).toString(36);
  return i + 1;
};

const Annotation = ({
  title, list = [], titleStyle, rowStyle, textStyle, indexBy,
}) => (
  <View style={[Style.Main.container]}>
    {
      !isEmpty(title) &&
        <Text style={[Style.Main.setFontAlbertBold(12, Colors.f3f), Style.Main.mV5, titleStyle]}>
          {isText(title) ? `${_(title)} :` : title}
        </Text>
    }
    {
      !isEmpty(list) && list.map((x, index) => {
        const Tag = isText(x) ? Text : View;
        return (
          <Row style={[Style.Main.mV2, rowStyle]} key={index.toString()}>
            <Text style={[Style.Main.setFontAlbert(12, Colors.gray83), textStyle]}>
              {`${convertIndex(index, indexBy)}. `}
            </Text>
            <Tag style={[Style.Main.setFontAlbert(12, Colors.gray83), Style.Main.textWrap, textStyle]}>
              {isArray(x) ? x.map((subX, i) => (
                <Text key={i.toString()} style={[Style.Main.setFontAlbert(12, Colors.gray83), textStyle]}>
                  {subX}
                </Text>
              )) : x}
            </Tag>
          </Row>
        );
      })
    }
  </View>
);

const FormText = ({
  label, value, style, labelStyle, skeletonLayout, valueStyle, labelWidth = '40%', skeletonWidth = '90%', onPress = null, isLoading = false,
  showArrow = true,
}) => {
  const Tag = onPress && !isLoading ? TouchableOpacity : View;
  const isValueText = isText(value);
  return (
    <View style={[Style.Main.container, Style.Main.rowDirectionSpaceBetween, style]}>
      <View style={[Style.Main.mr20, Style.Main.pv5, { width: labelWidth }]}>
        {
          isText(label) || isEmpty(label) ?
            <View style={[Style.Main.textWrap]}>
              <StyledText color={Colors.gray83} style={labelStyle}>{_(label)}</StyledText>
            </View>
            : label
        }
      </View>
      <Tag
        onPress={onPress}
        style={[Style.Main.pv5, Style.Main.container, onPress && Style.Main.rowDirectionSpaceBetween]}
      >
        <Skeleton
          isLoading={isLoading}
          layout={skeletonLayout || [rowLayout({ h: 9, w: skeletonWidth })]}
          style={[Style.Main.container, isValueText && Style.Main.textWrap]}
        >
          {isValueText || isEmpty(value) ? <StyledText style={valueStyle}>{value || '-'}</StyledText> : value}
        </Skeleton>
        {onPress && showArrow && !isLoading && <Icon name="chevron-forward" style={[Style.Main.textColor3f3, Style.Main.font14, valueStyle]} />}
      </Tag>
    </View>
  );
};

/** Components for rendering addresses in the form of an array that was obtained from the API */
const FormattedAddress = ({ array, nullText, style }) => {
  if (!isEmpty(array)) {
    return (
      array.map((item, index) => (
        <View key={index.toString()} style={[Style.Main.textWrap]}>
          <StyledText style={style}>{item}</StyledText>
        </View>
      ))
    );
  } if (nullText) return <StyledText style={style}>{nullText}</StyledText>;
  return null;
};

export {
  CardRedHeader,
  TouchableArrow,
  TouchableArrow2,
  ImageHeader,
  ContainerNonProduct,
  ContentAdjusted,
  ContentCentered,
  ContentWithKeyboard,
  StyledText,
  LinkedTest,
  SkeletonText,
  Annotation,
  FormText,
  FormattedAddress,
};
