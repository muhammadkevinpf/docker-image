import { StyleSheet } from 'react-native';
import Styles from '../../styles';
import Fonts from '../../styles/Fonts';

const Style = StyleSheet.create({
  textAlignCenter: {
    textAlign: 'center',
  },
  iconStyle: {
    textAlign: 'center',
    marginRight: 3,
  },
  styleTextLabel: {
    flex: 1,
    padding: 0,
    margin: 0,
    fontSize: 11,
    color: Styles.Color.gray,
    fontFamily: Fonts.FSAlbertPro,
  },
  formStyle: {
    marginTop: 15,
    marginLeft: 0,
    paddingLeft: 0,
  },
  placeholderTextStyle: {
    color: Styles.Color.gray,
    fontSize: 14,
    padding: 5,
    paddingTop: 0,
    fontFamily: Fonts.FSAlbertPro,
    // paddingLeft: 5,
  },
  item: {
    height: 47,
    marginLeft: 0,
    paddingLeft: 0,
    // paddingTop: 15,
    // paddingBottom: 15,
  },
  labelAndData: {
    // paddingTop: 30,
    // flexDirection: 'column',
    maxHeight: 47,
    // alignItems: 'flex-start',
    // backgroundColor: Styles.Color.lightGreen,
  },
  styleBottomLabel: {
    // marginBottom: 15,
    fontFamily: Fonts.FSAlbertPro,
    color: Styles.Color.red,
    fontSize: 10,
    marginLeft: 15,
  },
  pickerTextStyle: {
    // backgroundColor: 'yellow',
    // maxHeight: 30,
    padding: 5,
    paddingTop: 0,
    fontSize: 14,
    fontFamily: Fonts.FSAlbertPro,
    // paddingLeft: 5,
    color: Styles.Color.almostBlack,
  },
});

export default Style;
