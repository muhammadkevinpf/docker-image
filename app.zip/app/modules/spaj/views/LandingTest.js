/* eslint-disable no-return-assign */
/* eslint-disable no-console */
import React, { Component } from 'react';
import {
  Container, Content, View, Text,
} from 'native-base';
import { connect } from 'react-redux';
import { CustomButton } from '../components';
import {
  UPDATE_SPAJ, UPDATE_FUND_MASTER, UPDATE_TOPUP, RESET_SPAJ,
} from '../actions/types';
import { updateSpajAction, fundAction, spajSubmissionAction } from '../actions';
import { FundService } from '../services';
import Style from '../../../styles';
import SpajStyles from '../StyleSpaj';
import NewSPAJStorageService from '../../sqs-spaj/services/NewSPAJStorageService';
import LoadingModal from '../../../components/loading_modal';
import Caches from '../../../utilities/Caches';

class LandingTest extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    };
  }

  storeSpajToRedux = async () => {
    const { agentCode } = this.props.resAuth.userProfile;
    const pruSmartDB = global.database.pruSmart;
    const spajData = await NewSPAJStorageService.getByCode(pruSmartDB, { agentCode, spajCode: 'P15694045669088500841117' });

    return this.props.updateSpaj(spajData);
  }

  handlingProceed = async () => {
    this.setState({ isLoading: true });
    await this.storeSpajToRedux();
    await this.getFundMaster();
    this.setState({ isLoading: false });
    if (global.database) { this.props.navigation.navigate('SubmitSpaj'); }
  }

  getFundMaster = () => {
    this.setState({ isLoading: true });
    const { fund } = this.props.spaj.policy.topUp;
    if (Caches.get('fund')) {
      const { agentType } = this.props.resAuth.userProfile;
      const prodCategory = 'TRD';
      const prodCode = 'T1Q';
      const fundMaster = FundService.getFundMaster(agentType, prodCategory, prodCode);
      if (fund && fund.length > 0) {
        let tempList = [];
        fund.map((item) => {
          const masterIndex = fundMaster.findIndex(obj => obj.fundRisk === item.type);
          const index = tempList.findIndex(obj => obj.code === item.code);
          tempList = fundMaster.find(obj => obj.fundRisk === item.type).fundList;
          tempList.splice(index, 1, item);
          fundMaster.splice(masterIndex, 1, {
            ...fundMaster[masterIndex],
            fundList: tempList,
            percentTopUp: fundMaster[masterIndex].percentTopUp + item.percent,
          });
          return fundMaster;
        });
      }
      this.props.updateFund(fundMaster);
    }
    this.setState({ isLoading: false });
    return fund;
  }

  introSpaj = () => {
    this.getFundMaster();
    this.props.navigation.navigate('IntroSpaj');
  }

  resetSQL = async () => {
    this.setState({ isLoading: true });
    await this.props.resetSpaj();
    const { agentCode } = this.props.resAuth.userProfile;
    const pruSmartDB = global.database.pruSmart;
    await NewSPAJStorageService.deleteByCode(pruSmartDB, { agentCode, spajCode: 'P15694045669088500841117' });
    await this.storeSpajToRedux();
    this.setState({ isLoading: false });
  }

  render() {
    return (
      <Container>
        <Content ref={c => this.component = c} style={SpajStyles.spajContainer} keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
          <CustomButton
            style={Style.Main.mb35}
            label="Lanjutkan"
            onPress={() => this.handlingProceed()}
            // onPress={() => this.stringifyJson()}
          />
          <CustomButton
            style={Style.Main.mb35}
            label="Intro Spaj"
            onPress={this.introSpaj}
          />
          <CustomButton
            style={Style.Main.mb35}
            label="Reset SQL"
            onPress={this.resetSQL}
          />
          <View style={SpajStyles.componentContainer}>
            <Text style={Style.Main.mt15}>Contoh penggunaan componentContainer styling, dengan text tanpa styling</Text>
            <Text style={[SpajStyles.text, Style.Main.mt15]}>Contoh penggunaan text style untuk label dan value secara general</Text>
            <Text style={[SpajStyles.strongText, Style.Main.mt15]}>Contoh penggunaan bold text</Text>
            <Text style={[SpajStyles.strongCenteredText, Style.Main.mt15]}>Contoh penggunaan centered bold text</Text>
          </View>
          <View style={SpajStyles.cardContainer}>
            <Text style={Style.Main.mt15}>Contoh penggunaan card styling, dengan text tanpa styling</Text>
            <Text style={[SpajStyles.warningText, Style.Main.mt15]}>Contoh penggunaan warning text</Text>
            <Text style={[SpajStyles.bigWarningText, Style.Main.mt15]}>Contoh penggunaan big centered warning text</Text>
          </View>
          <View style={SpajStyles.componentContainer}>
            <Text style={Style.Main.mt15}>Contoh penggunaan componentContainer styling, dengan text tanpa styling</Text>
            <Text style={[SpajStyles.text, Style.Main.mt15]}>Contoh penggunaan text style untuk label dan value secara general</Text>
            <Text style={[SpajStyles.strongText, Style.Main.mt15]}>Contoh penggunaan bold text</Text>
            <Text style={[SpajStyles.strongCenteredText, Style.Main.mt15]}>Contoh penggunaan centered bold text</Text>
          </View>
          <View style={SpajStyles.cardContainer}>
            <Text style={Style.Main.mt15}>Contoh penggunaan card styling, dengan text tanpa styling</Text>
            <Text style={[SpajStyles.warningText, Style.Main.mt15]}>Contoh penggunaan warning text</Text>
            <Text style={[SpajStyles.bigWarningText, Style.Main.mt15]}>Contoh penggunaan big centered warning text</Text>
          </View>
          <View style={SpajStyles.componentContainer}>
            <Text style={Style.Main.mt15}>Contoh penggunaan componentContainer styling, dengan text tanpa styling</Text>
            <Text style={[SpajStyles.text, Style.Main.mt15]}>Contoh penggunaan text style untuk label dan value secara general</Text>
            <Text style={[SpajStyles.strongText, Style.Main.mt15]}>Contoh penggunaan bold text</Text>
            <Text style={[SpajStyles.strongCenteredText, Style.Main.mt15]}>Contoh penggunaan centered bold text</Text>
          </View>
          <View style={SpajStyles.cardContainer}>
            <Text style={Style.Main.mt15}>Contoh penggunaan card styling, dengan text tanpa styling</Text>
            <Text style={[SpajStyles.warningText, Style.Main.mt15]}>Contoh penggunaan warning text</Text>
            <Text style={[SpajStyles.bigWarningText, Style.Main.mt15]}>Contoh penggunaan big centered warning text</Text>
          </View>
          <View style={SpajStyles.componentContainer}>
            <Text style={Style.Main.mt15}>Contoh penggunaan componentContainer styling, dengan text tanpa styling</Text>
            <Text style={[SpajStyles.text, Style.Main.mt15]}>Contoh penggunaan text style untuk label dan value secara general</Text>
            <Text style={[SpajStyles.strongText, Style.Main.mt15]}>Contoh penggunaan bold text</Text>
            <Text style={[SpajStyles.strongCenteredText, Style.Main.mt15]}>Contoh penggunaan centered bold text</Text>
          </View>
          <View style={SpajStyles.cardContainer}>
            <Text style={Style.Main.mt15}>Contoh penggunaan card styling, dengan text tanpa styling</Text>
            <Text style={[SpajStyles.warningText, Style.Main.mt15]}>Contoh penggunaan warning text</Text>
            <Text style={[SpajStyles.bigWarningText, Style.Main.mt15]}>Contoh penggunaan big centered warning text</Text>
          </View>
          <View style={SpajStyles.componentContainer}>
            <Text style={Style.Main.mt15}>Contoh penggunaan componentContainer styling, dengan text tanpa styling</Text>
            <Text style={[SpajStyles.text, Style.Main.mt15]}>Contoh penggunaan text style untuk label dan value secara general</Text>
            <Text style={[SpajStyles.strongText, Style.Main.mt15]}>Contoh penggunaan bold text</Text>
            <Text style={[SpajStyles.strongCenteredText, Style.Main.mt15]}>Contoh penggunaan centered bold text</Text>
          </View>
          <View style={SpajStyles.cardContainer}>
            <Text style={Style.Main.mt15}>Contoh penggunaan card styling, dengan text tanpa styling</Text>
            <Text style={[SpajStyles.warningText, Style.Main.mt15]}>Contoh penggunaan warning text</Text>
            <Text style={[SpajStyles.bigWarningText, Style.Main.mt15]}>Contoh penggunaan big centered warning text</Text>
          </View>
          <View style={SpajStyles.componentContainer}>
            <Text style={Style.Main.mt15}>Contoh penggunaan componentContainer styling, dengan text tanpa styling</Text>
            <Text style={[SpajStyles.text, Style.Main.mt15]}>Contoh penggunaan text style untuk label dan value secara general</Text>
            <Text style={[SpajStyles.strongText, Style.Main.mt15]}>Contoh penggunaan bold text</Text>
            <Text style={[SpajStyles.strongCenteredText, Style.Main.mt15]}>Contoh penggunaan centered bold text</Text>
          </View>
          <View style={SpajStyles.cardContainer}>
            <Text style={Style.Main.mt15}>Contoh penggunaan card styling, dengan text tanpa styling</Text>
            <Text style={[SpajStyles.warningText, Style.Main.mt15]}>Contoh penggunaan warning text</Text>
            <Text style={[SpajStyles.bigWarningText, Style.Main.mt15]}>Contoh penggunaan big centered warning text</Text>
          </View>
          <View style={SpajStyles.componentContainer}>
            <Text style={Style.Main.mt15}>Contoh penggunaan componentContainer styling, dengan text tanpa styling</Text>
            <Text style={[SpajStyles.text, Style.Main.mt15]}>Contoh penggunaan text style untuk label dan value secara general</Text>
            <Text style={[SpajStyles.strongText, Style.Main.mt15]}>Contoh penggunaan bold text</Text>
            <Text style={[SpajStyles.strongCenteredText, Style.Main.mt15]}>Contoh penggunaan centered bold text</Text>
          </View>
          <View style={SpajStyles.cardContainer}>
            <Text style={Style.Main.mt15}>Contoh penggunaan card styling, dengan text tanpa styling</Text>
            <Text style={[SpajStyles.warningText, Style.Main.mt15]}>Contoh penggunaan warning text</Text>
            <Text style={[SpajStyles.bigWarningText, Style.Main.mt15]}>Contoh penggunaan big centered warning text</Text>
          </View>
          <LoadingModal show={this.state.isLoading} size="large" color="white" />
          <CustomButton
            style={[Style.Main.roundedButton, Style.Main.mb30]}
            iconName="chevron-up"
            iconColor="white"
            onPress={() => this.component._root.scrollToPosition(0, 0)}
          />
        </Content>
      </Container>
    );
  }
}

const mapStateToProps = state => ({
  resAuth: state.auth.res,
  spaj: state.spaj.data,
  submission: state.spaj.submission,
});

const mapDispatchToProps = dispatch => ({
  updateSpaj: spaj => dispatch(updateSpajAction(UPDATE_SPAJ, spaj)),
  updateFund: data => dispatch(fundAction(UPDATE_FUND_MASTER, data)),
  updateTopup: data => dispatch(updateSpajAction(UPDATE_TOPUP, data)),
  resetSpaj: () => dispatch(updateSpajAction(RESET_SPAJ)),
  updateSubmission: (status, payload) => dispatch(spajSubmissionAction(status, payload)),
});

export default connect(mapStateToProps, mapDispatchToProps)(LandingTest);
