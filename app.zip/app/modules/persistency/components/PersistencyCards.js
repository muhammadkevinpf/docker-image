import React, { Component } from 'react';
import moment from 'moment';
import { Text, View } from 'native-base';
import { VictoryPie } from 'victory-native';
import { toFixedCurrency } from '../../../utilities/String';
import { AgentScopes } from '../../../config/Constants';
import { isEmpty } from '../../../utilities';
import {
  Collapsible, rowLayout, Skeleton, StyledText,
} from '../../../components';
import Colors from '../../../styles/Colors';
import Style from '../../../styles';
import _ from '../../../lang';

const skeletonLayout = [{
  flexDirection: 'row',
  justifyContent: 'space-between',
  width: '100%',
  height: 7,
  marginVertical: 3,
  children: [
    { width: '25%', height: '100%', borderRadius: 1 },
  ],
}, {
  flexDirection: 'row',
  justifyContent: 'space-between',
  width: '100%',
  height: 9,
  marginVertical: 3,
  children: [
    { width: '40%', height: '100%', borderRadius: 1 },
    { width: '40%', height: '100%', borderRadius: 1 },
  ],
}];

class PersistencyValue extends Component {
  renderAPI = ({ type, value, rollng }) => {
    const { noBorder = false, isLoading = false } = this.props;
    return (
      <View style={[Style.Main.container, Style.Main.rowDirection]}>
        {!noBorder && <View style={[Style.Main.setSize({ w: 3, h: '100%', backgroundColor: Colors.red })]} />}
        <View style={[Style.Main.container, Style.Main.padding10]}>
          <Skeleton isLoading={isLoading} layout={skeletonLayout}>
            <StyledText font={10} color={Colors.gray83}>
              <StyledText italic={type === 'Issued' || type === 'Lapsed'} font={10} color={Colors.gray83}>{type}</StyledText> API
            </StyledText>
            <View style={[Style.Main.rowDirectionSpaceBetween]}>
              <StyledText bold={noBorder}>Rp. {value && String(value) !== '-1' ? toFixedCurrency(value, 2) : '0.00'}</StyledText>
              <StyledText bold={noBorder}>Rp. {rollng && String(rollng) !== '-1' ? toFixedCurrency(rollng, 2) : '0.00'}</StyledText>
            </View>
          </Skeleton>
        </View>
      </View>
    );
  }

  render() {
    const { data, noBorder = false } = this.props;
    return (
      <View style={[Style.Main.fullWidth, !noBorder && Style.Main.setBorder()]}>
        <this.renderAPI type="Issued" value={data.apiIssuedCurrent} rollng={data.apiIssuedRolling} />
        <this.renderAPI type="Kenaikan" value={data.apiIssuedCurrent} rollng={data.apiIncreasedRolling} />
        <this.renderAPI type="Penurunan" value={data.apiDecreasedCurrent} rollng={data.apiDecreasedRolling} />
        <this.renderAPI type="Lapsed" value={data.apiLapsedCurrent} rollng={data.apiLapsedRolling} />
      </View>
    );
  }
}

class PersistencyCard extends Component {
  percentLabelStyle = [
    Style.Main.fontAlbert11, Style.Main.absolute, { bottom: 25 },
    Style.Main.alignCenter, Style.Main.displayFlex,
  ];

  getColor = (percent) => {
    let color = Colors.gray83;
    if (percent > 0) {
      if (percent < 33) color = Colors.redPastel;
      else if (percent > 66) color = Colors.online;
      else color = Colors.orangePastel;
    }
    return color;
  }

  renderPie = (label, percent) => {
    const size = 75;
    const circleWidth = 15;
    const halfSize = Math.round((size - circleWidth) / 2);
    return (
      <View style={[Style.Main.container, Style.Main.center]}>
        <StyledText bold style={[Style.Main.mb10]}>{_(label)}</StyledText>
        <VictoryPie
          padding={0}
          width={size}
          height={size}
          data={[
            { x: 1, y: percent },
            { x: 2, y: 100 - percent },
          ]}
          innerRadius={halfSize}
          cornerRadius={0}
          labels={() => null}
          style={{
            data: { fill: ({ datum }) => (datum.x === 1 ? this.getColor(datum.y) : Colors.grayNearWhite) },
          }}
        />
        <Text style={[Style.Main.fontAlbert11, Style.Main.absolute, Style.Main.alignCenter, Style.Main.displayFlex,
          Style.Main.setSize({ bottom: halfSize, color: this.getColor(percent) })]}
        >{percent}%
        </Text>
      </View>
    );
  }

  render() {
    const {
      data = {}, agentScope = '', lastUpdate, isLoading = false,
    } = this.props;

    let value = {}; let label = '';
    if (agentScope) {
      if (agentScope === AgentScopes.individu) {
        value = data.Individu || {}; label = 'Individu';
      } else if (agentScope.includes(AgentScopes.unit)) {
        value = data.Unit || {}; label = 'Unit';
      }
      // else if (this.props.agentScope.includes(AgentScopes.group)) { value = this.props.data.Group; label = 'GROUP'; }
    }
    return (
      <Collapsible
        title={_('SAAT INI')}
        content={
          <>
            <StyledText>{_(label)}</StyledText>
            <Skeleton isLoading={isLoading} layout={[rowLayout({ w: '70%', h: 7 })]}>
              <StyledText font={10} color={Colors.gray83}>
                {!isEmpty(data) && !isEmpty(data.date) ? `${_('Data diperbaharui pada')} ${moment(lastUpdate).format('LLLL')}`
                  : _('Data belum diperbarui')}
              </StyledText>
            </Skeleton>
            <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.mV15, Style.Main.pt5]}>
              {this.renderPie('Persistensi Lama', Number(value.totalApiCurrent !== -1 ? value.totalApiCurrent || 0 : 0))}
              {this.renderPie('Rolling Persistensi', Number(value.totalApiRolling !== -1 ? value.totalApiRolling || 0 : 0))}
            </View>
          </>
        }
        expandedContent={<PersistencyValue noBorder isLoading={isLoading} data={value} />}
        onDetail={this.props.onPress || (() => {})}
      />
    );
  }
}

class PersistencyHistoryDetail extends Component {
  render() {
    const {
      data, showDetail, showButton, isGroupUnit, isLoading = false, onPress = () => {}, onExpand = () => {},
    } = this.props;
    const totalApiCurrent = isGroupUnit ? data.totalNetAPICurrent : data.totalApiCurrent;
    const totalApiRolling = isGroupUnit ? data.totalNetAPIRolling : data.totalApiRolling;
    return (
      <Collapsible
        isLoading={isLoading}
        title={isGroupUnit ? data.clientName : moment(data.period, 'MM-YYYY').format('MMMM YYYY')}
        content={
          <>
            {
              isGroupUnit &&
              <Skeleton isLoading={isLoading} layout={[rowLayout({ h: 8, w: '15%' })]}>
                <View style={[Style.Main.rowDirection]}>
                  <Text style={[Style.Main.fontAlbert11, Style.Main.mr5, { color: Colors[data.agentType] }]}>{data.agentType}</Text>
                  <Text style={[Style.Main.fontAlbert11]}>{data.agentNumber}</Text>
                </View>
              </Skeleton>
            }
            <View style={[Style.Main.rowDirection, Style.Main.padding15]}>
              <Skeleton
                isLoading={isLoading}
                layout={[rowLayout({ w: 100, h: 8, alignSelf: 'center' }), rowLayout({ w: 50, h: 15, alignSelf: 'center' })]}
              >
                <View style={[Style.Main.center]}>
                  <StyledText font={11} color={Colors.gray83}>{_('Persistensi Lama')}</StyledText>
                  <StyledText font={18}>{totalApiCurrent === -1 ? 0 : totalApiCurrent || 0}%</StyledText>
                </View>
              </Skeleton>
              <Skeleton
                isLoading={isLoading}
                layout={[rowLayout({ w: 100, h: 7, alignSelf: 'center' }), rowLayout({ w: 45, h: 15, alignSelf: 'center' })]}
              >
                <View style={[Style.Main.center]}>
                  <StyledText font={11} color={Colors.gray83}>{_('Rolling Persistensi')}</StyledText>
                  <StyledText font={18}>{totalApiRolling === -1 ? 0 : totalApiRolling || 0}%</StyledText>
                </View>
              </Skeleton>
            </View>
          </>
        }
        expandedContent={<PersistencyValue {...this.props} />}
        onDetail={showButton ? onPress : null}
        onExpand={onExpand}
        isExpanded={showDetail}
      />
    );
  }
}

export {
  PersistencyCard,
  PersistencyHistoryDetail,
};
