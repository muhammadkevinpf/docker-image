import moment from 'moment';
// import Analytics from 'appcenter-analytics';
import CryptoJS from 'crypto-js';
import SQLiteUtils from '../../../utilities/SQLiteUtils';
import Database from '../../../config/Database';

const { customer } = Database.pruSmart.tables;

const querySelect = `SELECT * FROM ${customer.name} WHERE method = ? and agentCode = ?`;
const querySelectByKey = `SELECT * FROM ${customer.name} WHERE method = ? and agentCode = ? and customerCode = ?`;
const queryCount = `SELECT COUNT(*) as totalCustomer FROM ${customer.name} WHERE method = ? and agentCode = ?`;
const queryUpdateByKey = `UPDATE ${customer.name} SET data = ?, createDate = ? where method = ? and agentCode = ? and customerCode = ?`;
const queryInsert = `INSERT INTO ${customer.name} (method, agentCode, customerCode, data, createDate) VALUES (?,?,?,?,?)`;
const queryDeleteByKey = `DELETE FROM ${customer.name} WHERE method = ? and agentCode = ? and customerCode = ?`;
const queryCreateTable = `CREATE TABLE IF NOT EXISTS ${customer.name} (agentCode, method, customerCode, data, createDate)`;
const serviceName = 'CustomerStorageService';

const openDatabase = () => new Promise(async (resolve, reject) => {
  try {
    const dbName = Database.pruSmart.name;
    const db = await SQLiteUtils.openDatabase(dbName, 'default');
    await SQLiteUtils.executeTransaction(db, queryCreateTable, []);
    resolve(db);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const getAll = (db, agentCode) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(db, querySelect, [customer.method, agentCode]);
    const data = [];
    for (let i = 0; i < res.rows.length; i += 1) {
      data.push(JSON.parse(CryptoJS.AES.decrypt(res.rows.item(i).data, SQLiteUtils.DBKEY).toString(CryptoJS.enc.Utf8)));
    }
    resolve(data);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const getByCode = (db, param) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(db, querySelectByKey, [customer.method, param.agentCode, param.customerId]);
    if (res.rows.length > 0) {
      resolve(JSON.parse(CryptoJS.AES.decrypt(res.rows.item(0).data, SQLiteUtils.DBKEY).toString(CryptoJS.enc.Utf8)).invocationResult);
    } else {
      resolve(res.rows.length);
    }
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const getTotalCustomer = (db, agentCode) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(db, queryCount, [customer.method, agentCode]);
    resolve(res);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const getCustomerStorageByCustomerMap = (db, param) => new Promise(async (resolve, reject) => {
  try {
    const result = [];
    const objParameter = param.customerIdMap;
    const objLength = Object.keys(objParameter).length;
    let counter = 0;
    Object.keys(objParameter).forEach(async (key) => {
      const res = await SQLiteUtils.executeQuery(
        db,
        querySelectByKey,
        [customer.method, param.agentCode, param.customerIdMap[key]],
      );
      counter += 1;
      for (let jj = 0; jj < res.rows.length; jj += 1) {
        result.push(JSON.parse(CryptoJS.AES.decrypt(res.rows.item(jj).data, SQLiteUtils.DBKEY).toString(CryptoJS.enc.Utf8)).invocationResult);
      }

      if (counter === objLength) {
        resolve(result);
      }
    });
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const deleteByCode = (db, param) => new Promise(async (resolve, reject) => {
  try {
    // const checkData = await getByCode(db, param);
    // if (!checkData) { reject(new Error(`${serviceName} Data not found`)); }
    const res = await SQLiteUtils.executeTransaction(
      db,
      queryDeleteByKey,
      [customer.method, param.agentCode, param.customerId],
    );
    resolve(res);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const deleteByMultipleCodes = (db, param) => new Promise(async (resolve, reject) => {
  try {
    const queryDeleteByMultipleCodes = `DELETE FROM ${customer.name} WHERE 
      method = '${customer.method}' AND 
      agentCode = '${param.agentCode}' AND 
      customerCode IN (${param.listCustomerId})`;
    const res = await SQLiteUtils.executeTransaction(db, queryDeleteByMultipleCodes, []);
    resolve(res);
  } catch (error) {
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const upsert = (db, param) => new Promise(async (resolve, reject) => {
  try {
    let data = {};
    data.invocationResult = param.data;
    data.agentId = param.agentCode;
    data.customerId = param.customerId;
    data.retrieveDate = new Date();

    let queryToProcess = queryInsert;

    let parameterToInput = [
      customer.method,
      param.agentCode,
      param.customerId,
      CryptoJS.AES.encrypt(JSON.stringify(data), SQLiteUtils.DBKEY).toString(),
      moment().format('DD/MM/YYYY hh:mm'),
    ];

    const res = await SQLiteUtils.executeQuery(
      db,
      querySelectByKey,
      [customer.method, param.agentCode, param.customerId],
    );

    if (res.rows.length > 0) {
      data = JSON.parse(CryptoJS.AES.decrypt(res.rows.item(0).data, SQLiteUtils.DBKEY).toString(CryptoJS.enc.Utf8));
      data.invocationResult = param.data;
      data.customerId = param.customerId;
      queryToProcess = queryUpdateByKey;
      parameterToInput = [
        CryptoJS.AES.encrypt(JSON.stringify(data), SQLiteUtils.DBKEY).toString(),
        moment().format('DD/MM/YYYY hh:mm'),
        customer.method,
        param.agentCode,
        param.customerId,
      ];
    }

    const resUpsert = await SQLiteUtils.executeTransaction(
      db,
      queryToProcess,
      parameterToInput,
    );
    resolve(`UPSERT ${resUpsert}`);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const insert = (db, param) => new Promise(async (resolve, reject) => {
  try {
    const data = {};
    data.invocationResult = param.data;
    data.agentId = param.agentCode;
    data.customerId = param.customerId;
    data.retrieveDate = new Date();

    const res = await SQLiteUtils.executeTransaction(
      db,
      queryInsert,
      [
        customer.method,
        param.agentCode,
        param.customerId,
        CryptoJS.AES.encrypt(JSON.stringify(data), SQLiteUtils.DBKEY).toString(),
        moment().format('DD/MM/YYYY hh:mm'),
      ],
    );
    resolve(`INSERT ${res}`);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

export default {
  openDatabase,
  getAll,
  getByCode,
  getCustomerStorageByCustomerMap,
  getTotalCustomer,
  upsert,
  insert,
  deleteByCode,
  deleteByMultipleCodes,
};
