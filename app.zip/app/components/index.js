import AlertTemplate_ from './alert-template';
import AutoComplete_ from './autocomplete';
import AutoCompleteNew_ from './autocomplete-new';
import Badge_ from './badge';
import ButtonCustom_ from './button-custom';
import CheckBoxCustom_ from './checkbox-custom';
import CheckBoxCustomNew_ from './checkbox-custom-new';
import CheckBoxPicture_ from './checkbox-picture';
import DatePicker_ from './datepicker';
import DatePickerNew_ from './datepicker-new';
import DrawerBurgerHeader_ from './drawer-burger-header';
import Dropdown_ from './picker-dropdown';
import DropdownNew_ from './picker-dropdown-new';
import Header_ from './header';
import InputField_ from './input-field';
import InputFieldNew_ from './input-field-new';
import TextareaNew_ from './textarea-new';
import LoadingModal_ from './loading_modal';
import LogoText_ from './logo-text';
import ModalCustom_ from './modal-custom';
import MorePopupMenu_ from './more-popup-menu';
import RadioButton_ from './radio-button';
import SearchBar_ from './search-bar';
import SignaturePad_ from './signature-pad';
import TabContainer_ from './tab-container';
import ConnectionStatus from './connection-status';
import OutlineCheckbox_ from './outline-checkbox';
import InputFieldOld_ from './input-field-old';
import RadioListCardOld_ from './radio-list-card-old';
import PickerDropdownOld_ from './picker-dropdown-old';
import CheckBoxCustomOld_ from './checkbox-custom-old';
import RadioListCard from './radio-list-card';
import HeaderWithTodo from './header-with-todo-and-notification';
import SearchNativeBase from './search-bar-native-base';
import SortFilter from './sort-and-filter';
import CustomAccordion from './accordion';
import NativeTabs from './tabs-native-base';
import CustomFlatList from './custom-flat-list';
import ButtonDownload from './button-download';
import Collapsible from './collapsible';
import CustomSectionList from './custom-section-list';

const AlertTemplate = AlertTemplate_;
const AutoComplete = AutoComplete_;
const Badge = Badge_;
const ButtonCustom = ButtonCustom_;
const CheckBoxCustom = CheckBoxCustom_;
const CheckBoxPicture = CheckBoxPicture_; // mot being used
const DatePicker = DatePicker_;
const DrawerBurgerHeader = DrawerBurgerHeader_; // not being used
const Dropdown = Dropdown_;
const Header = Header_;
const InputField = InputField_;
const LoadingModal = LoadingModal_;
const LogoText = LogoText_; // not being used
const ModalCustom = ModalCustom_;
const MorePopupMenu = MorePopupMenu_;
const RadioButton = RadioButton_;
const SearchBar = SearchBar_;
const SignaturePad = SignaturePad_;
const TabContainer = TabContainer_;
const OutlineCheckbox = OutlineCheckbox_;
const AutoCompleteNew = AutoCompleteNew_;
const CheckBoxCustomNew = CheckBoxCustomNew_;
const DatePickerNew = DatePickerNew_;
const DropdownNew = DropdownNew_;
const InputFieldNew = InputFieldNew_;
const TextareaNew = TextareaNew_;
const InputFieldOld = InputFieldOld_;
const RadioListCardOld = RadioListCardOld_;
const PickerDropdownOld = PickerDropdownOld_; // not being used
const CheckBoxCustomOld = CheckBoxCustomOld_; // not being used

export {
  AlertTemplate,
  AutoComplete,
  Badge,
  ButtonCustom,
  CheckBoxCustom,
  CheckBoxPicture,
  DatePicker,
  DrawerBurgerHeader,
  Dropdown,
  Header,
  InputField,
  LoadingModal,
  LogoText,
  ModalCustom,
  MorePopupMenu,
  RadioButton,
  SearchBar,
  SignaturePad,
  TabContainer,
  AutoCompleteNew,
  CheckBoxCustomNew,
  DatePickerNew,
  DropdownNew,
  InputFieldNew,
  TextareaNew,
  ConnectionStatus,
  OutlineCheckbox,
  RadioListCard,
  HeaderWithTodo,
  CustomFlatList,
  SearchNativeBase,
  SortFilter,
  CustomAccordion,
  NativeTabs,
  InputFieldOld,
  RadioListCardOld,
  PickerDropdownOld,
  CheckBoxCustomOld,
  ButtonDownload,
  Collapsible,
  CustomSectionList,
};

export * from './list-information';
export * from './seacrh-sort-filter';
export * from './side-bar-menu';
export * from './common-components';
export * from './month-year-picker';
export * from './pru-text/CoverageText';
export * from './signature-new';
export * from './header/MyStatusBar';
export * from './skeleton-loading';
export * from './custom-flat-list';
export * from './filter-bars';
