/**
 * @author: ahmdichsanb@gmail.com
*/

import React, { PureComponent, Fragment } from 'react';
import {
  TouchableOpacity,
  FlatList,
  View,
  Text,
} from 'react-native';
import PropTypes from 'prop-types';
import Icon from 'react-native-vector-icons/FontAwesome5';

import StyleCheckBoxPicture from './StyleCheckBoxPicture';

class CheckBoxPicture extends PureComponent {
  keyExtractor = item => item.value;

  handleOnPress = (value) => {
    this.props.onPress(value);
  }

  renderItem = ({ item, index }) => {
    const {
      value,
      icon,
      label,
      isSelected,
      isDisabled,
    } = item;
    const order = index + 1;

    return (
      <TouchableOpacity
        key={order}
        onPress={() => this.handleOnPress(value)}
        style={[
          StyleCheckBoxPicture.container,
          isSelected ? StyleCheckBoxPicture.backgroundSelected : StyleCheckBoxPicture.backgroundUnSelected,
        ]}
        disabled={isDisabled}
        activeOpacity={0.8}
      >
        {
          /* below code if the icon which passed is a converted-js-file-from-svg */
          typeof icon !== 'string' && (
            <View style={[StyleCheckBoxPicture.svgIconWrapper]}>
              {icon}
            </View>
          )
        }
        <View style={[StyleCheckBoxPicture.labelWrapper]}>
          <Text style={[StyleCheckBoxPicture.label]}>
            {
              typeof icon === 'string' && (
                <Icon name={icon} size={30} color="white" />
              )
            }
            {'\n'}
            {label}
          </Text>
        </View>
      </TouchableOpacity>
    );
  }

  render() {
    const { data } = this.props;
    return (
      <Fragment>
        <FlatList
          data={data}
          keyExtractor={this.keyExtractor}
          renderItem={this.renderItem}
          numColumns={2}
          columnWrapperStyle={[StyleCheckBoxPicture.columnWrapperStyle]}
        />
      </Fragment>
    );
  }
}

CheckBoxPicture.propTypes = {
  data: PropTypes.arrayOf(PropTypes.object).isRequired,
  onPress: PropTypes.func.isRequired,
};

export default CheckBoxPicture;
