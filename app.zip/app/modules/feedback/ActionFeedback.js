export const feedbackAction = (action, value) => ({ type: action, payload: value });
