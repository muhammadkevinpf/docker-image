/* eslint-disable import/no-cycle */
import moment from 'moment';
// import Analytics from 'appcenter-analytics';
import CryptoJS from 'crypto-js';
import SQLiteUtils from '../../../utilities/SQLiteUtils';
import Database from '../../../config/Database';
import HeaderService from './HeaderService';

const { quotation } = Database.pruSmart.tables;

const querySelect = `SELECT * FROM ${quotation.name} WHERE method = ? and agentCode = ? and quotationCode != ''`;
const querySelectByKey = `SELECT * FROM ${quotation.name} WHERE method = ? and agentCode = ? and quotationCode = ?`;
const queryInsertByKey = `INSERT INTO ${quotation.name} (method, agentCode, quotationCode, data, createDate) VALUES (?,?,?,?,?)`;
const queryUpdateByKey = `UPDATE ${quotation.name} SET data = ?, createDate = ? where method = ? and agentCode = ? and quotationCode = ?`;
const queryDelete = `DELETE FROM ${quotation.name} WHERE method = ? and agentCode = ? and quotationCode = ?`;
const queryCreateTable = `CREATE TABLE IF NOT EXISTS ${quotation.name} (agentCode, method, quotationCode, data, createDate)`;
const serviceName = 'NewQuotationService';

const openDatabase = () => new Promise(async (resolve, reject) => {
  try {
    const dbName = Database.pruSmart.name;
    const db = await SQLiteUtils.openDatabase(dbName, 'default');
    await SQLiteUtils.executeTransaction(db, queryCreateTable, []);
    resolve(db);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const getAll = (db, agentCode) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(db, querySelect, [quotation.method, agentCode]);
    const data = [];
    for (let i = 0; i < res.rows.length; i += 1) {
      data.push(JSON.parse(CryptoJS.AES.decrypt(res.rows.item(i).data, SQLiteUtils.DBKEY).toString(CryptoJS.enc.Utf8)));
    }
    resolve(data);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const getByCode = (db, param) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(
      db,
      querySelectByKey,
      [quotation.method, param.agentCode, param.quotationCode],
    );
    if (res.rows.length > 0) {
      resolve(JSON.parse(CryptoJS.AES.decrypt(res.rows.item(0).data, SQLiteUtils.DBKEY).toString(CryptoJS.enc.Utf8)).invocationResult);
    } else {
      resolve(res.rows.length);
    }
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const deleteByCode = (db, param) => new Promise(async (resolve, reject) => {
  try {
    // const checkData = await getByCode(db, param);
    // if (!checkData) { reject(new Error(`${serviceName} Data not found`)); }
    const res = await SQLiteUtils.executeTransaction(
      db,
      queryDelete,
      [quotation.method, param.agentCode, param.quotationCode],
    );
    resolve(res);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const upsert = (db, param) => new Promise(async (resolve, reject) => {
  try {
    let data = {};
    // eslint-disable-next-line no-param-reassign
    param.data.sqs.updatedDate = (`${moment(new Date(), 'YYYY-MM-DDTHH:mm:ss.SSS').format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`);
    data.invocationResult = param.data;
    data.agentId = param.agentCode;
    data.quotationCd = param.quotationCode;
    data.retrieveDate = (`${moment(new Date(), 'YYYY-MM-DDTHH:mm:ss.SSS').format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`);
    let queryToProcess = queryInsertByKey;
    let parameterToInput = [
      quotation.method,
      param.agentCode,
      param.quotationCode,
      CryptoJS.AES.encrypt(JSON.stringify(data), SQLiteUtils.DBKEY).toString(),
      moment().format('DD/MM/YYYY HH:mm'),
    ];
    const res = await SQLiteUtils.executeQuery(db, querySelectByKey, [quotation.method, param.agentCode, param.quotationCode]);
    if (res.rows.length > 0) {
      data = JSON.parse(CryptoJS.AES.decrypt(res.rows.item(0).data, SQLiteUtils.DBKEY).toString(CryptoJS.enc.Utf8));
      data.invocationResult = param.data;
      data.quotationCd = param.quotationCode;
      queryToProcess = queryUpdateByKey;
      parameterToInput = [
        CryptoJS.AES.encrypt(JSON.stringify(data), SQLiteUtils.DBKEY).toString(),
        moment().format('DD/MM/YYYY HH:mm'),
        quotation.method,
        param.agentCode,
        param.quotationCode,
      ];
    }
    const resUpsert = await SQLiteUtils.executeTransaction(
      db,
      queryToProcess,
      parameterToInput,
    );
    let headerUpdate = '';
    const CoState = param.data.prop_no ? 'SQS' : '';
    if (!param.isFromApi && !param.isFromSubmit) {
      headerUpdate = await HeaderService.convertSqsToHeader(
        param.data, param.agentCode, param.agentCode,
        param.data.status, param.data.prop_no, CoState,
      );
    }
    resolve(`UPSERT ${resUpsert} ${headerUpdate}`);
  } catch (error) {
    console.log('error newqsservice:', error);
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

export default {
  openDatabase,
  getAll,
  getByCode,
  deleteByCode,
  upsert,
};
