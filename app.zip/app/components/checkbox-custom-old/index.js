/**
 * @author:
 * ahmdichsanb@gmail.com
 * definite maji arsana
*/

import React, { Component, Fragment } from 'react';
import {
  Text, View, Icon,
} from 'native-base';
import PropTypes from 'prop-types';
import { Row, Col } from 'react-native-easy-grid';
import { NavigationEvents } from 'react-navigation';
import _ from '../../lang';
import InputField from '../input-field-old';
import Style from '../../styles';
import StyleCheckBox from './style';

class CheckBoxCustomOld extends Component {
  constructor(props) {
    super(props);
    this.state = {
      checkBoxData: this.props.renderData,
      validStatus: false,
      validStatusInvoked: true,
      errorMessage: 'Wajib dipilih salah satu!',
      errorMessageInvoked: '',
    };
  }

  onCheckBoxPressed = (value) => {
    const checkBoxData = this.props.renderData;
    const obj = checkBoxData.find(x => x.value === value);
    obj.isSelected = !obj.isSelected;
    if (!obj.isSelected) {
      if (obj.input) {
        if (obj.input !== '') {
          obj.input = '';
        }
      }
    }
    this.setState({ checkBoxData });
    this.checkValidStatusSelected(checkBoxData);
    if (this.props.onPress) {
      this.props.onPress(obj);
    }
  }

  setValueFromChild = (id, value) => {
    this.setState({ [`dataChild${id}`]: value }, () => { this.onTextInput(id); });
  }

  onTextInput = (i) => {
    const { checkBoxData } = this.state;
    const copyCheckBoxData = [...checkBoxData];
    copyCheckBoxData[i].input = this.state[`dataChild${i}`];
    this.setState({ checkBoxData: copyCheckBoxData });
    this.checkValidStatusByInput(copyCheckBoxData);
    if (this.props.onChangeText) {
      this.props.onChangeText(copyCheckBoxData[i]);
    }
  }

  checkValidStatusSelected = (checkBoxData) => {
    const selected = checkBoxData.filter(x => x.isSelected);
    const noSelected = selected.length === 0;
    const selectedWInput = selected.filter(x => x.isTextInput && x.input === '').length >= 1;
    if (noSelected) {
      this.setState({ validStatus: false, errorMessage: 'Checkbox wajib dipilih salah satu!' });
    } else if (selectedWInput) {
      this.setState({ validStatus: false, errorMessage: 'Mohon input field diisi!' });
    } else {
      this.setState({ validStatus: true, errorMessage: '' });
    }
  }

  checkValidStatusByInput = (checkBoxData) => {
    const selectedWInputValue = checkBoxData.filter(x => x.isSelected && x.isTextInput && x.input).length > 0;
    if (selectedWInputValue) {
      this.setState({ validStatus: true, errorMessage: '' });
    } else {
      this.setState({ validStatus: false, errorMessage: 'Mohon input field diisi!' });
    }
  }

  invokeValidation = (validStatusInvoked, errorMessageInvoked) => {
    if (errorMessageInvoked === null || errorMessageInvoked === undefined || errorMessageInvoked === '') {
      // eslint-disable-next-line no-param-reassign
      errorMessageInvoked = '';
    }
    this.setState({
      validStatusInvoked,
      errorMessageInvoked,
    });
  }

  onDisabledCheckBox = () => {
    this.setState({
      checkBoxData: this.props.renderData,
      validStatus: true,
      errorMessage: '',
    });
  }

  isIncluded = (obj, arr) => {
    if (arr && arr.length > 0 && arr.find(item => item[this.props.valueProp] === obj)) return true;
    return false;
  }

  renderInputValue = () => {
    /* let val = '';
    if (this.isIncluded(data.value, this.props.selectedObjects)) {
      val = this.props.selectedObjects.find(item => item[this.props.valueProp] === data.value)[this.props.inputLabelProp];
    }
    return val; */
  }

  renderOneColumn = (i, data) => {
    const {
      textType, inputPlaceholder,
    } = this.props;
    // const isChecked = this.isIncluded(data.value, this.props.selectedObjects);
    const isChecked = data.isSelected;
    const isDisabled = this.isIncluded(data.value, this.props.disabledValues);
    return (
      <View key={i} style={[Style.Main.mt8, Style.Main.mb8]}>
        <View>
          <Text
            onPress={isDisabled ? () => { } : () => this.onCheckBoxPressed(data.value)}
          >
            <Icon
              type={(isChecked) ? 'AntDesign' : 'Ionicons'}
              name={(isChecked) ? 'checksquareo' : 'ios-square-outline'}
              onPress={isDisabled ? () => { } : () => this.onCheckBoxPressed(data.value)}
              style={(isChecked) ? [Style.Main.font14, Style.Main.textRed] : [Style.Main.font20, Style.Main.textAlmostBlack, Style.Main.pt5]}
            />
            <Text style={[Style.Main.gray83, Style.Main.fontAlbert, Style.Main.font14, this.props.fontStyle]}>&nbsp;&nbsp;&nbsp;{data.label}</Text>
          </Text>
        </View>
        {
          (data.isTextInput && isChecked) && (
            <View style={[Style.Main.ml8, Style.Main.mtn30]}>
              <InputField
                value={this.renderInputValue(data)}
                ref={(ref) => { this[`_inputField${i}`] = ref; }}
                placeholder={inputPlaceholder}
                onChangeText={() => this.onTextInput(i)}
                type={data.textType || textType}
                setValueToParent={this.setValueFromChild}
                index={i}
                isInsideCheckbox
                isRequired={false}
              />
            </View>
          )
        }
      </View>
    );
  }

  renderColumn = (i, data) => {
    const {
      fontStyle, renderData, colIconStyle, colLabelStyle,
      colInputStyle, colIconSize, colLabelSize, textType, inputPlaceholder,
    } = this.props;
    const lastIndex = renderData.length - 1;
    const oddsIndex = renderData.length % 2 !== 0;
    const isChecked = this.isIncluded(data.value, this.props.selectedObjects);
    const isDisabled = this.isIncluded(data.value, this.props.disabledValues);
    return (
      <View size={oddsIndex && i === lastIndex ? 0.5 : 1} key={`col ${i}`}>
        <Row style={isDisabled && Style.Main.halfOpacity}>
          <Col size={colIconSize} style={[colIconStyle]}>
            <Icon
              type={(isChecked) ? 'AntDesign' : 'Ionicons'}
              name={(isChecked) ? 'checksquareo' : 'ios-square-outline'}
              onPress={isDisabled ? () => { } : () => this.onCheckBoxPressed(data.value)}
            />
          </Col>
          <Col size={colLabelSize} style={[colLabelStyle]}>
            <Text
              style={[Style.Main.gray83, Style.Main.fontAlbert, fontStyle]}
              onPress={isDisabled ? () => { } : () => this.onCheckBoxPressed(data.value)}
            >
              {data.label}
            </Text>
          </Col>
        </Row>
        {
          (data.isTextInput && isChecked) && (
            <Row>
              <Col style={[colInputStyle]}>
                <InputField
                  value={this.renderInputValue(data)}
                  ref={(ref) => { this[`_inputField${i}`] = ref; }}
                  placeholder={inputPlaceholder}
                  onChangeText={() => this.onTextInput(i)}
                  type={data.textType || textType}
                  setValueToParent={this.setValueFromChild}
                  index={i}
                  isInsideCheckbox
                />
              </Col>
            </Row>
          )
        }
      </View>
    );
  }

  render() {
    const {
      title, fontStyle,
    } = this.props;
    const {
      checkBoxData, validStatus, errorMessage,
      validStatusInvoked, errorMessageInvoked,
    } = this.state;
    // eslint-disable-next-line prefer-const
    let renderData = [];
    for (let i = 0; i < checkBoxData.length; i += 2) {
      // eslint-disable-next-line prefer-const
      let column = [];
      column.push(
        this.renderColumn(i, checkBoxData[i]),
      );
      if (i + 1 < checkBoxData.length) {
        column.push(
          this.renderColumn(i + 1, checkBoxData[i + 1]),
        );
      }
      renderData.push(<Row key={`row ${i}`}>{column}</Row>);
    }
    return (
      <Fragment>
        <NavigationEvents />
        {
          title && (
            <Row style={[Style.Main.mt15]}>
              <Text style={[Style.Main.textAlmostBlack, Style.Main.font16, Style.Main.fontAlbert, fontStyle]}>
                {_(title)}
              </Text>
            </Row>
          )
        }
        <View>
          {this.props.isOneColumn ? this.props.renderData.map((item, i) => this.renderOneColumn(i, item)) : renderData}
        </View>
        {!validStatus && (!this.props.selectedObjects || this.props.selectedObjects.length <= 0) && this.props.isRequired && (
          <Row>
            <Text style={[Style.Main.textRed, Style.Main.font10, Style.Main.fontAlbert,
              (errorMessage === 'Mohon input field diisi!')
                ? Style.Main.ml26
                : undefined,
            ]}
            >{_(errorMessage)}
            </Text>
          </Row>
        )}
        {!validStatusInvoked && this.props.isRequired && (
          <Row>
            <Text
              style={[
                Style.Main.textRed,
                Style.Main.font10,
                Style.Main.mb15,
                Style.Main.fontAlbert,
              ]}
            >{_(errorMessageInvoked)}
            </Text>
          </Row>
        )}
      </Fragment>
    );
  }
}

CheckBoxCustomOld.propTypes = {
  colIconSize: PropTypes.number,
  colLabelSize: PropTypes.number,
  fontStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  colIconStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  colLabelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  colInputStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  textType: PropTypes.string,

  // added
  selectedObjects: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  valueProp: PropTypes.string,
  // inputLabelProp: PropTypes.string,
  isOneColumn: PropTypes.bool,
  isRequired: PropTypes.bool,
  disabledValues: PropTypes.arrayOf(PropTypes.oneOfType([
    PropTypes.number, PropTypes.string, PropTypes.bool,
  ])),
};

CheckBoxCustomOld.defaultProps = {
  colIconSize: 10,
  colLabelSize: 90,
  fontStyle: StyleCheckBox.fontStyle,
  colIconStyle: StyleCheckBox.colIconStyle,
  colLabelStyle: StyleCheckBox.colLabelStyle,
  colInputStyle: StyleCheckBox.colInputStyle,
  textType: 'default',

  // added
  valueProp: 'value',
  // inputLabelProp: 'input',
  selectedObjects: null,
  isOneColumn: false,
  isRequired: true,
  disabledValues: null,
};

export default CheckBoxCustomOld;

// ========== KETERANGAN PROPS =========== //
// renderData: Strukturnya seperti berikut
// const data = [
//   {
//     label: 'Kerja Serabutan',
//     value: 'B',
//     isSelected: false,
//     isTextInput: true,
//     textType: 'default',
//     input: '',
//   },
//   {
//     label: 'Pengangguran',
//     value: 'C',
//     isSelected: false,
//     isTextInput: false,
//   },
// ]
//
//  ref CheckBoxCard ini adalah:
//  1. CheckBoxData: berupa arrayObject yang di lemparkan
//     sebagai dataRender yang sudah diedit di dalam komponen ini;
//  2. ValidStatus: berupa bolean yang menandakan bahwa komponen ini
//     sudah ada pilihan atau belum;
//  3. ValidStatusInvoke: berupa bolean yang menandakan bahwa komponen ini
//     sudah ada pilihan atau belum berdasarkan validasi khusus dari index atau parent;
//  4. ErrorMessage: pesan mengenai terdapat pilihan yang kurang atau belum diisi input field
//  5. ErrorMessageInvoked: pesan mengenai terdapat pilihan yang kurang atau belum diisi input field
//     berdasarkan validasi khusus dari index atau parent;
