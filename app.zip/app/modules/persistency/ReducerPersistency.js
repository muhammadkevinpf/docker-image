/* eslint-disable max-len */
import { requestStatus } from '../../utilities/ApiConnection';
import {
  PERSISTENCY_MAIN_CURRENT, PERSISTENCY_MAIN_HISTORY,
  PERSISTENCY_GROUPUNIT_LIST, PERSISTENCY_GROUPUNIT_FILTER,
  PERSISTENCY_INDIVIDU_CURRENT_LIST, PERSISTENCY_INDIVIDU_ROLLING_LIST,
  PERSISTENCY_INDIVIDU_CURRENT_FILTER, PERSISTENCY_INDIVIDU_ROLLING_FILTER,
  CLEAR_PERSISTENCY_GROUPUNIT_LIST, CLEAR_PERSISTENCY_GROUPUNIT_FILTER,
  CLEAR_PERSISTENCY_INDIVIDU_CURRENT_LIST, CLEAR_PERSISTENCY_INDIVIDU_ROLLING_LIST,
  CLEAR_PERSISTENCY_INDIVIDU_CURRENT_FILTER, CLEAR_PERSISTENCY_INDIVIDU_ROLLING_FILTER,
  PERSISTENCY_HISTORY_DETAIL, CLEAR_PERSISTENCY_HISTORY_DETAILS,
} from './ConfigPersistency';
import { RESET_ALL_STATE } from '../dashboard/ConfigDashboard';

const initialStatePersistency = {
  mainCurrentStatus: requestStatus.IDLE,
  mainHistoryStatus: requestStatus.IDLE,
  listGroupUnitStatus: requestStatus.IDLE,
  listIndividuCurrentStatus: requestStatus.IDLE,
  listIndividuRollingStatus: requestStatus.IDLE,
  filterGroupUnitStatus: requestStatus.IDLE,
  filterIndividuCurrentStatus: requestStatus.IDLE,
  filterIndividuRollingStatus: requestStatus.IDLE,
  historyDetailStatus: requestStatus.IDLE,

  // result
  groupUnitList: [],
  individuCurrentList: [],
  individuRollingList: [],
  groupUnitDate: new Date(),
  individuCurrentDate: new Date(),
  individuRollingDate: new Date(),
  groupUnitFilter: {},
  individuCurrentFilter: {},
  individuRollingFilter: {},
  historyDetail: { result: [] },
  error: null,
  send: null,
};

export function ReducerPersistency(state = initialStatePersistency, action) {
  switch (action.type) {
    case RESET_ALL_STATE: return initialStatePersistency;

    case PERSISTENCY_MAIN_CURRENT.FETCH: return { ...state, mainCurrentStatus: requestStatus.FETCH };
    case PERSISTENCY_MAIN_CURRENT.SUCCESS: return { ...state, mainCurrentStatus: requestStatus.SUCCESS };
    case PERSISTENCY_MAIN_CURRENT.FAILED: return { ...state, mainCurrentStatus: requestStatus.FAILED };

    case PERSISTENCY_MAIN_HISTORY.FETCH: return { ...state, mainHistoryStatus: requestStatus.FETCH };
    case PERSISTENCY_MAIN_HISTORY.SUCCESS: return { ...state, mainHistoryStatus: requestStatus.SUCCESS };
    case PERSISTENCY_MAIN_HISTORY.FAILED: return { ...state, mainHistoryStatus: requestStatus.FAILED };

    case PERSISTENCY_GROUPUNIT_LIST.FETCH: return { ...state, listGroupUnitStatus: requestStatus.FETCH, send: action.payload };
    case PERSISTENCY_GROUPUNIT_LIST.SUCCESS: return {
      ...state,
      listGroupUnitStatus: requestStatus.SUCCESS,
      groupUnitList: state.groupUnitList.length ? [...state.groupUnitList, ...action.payload.result.filter(x => !state.groupUnitList.some(item => item === x))]
        : action.payload.result,
      groupUnitDate: action.payload.date,
    };
    case PERSISTENCY_GROUPUNIT_LIST.FAILED: return { ...state, listGroupUnitStatus: requestStatus.FAILED, error: action.payload };
    case CLEAR_PERSISTENCY_GROUPUNIT_LIST: return { ...state, listGroupUnitStatus: requestStatus.IDLE, groupUnitList: [] };

    case PERSISTENCY_INDIVIDU_CURRENT_LIST.FETCH: return { ...state, listIndividuCurrentStatus: requestStatus.FETCH, send: action.payload };
    case PERSISTENCY_INDIVIDU_CURRENT_LIST.SUCCESS: return {
      ...state,
      listIndividuCurrentStatus: requestStatus.SUCCESS,
      individuCurrentList: state.individuCurrentList.length ? [...state.individuCurrentList, ...action.payload.result.filter(x => !state.individuCurrentList.some(item => item.policyNo === x.policyNo))]
        : action.payload.result,
      individuCurrentDate: action.payload.date,
    };
    case PERSISTENCY_INDIVIDU_CURRENT_LIST.FAILED: return { ...state, listIndividuCurrentStatus: requestStatus.FAILED, error: action.payload };
    case CLEAR_PERSISTENCY_INDIVIDU_CURRENT_LIST: return { ...state, listIndividuCurrentStatus: requestStatus.IDLE, individuCurrentList: [] };

    case PERSISTENCY_INDIVIDU_ROLLING_LIST.FETCH: return { ...state, listIndividuRollingStatus: requestStatus.FETCH, send: action.payload };
    case PERSISTENCY_INDIVIDU_ROLLING_LIST.SUCCESS: return {
      ...state,
      listIndividuRollingStatus: requestStatus.SUCCESS,
      individuRollingList: state.individuRollingList.length ? [...state.individuRollingList, ...action.payload.result.filter(x => !state.individuRollingList.some(item => item === x))]
        : action.payload.result,
      individuRollingDate: action.payload.date,
    };
    case PERSISTENCY_INDIVIDU_ROLLING_LIST.FAILED: return { ...state, listIndividuRollingStatus: requestStatus.FAILED, error: action.payload };
    case CLEAR_PERSISTENCY_INDIVIDU_ROLLING_LIST: return { ...state, listIndividuRollingStatus: requestStatus.IDLE, individuRollingList: [] };

    case PERSISTENCY_GROUPUNIT_FILTER.FETCH: return { ...state, filterGroupUnitStatus: requestStatus.FETCH, send: action.payload };
    case PERSISTENCY_GROUPUNIT_FILTER.SUCCESS: return { ...state, filterGroupUnitStatus: requestStatus.SUCCESS, groupUnitFilter: action.payload };
    case PERSISTENCY_GROUPUNIT_FILTER.FAILED: return { ...state, filterGroupUnitStatus: requestStatus.FAILED, error: action.payload };
    case CLEAR_PERSISTENCY_GROUPUNIT_FILTER: return { ...state, filterGroupUnitStatus: requestStatus.IDLE, groupUnitFilter: {} };

    case PERSISTENCY_INDIVIDU_CURRENT_FILTER.FETCH: return { ...state, filterIndividuCurrentStatus: requestStatus.FETCH, send: action.payload };
    case PERSISTENCY_INDIVIDU_CURRENT_FILTER.SUCCESS: return { ...state, filterIndividuCurrentStatus: requestStatus.SUCCESS, individuCurrentFilter: action.payload };
    case PERSISTENCY_INDIVIDU_CURRENT_FILTER.FAILED: return { ...state, filterIndividuCurrentStatus: requestStatus.FAILED, error: action.payload };
    case CLEAR_PERSISTENCY_INDIVIDU_CURRENT_FILTER: return { ...state, filterIndividuCurrentStatus: requestStatus.IDLE, individuCurrentFilter: {} };

    case PERSISTENCY_INDIVIDU_ROLLING_FILTER.FETCH: return { ...state, filterIndividuRollingStatus: requestStatus.FETCH, send: action.payload };
    case PERSISTENCY_INDIVIDU_ROLLING_FILTER.SUCCESS: return { ...state, filterIndividuRollingStatus: requestStatus.SUCCESS, individuRollingFilter: action.payload };
    case PERSISTENCY_INDIVIDU_ROLLING_FILTER.FAILED: return { ...state, filterIndividuRollingStatus: requestStatus.FAILED, error: action.payload };
    case CLEAR_PERSISTENCY_INDIVIDU_ROLLING_FILTER: return { ...state, filterIndividuRollingStatus: requestStatus.IDLE, individuRollingFilter: {} };

    case PERSISTENCY_HISTORY_DETAIL.FETCH: return { ...state, historyDetailStatus: requestStatus.FETCH, send: action.payload };
    case PERSISTENCY_HISTORY_DETAIL.SUCCESS: return { ...state, historyDetailStatus: requestStatus.SUCCESS, historyDetail: action.payload };
    case PERSISTENCY_HISTORY_DETAIL.FAILED: return { ...state, historyDetailStatus: requestStatus.FAILED, error: action.payload };
    case CLEAR_PERSISTENCY_HISTORY_DETAILS: return { ...state, historyDetailStatus: requestStatus.IDLE, historyDetail: { result: [] } };

    default: return state;
  }
}
