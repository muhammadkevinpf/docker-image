import Views from './views';

export default {
  ClientList: { screen: Views.ClientList },
};
