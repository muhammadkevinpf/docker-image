import SQLiteUtils from '../../../utilities/SQLiteUtils';
import Database from '../../../config/Database';

const { clientSync } = Database.inquiries.tables;

const querySelectAll = `SELECT * FROM ${clientSync}`;
const querySelectByKey = `SELECT clientNumber, createdDate FROM ${clientSync} WHERE clientNumber = ?`;
const queryInsert = `INSERT INTO ${clientSync} `
  + '(address1, address2, address3, address4, address5, clientName, clientNumber, dateOfBirth, emailAddress, '
  + 'gender, idNumber, maritalStatus, mobileNumber1, mobileNumber2, mobileNumber3, '
  + 'nationality, ownerStatus, religion, createdDate, modifiedDate, agentCode) '
  + 'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ';
const queryCreateTable = `CREATE TABLE IF NOT EXISTS ${clientSync} `
  + '(address1 TEXT, address2 TEXT, address3 TEXT, address4, address5 TEXT, '
  + 'clientName TEXT, clientNumber TEXT, dateOfBirth TEXT, emailAddress TEXT, gender TEXT, '
  + 'idNumber TEXT, maritalStatus TEXT, mobileNumber1 TEXT, '
  + 'mobileNumber2 TEXT, mobileNumber3 TEXT, nationality TEXT, ownerStatus TEXT, religion TEXT, createdDate TEXT, '
  + 'modifiedDate TEXT, agentCode TEXT NOT NULL, additionalParam TEXT)';
const queryUpdateByKey = `UPDATE ${clientSync} SET address1 = ?, address2 = ?, address3 = ? ,address4 = ?, address5 = ?, `
  + 'clientName = ?, dateOfBirth = ?, emailAddress = ?, gender = ?,idNumber = ? ,maritalStatus = ?, mobileNumber1 = ?, '
  + 'mobileNumber2 = ?, mobileNumber3 = ?, nationality = ?, ownerStatus = ?, religion = ?, '
  + 'modifiedDate = ? where clientNumber = ?';
const querySelectByAgentCode = `SELECT * FROM ${clientSync} WHERE agentCode = ?`;

const openDatabase = () => new Promise(async (resolve, reject) => {
  try {
    const db = await SQLiteUtils.openDatabase(Database.inquiries.name, 'default');
    resolve(db);
  } catch (error) {
    reject(error);
  }
});

const createTable = db => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeTransaction(db, queryCreateTable, []);
    resolve(res);
  } catch (error) {
    reject(error);
  }
});

const getAll = db => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(db, querySelectAll, []);
    const data = [];
    for (let i = 0; i < res.rows.length; i += 1) {
      data.push(res.rows.item(i));
    }
    resolve(data);
  } catch (error) {
    reject(error);
  }
});

const getByCode = (db, param) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(db, querySelectByKey, [param]);
    if (res.rows.length > 0) {
      resolve(JSON.parse(res.rows.item(0)));
    } else {
      resolve(res.rows.length);
    }
  } catch (error) {
    reject(error);
  }
});

const insert = (db, param) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeTransaction(
      db,
      queryInsert,
      [param.address1, param.address2, param.address3,
        param.address4, param.address5, param.clientName,
        param.clientNumber, param.dateOfBirth, param.emailAddress,
        param.gender, param.idNumber, param.maritalStatus,
        param.mobileNumber1, param.mobileNumber2, param.mobileNumber3,
        param.nationality, param.ownerStatus, param.religion,
        param.createdDate, param.modifiedDate, param.agentCode],
    );
    resolve(res);
  } catch (error) {
    reject(error);
  }
});

const update = (db, param) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeTransaction(
      db,
      queryUpdateByKey,
      [param.address1, param.address2, param.address3,
        param.address4, param.address5, param.clientName,
        param.dateOfBirth, param.emailAddress, param.gender,
        param.idNumber, param.maritalStatus, param.mobileNumber1,
        param.mobileNumber2, param.mobileNumber3, param.nationality,
        param.ownerStatus, param.religion, param.modifiedDate, param.clientNumber],
    );
    resolve(res);
  } catch (error) {
    reject(error);
  }
});

const getByAgentCode = (db, agentCode) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(
      db,
      querySelectByAgentCode,
      [agentCode],
    );
    resolve(res.rows.item(0));
  } catch (error) {
    reject(error);
  }
});

export default {
  openDatabase,
  createTable,
  getAll,
  getByCode,
  getByAgentCode,
  insert,
  update,
};
