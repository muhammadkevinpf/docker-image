import { adapter } from '../../config';

export const cardTypes = {
  individu: 'individu',
  unit: 'unit',
  group: 'group',
};

export const dataTypes = {
  mtdYtd: 'mtdYtd',
  graph: 'graph',
  period: 'period',
};

export const tabTypes = {
  mtd: 'mtd',
  ytd: 'ytd',
  history: 'history',
};

export const individuSortProd = [
  {
    value: '01', orderBy: 'clientName', direction: 'asc', label: 'Nama Pemegang Polis A-Z',
  },
  {
    value: '02', orderBy: 'clientName', direction: 'desc', label: 'Nama Pemegang Polis Z-A',
  },
  {
    value: '03', orderBy: 'policyNumber', direction: 'asc', label: 'Nomor Polis 0-9',
  },
  {
    value: '04', orderBy: 'policyNumber', direction: 'desc', label: 'Nomor Polis 9-0',
  },
  {
    value: '05', orderBy: 'transactionDate', direction: 'asc', label: 'Tanggal Transaksi Terlama',
  },
  {
    value: '06', orderBy: 'transactionDate', direction: 'desc', label: 'Tanggal Transaksi Terbaru',
  },
];

export const unitSortProd = [
  { value: 'asc', label: 'APE Terendah' },
  { value: 'desc', label: 'APE Tertinggi' },
];

/* ---------------------------REDUX------------------------ */

// Find Transaction Detail List //

export const FIND_TRANSACTION_INDIVIDU_MONTHLY = {
  API: `${adapter.COMMON}/findAllPolicyMonthly`,
  FETCH: 'FIND_TRANSACTION_INDIVIDU_MONTHLY_FETCH',
  SUCCESS: 'FIND_TRANSACTION_INDIVIDU_MONTHLY_SUCCESS',
  FAILED: 'FIND_TRANSACTION_INDIVIDU_MONTHLY_FAILED',
};

export const FIND_TRANSACTION_INDIVIDU_YEARLY = {
  API: `${adapter.COMMON}/findAllPolicyYearly`,
  FETCH: 'FIND_TRANSACTION_INDIVIDU_YEARLY_FETCH',
  SUCCESS: 'FIND_TRANSACTION_INDIVIDU_YEARLY_SUCCESS',
  FAILED: 'FIND_TRANSACTION_INDIVIDU_YEARLY_FAILED',
};

export const FIND_TRANSACTION_UNIT_MONTHLY = {
  API: `${adapter.COMMON}/findAllPolicyMonthlyUnit`,
  FETCH: 'FIND_TRANSACTION_UNIT_MONTHLY_FETCH',
  SUCCESS: 'FIND_TRANSACTION_UNIT_MONTHLY_SUCCESS',
  FAILED: 'FIND_TRANSACTION_UNIT_MONTHLY_FAILED',
};

export const FIND_TRANSACTION_UNIT_YEARLY = {
  API: `${adapter.COMMON}/findAllPolicyYearlyUnit`,
  FETCH: 'FIND_TRANSACTION_UNIT_YEARLY_FETCH',
  SUCCESS: 'FIND_TRANSACTION_UNIT_YEARLY_SUCCESS',
  FAILED: 'FIND_TRANSACTION_UNIT_YEARLY_FAILED',
};

export const FIND_TRANSACTION_LIST_FILTER = {
  API: `${adapter.COMMON}/getAllTransactionType`,
  FETCH: 'FIND_TRANSACTION_LIST_FILTER_FETCH',
  SUCCESS: 'FIND_TRANSACTION_LIST_FILTER_SUCCESS',
  FAILED: 'FIND_TRANSACTION_LIST_FILTER_FAILED',
};

export const FIND_AGENT_TYPE_LIST_FILTER = {
  API: `${adapter.COMMON}/getAllAgentType`,
  FETCH: 'FIND_AGENT_TYPE_LIST_FILTER_FETCH',
  SUCCESS: 'FIND_AGENT_TYPE_LIST_FILTER_SUCCESS',
  FAILED: 'FIND_AGENT_TYPE_LIST_FILTER_FAILED',
};

export const RESET_PRODUCTION = {
  INDIVIDU: 'CLEAR_TRANSACTION_INDIVIDU',
  UNIT: 'CLEAR_TRANSACTION_UNIT',
  FILTER: 'CLEAR_PRODUCTION_FILTER',
  HISTORY: 'CLEAR_PRODUCTION_HISTORY_DETAIL',
  MAIN: 'RESET_PRODUCTION',
};

// MAIN PRODUCTION ACTION TYPES
export const PROD_INDIVIDU_BY_RANGE = {
  API: `${adapter.COMMON}/findSummaryByRange`,
  FETCH: 'PROD_INDIVIDU_BY_RANGE_FETCH',
  SUCCESS: 'PROD_INDIVIDU_BY_RANGE_SUCCESS',
  FAILED: 'PROD_INDIVIDU_BY_RANGE_FAILED',
};

export const PROD_INDIVIDU_YTD = {
  API: `${adapter.COMMON}/findDashboardSummary`,
  FETCH: 'PROD_INDIVIDU_YTD_FETCH',
  SUCCESS: 'PROD_INDIVIDU_YTD_SUCCESS',
  FAILED: 'PROD_INDIVIDU_YTD_FAILED',
};

export const PROD_UNIT_BY_RANGE = {
  API: `${adapter.COMMON}/findSummaryByRangeUnit`,
  FETCH: 'PROD_UNIT_BY_RANGE_FETCH',
  SUCCESS: 'PROD_UNIT_BY_RANGE_SUCCESS',
  FAILED: 'PROD_UNIT_BY_RANGE_FAILED',
};

export const PROD_UNIT_YTD = {
  API: `${adapter.COMMON}/findDashboardSummaryUnit`,
  FETCH: 'PROD_UNIT_YTD_FETCH',
  SUCCESS: 'PROD_UNIT_YTD_SUCCESS',
  FAILED: 'PROD_UNIT_YTD_FAILED',
};

export const PROD_GRAPH_DETAIL_INDIVIDU = {
  API: `${adapter.COMMON}/findProductionSummaryByPeriod`,
  FETCH: 'PROD_GRAPH_DETAIL_INDIVIDU_FETCH',
  SUCCESS: 'PROD_GRAPH_DETAIL_INDIVIDU_SUCCESS',
  FAILED: 'PROD_GRAPH_DETAIL_INDIVIDU_FAILED',
};

export const PROD_GRAPH_DETAIL_UNIT = {
  API: `${adapter.COMMON}/findProductionSummaryByPeriodUnit`,
  FETCH: 'PROD_GRAPH_DETAIL_UNIT_FETCH',
  SUCCESS: 'PROD_GRAPH_DETAIL_UNIT_SUCCESS',
  FAILED: 'PROD_GRAPH_DETAIL_UNIT_FAILED',
};

export const PROD_HISTORY_LIST_INDIVIDU = {
  API: `${adapter.COMMON}/findAllPolicyByRange`,
  FETCH: 'PROD_HISTORY_LIST_INDIVIDU_FETCH',
  SUCCESS: 'PROD_HISTORY_LIST_INDIVIDU_SUCCESS',
  FAILED: 'PROD_HISTORY_LIST_INDIVIDU_FAILED',
};

export const PROD_HISTORY_LIST_UNIT = {
  API: `${adapter.COMMON}/findAllPolicyByRangeUnit`,
  FETCH: 'PROD_HISTORY_LIST_UNIT_FETCH',
  SUCCESS: 'PROD_HISTORY_LIST_UNIT_SUCCESS',
  FAILED: 'PROD_HISTORY_LIST_UNIT_FAILED',
};
