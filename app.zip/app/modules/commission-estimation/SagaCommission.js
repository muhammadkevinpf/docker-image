/* eslint-disable no-console */
import { takeLatest } from 'redux-saga/effects';
import { apiSagaFunction } from '../../utilities/Functions';
import { commissionEstimationAction, COMMISSION_ESTIMATION } from './ConfigCommission';

export const watcherCommissionEstimation = [
  takeLatest(COMMISSION_ESTIMATION.FETCH, params => apiSagaFunction(params.payload, commissionEstimationAction, COMMISSION_ESTIMATION)),
];
