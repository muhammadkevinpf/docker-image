/**
 * @author: ahmdichsanb@gmail.com
*/

import { StyleSheet } from 'react-native';
import Styles from '../../styles';

const Style = StyleSheet.create({
  buttonCancel: {
    backgroundColor: Styles.Color.gray,
    padding: 10,
  },
  buttonConfirm: {
    backgroundColor: Styles.Color.red,
    padding: 10,
  },
  textAlignCenter: {
    textAlign: 'center',
  },
});

export default Style;
