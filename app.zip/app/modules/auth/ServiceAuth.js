
import { Alert, Platform } from 'react-native';
import decodeJwt from 'jwt-decode';
import DeviceInfo from 'react-native-device-info';
import _ from '../../lang';
import { getBranchMasterFromAPI, getReferralFromAPI } from '../../utilities';

export function isTokenExpired(token) {
  const expiredTime = decodeJwt(token).exp;
  const currentTime = new Date().getTime() / 1000;
  if (currentTime > expiredTime) return true;
  return false;
}

export function handleExpiredToken(
  token, callback, onAlertPress, message = 'Token expired. Silakan login ulang dalam keadaan online untuk melanjutkan',
) {
  if (isTokenExpired(token)) {
    return Alert.alert('Warning',
      _(message), [
        {
          text: _('OK'),
          onPress: onAlertPress,
        },
      ]);
  } return callback();
}

export function getVAParam(VANumbers) {
  const params = {
    capacity: 10,
    deviceId: DeviceInfo.getUniqueId(),
    deviceType: `${Platform.OS} ${Platform.Version}`,
    imei: null,
    numberUsed: VANumbers[0],
    numberUnused: VANumbers[1],
  };

  return params;
}

/**
 * added by: WF @ ecomindo
 * @param vaNumbers array of VA, you can get VA list from redux state in your component.
 * then pass the list and this function will update the redux state and return the VA number.
 * @param action action for updating the VA in redux state.
 */
export function getVA(vaNumbers = [], action = () => {}) {
  const va = vaNumbers.find(x => !x.isUsed);
  const updatedVA = vaNumbers.map((x) => {
    if (x.vaNumber === va.vaNumber) {
      return { ...x, isUsed: true };
    }
    return x;
  });
  action(updatedVA);
  return va.vaNumber;
}

/**
 * added by: WF @ ecomindo
 * @param firstString a string from office property in userProfile object.
 * @param secondString a string from raddName property in userProfile object.
 * this method returning agent channel.
 */
export function getAgentChannel(firstString = '', secondString = '', token) {
  const partners = {
    BUOI: 'BUOI',
    UOB: 'UOB',
    SCB: 'SCB',
    OCBCN: 'OCBCN',
  };

  try {
    const channels = Object.keys(partners);
    let channel = 'AG';
    for (let i = 0; i < channels.length; i += 1) {
      if (firstString.toUpperCase().includes(channels[i]) || secondString.toUpperCase().includes(channels[i])) {
        channel = partners[channels[i]];
        break;
      }
    }
    // if (!channel) {
    //   // throw Error('Channel not found. Please check your office and raddName in userProfile object!');
    //   channel = 'AG';
    // }
    getBranchMasterFromAPI(channel, token);
    getReferralFromAPI(channel, token);
    return channel;
  } catch (error) {
    throw error;
  }
}
