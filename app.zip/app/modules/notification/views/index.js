import MainNotification_ from './MainNotification';

const MainNotification = MainNotification_;

export default {
  MainNotification,
};
