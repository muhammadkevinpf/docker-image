/**
 * @author: dwi.setiyadi@gmail.com
*/

import {
  Platform, StyleSheet, Dimensions, PixelRatio,
} from 'react-native';
import color from 'color';
import Color_ from './Colors';
import Font_ from './Fonts';
import { isTablet } from '../utilities';
import { statusBarHeight } from '../config/Platform';

let phoneInput = {};
let lengthIndicator = {};
let leftCurrency = {};
let fontBold = {};
const dimensions = Dimensions.get('window');
const minHeightFull = dimensions.height >= dimensions.width ? dimensions.height : dimensions.width;

switch (Platform.OS) {
  case 'ios':
    phoneInput = {
      borderBottomWidth: 1,
      borderBottomColor: Color_.inputBorderColor,
      fontSize: 12,
      paddingBottom: 7,
      marginTop: 37,
    };
    lengthIndicator = {
      fontSize: 12,
      paddingTop: 15,
      textAlign: 'right',
    };
    leftCurrency = {
      marginTop: 34,
      paddingBottom: 6,
      borderBottomWidth: 1,
      borderBottomColor: Color_.inputBorderColor,
    };
    fontBold = {
      fontWeight: 'bold',
    };
    break;
  case 'android':
    phoneInput = {
      borderBottomWidth: 1,
      borderBottomColor: Color_.inputBorderColor,
      fontSize: 12,
      paddingBottom: 3,
      marginTop: 12,
      paddingTop: 14,
    };
    lengthIndicator = {
      fontSize: 12,
      paddingTop: 15,
      textAlign: 'right',
      marginTop: 10,
    };
    leftCurrency = {
      marginTop: 16,
      borderBottomWidth: 1,
      borderBottomColor: Color_.inputBorderColor,
      paddingBottom: 2,
    };
    fontBold = {
      fontWeight: 'normal',
    };
    break;
  default:
    break;
}

const Styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  fullWidth: {
    width: '100%',
  },
  autoWidth: {
    width: 'auto',
  },
  halfWidth: {
    width: '50%',
  },
  width70: {
    width: '70%',
  },
  width75pr: {
    width: '75%',
  },
  width80: {
    width: '80%',
  },
  width90: {
    width: '90%',
  },
  width200: {
    width: 220,
  },
  width300: {
    width: 300,
  },
  autoHeight: {
    height: 'auto',
  },
  height20pr: {
    height: '20%',
  },
  height80Percent: {
    height: '80%',
  },
  height90: {
    height: 90,
  },
  height85: {
    height: 85,
  },
  height55: {
    height: 55,
  },
  height65: {
    height: 65,
  },
  height60: {
    height: 60,
  },
  padding10: {
    padding: 10,
  },
  padding18: {
    padding: 18,
  },
  padding20: {
    padding: 20,
  },
  padding30: {
    padding: 30,
  },
  padding2: {
    padding: 2,
  },
  pt0: {
    paddingTop: 0,
  },
  pr0: {
    paddingRight: 0,
  },
  pb0: {
    paddingBottom: 0,
  },
  pl0: {
    paddingLeft: 0,
  },
  pt2: {
    paddingTop: 2,
  },
  pt3: {
    paddingTop: 3,
  },
  pr2: {
    paddingRight: 2,
  },
  pb2: {
    paddingBottom: 2,
  },
  pl2: {
    paddingLeft: 2,
  },
  pt5: {
    paddingTop: 5,
  },
  pr5: {
    paddingRight: 5,
  },
  pb3: {
    paddingBottom: 3,
  },
  pb5: {
    paddingBottom: 5,
  },
  pl5: {
    paddingLeft: 5,
  },
  pt15: {
    paddingTop: 15,
  },
  pt30: {
    paddingTop: 30,
  },
  pr15: {
    paddingRight: 15,
  },
  pr18: {
    paddingRight: 18,
  },
  pr20: {
    paddingRight: 20,
  },
  pb15: {
    paddingBottom: 15,
  },
  pr30: {
    paddingRight: 30,
  },
  pr90: {
    paddingRight: 90,
  },
  pl15: {
    paddingLeft: 15,
  },
  pl16: {
    paddingLeft: 16,
  },
  pl18: {
    paddingLeft: 18,
  },
  pl20: {
    paddingLeft: 20,
  },
  pl30: {
    paddingLeft: 30,
  },
  pl90: {
    paddingLeft: 90,
  },
  pt10: {
    paddingTop: 10,
  },
  pr10: {
    paddingRight: 10,
  },
  pb10: {
    paddingBottom: 10,
  },
  pb14: {
    paddingBottom: 14,
  },
  pl10: {
    paddingLeft: 10,
  },
  margin7: {
    margin: 7.5,
  },
  margin10: {
    margin: 10,
  },
  margin15: {
    margin: 15,
  },
  margin20: {
    margin: 20,
  },
  mt0: {
    marginTop: 0,
  },
  mr0: {
    marginRight: 0,
  },
  mbmin15: {
    marginBottom: -15,
  },
  mb0: {
    marginBottom: 0,
  },
  ml0: {
    marginLeft: 0,
  },
  mt1: {
    marginTop: 1,
  },
  mr1: {
    marginRight: 1,
  },
  mb1: {
    marginBottom: 1,
  },
  ml1: {
    marginLeft: 1,
  },
  mt2: {
    marginTop: 2,
  },
  mr2: {
    marginRight: 2,
  },
  mb2: {
    marginBottom: 2,
  },
  mb24: {
    marginBottom: 24,
  },
  ml2: {
    marginLeft: 2,
  },
  mt3: {
    marginTop: 3,
  },
  mr3: {
    marginRight: 3,
  },
  mb3: {
    marginBottom: 3,
  },
  ml3: {
    marginLeft: 3,
  },
  mt4: {
    marginTop: 4,
  },
  mr4: {
    marginRight: 4,
  },
  pb25: {
    paddingBottom: 25,
  },
  mb4: {
    marginBottom: 4,
  },
  ml4: {
    marginLeft: 4,
  },
  mt5: {
    marginTop: 5,
  },
  mr5: {
    marginRight: 5,
  },
  mb5: {
    marginBottom: 5,
  },
  ml5: {
    marginLeft: 5,
  },
  mt8: {
    marginTop: 8,
  },
  mr8: {
    marginRight: 8,
  },
  mb8: {
    marginBottom: 8,
  },
  mt9: {
    marginTop: 9,
  },
  ml8: {
    marginLeft: 8,
  },
  mt10: {
    marginTop: 10,
  },
  mr10: {
    marginRight: 10,
  },
  mb10: {
    marginBottom: 10,
  },
  ml10: {
    marginLeft: 10,
  },
  mt12: {
    marginTop: 12,
  },
  mt13: {
    marginTop: 13,
  },
  mr11: {
    marginRight: 11,
  },
  mr12: {
    marginRight: 12,
  },
  mr14: {
    marginRight: 14,
  },
  mb12: {
    marginBottom: 12,
  },
  ml12: {
    marginLeft: 12,
  },
  mt15: {
    marginTop: 15,
  },
  mr15: {
    marginRight: 15,
  },
  mb15: {
    marginBottom: 15,
  },
  ml15: {
    marginLeft: 15,
  },
  mt18: {
    marginTop: 18,
  },
  mr18: {
    marginRight: 18,
  },
  mb18: {
    marginBottom: 18,
  },
  ml18: {
    marginLeft: 18,
  },
  ml7: {
    marginLeft: 7,
  },
  mt20: {
    marginTop: 20,
  },
  mt22: {
    marginTop: 22,
  },
  mr20: {
    marginRight: 20,
  },
  mb20: {
    marginBottom: 20,
  },
  ml20: {
    marginLeft: 20,
  },
  mt30: {
    marginTop: 30,
  },
  mr30: {
    marginRight: 30,
  },
  mb30: {
    marginBottom: 30,
  },
  ml30: {
    marginLeft: 30,
  },
  mt35: {
    marginTop: 35,
  },
  mr35: {
    marginRight: 35,
  },
  mb35: {
    marginBottom: 35,
  },
  ml35: {
    marginLeft: 35,
  },
  mt55: {
    marginTop: 55,
  },
  mt52: {
    marginTop: 52,
  },
  mr55: {
    marginRight: 55,
  },
  mb55: {
    marginBottom: 55,
  },
  mr65: {
    marginRight: 65,
  },
  ml65: {
    marginLeft: 65,
  },
  ml50: {
    marginLeft: 50,
  },
  ml55: {
    marginLeft: 55,
  },
  ml70: {
    marginLeft: 70,
  },
  mtUnduh: {
    marginTop: Platform.OS === 'ios' ? 5 : 2,
  },
  iconHeaderLeft: {
    padding: 10,
  },
  subHeaderPosition: {
    marginTop: Platform.OS === 'ios' ? 0 : 15,
  },
  font1: {
    fontSize: 1,
  },
  font10: {
    fontSize: 10,
  },
  font12: {
    fontSize: 12,
  },
  font14: {
    fontSize: 14,
  },
  font15: {
    fontSize: 15,
  },
  font16: {
    fontSize: 16,
  },
  font20: {
    fontSize: 20,
  },
  textStrong: {
    fontSize: 15,
    fontWeight: '600',
  },
  textStrongWhite: {
    fontSize: 15,
    fontWeight: '600',
    color: Color_.white,
  },
  textStrongWhite25: {
    fontSize: 25,
    fontWeight: '400',
    color: Color_.white,
  },
  fontRegular: {
    fontWeight: 'normal',
  },
  fontBold,
  fontBoldExtra: {
    fontWeight: 'bold',
  },
  textWrap: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    // flexGrow: 1,
    // width: '100%',
  },
  textLeft: {
    flex: 1,
    alignSelf: 'flex-start',
    textAlign: 'left',
  },
  textCenter: {
    flex: 1,
    alignSelf: 'center',
    textAlign: 'center',
  },
  textRight: {
    flex: 1,
    alignSelf: 'flex-start',
    textAlign: 'right',
  },
  textJustify: {
    flex: 1,
    textAlign: 'justify',
  },
  textBlue: {
    color: Color_.blue,
  },
  textRed: {
    color: Color_.red,
  },
  textWhite: {
    color: Color_.white,
  },
  textGray: {
    color: Color_.lightGray,
  },
  textYellow: {
    color: Color_.yellow,
  },
  textGreen: {
    color: Color_.green,
  },
  textLineHeight10: {
    lineHeight: 10,
  },
  textLineHeight15: {
    lineHeight: 15,
  },
  btnSecondary: {
    backgroundColor: Color_.white,
    borderRadius: 4,
    color: Color_.red,
  },
  btnPrimary: {
    backgroundColor: Color_.red,
    borderRadius: 4,
    color: Color_.white,
  },
  btnDisable: {
    backgroundColor: Color_.gray,
    borderRadius: 4,
    color: Color_.white,
  },
  btnOldPersistensi: {
    height: 0.1,
    borderWidth: 2,
    borderColor: Color_.red,
  },
  btnRollPersistensi: {
    height: 0.1,
    borderWidth: 2,
    borderColor: Color_.green,
  },
  backgroundRed: {
    backgroundColor: Color_.red,
  },
  backgroundBarPink: {
    backgroundColor: Color_.barPink,
  },
  backgroundWhite: {
    backgroundColor: Color_.white,
  },
  backgroundGreen: {
    backgroundColor: Color_.green,
  },
  backgroundYellow: {
    backgroundColor: Color_.yellow,
  },
  backgroundOrange: {
    backgroundColor: Color_.orange,
  },
  backgroundLightGray: {
    backgroundColor: Color_.lightGray,
  },
  backgroundGray: {
    backgroundColor: Color_.gray,
  },
  backgroundTransparent: {
    backgroundColor: Color_.transparent,
  },
  backgroundLightSmoke: {
    backgroundColor: Color_.lightSmoke,
  },
  backgroundDarkWhite: {
    backgroundColor: Color_.darkWhite,
  },
  backgroundBlueCommission: {
    backgroundColor: Color_.commissionBlue,
  },
  backgroundGreenCommission: {
    backgroundColor: Color_.commissionGreen,
  },
  formInputBg: {
    backgroundColor: color(Color_.red).darken(0.2).hex(),
    height: 50,
  },
  noBorderBottom: {
    borderBottomWidth: 0,
  },
  noBorderRight: {
    borderLeftWidth: 0,
  },
  noBorderTop: {
    borderTopWidth: 0,
  },
  noBorderLeft: {
    borderRightWidth: 0,
  },
  borderRed: {
    borderColor: Color_.red,
    borderWidth: 1,
  },
  timeStyle: {
    textAlign: 'right',
  },
  iconStyle: {
    color: Color_.gray,
  },
  heightLine: {
    lineHeight: 15,
  },
  heightLine10: {
    height: 20,
  },
  alignCenter: {
    alignSelf: 'center',
  },
  alignLeft: {
    alignSelf: 'flex-start',
  },
  alignRight: {
    alignSelf: 'flex-end',
  },
  borderRadius5: {
    borderRadius: 5,
  },
  borderRadius6: {
    borderRadius: 6,
  },
  borderTopRadius6: {
    borderTopLeftRadius: 6,
    borderTopRightRadius: 6,
  },
  borderRadius8: {
    borderRadius: 8,
  },
  borderRadius10: {
    borderRadius: 10,
  },
  borderRadius2: {
    borderRadius: 2,
  },
  borderRadius40: {
    borderRadius: 40,
  },
  borderBottomWidth1: {
    borderBottomWidth: 1,
  },
  borderBottomLightGray: {
    borderBottomColor: Color_.lightGray,
  },
  borderBottomBrightGray: {
    borderBottomColor: Color_.mediumGray,
  },
  borderRightBrightGray: {
    borderRightColor: Color_.mediumGray,
    borderRightWidth: 1,
  },
  borderTopCustom: {
    borderTopColor: Color_.lightGray,
    borderTopWidth: 1,
  },
  borderBottomBlurGray: {
    borderBottomColor: Color_.inputBorderColor,
  },
  justifyCenter: {
    justifyContent: 'center',
  },
  centerVertical: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  padding12: {
    padding: 12,
  },
  padding14: {
    padding: 14,
  },
  pl7: {
    paddingLeft: 7,
  },
  pl12: {
    paddingLeft: 12,
  },
  pr7: {
    paddingRight: 7,
  },
  pt7: {
    paddingTop: 7,
  },
  pt8: {
    paddingTop: 8,
  },
  pb7: {
    paddingBottom: 7,
  },
  py7: {
    paddingBottom: 7,
    paddingTop: 7,
  },
  pr12: {
    paddingRight: 12,
  },
  pr13: {
    paddingRight: 13,
  },
  pr14: {
    paddingRight: 14,
  },
  pt18: {
    paddingTop: 18,
  },
  py25: {
    paddingBottom: 25,
    paddingTop: 25,
  },
  mt26: {
    marginTop: 26,
  },
  mt28: {
    marginTop: 28,
  },
  mb26: {
    marginBottom: 26,
  },
  headerHeight: {
    height: 56,
  },
  btnLarge: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    padding: 15,
    borderRadius: 8,
    display: 'flex',
  },
  backgroundBrightGray: {
    backgroundColor: Color_.brightGray,
  },
  backgroundMediumGray: {
    backgroundColor: Color_.mediumGray,
  },
  flexTop: {
    flexDirection: 'column',
  },
  accordionHeader: {
    flexDirection: 'row',
    padding: 10,
    justifyContent: 'space-between',
    alignItems: 'center',
    // backgroundColor: Color_.brightGray,
  },
  pl6: {
    paddingLeft: 6,
  },
  pr6: {
    paddingRight: 6,
  },
  accordionContentRow: {
    // backgroundColor: Color_.mediumGray,
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: Color_.white,
  },
  accordionHeaderStyle: {
    backgroundColor: Color_.lightGray,
    color: Color_.white,
  },
  accordionContentStyle: {
    backgroundColor: Color_.brightGray,
    color: Color_.almostBlack,
  },
  barPink: {
    backgroundColor: Color_.barPink,
    borderRadius: 4,
    height: 10,
  },
  barGray: {
    backgroundColor: Color_.barGray,
    borderRadius: 4,
    height: 10,
  },
  barStep: {
    width: '100%',
    textAlign: 'center',
  },
  h85: {
    height: 85,
  },
  btnLanjutkan: {
    backgroundColor: Color_.red,
    marginLeft: 12,
    marginRight: 12,
    borderRadius: 6,
  },
  btnLanjutkanTablet: {
    backgroundColor: Color_.red,
    marginLeft: 25,
    marginRight: 25,
    borderRadius: 6,
  },
  btnTambahTelephone: {
    backgroundColor: Color_.whiteSmoke,
    marginLeft: 15,
    marginRight: 15,
    borderRadius: 6,
  },
  btnDeleteOnBottom: {
    backgroundColor: Color_.whiteSmoke,
    marginLeft: 15,
    marginRight: 15,
    borderRadius: 6,
  },
  btnDelete: {
    backgroundColor: Color_.whiteSmoke,
    borderRadius: 6,
  },
  btnLanjutkanOk: {
    backgroundColor: Color_.red,
    marginLeft: 12,
    marginRight: 12,
    borderRadius: 6,
  },
  btnLanjutkanDisabled: {
    backgroundColor: Color_.gray,
    marginLeft: 12,
    marginRight: 12,
    borderRadius: 6,
  },
  btnLanjutkanDisabledTablet: {
    backgroundColor: Color_.gray,
    marginLeft: 25,
    marginRight: 25,
    borderRadius: 6,
  },
  grayBorderBottom: {
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: Color_.inputBorderColor,
  },
  redBorderBottom: {
    borderBottomWidth: 1,
    borderBottomColor: Color_.red,
    width: '90%',
  },
  textAlmostBlack: {
    color: Color_.almostBlack,
  },
  textBrightGray: {
    color: Color_.brightGray,
  },
  footerHeight: {
    height: 85,
    borderWidth: 0,
    borderColor: Color_.white,
  },
  pickerTextStyle: {
    color: Color_.gray83,
    marginLeft: 0,
    paddingLeft: 0,
  },
  pickerItemStyle: {
    marginLeft: 5,
    paddingLeft: 0,
  },
  pickerPlaceHolderStyle: {
    fontSize: 12,
    marginLeft: 5,
    paddingLeft: 0,
  },
  mr7: {
    marginRight: 7,
  },
  datePickerTextStyle: {
    color: Color_.almostBlack,
    fontSize: 13,
  },
  datePickerPlaceHolderTextStyle: {
    color: Color_.gray83,
    marginLeft: 0,
    paddingLeft: 0,
    fontSize: 13,
  },
  datePickerIcon: {
    color: Color_.gray93,
    textAlign: 'right',
  },
  pickerIcon: {
    fontSize: 12,
    color: Color_.gray83,
  },
  radioSelectedColor: {
    color: Color_.red,
  },
  gray83: {
    color: Color_.gray83,
  },
  font18: {
    fontSize: 18,
  },
  pt6: {
    paddingTop: 6,
  },
  flatListAction: {
    width: 50,
    height: 50,
  },
  sliderContainer: {
    flex: 1,
    flexDirection: 'row',
  },
  sliderThumbStyle: {
    width: 20,
    height: 20,
  },
  sliderStyle: {
    width: '100%',
    height: 40,
  },
  fontAlbert: {
    fontFamily: Font_.FSAlbertPro,
  },
  py15: {
    paddingVertical: 15,
  },
  textAlignCenter: {
    textAlign: 'center',
  },
  textAlignLeft: {
    textAlign: 'left',
  },
  textAlignVerticalCenter: {
    textAlignVertical: 'center',
  },
  modalOverlay: {
    backgroundColor: Color_.overlay,
    flex: 1,
    flexDirection: 'column',
    display: 'flex',
  },
  modalHalf: {
    backgroundColor: Color_.white,
    padding: 12,
    borderRadius: 8,
    flex: 1,
  },
  flexCnt: {
    justifyContent: 'space-evenly',
    flexDirection: 'row',
  },
  redLine: {
    borderBottomWidth: 1,
    borderColor: Color_.red,
    marginBottom: 15,
    marginTop: 15,
  },
  dialogBtnCnt: {
    justifyContent: 'center',
    flexDirection: 'row',
  },
  buttonBorderRed: {
    justifyContent: 'center',
    flexDirection: 'row',
    backgroundColor: Color_.white,
    borderColor: Color_.red,
    borderWidth: 1,
    alignSelf: 'center',
    alignItems: 'center',
    width: 210,
  },
  buttonRed: {
    justifyContent: 'center',
    flexDirection: 'row',
    backgroundColor: Color_.red,
    alignSelf: 'center',
    alignItems: 'center',
    width: 210,
  },
  dialogOutlineBtn: {
    borderRadius: 8,
    borderWidth: 1,
    width: 120,
  },
  rotate90Deg: { transform: [{ rotate: '90deg' }] },
  dialogBtnwidth: {
    width: 120,
  },
  pruLogo: {
    height: '60%',
    width: '60%',
  },
  largeOutlineBtn: {
    height: 50,
    width: 200,
    borderRadius: 8,
    alignSelf: 'center',
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: Color_.red,
  },
  largeRedBtn: {
    height: 50,
    width: 200,
    borderRadius: 8,
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Color_.red,
    color: Color_.white,
  },
  cardCnt: {
    borderRadius: 8,
    borderColor: Color_.red,
    borderWidth: 1,
  },
  cardTitle: {
    backgroundColor: Color_.red,
    borderTopLeftRadius: 8,
    borderTopRightRadius: 8,
    padding: 12,
  },
  cardTitleNoRider: {
    backgroundColor: Color_.red,
    borderTopLeftRadius: 7.8,
    borderTopRightRadius: 7.8,
    borderBottomLeftRadius: 7.8,
    borderBottomRightRadius: 7.8,
    padding: 12,
  },
  cardTitleText: {
    color: Color_.white,
    textAlign: 'center',
    fontSize: 13,
  },
  cardLongMoney: {
    color: Color_.almostBlack,
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 10,
  },
  cardContent: {
    textAlign: 'center',
    paddingTop: 15,
    paddingBottom: 10,
    fontSize: 14,
    lineHeight: 15,
  },
  cardContainer: {
    paddingHorizontal: 15,
    paddingBottom: 20,
    marginVertical: 15,
    marginHorizontal: 3,
    elevation: 2,
    borderRadius: 5,
    shadowRadius: 2,
    backgroundColor: Color_.white,
    shadowColor: Color_.f10,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.5,
  },
  pr4: {
    paddingRight: 4,
  },
  pl4: {
    paddingLeft: 4,
  },
  mln10: {
    marginLeft: -10,
  },
  displayNone: {
    display: 'none',
  },
  imgTTD: {
    width: '100%',
    height: 160,
    borderWidth: 1,
    borderColor: Color_.gray97,
    borderRadius: 8,
    backgroundColor: Color_.grayF9,
  },
  displayFlex: {
    display: 'flex',
  },
  mt37: {
    marginTop: 37,
  },
  phoneInput,
  lengthIndicator,
  leftCurrency,
  textOnline: {
    color: Color_.online,
  },
  textOffline: {
    color: Color_.yellow,
  },
  textTTD: {
    fontSize: 35,
    textAlign: 'center',
    color: Color_.e4,
    textAlignVertical: 'center',
    lineHeight: 40,
  },
  flex8: {
    flex: 8,
  },
  flex5: {
    flex: 5,
  },
  backgroundColorEe: {
    backgroundColor: Color_.ee,
  },
  rowDirectionSpaceBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  rowDirectionSpaceAround: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  rowDirectionSpaceEvently: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',
  },
  rowDirectionFlexStart: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
  },
  rowDirectionJustifyCenter: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  rowDirection: {
    flexDirection: 'row',
  },
  plusBtn: {
    fontSize: 23,
    color: Color_.red,
    alignSelf: 'center',
    alignItems: 'center',
    marginTop: (Platform.OS === 'android')
      ? 7
      : 0,
  },
  columnDirectionJustifyCenter: {
    flexDirection: 'column',
    justifyContent: 'center',
  },
  columnDirectionFlexStart: {
    flexDirection: 'column',
    justifyContent: 'flex-start',
  },
  columnDirectionFlexEnd: {
    flexDirection: 'column',
    justifyContent: 'flex-end',
  },
  columnDirectionSpaceBetween: {
    flexDirection: 'column',
    justifyContent: 'space-between',
  },
  columnDirectionSpaceEvently: {
    flexDirection: 'column',
    justifyContent: 'space-evenly',
  },
  swiperView: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  flex7: {
    flex: 7,
  },
  flex10: {
    flex: 10,
  },
  flex1: {
    flex: 1,
  },
  headerBadge: {
    flex: 3,
    maxWidth: 75,
  },
  ml6: {
    marginLeft: 6,
  },
  badge: {
    backgroundColor: Color_.red,
    elevation: 4,
    shadowColor: Color_.almostBlack,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 1,
    shadowRadius: 1,
    padding: 0,
    borderWidth: 1,
    borderColor: Color_.white,
  },
  font8: {
    fontSize: 8,
  },
  font9: {
    fontSize: 9,
  },
  headerArt: {
    height: 148,
    width: '100%',
    backgroundColor: Color_.red,
    position: 'absolute',
    top: 0,
    left: 0,
    borderBottomRightRadius: 8,
    borderBottomLeftRadius: 8,
    zIndex: -1,
  },
  borderBottom15: {
    borderBottomRightRadius: 15,
    borderBottomLeftRadius: 15,
  },
  headerArt54: {
    height: 54,
    width: '100%',
    backgroundColor: Color_.red,
    position: 'absolute',
    top: 0,
    left: 0,
    borderBottomRightRadius: 8,
    borderBottomLeftRadius: 8,
    zIndex: -1,
  },
  cardShadow: {
    shadowColor: Color_.mediumGray,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.5,
    shadowRadius: 2,
    elevation: 4,
    borderRadius: 8,
    backgroundColor: Color_.white,
  },
  reverseCardShadow: {
    shadowColor: Color_.mediumGray,
    shadowOffset: { width: 0, height: -3 },
    shadowOpacity: 0.5,
    shadowRadius: 2,
    elevation: 4,
    borderRadius: 8,
  },
  cardShadowForm: {
    shadowColor: Color_.mediumGray,
    shadowOffset: { width: 3, height: 3 },
    shadowOpacity: 0.5,
    shadowRadius: 2,
    elevation: 4,
    borderRadius: 8,
    borderColor: Color_.mediumGray,
    borderWidth: 0.5,
  },
  px10: {
    paddingLeft: 10,
    paddingRight: 10,
  },
  pb8: {
    paddingBottom: 8,
  },
  alignContentCenter: {
    alignContent: 'center',
  },
  flexWrap: {
    flexWrap: 'wrap',
  },
  outlineIconButton: {
    height: 54,
    width: 56,
  },
  my15: {
    marginTop: 15,
    marginBottom: 15,
  },
  my3: {
    marginVertical: 3,
  },
  my5: {
    marginVertical: 5,
  },
  my7: {
    marginVertical: 7,
  },
  swiperHeight: {
    height: (dimensions.width / 2),
  },
  radius8: {
    borderRadius: 8,
  },
  fullHeight: {
    height: '100%',
  },
  halfHeight: {
    height: '50%',
  },
  modalWidget: {
    height: dimensions.height - 410,
  },
  modalWidgetHeight: {
    height: 410,
  },
  textColor3f3: {
    color: Color_.f3f,
  },
  height252: {
    height: 252,
  },
  font28: {
    fontSize: 28,
  },
  font30: {
    fontSize: 30,
  },
  footerBgBtn: {
    position: 'absolute',
    top: -34,
    left: (dimensions.width / 2) - 37,
    borderRadius: 90,
    backgroundColor: Color_.ee,
    borderWidth: 1,
    borderColor: Color_.ee,
    padding: 6,
    width: 68,
    height: 68,
  },
  footerBgBtnClear: {
    backgroundColor: Color_.ee,
    position: 'absolute',
    top: -34,
    height: 33,
    width: '100%',
  },
  footerMiddleBtn: {
    alignSelf: 'center',
    position: 'absolute',
    top: -60,
    left: 30,
  },
  font21: {
    fontSize: 21,
  },
  font22: {
    fontSize: 22,
  },
  itemCenter: {
    alignItems: 'center',
  },
  font26: {
    fontSize: 26,
  },
  fab: {
    fontSize: 26,
    color: Color_.red,
  },
  pr3: {
    paddingRight: 3,
  },
  searchItem: {
    borderBottomWidth: 0,
    backgroundColor: Color_.barGray,
    borderRadius: 8,
    paddingTop: 10,
    padding: 10,
    height: 40,
  },
  bgBarGray: {
    backgroundColor: Color_.barGray,
  },
  square40: {
    width: 40,
    height: 40,
  },
  boxShadow: {
    shadowColor: Color_.f10,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.5,
    shadowRadius: 1,
    elevation: 4,
  },
  flexGrow: {
    flexGrow: 1,
  },
  height30: {
    height: 30,
  },
  height40: {
    height: 40,
  },
  mx2: {
    marginLeft: 2,
    marginRight: 2,
  },
  mt64: {
    marginTop: 64,
  },
  badgeRoundedBtn: {
    borderRadius: 40,
    borderWidth: 2,
    borderColor: Color_.red,
  },
  sideOverlay: {
    backgroundColor: Color_.overlay,
    width: 30,
  },
  sortBtn: {
    alignItems: 'flex-end',
    justifyContent: 'flex-end',
    flexDirection: 'row',
  },
  justifyBottom: {
    justifyContent: 'flex-end',
  },
  flex3: {
    flex: 3,
  },
  separator: {
    height: 30,
    borderColor: Color_.barGray,
    margin: 5,
    borderLeftWidth: 1,
    width: 1,
  },
  padding0: {
    padding: 0,
  },
  width120: {
    width: 120,
  },
  borderYellow: {
    borderWidth: 1,
    borderColor: Color_.ea15,
  },
  borderTrans: {
    // borderWidth: 1,
    borderColor: Color_.transparent,
  },
  textColorea15: {
    color: Color_.ea15,
  },
  borderGreen: {
    borderWidth: 1,
    borderColor: Color_.greed42b,
  },
  textGreen42b: {
    color: Color_.greed42b,
  },
  borderCard: {
    borderColor: Color_.borderCard,
    borderWidth: 1,
  },
  borderGray: {
    borderWidth: 1,
    borderColor: Color_.gray97,
  },
  textGray97: {
    color: Color_.gray97,
  },
  font24: {
    fontSize: 24,
  },
  height144: {
    height: 144,
  },
  loginPosition: {
    position: 'absolute',
    bottom: 0,
  },
  registerBtn: {
    borderRadius: 6,
    borderWidth: 1,
    borderColor: Color_.red,
  },
  font44: {
    fontSize: 44,
    lineHeight: 44,
  },
  backgroundF9: {
    backgroundColor: Color_.grayF9,
  },
  width187: {
    width: 187,
  },
  width165: {
    width: 165,
  },
  width40pr: {
    width: '40%',
  },
  ornamenPosition: {
    position: 'absolute',
    bottom: 0,
    zIndex: -1,
  },
  bottom20: {
    bottom: 0,
  },
  bottom200: {
    bottom: -100,
  },
  androidHomeMainButton: {
    borderBottomWidth: 1,
    borderColor: Color_.red,
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
    paddingTop: 1,
  },
  line17: {
    lineHeight: 17,
  },
  square60: {
    width: 60,
    height: 60,
  },
  square80: {
    width: 80,
    height: 80,
  },
  width60: {
    width: 60,
  },
  line24: {
    lineHeight: 24,
  },
  backgroundGrayCe: {
    backgroundColor: Color_.grayce,
  },
  wrongInput: {
    borderBottomWidth: 1,
    borderBottomColor: Color_.red,
  },
  autoCompleteShadow: {
    shadowColor: Color_.mediumGray,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.5,
    shadowRadius: 2,
    elevation: 4,
  },

  // add
  halfOpacity: {
    opacity: 0.5,
  },
  quarterOpacity: {
    opacity: 0.25,
  },
  backgroundWhiteSmoke: {
    backgroundColor: Color_.whiteSmoke,
  },
  mV2: {
    marginVertical: 2,
  },
  mV5: {
    marginVertical: 5,
  },
  mV10: {
    marginVertical: 10,
  },
  mV15: {
    marginVertical: 15,
  },
  mH5: {
    marginHorizontal: 5,
  },
  mH15: {
    marginHorizontal: 15,
  },
  ph12: {
    paddingHorizontal: 12,
  },
  ph10: {
    paddingHorizontal: 10,
  },
  ph9: {
    paddingHorizontal: 9,
  },
  italic: {
    fontFamily: Font_.FSAlberProItalic,
    // fontStyle: 'italic',
  },
  textDisabled: {
    color: Color_.brightGray,
  },
  padding5: {
    padding: 5,
  },
  btn: {
    borderWidth: 1,
    borderRadius: 4,
    borderColor: Color_.black,
    backgroundColor: Color_.white,
    color: Color_.black,
  },
  textStrongBlack: {
    fontSize: 15,
    fontWeight: '500',
    color: Color_.black,
  },
  alignContentEnd: {
    alignContent: 'flex-end',
  },
  borderBottomWhiteSmoke: {
    borderBottomColor: Color_.whiteSmoke,
  },
  borderBottomNativeBase: {
    borderColor: Color_.nativeBaseBorderGray,
    borderBottomWidth: 1 / PixelRatio.getPixelSizeForLayoutSize(1) * 2,
  },
  borderRightNativeBase: {
    borderColor: Color_.nativeBaseBorderGray,
    borderRightWidth: 1 / PixelRatio.getPixelSizeForLayoutSize(1) * 2,
  },
  absoluteTopRight: {
    position: 'absolute',
    top: 0,
    right: 0,
  },
  absoluteFull: {
    position: 'absolute',
    width: '100%',
    height: dimensions.height,
    top: 0,
    bottom: 0,
  },
  hide: {
    display: 'none',
  },
  margin30: {
    margin: 30,
  },
  font11: {
    fontSize: 11,
  },
  excludeFontPadding: {
    includeFontPadding: false,
  },
  roundedButton: {
    width: 50,
    borderRadius: 25,
    elevation: 5,
    shadowColor: Color_.f10,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.5,
    shadowRadius: 2,
  },
  screenContainer: {
    display: 'flex',
    flex: 1,
    position: 'absolute',
    top: 0,
    bottom: 0,
    width: '100%',
    height: '100%',
    minHeight: isTablet() ? null : minHeightFull - statusBarHeight,
  },
  nullMinHeight: { minHeight: null },
  flex15: {
    flex: 15,
  },
  height50: {
    height: 50,
  },
  containerWithPadding12: {
    padding: 12,
    flex: 1,
    paddingBottom: 0,
  },
  containerWithPaddingTablet: {
    paddingTop: 20,
    paddingHorizontal: 150,
    flex: 1,
    paddingBottom: 0,
  },
  containerWithMargin12: {
    margin: 12,
    flex: 1,
  },
  margin0: {
    margin: 0,
  },
  margin3: {
    margin: 3,
  },
  fontAlbert11: {
    fontFamily: Font_.FSAlbertPro,
    fontSize: 11,
    lineHeight: 15,
  },
  fontAlbert12: {
    fontFamily: Font_.FSAlbertPro,
    fontSize: 12,
    lineHeight: 16,
  },
  fontAlbert14: {
    fontFamily: Font_.FSAlbertPro,
    fontSize: 14,
    lineHeight: 18,
  },
  fontAlbert16: {
    fontFamily: Font_.FSAlbertPro,
    fontSize: 16,
    lineHeight: 20,
  },
  fontAlbert18: {
    fontFamily: Font_.FSAlbertPro,
    fontSize: 18,
    lineHeight: 22,
  },
  fontAlbertBold11: {
    fontFamily: Font_.FSAlbertProBold,
    fontSize: 11,
    lineHeight: 15,
    fontWeight: 'bold',
  },
  fontAlbertBold12: {
    fontFamily: Font_.FSAlbertProBold,
    fontSize: 12,
    lineHeight: 16,
    fontWeight: 'bold',
  },
  fontAlbertBold14: {
    fontFamily: Font_.FSAlbertProBold,
    fontSize: 14,
    lineHeight: 18,
    fontWeight: 'bold',
  },
  fontAlbertBold16: {
    fontFamily: Font_.FSAlbertProBold,
    fontSize: 16,
    lineHeight: 20,
    fontWeight: 'bold',
  },
  alignEnd: {
    alignContent: 'flex-end',
    alignItems: 'flex-end',
  },
  pb30: {
    paddingBottom: 30,
  },
  pb60: {
    paddingBottom: 60,
  },
  pb80: {
    paddingBottom: 80,
  },
  noBorder: {
    borderWidth: 0,
  },
  width40: {
    width: 40,
  },
  width30: {
    width: 30,
  },
  overflowHide: {
    overflow: 'hidden',
  },
  carouselWidth: {
    width: 220,
  },
  topBorderRadius8: {
    borderTopLeftRadius: 8,
    borderTopRightRadius: 8,
  },
  p: {
    textAlign: 'justify',
    lineHeight: 16,
  },
  mln15: {
    marginLeft: -15,
  },
  bgImage: {
    position: 'absolute',
    left: 0,
    top: 0,
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height,
  },
  font63: {
    fontSize: 63,
  },
  width75: {
    width: 75,
  },
  height75: {
    height: 75,
  },
  justifySpaceArround: {
    justifyContent: 'space-around',
  },
  swiperImage: {
    borderRadius: 8,
    resizeMode: 'stretch',
  },
  resizeContain: {
    resizeMode: 'contain',
  },
  py20: {
    paddingVertical: 20,
  },
  borderTopGray: {
    borderTopWidth: 1,
    borderTopColor: Color_.barGray,
  },
  borderBottomGray: {
    borderBottomWidth: 1,
    borderBottomColor: Color_.barGray,
  },
  height150: {
    height: 150,
  },
  height165: {
    height: 165,
  },
  height175: {
    height: 175,
  },
  imgTTDContainer: {
    width: '100%',
    height: 180,
    backgroundColor: Color_.white,
  },
  ttdContainer: {
    borderWidth: 1,
    borderColor: Color_.gray97,
    backgroundColor: Color_.ttdBg,
    borderRadius: 8,
  },
  mt40: {
    marginTop: 40,
  },
  height4: {
    height: 4,
  },
  sliderThumb: {
    width: 18,
    height: 18,
    borderRadius: 18 / 2,
    backgroundColor: Color_.white,
    borderColor: Color_.red,
    borderWidth: 2,
  },
  mrn15: {
    marginRight: -15,
  },
  mrn18: {
    marginRight: -18,
  },
  mtn30: {
    marginTop: -30,
  },
  textBlack: {
    color: Color_.black,
  },
  calculatorContainer: {
    elevation: 2,
    borderBottomColor: Color_.efefef,
    borderBottomWidth: 1,
    borderLeftColor: Color_.efefef,
    borderRightColor: Color_.efefef,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
    position: 'absolute',
    top: 50,
    left: 0,
    width: '100%',
    right: 0,
    backgroundColor: Color_.white,
    zIndex: 999,
  },
  pl25: {
    paddingLeft: 25,
  },
  pr25: {
    paddingRight: 25,
  },
  br8bw1: {
    borderRadius: 8,
    borderWidth: 1,
  },
  calcModal: {
    backgroundColor: Color_.overlay,
    height: '100%',
    flex: 1,
    justifyContent: 'flex-end',
    flexDirection: 'column',
  },
  imageBanner: {
    borderRadius: 2,
    width: '100%',
    height: '100%',
  },
  modalSeparator: {
    flexDirection: 'row',
    justifyContent: 'center',
    paddingLeft: '35%',
    paddingRight: '35%',
    marginBottom: 20,
  },
  calcSeparator: {
    borderBottomColor: Color_.brightGray,
    borderBottomWidth: 3,
  },
  calcSeparatorCnt: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    paddingLeft: '25%',
    paddingRight: '25%',
  },
  calcPosition: {
    height: '50%',
    backgroundColor: Color_.white,
    padding: 15,
    borderTopLeftRadius: 8,
    borderTopRightRadius: 8,
    bottom: 0,
  },
  editDashbordIcons: {
    backgroundColor: Color_.white,
    borderTopLeftRadius: 8,
    borderTopRightRadius: 8,
    bottom: 0,
  },
  calcRedSeparator: {
    borderBottomColor: Color_.red,
    borderBottomWidth: 2,
  },
  padding15: {
    padding: 15,
  },
  sqs6EditBtn: {
    backgroundColor: Color_.white,
    borderRadius: 10,
    width: '40%',
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: Color_.red,
    borderWidth: 1,
  },
  border2: {
    borderWidth: 2,
  },
  redBorder: {
    borderColor: Color_.red,
  },
  grayBorder: {
    borderColor: Color_.gray88,
  },
  height100: {
    height: 100,
  },
  height120: {
    height: 120,
  },
  backgroundffe5e5: {
    backgroundColor: Color_.ffe5e5,
  },
  absolute: {
    position: 'absolute',
    zIndex: 0,
  },
  width10pr: {
    width: '10%',
  },
  width25pr: {
    width: '25%',
  },
  width80pr: {
    width: '80%',
  },
  width90pr: {
    width: '90%',
  },
  backgroundNearWhite: {
    backgroundColor: Color_.grayNearWhite,
  },
  width100: {
    width: 100,
  },
  ml26: {
    marginLeft: 26,
  },
  padding25: {
    padding: 25,
  },
  height130: {
    height: 130,
  },
  height190: {
    height: 190,
  },
  height330: {
    height: 330,
  },
  height400: {
    height: 400,
  },
  justifySpaceBetween: {
    justifyContent: 'space-between',
  },
  pickerDropdownAndroid: {
    width: '100%',
    height: 30,
    marginLeft: -9,
  },
  rowDirectionFlexEnd: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  newBadge: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: Color_.red,
    borderRadius: 12.5,
    borderWidth: 1,
    borderColor: Color_.white,
    zIndex: 99,
    minWidth: 25,
    padding: 0,
    alignContent: 'center',
    justifyContent: 'center',
    alignItems: 'center',
  },
  moveBadge: {
    position: 'absolute',
    top: -6,
    right: -6,
    backgroundColor: Color_.whiteSmoke,
    opacity: 0.50,
    borderRadius: 12.5,
    borderWidth: 1,
    borderColor: Color_.white,
    zIndex: 10,
    minWidth: 25,
    padding: 0,
    alignContent: 'center',
    justifyContent: 'center',
    alignItems: 'center',
  },
  dragStyle: {
    // justifyContent: 'center',
    alignItems: 'flex-end',
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  mH12: {
    marginHorizontal: 12,
  },
  height47: {
    height: 47,
  },
  loadingOnBackground: {
    position: 'absolute',
    zIndex: -1,
  },
  ttdBtnCnt: {
    height: 70, position: 'absolute', bottom: 0, left: 0, right: 0, zIndex: 999,
  },
  mtMin26: { marginTop: -26 },
  mtMin10: { marginTop: -10 },
  center: { justifyContent: 'center', alignContent: 'center', alignItems: 'center' },
  ph5: { paddingHorizontal: 5 },
  ph15: { paddingHorizontal: 15 },
  pv2: { paddingVertical: 2 },
  pv5: { paddingVertical: 5 },
  pv10: { paddingVertical: 10 },
  pv15: { paddingVertical: 15 },
  legendStyle: { width: 15, height: 11 },
  mb45: { marginBottom: 45 },
  mtMin1: { marginTop: -1 },
  horizontalLine: {
    height: 1, backgroundColor: Color_.nativeBaseBorderGray, alignSelf: 'center', flex: 1,
  },
  height200: { height: 200 },
});

const setFont = ({ fontFamily = Font_.FSAlbertPro, size = 12, fontColor }) => {
  const defaultStyle = {
    fontFamily,
    fontSize: size,
    lineHeight: size + 4,
  };
  return (fontColor ? { ...defaultStyle, color: fontColor } : defaultStyle);
};

const Color = Color_;
const Font = Font_;
const Main = {
  ...Styles,
  // Add dynamic styles here
  setRound: (size, backgroundColor, borderColor) => ({
    width: size,
    height: size,
    borderRadius: Math.round(size / 2),
    backgroundColor: backgroundColor || Color.transparent,
    borderWidth: borderColor ? 2 : 0,
    borderColor,
  }),
  setFontAlbert: (size, fontColor) => setFont({ size, fontColor }),
  setFontAlbertBold: (size, fontColor) => setFont({ size, fontColor, fontFamily: Font_.FSAlbertProBold }),
  setFontAlbertExtraBold: (size, fontColor) => setFont({ size, fontColor, fontFamily: Font_.FSAlbertProExtraBold }),
  /** @param on 'Bottom' | 'Left' | 'Right' | 'Top' | '' */
  setBorder: ({
    on = '', width = 1, borderColor = Color.nativeBaseBorderGray, borderRadius, ...props
  } = {}) => ({
    borderColor,
    borderRadius,
    [`border${on}Width`]: width,
    ...props,
  }),
  /**
   * @param w: width
   * @param h: height
   * @param r: borderRadius
  */
  setSize: ({
    w, h, r, ...props
  }) => ({
    width: w, height: h, borderRadius: r, ...props,
  }),
  setAbsolute: ({
    zIndex = 1, top = 0, bottom, right, left = 0, ...props
  } = {}) => ({
    position: 'absolute', zIndex, top, bottom, right, left, ...props,
  }),
};

export default {
  Main,
  Color,
  Font,
};
