/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import {
  Alert, TextInput, Image, View, BackHandler,
} from 'react-native';
import { connect } from 'react-redux';
import {
  Container,
  Content, Button, Text, Icon,
} from 'native-base';
import _ from '../../../lang';
import LoadingModal from '../../../components/loading_modal';
import Style from '../../../styles';
import { CandidateServices, AOBServices } from '../../recruitment/services';
import { ConfigAOB } from '../../recruitment/config';
// import ornamen from '../../../assets/images/ornamen.png';
import bg from '../../../assets/images/bg.png';

class SignUpNonAgentHome extends Component {
  constructor() {
    super();
    this.state = {
      npa: '',
      nama: '',
      idCardNo: '',
      checkSalesForceIdFlag: 'Y',
      showLoadingModal: false,
    };

    this.onPressVerify = this.onPressVerify.bind(this);
  }

  componentDidMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleBack();
      return true;
    });
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  handleBack = () => {
    this.props.navigation.replace('SignUpHome');
  }

  onPressVerify = async () => {
    try {
      const {
        npa, nama, idCardNo, checkSalesForceIdFlag,
      } = this.state;

      const token = [{
        keyHeader: 'X-CSRF-Token',
        valueHeader: `Bearer ${this.props.resAuth.access_token}`,
      }];

      // validate data candidate
      if (npa === '' || nama === '' || idCardNo === '') {
        Alert.alert(_('Error'), 'Semua field pada halaman wajib diisi', [{ text: _('Tutup') }]);
      } else {
        this.setState({ showLoadingModal: true });
        // action verifiy
        const requestVerify = ConfigAOB.VerifyCandidate(npa, nama, idCardNo, checkSalesForceIdFlag);
        requestVerify.data = {
          headers: token,
          params: requestVerify.parameters.params,
        };
        const responseVerify = await CandidateServices.verifyCalonCandidate(requestVerify, true);

        const { phoneNumber } = responseVerify;

        const requestGetPruForceId = ConfigAOB.GetPruForceID('', npa);
        requestGetPruForceId.data = {
          headers: token,
          params: requestGetPruForceId.parameters.params,
        };
        const responseGetPruForceId = await AOBServices.getDataFromAPI(requestGetPruForceId, true);

        const { errorCode, errorMessage } = responseGetPruForceId;
        // check response code
        // eslint-disable-next-line no-empty
        if (errorCode === '000000' || errorCode === '000016') {
          Alert.alert(_('Error'), errorMessage, [{ text: _('Tutup') }]);
        } else {
          // go to sms-verification
          this.props.navigation.replace('SMSVerification',
            {
              smsType: 'DaftarPRUForceID', userType: 'candidate', phoneNumber, pageType: undefined,
            });
        }
      }
    } catch (error) {
      Alert.alert(_('Error'), error, [{ text: _('Tutup') }]);
    } finally {
      this.setState({ showLoadingModal: false });
    }
  }

  render() {
    return (
      <Container>
        <Image source={bg} style={Style.Main.bgImage} />
        <View>
          <Button
            transparent
            iconLeft
            onPress={() => this.props.navigation.replace('SignUpHome')}
          >
            <Icon name="angle-left" type="FontAwesome" style={[Style.Main.textRed]} />
            <Text style={[Style.Main.textRed]}>{_('Back')}</Text>
          </Button>
        </View>
        <Content keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
          <Text
            style={[Style.Main.font44, Style.Main.textRed, Style.Main.mt64, Style.Main.textAlignCenter, Style.Main.fontBold, Style.Main.mb55]}
          >PRUFast
          </Text>
          <Text
            style={[Style.Main.font18, Style.Main.textColor3f3, Style.Main.textAlignCenter]}
          >{_('Verifikasi Data Calon Agen')}
          </Text>
          <View
            style={[Style.Main.container, Style.Main.mt30]}
          >
            <TextInput
              style={[Style.Main.container, Style.Main.grayBorderBottom, Style.Main.pb5,
                Style.Main.textGray97, Style.Main.alignCenter, Style.Main.width187]}
              keyboardAppearance="default"
              keyboardType="default"
              returnKeyType="done"
              maxLength={15}
              placeholder={_('Nomor Pengajuan Agen (NPA)')}
              onChangeText={text => this.setState({ npa: text })}
              value={this.state.npa}
            />
          </View>
          <View
            style={[Style.Main.container, Style.Main.mt30]}
          >
            <TextInput
              style={[Style.Main.container, Style.Main.grayBorderBottom, Style.Main.pb5,
                Style.Main.textGray97, Style.Main.alignCenter, Style.Main.width187]}
              keyboardAppearance="default"
              keyboardType="default"
              returnKeyType="done"
              maxLength={15}
              placeholder={_('Nama Sesuai KTP')}
              onChangeText={text => this.setState({ nama: text })}
              value={this.state.nama}
            />
          </View>
          <View
            style={[Style.Main.container, Style.Main.mt30]}
          >
            <TextInput
              style={[Style.Main.container, Style.Main.grayBorderBottom, Style.Main.pb5,
                Style.Main.textGray97, Style.Main.alignCenter, Style.Main.width187]}
              keyboardAppearance="default"
              keyboardType="default"
              returnKeyType="done"
              maxLength={15}
              placeholder={_('Nomor KTP')}
              onChangeText={text => this.setState({ idCardNo: text })}
              value={this.state.idCardNo}
            />
          </View>
          <View
            style={[Style.Main.container]}
          >
            <Button
              rounded
              danger
              style={[Style.Main.alignCenter, Style.Main.backgroundRed, Style.Main.mt20,
                Style.Main.width187, Style.Main.dialogBtnCnt, Style.Main.itemCenter]}
              onPress={this.onPressVerify}
            >
              <Text
                style={[Style.Main.textWhite]}
              >{_('VERIFIKASI')}
              </Text>
            </Button>
          </View>
        </Content>
        <LoadingModal
          show={this.state.showLoadingModal}
          size="large"
          color="white"
        />
      </Container>
    );
  }
}

const mapStateToProps = state => ({
  resAuth: state.auth.res,
});

export default connect(mapStateToProps, null)(SignUpNonAgentHome);
