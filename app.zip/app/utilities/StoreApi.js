/**
 * @author: dwi.setiyadi@gmail.com
*/

import { WLAuthorizationManager, WLResourceRequest, WLClient } from 'react-native-ibm-mobilefirst';
import Axios from 'axios';
import { Platform } from 'react-native';

export const resourceRequest = (adapter, method, params, setTimeout) => WLAuthorizationManager.obtainAccessToken('')
  .then(async (token) => {
    let applyMethod;
    const timeout = setTimeout || 25000;
    switch (method) {
      case 'get':
        applyMethod = WLResourceRequest.GET;
        break;
      case 'post':
        applyMethod = WLResourceRequest.POST;
        break;
      case 'update':
        applyMethod = WLResourceRequest.UPDATE;
        break;
      case 'delete':
        applyMethod = WLResourceRequest.DELETE;
        break;
      default:
        applyMethod = WLResourceRequest.GET;
        break;
    }

    const serverUrl = await WLClient.getServerUrl();
    let headers = {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    };
    if (params.headers) {
      params.headers.forEach((x) => {
        headers = {
          ...headers,
          [x.keyHeader]: x.valueHeader,
        };
      });
    }
    const config = {
      method: applyMethod,
      url: `${serverUrl}/${adapter}`,
      headers,
      timeout,
    };
    if (params.params) {
      let formData = {};
      const newParams = Object.keys(params).reduce((object, key) => {
        if (key !== 'headers') {
          object[key] = params[key]; // eslint-disable-line no-param-reassign
        }
        return object;
      }, {});
      headers = { ...headers, 'Content-Type': 'multipart/form-data' };
      formData = new FormData();
      Object.keys(newParams).forEach((x) => {
        formData.append(x, newParams[x]);
      });
      config.headers = headers;
      config.data = formData;
    }
    Axios.defaults.timeout = timeout;
    return Axios(config);
  }, (err) => {
    const message = JSON.parse(err.message);
    const errorObj = {
      code: '999',
      errorMessage: 'Terjadi Kesalahan komunikasi dengan server. Silakan hubungi Customer Care. [999]',
    };
    if (message.errorMsg.includes('java.net.UnknownHostException')) {
      errorObj.code = '001';
      errorObj.errorMessage = `Terjadi kesalahan komunikasi dengan server. Periksa koneksi anda. [${errorObj.code}]`;
    } else if (message.errorMsg.includes('Application doesn\'t exist')) {
      errorObj.code = '002';
      errorObj.errorMessage = `Terjadi kesalahan komunikasi dengan server. Silakan hubungi Customer Care. [${errorObj.code}]`;
    } else if (message.errorMsg.includes('Unable to find explicit activity class {id.co.prudential.pd/com.worklight.wlclient.ui.UIActivity};')) {
      errorObj.code = '003';
      // eslint-disable-next-line max-len
      errorObj.errorMessage = `Yth. Tenaga Pemasar.\nAplikasi terbaru tersedia di ${Platform.OS === 'android' ? 'Play' : 'App'} Store dan silakan melakukan pembaruan.\nTerimakasih. [${errorObj.code}]`;
    }
    return {
      data: errorObj,
    };
  });
