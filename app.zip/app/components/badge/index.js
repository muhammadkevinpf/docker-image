/**
 * @author: ahmdichsanb@gmail.com
*/

import React, { Component } from 'react';
import {
  Text, View,
} from 'react-native';
import PropTypes from 'prop-types';
import StyleBadge from './StyleBadge';

class Badge extends Component {
  render() {
    const {
      badgeValue,
      badgeType,
      badgeStyleProps,
    } = this.props;

    let badgeStyle;
    let fontStyle;
    let _badgeValue;
    switch (badgeType) {
      case 'primary':
        badgeStyle = [StyleBadge.badgeCore, StyleBadge.primaryBadge, badgeStyleProps];
        fontStyle = StyleBadge.nonDefaultFontStyle;
        break;
      case 'success':
        badgeStyle = [StyleBadge.badgeCore, StyleBadge.successBadge, badgeStyleProps];
        fontStyle = StyleBadge.nonDefaultFontStyle;
        break;
      case 'info':
        badgeStyle = [StyleBadge.badgeCore, StyleBadge.infoBadge, badgeStyleProps];
        fontStyle = StyleBadge.nonDefaultFontStyle;
        break;
      case 'warning':
        badgeStyle = [StyleBadge.badgeCore, StyleBadge.warningBadge, badgeStyleProps];
        fontStyle = StyleBadge.nonDefaultFontStyle;
        break;
      case 'danger':
        badgeStyle = [StyleBadge.badgeCore, StyleBadge.dangerBadge, badgeStyleProps];
        fontStyle = StyleBadge.nonDefaultFontStyle;
        break;
      default:
        // default pru
        badgeStyle = [StyleBadge.badgeCore, StyleBadge.defaultBadge, badgeStyleProps];
        fontStyle = StyleBadge.defaultFontStyle;
        break;
    }

    if (badgeValue === 0 || badgeValue === null || badgeValue === undefined) {
      _badgeValue = '0';
    } else if (badgeValue > 99) {
      _badgeValue = '99+';
    } else {
      _badgeValue = badgeValue;
    }

    return (
      <View style={[badgeStyle]}>
        <Text style={[fontStyle]}>{_badgeValue}</Text>
      </View>
    );
  }
}

Badge.propTypes = {
  badgeValue: PropTypes.number.isRequired,
  badgeType: PropTypes.string.isRequired,
  badgeStyleProps: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
};

Badge.defaultProps = {
  badgeStyleProps: null,
};

export default Badge;
