import {
  TOTALTODOFETCH,
  TOTALTODOSUCCESS,
  TOTALTODOFAILED,

  TOTALTODORECRUITMENTFETCH,
  TOTALTODORECRUITMENTSUCCESS,
  TOTALTODORECRUITMENTFAILED,

  TOTALTODONTUCASEFETCH,
  TOTALTODONTUCASESUCCESS,
  TOTALTODONTUCASEFAILED,

  TOTALTODOBILLINGPENDINGFETCH,
  TOTALTODOBILLINGPENDINGSUCCESS,
  TOTALTODOBILLINGPENDINGFAILED,

  TOTALTODOPOLICYHOLDERFETCH,
  TOTALTODOPOLICYHOLDERSUCCESS,
  TOTALTODOPOLICYHOLDERFAILED,

  TOTALTODOCLAIMPENDINGFETCH,
  TOTALTODOCLAIMPENDINGSUCCESS,
  TOTALTODOCLAIMPENDINGFAILED,

  TOTALTODOPOLICYDUEDATEFETCH,
  TOTALTODOPOLICYDUEDATESUCCESS,
  TOTALTODOPOLICYDUEDATEFAILED,

  TOTALTODOPOLICYDUEDATEAGEINGFETCH,
  TOTALTODOPOLICYDUEDATEAGEINGSUCCESS,
  TOTALTODOPOLICYDUEDATEAGEINGFAILED,

  TOTALTODOCLIENTBIRTHDAYFETCH,
  TOTALTODOCLIENTBIRTHDAYSUCCESS,
  TOTALTODOCLIENTBIRTHDAYFAILED,

  FINDLISTTODORECRUITMENTFETCH,
  FINDLISTTODORECRUITMENTSUCCESS,
  FINDLISTTODORECRUITMENTFAILED,

  FINDLISTTODONEWBUSINESSFETCH,
  FINDLISTTODONEWBUSINESSSUCCESS,
  FINDLISTTODONEWBUSINESSFAILED,

  FINDLISTTODOFUNDHISTORYFETCH,
  FINDLISTTODOFUNDHISTORYSUCCESS,
  FINDLISTTODOFUNDHISTORYFAILED,

  FINDLISTTODOFOLLOWUPFETCH,
  FINDLISTTODOFOLLOWUPSUCCESS,
  FINDLISTTODOFOLLOWUPFAILED,

  FINDLISTTODOFOLLOWUPPOLICYFETCH,
  FINDLISTTODOFOLLOWUPPOLICYSUCCESS,
  FINDLISTTODOFOLLOWUPPOLICYFAILED,

  FINDLISTTODOCLAIMHISTORYNONDEATHFETCH,
  FINDLISTTODOCLAIMHISTORYNONDEATHSUCCESS,
  FINDLISTTODOCLAIMHISTORYNONDEATHFAILED,

  FINDLISTTODOCLAIMHISTORYPREMIUMFETCH,
  FINDLISTTODOCLAIMHISTORYPREMIUMSUCCESS,
  FINDLISTTODOCLAIMHISTORYPREMIUMFAILED,

  FINDLISTTODOCLAIMHISTORYDEATHFETCH,
  FINDLISTTODOCLAIMHISTORYDEATHSUCCESS,
  FINDLISTTODOCLAIMHISTORYDEATHFAILED,

  FINDLISTTODOPRODUCTDETAILFETCH,
  FINDLISTTODOPRODUCTDETAILSUCCESS,
  FINDLISTTODOPRODUCTDETAILFAILED,

  FINDLISTTODOBILLINGPENDINGFETCH,
  FINDLISTTODOBILLINGPENDINGSUCCESS,
  FINDLISTTODOBILLINGPENDINGFAILED,

  FINDLISTTODOPOLICYHOLDERFETCH,
  FINDLISTTODOPOLICYHOLDERSUCCESS,
  FINDLISTTODOPOLICYHOLDERFAILED,

  FINDLISTTODOPENDINGCLAIMFETCH,
  FINDLISTTODOPENDINGCLAIMSUCCESS,
  FINDLISTTODOPENDINGCLAIMFAILED,

  FINDLISTTODOCLIENTBIRTHDAYRECENTFETCH,
  FINDLISTTODOCLIENTBIRTHDAYRECENTSUCCESS,
  FINDLISTTODOCLIENTBIRTHDAYRECENTFAILED,

  FINDLISTTODOCLIENTBIRTHDAYTODAYFETCH,
  FINDLISTTODOCLIENTBIRTHDAYTODAYSUCCESS,
  FINDLISTTODOCLIENTBIRTHDAYTODAYFAILED,

  FINDLISTTODOCLIENTBIRTHDAYUPCOMINGFETCH,
  FINDLISTTODOCLIENTBIRTHDAYUPCOMINGSUCCESS,
  FINDLISTTODOCLIENTBIRTHDAYUPCOMINGFAILED,
  FINDLASTUPDATECLIENTFETCH,
  FINDLASTUPDATECLIENTSUCCESS,
  FINDLASTUPDATECLIENTFAILED,
  FINDLASTUPDATEPOLICYFETCH,
  FINDLASTUPDATEPOLICYSUCCESS,
  FINDLASTUPDATEPOLICYFAILED,
  CLIENTPROFILEFETCH,
  CLIENTPROFILESUCCESS,
  CLIENTPROFILEFAILED,
  CLIENTPROFILERESET,
  CLIENTPOLICYOWNERFETCH,
  CLIENTPOLICYOWNERSUCCESS,
  CLIENTPOLICYOWNERFAILED,
  CLIENTPOLICYLISTFETCH,
  CLIENTPOLICYLISTSUCCESS,
  CLIENTPOLICYLISTFAILED,
  CLIENTPROPOSALLISTFETCH,
  CLIENTPROPOSALLISTSUCCESS,
  CLIENTPROPOSALLISTFAILED,
  CLIENTSUMATRISKFETCH,
  CLIENTSUMATRISKFAILED,
  CLIENTSUMATRISKSUCCESS,

  // Tracker for Todo
  TRACKERADDSTACK,
  TRACKERGOBACK,
  DELETETRACKER,

  CLEARTODONEWBUSINNESS,
  CLEARTODOCLIENTBIRTHDAYRECENT,
  CLEARTODOCLIENTBIRTHDAYTODAY,
  CLEARTODOCLIENTBIRTHDAYUPCOMING,

  // AfterDueDateTotal
  AFTERDUEDATETOTALFETCH,
  AFTERDUEDATETOTALSUCCESS,
  AFTERDUEDATETOTALFAILED,
  // BeforeDueDateTotal
  BEFOREDUEDATETOTALFETCH,
  BEFOREDUEDATETOTALSUCCESS,
  BEFOREDUEDATETOTALFAILED,
  // AllAfterDueDateTotal
  ALLAFTERDUEDATETOTALFETCH,
  ALLAFTERDUEDATETOTALSUCCESS,
  ALLAFTERDUEDATETOTALFAILED,
  // AfterDueDatePolicyList
  AFTERDUEDATEPOLICYLISTFETCH,
  AFTERDUEDATEPOLICYLISTSUCCESS,
  AFTERDUEDATEPOLICYLISTFAILED,
  DELETEDUEDATEPOLICYLISTREDUCER,
  // BeforedDueDatePolicyList
  BEFOREDUEDATEPOLICYLISTFETCH,
  BEFOREDUEDATEPOLICYLISTSUCCESS,
  BEFOREDUEDATEPOLICYLISTFAILED,

  // afterDueDatePolicyDetail
  AFTERDUEDATEPOLICYDETAILFETCH,
  AFTERDUEDATEPOLICYDETAILSUCCESS,
  AFTERDUEDATEPOLICYDETAILFAILED,
  DELETEDUEDATEPOLICYDETAILREDUCER,

  TOTALPOLICYINCANCELPERIODFETCH,
  TOTALPOLICYINCANCELPERIODSUCCESS,
  TOTALPOLICYINCANCELPERIODFAILED,

  POLICYINCANCELPERIODFETCH,
  POLICYINCANCELPERIODSUCCESS,
  POLICYINCANCELPERIODFAILED,

  // Rincian Polis Start
  LISTCLIENTBYAGENTNUMBERFETCH,
  LISTCLIENTBYAGENTNUMBERSUCCESS,
  LISTCLIENTBYAGENTNUMBERFAILED,

  PROFILECLIENTBYAGENTNUMBERFETCH,
  PROFILECLIENTBYAGENTNUMBERSUCCESS,
  PROFILECLIENTBYAGENTNUMBERFAILED,

  // function getPolicyMovementHistory
  GETPOLICYMOVEMENTHISTORYFETCH,
  GETPOLICYMOVEMENTHISTORYSUCCESS,
  GETPOLICYMOVEMENTHISTORYFAILED,

  // Only reset on Policy and Proposal Detail
  RESETPOLICYANDPROPOSALDETAILREDUCER,
  MEDICAL_LETTER_PDF,
  CLIENT_VIP_INFO,
  HNWI_TAGGING,
  HNWI_CALCULATOR,
  DOWNLOAD_PROPOSAL_PDF,
  DUEDATESTATECHANGE,
  DOWNLOAD_CLIENT_DETAIL_PDF,
  DOWNLOAD_FUND_TRANSACTION_PDF,
  GET_PERSONAL_DATA,
  GET_PROPOSAL_POLICY,
  GET_PREMIUM_DATA,
  GET_PRODUCT_LIST,
  GET_UPDATED_DATE,
  GET_ALLOCATION,
  GET_FUND_HOLDING,
  GET_DOCUMENT,
  renameDocument,
  RESETPROPOSALPOLICYDATAREDUCER,
  FINDFILTERFOLLOWUPSTATUSFETCH,
  FINDFILTERFOLLOWUPSTATUSSUCCESS,
  FINDFILTERFOLLOWUPSTATUSFAILED,
  FINDFILTERFOLLOWUPSTATUSTODOFETCH,
  FINDFILTERFOLLOWUPSTATUSTODOSUCCESS,
  FINDFILTERFOLLOWUPSTATUSTODOFAILED,
} from './ConfigTodoList';
import { RESET_ALL_STATE } from '../dashboard/ConfigDashboard';
import { requestStatus, isEmpty } from '../../utilities';

const initialClientState = {
  clientProfile: {},
  clientProfileStatus: requestStatus.IDLE,
  clientVIP: requestStatus.IDLE,
  clientPolicyOwner: [],
  clientPolicyList: [],
  clientProposalList: [],
  clientSumAtRisk: {},
  hnwiTagging: {},
  hnwiTaggingStatus: requestStatus.IDLE,
  clientDetailDownload: {},
  clientDetailDownloadStatus: requestStatus.IDLE,
  fundTransaction: {},
  fundTransactionStatus: requestStatus.IDLE,
};

const initialState = {
  updatedDate: null,
  updatedDateStatus: requestStatus.IDLE,
  personalData: {},
  personalDataStatus: requestStatus.IDLE,
  proposalPolicy: {},
  proposalPolicyStatus: requestStatus.IDLE,
  premiumData: {},
  premiumDataStatus: requestStatus.IDLE,
  productList: [],
  productListStatus: requestStatus.IDLE,
  allocation: [],
  allocationStatus: requestStatus.IDLE,
  fundHolding: [],
  fundHoldingStatus: requestStatus.IDLE,
  document: [],
  documentStatus: requestStatus.IDLE,
  proposalPdf: null,
  proposalPdfStatus: requestStatus.IDLE,
};

const initialStateToDo = {
  fetchTotalToDo: false,
  fetchTotalToDoRecruitment: false,
  fetchTotalToDoNTUCase: false,
  fetchTotalToDoBillingPending: false,
  fetchTotalToDoPolicyHolder: false,
  fetchTotalToDoClaimPending: false,
  fetchTotalToDoPolicyDueDate: false,
  fetchTotalToDoPolicyDueDateAgeing: false,
  fetchTotalToDoClientBirthDay: false,

  fetchListToDoRecruitment: false,
  fetchListToDoNewBusiness: false,
  fetchListToDoFundHistory: false,
  fetchFilterToDoFollowUp: false,
  fetchListToDoFollowUp: false,
  fetchListToDoFollowUpPolicy: false,
  fetchFilterToDoFollowUpPolicy: false,
  fetchListToDoClaimHistoryNonDeath: false,
  fetchListToDoClaimHistoryPremium: false,
  fetchListToDoClaimHistoryDeath: false,
  fetchListToDoProductDetail: false,
  fetchListToDoBillingPending: false,
  fetchListToDoPolicyHolder: false,
  fetchListToDoPendingClaim: false,
  fetchListToDoBirthDayRecent: false,
  fetchListToDoBirthDayToday: false,
  fetchListToDoBirthDayUpComing: false,
  send: null,
  res: null,
  err: null,

  // Client Information
  ...initialClientState,
  ...initialState,

  // Tracker Todo
  trackerTodo: [],

  // medical letter
  medicalLetter: { status: requestStatus.IDLE, data: {} },

  // HNWI Calculator
  withdrawalFee: { status: requestStatus.IDLE, data: {} },

  // Due Date State
  dueDateState: { isBefore: false, isAfter: false },
};

export function ReducerToDo(state = initialStateToDo, action) {
  switch (action.type) {
    case RESETPROPOSALPOLICYDATAREDUCER: return { ...state, ...initialState };
    case RESET_ALL_STATE: return initialStateToDo;

    case GET_UPDATED_DATE.FETCH: return { ...state, updatedDateStatus: requestStatus.FETCH };
    case GET_UPDATED_DATE.FAILED: return { ...state, updatedDateStatus: requestStatus.FAILED };
    case GET_UPDATED_DATE.SUCCESS: return { ...state, updatedDateStatus: requestStatus.SUCCESS, updatedDate: action.payload.latest };

    case GET_PERSONAL_DATA.FETCH: return { ...state, personalDataStatus: requestStatus.FETCH };
    case GET_PERSONAL_DATA.FAILED: return { ...state, personalDataStatus: requestStatus.FAILED };
    case GET_PERSONAL_DATA.SUCCESS: return { ...state, personalDataStatus: requestStatus.SUCCESS, personalData: action.payload };

    case GET_PROPOSAL_POLICY.FETCH: return { ...state, proposalPolicyStatus: requestStatus.FETCH };
    case GET_PROPOSAL_POLICY.FAILED: return { ...state, proposalPolicyStatus: requestStatus.FAILED };
    case GET_PROPOSAL_POLICY.SUCCESS: return { ...state, proposalPolicyStatus: requestStatus.SUCCESS, proposalPolicy: action.payload };

    case GET_PREMIUM_DATA.FETCH: return { ...state, premiumDataStatus: requestStatus.FETCH };
    case GET_PREMIUM_DATA.FAILED: return { ...state, premiumDataStatus: requestStatus.FAILED };
    case GET_PREMIUM_DATA.SUCCESS: return { ...state, premiumDataStatus: requestStatus.SUCCESS, premiumData: action.payload };

    case GET_PRODUCT_LIST.FETCH: return { ...state, productListStatus: requestStatus.FETCH };
    case GET_PRODUCT_LIST.FAILED: return { ...state, productListStatus: requestStatus.FAILED };
    case GET_PRODUCT_LIST.SUCCESS: return { ...state, productListStatus: requestStatus.SUCCESS, productList: action.payload.array };

    case GET_ALLOCATION.FETCH: return { ...state, allocationStatus: requestStatus.FETCH };
    case GET_ALLOCATION.FAILED: return { ...state, allocationStatus: requestStatus.FAILED };
    case GET_ALLOCATION.SUCCESS: return { ...state, allocationStatus: requestStatus.SUCCESS, allocation: action.payload.array };

    case GET_FUND_HOLDING.FETCH: return { ...state, fundHoldingStatus: requestStatus.FETCH };
    case GET_FUND_HOLDING.FAILED: return { ...state, fundHoldingStatus: requestStatus.FAILED };
    case GET_FUND_HOLDING.SUCCESS: return { ...state, fundHoldingStatus: requestStatus.SUCCESS, fundHolding: action.payload.array };

    case DOWNLOAD_PROPOSAL_PDF.FETCH: return { ...state, proposalPdfStatus: requestStatus.FETCH };
    case DOWNLOAD_PROPOSAL_PDF.FAILED: return { ...state, proposalPdfStatus: requestStatus.FAILED };
    case DOWNLOAD_PROPOSAL_PDF.SUCCESS: return { ...state, proposalPdfStatus: requestStatus.SUCCESS, proposalPdf: action.payload.result };

    case GET_DOCUMENT.FETCH: return { ...state, documentStatus: requestStatus.FETCH };
    case GET_DOCUMENT.FAILED: return { ...state, documentStatus: requestStatus.FAILED };
    case GET_DOCUMENT.SUCCESS: return {
      ...state,
      documentStatus: requestStatus.SUCCESS,
      document: isEmpty(action.payload.lists) ? []
        : action.payload.lists.map(item => (
          {
            mainLabel: renameDocument(item.fileType),
            label: item.attributes.Sub_Doc,
            format: item.attributes.fileFormat,
            policyNumber: item.attributes.Policy_Number,
            cmFlag: item.attributes.CM_Flag,
            type: item.fileType,
            holder: item.attributes.Owner_Name,
            docName: item.attributes.Sub_Doc,
          }
        )),
    };

    case TOTALTODOFETCH:
      return {
        ...state,
        fetchTotalToDo: true,
        send: action.send,
        action: action.type,
      };

    case TOTALTODOSUCCESS:
      return {
        ...state,
        err: null,
        action: action.type,
      };

    case TOTALTODOFAILED:
      return {
        ...state,
        fetchTotalToDo: false,
        err: action.err,
        action: action.type,
      };

      // -- Reducer Total List ToDo --//

    case TOTALTODORECRUITMENTFETCH:
      return {
        ...state,
        fetchTotalToDoRecruitment: true,
        send: action.send,
        action: action.type,
      };

    case TOTALTODORECRUITMENTSUCCESS:
      return {
        ...state,
        fetchTotalToDoRecruitment: false,
        res: {
          ...state.res,
          totalToDoRecruitment: action.res,
        },
        err: null,
        action: action.type,
      };

    case TOTALTODORECRUITMENTFAILED:
      return {
        ...state,
        fetchTotalToDoRecruitment: false,
        err: action.err,
        action: action.type,
      };

    case TOTALTODONTUCASEFETCH:
      return {
        ...state,
        fetchTotalToDoNTUCase: true,
        send: action.send,
        action: action.type,
      };

    case TOTALTODONTUCASESUCCESS:
      return {
        ...state,
        fetchTotalToDoNTUCase: false,
        res: {
          ...state.res,
          totalToDoNTUCase: action.res,
        },
        err: null,
        action: action.type,
      };

    case TOTALTODONTUCASEFAILED:
      return {
        ...state,
        fetchTotalToDoNTUCase: false,
        err: action.err,
        action: action.type,
      };

    case TOTALTODOBILLINGPENDINGFETCH:
      return {
        ...state,
        fetchTotalToDoBillingPending: true,
        send: action.send,
        action: action.type,
      };

    case TOTALTODOBILLINGPENDINGSUCCESS:
      return {
        ...state,
        fetchTotalToDoBillingPending: false,
        res: {
          ...state.res,
          totalToDoBillingPending: action.res,
        },
        err: null,
        action: action.type,
      };

    case TOTALTODOBILLINGPENDINGFAILED:
      return {
        ...state,
        fetchTotalToDoBillingPending: false,
        err: action.err,
        action: action.type,
      };

    case TOTALTODOPOLICYHOLDERFETCH:
      return {
        ...state,
        fetchTotalToDoPolicyHolder: true,
        send: action.send,
        action: action.type,
      };

    case TOTALTODOPOLICYHOLDERSUCCESS:
      return {
        ...state,
        fetchTotalToDoPolicyHolder: false,
        res: {
          ...state.res,
          totalToDoPolicyHolder: action.res,
        },
        err: null,
        action: action.type,
      };

    case TOTALTODOPOLICYHOLDERFAILED:
      return {
        ...state,
        fetchTotalToDoPolicyHolder: false,
        err: action.err,
        action: action.type,
      };

    case TOTALTODOCLAIMPENDINGFETCH:
      return {
        ...state,
        fetchTotalToDoClaimPending: true,
        send: action.send,
        action: action.type,
      };

    case TOTALTODOCLAIMPENDINGSUCCESS:
      return {
        ...state,
        fetchTotalToDoClaimPending: false,
        res: {
          ...state.res,
          totalToDoClaimPending: action.res,
        },
        err: null,
        action: action.type,
      };

    case TOTALTODOCLAIMPENDINGFAILED:
      return {
        ...state,
        fetchTotalToDoClaimPending: false,
        err: action.err,
        action: action.type,
      };

    case TOTALTODOPOLICYDUEDATEFETCH:
      return {
        ...state,
        fetchTotalToDoPolicyDueDate: true,
        send: action.send,
        action: action.type,
      };

    case TOTALTODOPOLICYDUEDATESUCCESS:
      return {
        ...state,
        fetchTotalToDoPolicyDueDate: false,
        res: {
          ...state.res,
          totalToDoPolicyDueDate: action.res,
        },
        err: null,
        action: action.type,
      };

    case TOTALTODOPOLICYDUEDATEFAILED:
      return {
        ...state,
        fetchTotalToDoPolicyDueDate: false,
        err: action.err,
        action: action.type,
      };

    case TOTALTODOPOLICYDUEDATEAGEINGFETCH:
      return {
        ...state,
        fetchTotalToDoPolicyDueDateAgeing: true,
        send: action.send,
        action: action.type,
      };

    case TOTALTODOPOLICYDUEDATEAGEINGSUCCESS:
      return {
        ...state,
        fetchTotalToDoPolicyDueDateAgeing: false,
        res: {
          ...state.res,
          totalToDoPolicyDueDateAgeing: action.res,
        },
        err: null,
        action: action.type,
      };

    case TOTALTODOPOLICYDUEDATEAGEINGFAILED:
      return {
        ...state,
        fetchTotalToDoPolicyDueDateAgeing: false,
        err: action.err,
        action: action.type,
      };

    case TOTALTODOCLIENTBIRTHDAYFETCH:
      return {
        ...state,
        fetchTotalToDoClientBirthDay: true,
        send: action.send,
        action: action.type,
      };

    case TOTALTODOCLIENTBIRTHDAYSUCCESS:
      return {
        ...state,
        fetchTotalToDoClientBirthDay: false,
        res: {
          ...state.res,
          totalToDoClientBirthDay: action.res,
        },
        err: null,
        action: action.type,
      };

    case TOTALTODOCLIENTBIRTHDAYFAILED:
      return {
        ...state,
        fetchTotalToDoClientBirthDay: false,
        err: action.err,
        action: action.type,
      };

      // -- Reducer Detail List ToDo --//

    // Reducer Find List Recruitment //
    case FINDLISTTODORECRUITMENTFETCH:
      return {
        ...state,
        fetchListToDoRecruitment: false,
        send: action.send,
        action: action.type,
      };

    case FINDLISTTODORECRUITMENTSUCCESS:
      return {
        ...state,
        fetchListToDoRecruitment: false,
        res: {
          ...state.res,
          listToDoRecruitment: action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDLISTTODORECRUITMENTFAILED:
      return {
        ...state,
        fetchListToDoRecruitment: false,
        err: action.err,
        action: action.type,
      };

    // Reducer Find List New Business //
    case FINDLISTTODONEWBUSINESSFETCH:
      return {
        ...state,
        fetchListToDoNewBusiness: true,
        send: action.send,
        action: action.type,
      };

    case FINDLISTTODONEWBUSINESSSUCCESS:
      return {
        ...state,
        fetchListToDoNewBusiness: false,
        res: {
          ...state.res,
          listToDoNewBusinessPending: state.res && state.res.listToDoNewBusinessPending
            ? [...state.res.listToDoNewBusinessPending, ...action.res] : action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDLISTTODONEWBUSINESSFAILED:
      return {
        ...state,
        fetchListToDoNewBusiness: false,
        err: action.err,
        action: action.type,
      };

    case CLEARTODONEWBUSINNESS:
      return {
        ...state,
        res: {
          ...state.res,
          listToDoNewBusinessPending: [],
        },
      };

    // Reducer Find List Fund History //
    case FINDLISTTODOFUNDHISTORYFETCH:
      return {
        ...state,
        fetchListToDoFundHistory: true,
        send: action.send,
        action: action.type,
      };

    case FINDLISTTODOFUNDHISTORYSUCCESS:
      return {
        ...state,
        fetchListToDoFundHistory: false,
        res: {
          ...state.res,
          listToDoFundHistory: action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDLISTTODOFUNDHISTORYFAILED:
      return {
        ...state,
        fetchListToDoFundHistory: false,
        err: action.err,
        action: action.type,
      };

      // Reducer Find Filter Follow Up Policy //
    case FINDFILTERFOLLOWUPSTATUSTODOFETCH:
      return {
        ...state,
        fetchFilterToDoFollowUp: true,
        send: action.send,
        action: action.type,
      };

    case FINDFILTERFOLLOWUPSTATUSTODOSUCCESS:
      return {
        ...state,
        fetchFilterToDoFollowUp: false,
        res: {
          ...state.res,
          filterToDoFollowUp: action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDFILTERFOLLOWUPSTATUSTODOFAILED:
      return {
        ...state,
        fetchFilterToDoFollowUp: false,
        err: action.err,
        action: action.type,
      };

    // Reducer Find List Follow Up //
    case FINDLISTTODOFOLLOWUPFETCH:
      return {
        ...state,
        fetchListToDoFollowUp: true,
        send: action.send,
        action: action.type,
      };

    case FINDLISTTODOFOLLOWUPSUCCESS:
      return {
        ...state,
        fetchListToDoFollowUp: false,
        res: {
          ...state.res,
          listToDoFollowUp: action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDLISTTODOFOLLOWUPFAILED:
      return {
        ...state,
        fetchListToDoFollowUp: false,
        err: action.err,
        action: action.type,
      };

    // Reducer Find List Follow Up Policy //
    case FINDLISTTODOFOLLOWUPPOLICYFETCH:
      return {
        ...state,
        fetchListToDoFollowUpPolicy: true,
        send: action.send,
        action: action.type,
      };

    case FINDLISTTODOFOLLOWUPPOLICYSUCCESS:
      return {
        ...state,
        fetchListToDoFollowUpPolicy: false,
        res: {
          ...state.res,
          listToDoFollowUpPolicy: action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDLISTTODOFOLLOWUPPOLICYFAILED:
      return {
        ...state,
        fetchListToDoFollowUpPolicy: false,
        err: action.err,
        action: action.type,
      };

    // Reducer Find Filter Follow Up Policy //
    case FINDFILTERFOLLOWUPSTATUSFETCH:
      return {
        ...state,
        fetchFilterToDoFollowUpPolicy: true,
        send: action.send,
        action: action.type,
      };

    case FINDFILTERFOLLOWUPSTATUSSUCCESS:
      return {
        ...state,
        fetchFilterToDoFollowUpPolicy: false,
        res: {
          ...state.res,
          filterToDoFollowUpPolicy: action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDFILTERFOLLOWUPSTATUSFAILED:
      return {
        ...state,
        fetchFilterToDoFollowUpPolicy: false,
        err: action.err,
        action: action.type,
      };

    // Reducer Find List Claim History Non Death //
    case FINDLISTTODOCLAIMHISTORYNONDEATHFETCH:
      return {
        ...state,
        fetchListToDoClaimHistoryNonDeath: true,
        send: action.send,
        action: action.type,
      };

    case FINDLISTTODOCLAIMHISTORYNONDEATHSUCCESS:
      return {
        ...state,
        fetchListToDoClaimHistoryNonDeath: false,
        res: {
          ...state.res,
          listToDoClaimHistoryNonDeath: action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDLISTTODOCLAIMHISTORYNONDEATHFAILED:
      return {
        ...state,
        fetchListToDoClaimHistoryNonDeath: false,
        err: action.err,
        action: action.type,
      };

    // Reducer Find List Claim History Premium //
    case FINDLISTTODOCLAIMHISTORYPREMIUMFETCH:
      return {
        ...state,
        fetchListToDoClaimHistoryPremium: true,
        send: action.send,
        action: action.type,
      };

    case FINDLISTTODOCLAIMHISTORYPREMIUMSUCCESS:
      return {
        ...state,
        fetchListToDoClaimHistoryPremium: false,
        res: {
          ...state.res,
          listToDoClaimHistoryPremium: action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDLISTTODOCLAIMHISTORYPREMIUMFAILED:
      return {
        ...state,
        fetchListToDoClaimHistoryPremium: false,
        err: action.err,
        action: action.type,
      };

    // Reducer Find List Claim History Death //
    case FINDLISTTODOCLAIMHISTORYDEATHFETCH:
      return {
        ...state,
        fetchListToDoClaimHistoryDeath: true,
        send: action.send,
        action: action.type,
      };

    case FINDLISTTODOCLAIMHISTORYDEATHSUCCESS:
      return {
        ...state,
        fetchListToDoClaimHistoryDeath: false,
        res: {
          ...state.res,
          listToDoClaimHistoryDeath: action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDLISTTODOCLAIMHISTORYDEATHFAILED:
      return {
        ...state,
        fetchListToDoClaimHistoryDeath: false,
        err: action.err,
        action: action.type,
      };

    // Reducer Find List Product Detail //
    case FINDLISTTODOPRODUCTDETAILFETCH:
      return {
        ...state,
        fetchListToDoProductDetail: true,
        send: action.send,
        action: action.type,
      };

    case FINDLISTTODOPRODUCTDETAILSUCCESS:
      return {
        ...state,
        fetchListToDoProductDetail: false,
        res: {
          ...state.res,
          listToDoProductDetail: action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDLISTTODOPRODUCTDETAILFAILED:
      return {
        ...state,
        fetchListToDoProductDetail: false,
        err: action.err,
        action: action.type,
      };

    // Reducer Find List Billing Pending //
    case FINDLISTTODOBILLINGPENDINGFETCH:
      return {
        ...state,
        fetchListToDoBillingPending: false,
        send: action.send,
        action: action.type,
      };

    case FINDLISTTODOBILLINGPENDINGSUCCESS:
      return {
        ...state,
        fetchListToDoBillingPending: false,
        res: {
          ...state.res,
          listToDoBillingPendig: action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDLISTTODOBILLINGPENDINGFAILED:
      return {
        ...state,
        fetchListToDoBillingPending: false,
        err: action.err,
        action: action.type,
      };

    // Reducer Find List Policy Holder //
    case FINDLISTTODOPOLICYHOLDERFETCH:
      return {
        ...state,
        fetchListToDoPolicyHolder: true,
        send: action.send,
        action: action.type,
      };

    case FINDLISTTODOPOLICYHOLDERSUCCESS:
      return {
        ...state,
        fetchListToDoPolicyHolder: false,
        res: {
          ...state.res,
          listToDoPolicyHolder: action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDLISTTODOPOLICYHOLDERFAILED:
      return {
        ...state,
        fetchListToDoPolicyHolder: false,
        err: action.err,
        action: action.type,
      };

    // Reducer Find List Pending Claim //
    case FINDLISTTODOPENDINGCLAIMFETCH:
      return {
        ...state,
        fetchListToDoPendingClaim: true,
        send: action.send,
        action: action.type,
      };

    case FINDLISTTODOPENDINGCLAIMSUCCESS:
      return {
        ...state,
        fetchListToDoPendingClaim: false,
        res: {
          ...state.res,
          listToDoPendingClaim: action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDLISTTODOPENDINGCLAIMFAILED:
      return {
        ...state,
        fetchListToDoPendingClaim: false,
        err: action.err,
        action: action.type,
      };

    // Reducer Find List Client BirthDay - Recent //
    case FINDLISTTODOCLIENTBIRTHDAYRECENTFETCH:
      return {
        ...state,
        fetchListToDoBirthDayRecent: true,
        send: action.send,
        action: action.type,
      };

    case FINDLISTTODOCLIENTBIRTHDAYRECENTSUCCESS:
      return {
        ...state,
        fetchListToDoBirthDayRecent: false,
        res: {
          ...state.res,
          listToDoBirthDayRecent: state.res && state.res.listToDoBirthDayRecent
            ? [...state.res.listToDoBirthDayRecent, ...action.res] : action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDLISTTODOCLIENTBIRTHDAYRECENTFAILED:
      return {
        ...state,
        fetchListToDoBirthDayRecent: false,
        err: action.err,
        action: action.type,
      };

    case CLEARTODOCLIENTBIRTHDAYRECENT:
      return {
        ...state,
        res: {
          ...state.res,
          listToDoBirthDayRecent: [],
        },
      };

    // Reducer Find List Client BirthDay - Today //
    case FINDLISTTODOCLIENTBIRTHDAYTODAYFETCH:
      return {
        ...state,
        fetchListToDoBirthDayToday: true,
        send: action.send,
        action: action.type,
      };

    case FINDLISTTODOCLIENTBIRTHDAYTODAYSUCCESS:
      return {
        ...state,
        fetchListToDoBirthDayToday: false,
        res: {
          ...state.res,
          listToDoBirthDayToday: state.res && state.res.listToDoBirthDayToday
            ? [...state.res.listToDoBirthDayToday, ...action.res] : action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDLISTTODOCLIENTBIRTHDAYTODAYFAILED:
      return {
        ...state,
        fetchListToDoBirthDayToday: false,
        err: action.err,
        action: action.type,
      };

    case CLEARTODOCLIENTBIRTHDAYTODAY:
      return {
        ...state,
        res: {
          ...state.res,
          listToDoBirthDayToday: [],
        },
      };

    // Reducer Find List Client BirthDay - UpComing //
    case FINDLISTTODOCLIENTBIRTHDAYUPCOMINGFETCH:
      return {
        ...state,
        fetchListToDoBirthDayUpComing: true,
        send: action.send,
        action: action.type,
      };

    case FINDLISTTODOCLIENTBIRTHDAYUPCOMINGSUCCESS:
      return {
        ...state,
        fetchListToDoBirthDayUpComing: false,
        res: {
          ...state.res,
          listToDoBirthDayUpComing: state.res && state.res.listToDoBirthDayUpComing
            ? [...state.res.listToDoBirthDayUpComing, ...action.res] : action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDLISTTODOCLIENTBIRTHDAYUPCOMINGFAILED:
      return {
        ...state,
        fetchListToDoBirthDayUpComing: false,
        err: action.err,
        action: action.type,
      };

    case CLEARTODOCLIENTBIRTHDAYUPCOMING:
      return {
        ...state,
        res: {
          ...state.res,
          listToDoBirthDayUpComing: [],
        },
      };

    // Reducer Get Latest Updated Date - Client
    case FINDLASTUPDATECLIENTFETCH:
      return {
        ...state,
        fetchLastUpdateClient: true,
        send: action.send,
        action: action.type,
      };

    case FINDLASTUPDATECLIENTSUCCESS:
      return {
        ...state,
        fetchLastUpdateClient: false,
        res: {
          ...state.res,
          lastUpdateClient: action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDLASTUPDATECLIENTFAILED:
      return {
        ...state,
        fetchLastUpdateClient: false,
        err: action.err,
        action: action.type,
      };

    // Reducer Get Latest Updated Date - Policy
    case FINDLASTUPDATEPOLICYFETCH:
      return {
        ...state,
        fetchLastUpdatePolicy: true,
        send: action.send,
        action: action.type,
      };

    case FINDLASTUPDATEPOLICYSUCCESS:
      return {
        ...state,
        fetchLastUpdatePolicy: false,
        res: {
          ...state.res,
          lastUpdatePolicy: action.res,
        },
        err: null,
        action: action.type,
      };

    case FINDLASTUPDATEPOLICYFAILED:
      return {
        ...state,
        fetchLastUpdatePolicy: false,
        err: action.err,
        action: action.type,
      };

    // Reducer Get ClientProfile Detail
    case CLIENTPROFILERESET:
      return { ...state, ...initialClientState };

    case CLIENTPROFILEFETCH:
      return {
        ...state,
        clientProfileStatus: requestStatus.FETCH,
        send: action.send,
        action: action.type,
      };

    case CLIENTPROFILESUCCESS:
      return {
        ...state,
        clientProfileStatus: requestStatus.SUCCESS,
        clientProfile: { ...state.clientProfile, ...action.res },
        err: null,
        action: action.type,
      };

    case CLIENTPROFILEFAILED:
      return {
        ...state,
        clientProfileStatus: requestStatus.FAILED,
        clientProfile: {},
        err: action.err,
        action: action.type,
      };

    case CLIENT_VIP_INFO.FETCH: return { ...state, clientVIP: requestStatus.FETCH };
    case CLIENT_VIP_INFO.SUCCESS: return {
      ...state,
      clientVIP: requestStatus.SUCCESS,
      clientProfile: !isEmpty(action.payload) ? { ...action.payload[0], ...state.clientProfile } : state.clientProfile,
    };
    case CLIENT_VIP_INFO.FAILED: return { ...state, error: action.payload, clientVIP: requestStatus.FAILED };

    case HNWI_TAGGING.FETCH: return { ...state, hnwiTaggingStatus: requestStatus.FETCH };
    case HNWI_TAGGING.SUCCESS: return { ...state, hnwiTaggingStatus: requestStatus.SUCCESS, hnwiTagging: action.payload };
    case HNWI_TAGGING.FAILED: return { ...state, error: action.payload, hnwiTaggingStatus: requestStatus.FAILED };

    // reducer for download client detail pdf
    case DOWNLOAD_CLIENT_DETAIL_PDF.FETCH: return { ...state, clientDetailDownloadStatus: requestStatus.FETCH };
    case DOWNLOAD_CLIENT_DETAIL_PDF.FAILED: return { ...state, clientDetailDownloadStatus: requestStatus.FAILED, error: action.payload };
    case DOWNLOAD_CLIENT_DETAIL_PDF.SUCCESS: return {
      ...state,
      clientDetailDownloadStatus: requestStatus.SUCCESS,
      clientDetailDownload: action.payload,
    };

    // reducer for fund transaction pdf
    case DOWNLOAD_FUND_TRANSACTION_PDF.FETCH: return { ...state, fundTransactionStatus: requestStatus.FETCH, fundTransaction: null };
    case DOWNLOAD_FUND_TRANSACTION_PDF.FAILED: return { ...state, fundTransactionStatus: requestStatus.FAILED, error: action.payload };
    case DOWNLOAD_FUND_TRANSACTION_PDF.SUCCESS: return {
      ...state,
      fundTransactionStatus: requestStatus.SUCCESS,
      fundTransaction: action.payload.result,
    };

    // Reducer Get Client Policy Owner
    case CLIENTPOLICYOWNERFETCH:
      return {
        ...state,
        fetchClientPolicyOwner: true,
        send: action.send,
        action: action.type,
      };

    case CLIENTPOLICYOWNERSUCCESS:
      return {
        ...state,
        fetchClientPolicyOwner: false,
        clientPolicyOwner: action.res,
        err: null,
        action: action.type,
      };

    case CLIENTPOLICYOWNERFAILED:
      return {
        ...state,
        fetchClientPolicyOwner: false,
        clientPolicyOwner: [],
        err: action.err,
        action: action.type,
      };

    // Reducer Get Client Policy List
    case CLIENTPOLICYLISTFETCH:
      return {
        ...state,
        fetchClientPolicyList: true,
        send: action.send,
        action: action.type,
      };

    case CLIENTPOLICYLISTSUCCESS:
      return {
        ...state,
        fetchClientPolicyList: false,
        clientPolicyList: action.res,
        err: null,
        action: action.type,
      };

    case CLIENTPOLICYLISTFAILED:
      return {
        ...state,
        fetchClientPolicyList: false,
        clientPolicyList: [],
        err: action.err,
        action: action.type,
      };

    // Reducer Get Client Policy List
    case CLIENTPROPOSALLISTFETCH:
      return {
        ...state,
        fetchClientProposalList: true,
        send: action.send,
        action: action.type,
      };

    case CLIENTPROPOSALLISTSUCCESS:
      return {
        ...state,
        fetchClientProposalList: false,
        clientProposalList: action.res,
        err: null,
        action: action.type,
      };

    case CLIENTPROPOSALLISTFAILED:
      return {
        ...state,
        fetchClientProposalList: false,
        clientProposalList: [],
        err: action.err,
        action: action.type,
      };

    // Reducer Get Sum At Risk
    case CLIENTSUMATRISKFETCH:
      return {
        ...state,
        fetchClientSumAtRisk: true,
        send: action.send,
        action: action.type,
      };

    case CLIENTSUMATRISKSUCCESS:
      return {
        ...state,
        fetchClientSumAtRisk: false,
        clientSumAtRisk: action.res,
        err: null,
        action: action.type,
      };

    case CLIENTSUMATRISKFAILED:
      return {
        ...state,
        fetchClientSumAtRisk: false,
        clientSumAtRisk: {},
        err: action.err,
        action: action.type,
      };

    case MEDICAL_LETTER_PDF.FETCH: return { ...state, medicalLetter: { ...state.medicalLetter, status: requestStatus.FETCH } };
    case MEDICAL_LETTER_PDF.SUCCESS: return { ...state, medicalLetter: { status: requestStatus.SUCCESS, data: action.payload } };
    case MEDICAL_LETTER_PDF.FAILED: return { ...state, error: action.payload, document: { ...state.medicalLetter, status: requestStatus.FAILED } };

    case HNWI_CALCULATOR.FETCH: return { ...state, withdrawalFee: { ...state.withdrawalFee, status: requestStatus.FETCH } };
    case HNWI_CALCULATOR.SUCCESS: return { ...state, withdrawalFee: { status: requestStatus.SUCCESS, data: action.payload } };
    case HNWI_CALCULATOR.FAILED: return { ...state, error: action.payload, withdrawalFee: { ...state.withdrawalFee, status: requestStatus.FAILED } };


    case TRACKERADDSTACK:
      return {
        ...state,
        trackerTodo: [...state.trackerTodo, action.props],
      };

    case DUEDATESTATECHANGE:
      return {
        ...state,
        dueDateState: action.props,
      };

    case TRACKERGOBACK:
      return {
        ...state,
        trackerTodo: state.trackerTodo.filter((x, i) => i !== state.trackerTodo.length - 1),
      };

    case DELETETRACKER:
      return {
        ...state,
        trackerTodo: [],
      };

    default:
      return state;
  }
}

const initialStateAfterDueDate = {
  fetchAfterDueDateTotal: false,
  fetchAllAfterDueDateTotal: false,
  fetchAfterDueDatePolicyList: false,
  fetchAfterDueDatePolicyDetail: false,
  fetchTotalPolicyInCancelPeriod: false,
  fetchPolicyInCancelPeriod: false,
  // before due date
  fetchBeforeDueDateTotal: false,
  fetchBeforeDueDatePolicyList: false,
  // Rincian Polis Start
  fetchPersonalDataProposalPolicy: false,
  fetchSubstandardProposalPolicyDetail: false,
  fetchProposalPolicyData: false,
  fetchPremiumDataProposalPolicy: false,
  fetchProductListDataProposalPolicy: false,
  fetchFundAllocationPolicy: false,
  fetchFundAllocationPolicyBasicSaver: false,
  fetchFundAllocationPolicyTopUpSaver: false,
  fetchFundAllocationPolicyBoosterSaver: false,
  fetchGetListDocument: false,
  fetchListClientByAgentNumber: false,
  fetchProfileClientByAgentNumber: false,
  fetchFundHoldingPolicy: false,
  fetchFundHoldingPolicyBasicSaver: false,
  fetchFundHoldingPolicyTopUpSaver: false,
  fetchFundHoldingPolicyBoosterSaver: false,
  fetchProposalPdf: false,

  fetchGetPolicyMovementHistory: false,
  // Rincian Polis End
  send: null,
  res: {
    afterDueDatePolicyList: [],
    beforeDueDatePolicyList: [],
    afterDueDateTotal: {
      totalInforce15: 0,
      totalInforce45: 0,
      totalInforce30: 0,
      totalInforce63: 0,
      totalLessThan2Years: 0,
    },
    beforeDueDateTotal: {
      totalBefore14: 0,
      totalBefore29: 0,
      totalBefore44: 0,
      totalBefore59: 0,
    },
    PolicyInCancelPeriod: [],
    totalPolicyInCancelPeriod: 0,
    productListDataProposalPolicy: [],
    listClientByAgentNumber: [],
    proposalPdf: null,
  },
  err: null,
};

export function ReducerDueDate(state = initialStateAfterDueDate, action) {
  switch (action.type) {
    case RESETPOLICYANDPROPOSALDETAILREDUCER:
    case RESET_ALL_STATE: return initialStateAfterDueDate;
    case AFTERDUEDATETOTALFETCH:
      return {
        ...state,
        fetchAfterDueDateTotal: true,
        send: action.send,
        action: action.type,
      };

    case AFTERDUEDATETOTALSUCCESS:
      return {
        ...state,
        fetchAfterDueDateTotal: false,
        res: {
          ...state.res,
          afterDueDateTotal: action.res,
        },
        err: null,
        action: action.type,
      };

    case AFTERDUEDATETOTALFAILED:
      return {
        ...state,
        fetchAfterDueDateTotal: false,
        err: action.err,
        action: action.type,
      };

    case BEFOREDUEDATETOTALFETCH:
      return {
        ...state,
        fetchBeforeDueDateTotal: true,
        send: action.send,
        action: action.type,
      };

    case BEFOREDUEDATETOTALSUCCESS:
      return {
        ...state,
        fetchBeforeDueDateTotal: action.end !== 59,
        res: {
          ...state.res,
          beforeDueDateTotal: {
            ...state.res.beforeDueDateTotal,
            [`totalBefore${action.end}`]: action.res,
          },
        },
        err: null,
        action: action.end === 59 ? action.type : '',
      };

    case BEFOREDUEDATETOTALFAILED:
      return {
        ...state,
        fetchBeforeDueDateTotal: false,
        err: action.err,
        action: action.type,
      };

    case ALLAFTERDUEDATETOTALFETCH:
      return {
        ...state,
        fetchAllAfterDueDateTotal: true,
        send: action.send,
        action: action.type,
      };

    case ALLAFTERDUEDATETOTALSUCCESS:
      return {
        ...state,
        fetchAllAfterDueDateTotal: false,
        res: {
          ...state.res,
          allAfterDueDateTotal: action.res,
        },
        err: null,
        action: action.type,
      };

    case ALLAFTERDUEDATETOTALFAILED:
      return {
        ...state,
        fetchAllAfterDueDateTotal: false,
        err: action.err,
        action: action.type,
      };

    case AFTERDUEDATEPOLICYLISTFETCH:
      return {
        ...state,
        fetchAfterDueDatePolicyList: true,
        send: action.send,
        action: action.type,
      };

    case AFTERDUEDATEPOLICYLISTSUCCESS:
      return {
        ...state,
        fetchAfterDueDatePolicyList: false,
        res: {
          ...state.res,
          afterDueDatePolicyList: [...state.res.afterDueDatePolicyList, ...action.res],
          dueDateLastUpdate: new Date(),
        },
        err: null,
        action: action.type,
      };

    case AFTERDUEDATEPOLICYLISTFAILED:
      return {
        ...state,
        fetchAfterDueDatePolicyList: false,
        err: action.err,
        action: action.type,
      };

    case DELETEDUEDATEPOLICYLISTREDUCER:
      return {
        ...state,
        fetchAfterDueDatePolicyList: false,
        res: {
          ...state.res,
          afterDueDatePolicyList: action.res,
          PolicyInCancelPeriod: action.res,
          beforeDueDatePolicyList: action.res,
        },
        err: null,
        action: action.type,
      };

    case BEFOREDUEDATEPOLICYLISTFETCH:
      return {
        ...state,
        fetchBeforeDueDatePolicyList: true,
        send: action.send,
        action: action.type,
      };

    case BEFOREDUEDATEPOLICYLISTSUCCESS:
      return {
        ...state,
        fetchBeforeDueDatePolicyList: false,
        res: {
          ...state.res,
          beforeDueDatePolicyList: [...state.res.beforeDueDatePolicyList, ...action.res],
          dueDateLastUpdate: new Date(),
        },
        err: null,
        action: action.type,
      };

    case BEFOREDUEDATEPOLICYLISTFAILED:
      return {
        ...state,
        fetchBeforeDueDatePolicyList: false,
        err: action.err,
        action: action.type,
      };

    case AFTERDUEDATEPOLICYDETAILFETCH:
      return {
        ...state,
        fetchAfterDueDatePolicyDetail: true,
        send: action.send,
        action: action.type,
      };

    case AFTERDUEDATEPOLICYDETAILSUCCESS:
      return {
        ...state,
        fetchAfterDueDatePolicyDetail: false,
        res: {
          ...state.res,
          afterDueDatePolicyDetail: { ...action.res, lastUpdate: new Date() },
        },
        err: null,
        action: action.type,
      };

    case AFTERDUEDATEPOLICYDETAILFAILED:
      return {
        ...state,
        fetchAfterDueDatePolicyDetail: false,
        err: action.err,
        action: action.type,
      };

    case DELETEDUEDATEPOLICYDETAILREDUCER:
      return {
        ...state,
        res: {
          ...state.res,
          afterDueDatePolicyDetail: action.res,
        },
      };

    case TOTALPOLICYINCANCELPERIODFETCH:
      return {
        ...state,
        fetchTotalPolicyInCancelPeriod: true,
        send: action.send,
        action: action.type,
      };

    case TOTALPOLICYINCANCELPERIODSUCCESS:
      return {
        ...state,
        fetchTotalPolicyInCancelPeriod: false,
        res: {
          ...state.res,
          totalPolicyInCancelPeriod: action.res,
        },
        err: null,
        action: action.type,
      };

    case TOTALPOLICYINCANCELPERIODFAILED:
      return {
        ...state,
        fetchTotalPolicyInCancelPeriod: false,
        err: action.err,
        action: action.type,
      };

    case POLICYINCANCELPERIODFETCH:
      return {
        ...state,
        fetchPolicyInCancelPeriod: true,
        send: action.send,
        action: action.type,
      };

    case POLICYINCANCELPERIODSUCCESS:
      return {
        ...state,
        fetchPolicyInCancelPeriod: false,
        res: {
          ...state.res,
          PolicyInCancelPeriod: action.res,
          dueDateLastUpdate: new Date(),
        },
        err: null,
        action: action.type,
      };

    case POLICYINCANCELPERIODFAILED:
      return {
        ...state,
        fetchPolicyInCancelPeriod: false,
        err: action.err,
        action: action.type,
      };

    // Rincian Polis Start
    case LISTCLIENTBYAGENTNUMBERFETCH:
      return {
        ...state,
        fetchListClientByAgentNumber: true,
        send: action.send,
        action: action.type,
      };

    case LISTCLIENTBYAGENTNUMBERSUCCESS:
      return {
        ...state,
        fetchListClientByAgentNumber: false,
        res: {
          ...state.res,
          listClientByAgentNumber: action.res,
        },
        err: null,
        action: action.type,
      };

    case LISTCLIENTBYAGENTNUMBERFAILED:
      return {
        ...state,
        fetchListClientByAgentNumber: false,
        err: action.err,
        action: action.type,
      };

    case PROFILECLIENTBYAGENTNUMBERFETCH:
      return {
        ...state,
        fetchProfileClientByAgentNumber: true,
        send: action.send,
        action: action.type,
      };

    case PROFILECLIENTBYAGENTNUMBERSUCCESS:
      return {
        ...state,
        fetchProfileClientByAgentNumber: false,
        res: {
          ...state.res,
          profileClientByAgentNumber: action.res,
        },
        err: null,
        action: action.type,
      };

    case PROFILECLIENTBYAGENTNUMBERFAILED:
      return {
        ...state,
        fetchProfileClientByAgentNumber: false,
        err: action.err,
        action: action.type,
      };

    case GETPOLICYMOVEMENTHISTORYFETCH:
      return {
        ...state,
        fetchGetPolicyMovementHistory: true,
        send: action.send,
        action: action.type,
      };

    case GETPOLICYMOVEMENTHISTORYSUCCESS:
      return {
        ...state,
        fetchGetPolicyMovementHistory: false,
        res: {
          ...state.res,
          getPolicyMovementHistory: action.res,
        },
        err: null,
        action: action.type,
      };

    case GETPOLICYMOVEMENTHISTORYFAILED:
      return {
        ...state,
        fetchGetPolicyMovementHistory: false,
        err: action.err,
        action: action.type,
      };

    default:
      return state;
  }
}
