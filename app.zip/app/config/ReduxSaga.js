/**
 * @author: dwi.setiyadi@gmail.com
*/

import { watcherAuth } from '../modules/auth/SagaAuth';
import { watcherSQSNSpaj } from '../modules/sqs-spaj/SagaSQSNSpaj';
import { watcherProduction } from '../modules/production/SagaProduction';
import { watcherNotification } from '../modules/notification/SagaNotification';
import { watcherNews } from '../modules/news-and-update/SagaNews';
import { watcherDashboard } from '../modules/dashboard/SagaDashboard';
import { watcherHome } from '../modules/home/SagaHome';
import { watcherPersistency } from '../modules/persistency/SagaPersistency';
import { watcherProposalPolicy } from '../modules/proposal-policy/SagaProposalPolicy';
import { watcherToDo } from '../modules/todo-list/SagaTodoList';
import { watcherClient } from '../modules/client/SagaClient';
import { watcherCommissionEstimation } from '../modules/commission-estimation/SagaCommission';
import { watcherIncomeStatement } from '../modules/income-statement/SagaIncomeStatement';
import { watcherFeedback } from '../modules/feedback/SagaFeedback';
import { watcherCorrespondence } from '../modules/correspondence/SagaCorrespondence';
import { watcherActivity } from '../modules/activity-management/SagaActivity';

export default [
  ...watcherAuth,
  ...watcherSQSNSpaj,
  ...watcherToDo,
  ...watcherProduction,
  ...watcherNotification,
  ...watcherNews,
  ...watcherDashboard,
  ...watcherHome,
  ...watcherPersistency,
  ...watcherProposalPolicy,
  ...watcherClient,
  ...watcherCommissionEstimation,
  ...watcherIncomeStatement,
  ...watcherFeedback,
  ...watcherCorrespondence,
  ...watcherActivity,
];
