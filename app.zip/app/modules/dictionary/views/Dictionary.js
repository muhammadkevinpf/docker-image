import React from 'react';
import { connect } from 'react-redux';
import {
  View, BackHandler, TouchableOpacity, ScrollView, Platform,
} from 'react-native';
import { Button, Card, Text } from 'native-base';
import {
  Annotation, Collapsible, ContainerNonProduct, CustomSectionList, ModalCustom, rowLayout, SearchNativeBase, Skeleton, SkeletonText, StyledText,
} from '../../../components';
import { disclaimerDictionary, GET_DICTIONARY } from '../ConfigDictionary';
import {
  apiWithTokenAction, defaultAction, isEmpty, requestStatus,
} from '../../../utilities';
import NavigationService from '../../../bootstrap/NavigationService';
import Style from '../../../styles';
import Colors from '../../../styles/Colors';
import _ from '../../../lang';
import { UPDATE_DICTIONARY_FLAG } from '../../dashboard/ConfigDashboard';
import { trackerGoBack } from '../../todo-list/ActionTodoList';

const dict = {
  INSURANCE: _('Daftar Istilah Asuransi'),
  MEDICAL: _('Daftar Istilah Medis'),
};

const isTextEmpty = text => isEmpty(text) || text === '-';

const Item = ({
  title, content, style, isLoading = false,
}) => (
  <Skeleton isLoading={isLoading} style={style} layout={[rowLayout({ h: 8, w: 70 }), rowLayout({ h: 7, w: '80%' })]}>
    <StyledText bold font={11}>{title}</StyledText>
    <StyledText font={10}>{content.replace(/(<([^>]+)>)/ig, '').trim()}</StyledText>
  </Skeleton>
);

class Dictionary extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      screen: dict.INSURANCE,
      showModal: this.props.flag,
      rerendered: true,
      isRefresh: false,
      searchKey: '',
      list: [],
    };
  }

  componentDidMount = () => {
    this.getData();
    this.setState({ showModal: this.props.flag });
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => { this.goBack(); return true; });
  }

  componentDidUpdate = (prevProps) => {
    if (prevProps.isOnline !== this.props.isOnline && this.props.isOnline) this.getData();
    if (prevProps.status !== this.props.status) {
      if (this.props.status !== requestStatus.FETCH) this.hideLoading();
      if (this.props.status === requestStatus.SUCCESS) this.setData();
    }
  }

  componentWillUnmount = () => this.backHandler.remove();

  goBack = () => {
    this.props.trackerGoBack();
    NavigationService.gotoDashboard();
  };

  getData = () => { if (this.props.isOnline) this.props.getDictionary("['']", this.props.resAuth.access_token); }

  handleRefresh = () => this.setState({ isRefresh: true }, () => this.getData());

  hideLoading = () => this.setState({ isRefresh: false })

  setData = () => {
    const { insurance = [], medical = [] } = this.props.data || {};
    this.setState((prevState) => {
      let temp = prevState.screen === dict.INSURANCE ? insurance : medical;
      if (prevState.searchKey.length > 2 && !isEmpty(temp)) {
        temp = temp.map(section => (isEmpty(section.data) ? section :
          {
            title: section.title,
            data: section.data.filter(item => (
              item.istilah.toLowerCase().includes(prevState.searchKey.toLowerCase()) ||
              item.istilahLain.toLowerCase().includes(prevState.searchKey.toLowerCase())
            )),
          }));
      }
      return { list: temp.filter(x => !isEmpty(x.data)), rerendered: true };
    });
  }

  onModalDismiss = () => this.setState({ showModal: false }, () => this.props.setFlag());

  onSearch = (key) => {
    if (key !== this.state.searchKey) {
      this.setState({ searchKey: key, rerendered: false, list: [] }, () => this.setData());
    }
  }

  onTabChange = (tabChoosen) => {
    if (tabChoosen !== this.state.screen) this.setState({ screen: tabChoosen, rerendered: false, list: [] }, () => this.setData());
  }

  renderTabs = () => {
    const { screen, searchKey } = this.state;
    const tabs = [
      { title: dict.INSURANCE },
      { title: dict.MEDICAL },
    ];
    return (
      <View style={[{ backgroundColor: Colors.redPruexpert }, Style.Main.setBorder({ on: 'Bottom', width: 1 })]}>
        <SearchNativeBase
          placeholder="Input kata minimal tiga huruf"
          onChangeText={this.onSearch}
          onInputBlur={this.onSearch}
          onClear={() => this.setState({ searchKey: '' }, () => this.setData())}
          style={[Style.Main.pl25, Style.Main.pr30, Style.Main.ml3]}
          value={searchKey}
        />
        <View style={[Style.Main.rowDirection]}>
          {tabs.map((item, i) => {
            const active = item.title === screen;
            return (
              <TouchableOpacity
                key={i.toString()}
                onPress={() => this.onTabChange(item.title)}
                style={[Style.Main.container, Style.Main.padding10, Style.Main.center,
                  Style.Main.setBorder({ on: 'Bottom', width: 3, borderColor: active ? Colors.white : Colors.redPruexpert })]}
              >
                <StyledText bold={active} font={14} color={active ? Colors.white : Colors.whiteSmoke}>{item.title}</StyledText>
              </TouchableOpacity>
            );
          })}
        </View>
      </View>
    );
  }

  renderContent = () => {
    const { list, isRefresh } = this.state;
    const { status } = this.props;
    const isLoading = isEmpty(list) && status === requestStatus.FETCH;
    const tempArray = Array(4).fill({ title: '', data: Array(3).fill({}) });
    const content = isLoading && !(isRefresh && isEmpty(list)) ? tempArray : list;
    const noContent = isEmpty(content);
    return (
      <View style={[Style.Main.container]}>
        <TouchableOpacity style={[Style.Main.pv10, Style.Main.pl30]} onPress={() => this.setState({ showModal: true })}>
          <StyledText color={Colors.blue} font={11}>
            {_('Syarat dan Ketentuan')}<StyledText italic color={Colors.blue} font={11}> Underwriting Dictionary</StyledText>
          </StyledText>
        </TouchableOpacity>
        <CustomSectionList
          style={[Style.Main.container, Style.Main.padding30, Style.Main.pt0, noContent && [Style.Main.pb0, Style.Main.overflowHide]]}
          sections={noContent ? [] : content}
          onRefresh={this.handleRefresh}
          refreshing={this.state.isRefresh}
          statusList={this.props.status}
          renderItem={({ section: { data }, item, index }) => (
            <Collapsible
              noBorder
              lineType="no-line"
              isExpanded={false}
              title={item.istilah}
              isLoading={isLoading}
              style={index + 1 < data.length ? [Style.Main.setBorder({ on: 'Bottom', borderColor: Colors.whiteSmoke })] : null}
              expandedContent={
                <>
                  <Item
                    style={!isTextEmpty(item.penyebab) || !isTextEmpty(item.penyebab) ? [Style.Main.mb10] : null}
                    title={_('Deskripsi')}
                    content={item.definisi}
                    isLoading={isLoading}
                  />
                  {!isTextEmpty(item.penyebab) && <Item style={[Style.Main.mb10]} title="Penyebab" content={item.penyebab} />}
                  {!isTextEmpty(item.komplikasi) && <Item title="Komplikasi" content={item.komplikasi} />}
                </>
            }
            />)}
          renderSectionHeader={({ section: { title, data } }) => (isEmpty(data) ? null :
          <View style={[Style.Main.container, Style.Main.rowDirection, Style.Main.center,
            Style.Main.mt10, Style.Main.backgroundWhite, Style.Main.pv5]}
          >
            <View>
              <SkeletonText isLoading={isLoading} width={20} key={title} bold font={20} style={[Style.Main.textAlignVerticalCenter]}>
                {title}
              </SkeletonText>
            </View>
            <View style={[Style.Main.horizontalLine, Style.Main.ml10, Style.Main.fullWidth]} />
          </View>
          )}
          ListEmptyText={
            <>
              <StyledText bold style={[Style.Main.textAlignCenter, Style.Main.mt15]}>{_('Kata yang anda cari tidak ditemukan.')}</StyledText>
              <StyledText font={11} style={[Style.Main.textAlignCenter, Style.Main.mt5]}>
                {_('Anda dapat mencarinya dalam Daftar Istilah Asuransi dan Daftar Istilah Medis')}
              </StyledText>
            </>
          }
        />
      </View>
    );
  }

  renderDisclaimer = () => (
    <ModalCustom
      isVisible={this.state.showModal}
      onPress={() => {}}
      content={
        <Card style={[Style.Main.mH15, Style.Main.width80pr, Style.Main.height80Percent, Style.Main.borderRadius5]}>
          <TouchableOpacity style={[Style.Main.container, Style.Main.padding12]} activeOpacity={1} onPress={() => {}}>
            <StyledText bold font={14}>{_('Syarat dan Ketentuan')}<StyledText italic font={14}> Underwriting Dictionary</StyledText></StyledText>
            <ScrollView style={[Style.Main.mV10]}>
              <Annotation rowStyle={Style.Main.mb10} list={disclaimerDictionary} />
            </ScrollView>
            <Button block style={[Style.Main.btnPrimary, Style.Main.borderRadius5]} onPress={this.onModalDismiss}><Text> {_('Setuju')}</Text></Button>
          </TouchableOpacity>
        </Card>
    }
      animationType="fade"
    />
  )

  render() {
    return (
      <ContainerNonProduct
        headerTitle="GLOSARIUM"
        navigation={this.props.navigation}
        headerColor={Colors.redPruexpert}
        onBackClicked={this.goBack}
      >
        {this.renderTabs()}
        {this.state.rerendered && this.renderContent()}
        {/*
        ios cant render modal at the first time and make screen freeze.
        we need to makesure modal didnt rendered at first time,
        we need to add more parameter to render the modal after the first render
        */}
        {/* eslint-disable-next-line max-len */}
        {Platform.OS === 'ios' ? this.state.showModal && this.props.status === requestStatus.SUCCESS && this.renderDisclaimer() : this.renderDisclaimer()}
      </ContainerNonProduct>
    );
  }
}

const mapStateToProps = state => ({
  resAuth: state.auth.res,
  isOnline: state.connectionStatus.isOnline,
  data: state.dashboard.dictionary,
  status: state.dashboard.dictionaryStatus,
  flag: state.dashboard.dictionaryTnCflag,
});

const dispatchMapToProps = dispatch => ({
  getDictionary: (params, token) => dispatch(apiWithTokenAction(GET_DICTIONARY.FETCH, params, token)),
  setFlag: () => dispatch(defaultAction(UPDATE_DICTIONARY_FLAG, false)),
  trackerGoBack: () => dispatch(trackerGoBack()),
});

export default connect(mapStateToProps, dispatchMapToProps)(Dictionary);
