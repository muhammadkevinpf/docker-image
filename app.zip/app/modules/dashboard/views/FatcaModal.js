/* eslint-disable react/no-array-index-key */
import React, { Component } from 'react';
import { Modal, TouchableOpacity } from 'react-native';
import { Text, View } from 'native-base';
import Style from '../../../styles';
import _ from '../../../lang';

class FatcaModal extends Component {
  render() {
    const statement = [
      'Memastikan Nasabah melengkapi dokumen tambahan sehubungan dengan FATCA',
      'Tidak menyarankan Nasabah untuk menghindari FATCA',
      'Tidak memberikan saran apapun mengenai pengisian FATCA kepada Nasabah',
    ];

    return (
      <Modal transparent visible={this.props.visible} onRequestClose={this.props.onClose}>
        <View
          style={[
            Style.Main.displayFlex,
            Style.Main.centerVertical,
            Style.Main.container,
            Style.Main.padding12,
            Style.Main.backgroundLightSmoke,
            Style.Main.borderRadius5]}
        >
          <View style={[Style.Main.backgroundWhiteSmoke, Style.Main.width90]}>
            <View style={[Style.Main.backgroundRed, Style.Main.padding12, Style.Main.justifyCenter]}>
              <Text style={[Style.Main.textWhite, Style.Main.textAlignCenter]}>{_('Persetujuan Fatca')}</Text>
            </View>
            <View style={[Style.Main.padding20]}>
              <Text style={[Style.Main.textAlmostBlack, Style.Main.font14]}>
                Dengan ini saya menyatakan telah memahami dan menyetujui untuk :
              </Text>
              {
                statement.map((val, i) => (
                  <View key={i} style={[Style.Main.rowDirection]}>
                    <Text style={[Style.Main.textAlmostBlack, Style.Main.font14]}>{i + 1}.&nbsp;&nbsp;</Text>
                    <Text style={[Style.Main.textAlmostBlack, Style.Main.font14]}>{val}</Text>
                  </View>
                ))
              }
            </View>
            {
              this.props.fatcaFlag && (
                <TouchableOpacity
                  style={[Style.Main.backgroundRed, Style.Main.padding12, Style.Main.justifyCenter, Style.Main.margin10]}
                  onPress={this.props.onClose}
                >
                  <Text
                    style={[Style.Main.font16, Style.Main.textWhite, Style.Main.fontAlbert, Style.Main.textAlignCenter]}
                  >{_('OK')}
                  </Text>
                </TouchableOpacity>
              )
            }
            {
              !this.props.fatcaFlag && (
                <View style={[Style.Main.rowDirection, Style.Main.fullWidth]}>
                  <TouchableOpacity
                    style={[Style.Main.backgroundGray, Style.Main.padding12, Style.Main.justifyCenter, Style.Main.halfWidth]}
                    onPress={this.props.onClose}
                  >
                    <Text
                      style={[Style.Main.font14, Style.Main.textWhite, Style.Main.fontAlbert, Style.Main.textAlignCenter]}
                    >{_('TIDAK SETUJU')}
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[Style.Main.backgroundRed, Style.Main.padding12, Style.Main.justifyCenter, Style.Main.halfWidth]}
                    onPress={this.props.onAgree}
                  >
                    <Text
                      style={[Style.Main.font14, Style.Main.textWhite, Style.Main.fontAlbert, Style.Main.textAlignCenter]}
                    >{_('SETUJU')}
                    </Text>
                  </TouchableOpacity>
                </View>
              )
            }
          </View>
        </View>
      </Modal>
    );
  }
}

export default FatcaModal;
