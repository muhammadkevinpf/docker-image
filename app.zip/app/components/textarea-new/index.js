import React, { Component } from 'react';
import { Textarea, View } from 'native-base';
import Style from '../../styles';

export class TextArea extends Component {
  onChangeValidation = (input) => {
    if (this.props.setValueToParent) {
      this.props.setValueToParent(this.props.index, input);
    }
  }

  render() {
    console.log(`ini value textarea ${this.props.value}`);
    return (
      <View>
        <Textarea
          rowSpan={5}
          bordered
          style={[Style.Main.fontAlbert, Style.Main.font14, Style.Color.almostBlack]}
          placeholder={this.props.placeholder}
          onChangeText={e => this.onChangeValidation(e)}
          value={this.props.value}
          maxLength={1000}
        />
      </View>
    );
  }
}

export default TextArea;
