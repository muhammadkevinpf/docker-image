/* eslint-disable react/no-array-index-key */
import React, { Component } from 'react';
import moment from 'moment';
import { connect } from 'react-redux';
import { Text, Card, View } from 'native-base';
import {
  VictoryChart, VictoryAxis, VictoryLabel, VictoryArea,
} from 'victory-native';
import { AgentScopes } from '../../../config/Constants';
import {
  isTablet, isEmpty, wp, toStringTwoDigit,
} from '../../../utilities';
import {
  rowLayout, Skeleton, SkeletonText, StyledText,
} from '../../../components';
import Colors from '../../../styles/Colors';
import Style from '../../../styles';
import _ from '../../../lang';

class PersistencyHistoryComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      current: [{ x: '', y: 0 }],
      history: [{ x: '', y: 0 }],
      value: this.props.data ? this.props.data.Individu || [] : [],
    };
  }

  componentDidMount = () => {
    this.renderData();
  }

  componentDidUpdate = (prevProps) => {
    if (prevProps.data !== this.props.data) this.renderData();
  }

  renderData = () => {
    let value; let label;
    if (this.props.agentScope) {
      if (this.props.agentScope === AgentScopes.individu) {
        value = this.props.data.Individu; label = 'Individu';
      } else if (this.props.agentScope.includes(AgentScopes.unit)) {
        value = this.props.data.Unit; label = 'Unit';
      }
      // else if (this.props.agentScope.includes(AgentScopes.group)) { value = this.props.data.Group; label = 'GROUP'; }
    }
    let current = [{ x: '', y: 0 }];
    let history = [{ x: '', y: 0 }];
    const month = new Date().getMonth() + 1;
    const year = new Date().getFullYear();
    if (value && value.length) {
      current = [];
      history = [];
      value.map((item) => {
        current.push({
          x: moment(item.period, 'MM-YYYY').format('MMM YYYY'),
          y: item.totalPrsctyApiCurrent === -1 ? 0 : item.totalPrsctyApiCurrent || 0,
        });
        history.push({
          x: moment(item.period, 'MM-YYYY').format('MMM YYYY'),
          y: item.totalPrsctyApiRolling === -1 ? 0 : item.totalPrsctyApiRolling || 0,
        });
        return null;
      });
    } else {
      Array(6).fill({}).map((item, i) => {
        const data = { x: moment(`${toStringTwoDigit(month - i)}-${month - i < 1 ? year - 1 : year}`, 'MM-YYYY').format('MMM YYYY'), y: 0 };
        current.push(data);
        history.push(data);
        return null;
      });
    }
    this.setState({
      current, value, history, label,
    });
  }

  renderLegend = (text, backgroundColor) => (
    <View style={[Style.Main.container, Style.Main.rowDirectionJustifyCenter, Style.Main.center]}>
      <View style={[Style.Main.setSize({
        w: 7, h: 7, backgroundColor, opacity: 0.5,
      })]}
      />
      <StyledText font={9} style={Style.Main.ml5}>{_(text)}</StyledText>
    </View>
  )

  renderGraph = () => {
    const { current = [], history = [] } = this.state;
    const height = isTablet() ? wp(180) : wp(130);
    let width = isTablet() ? wp(520) : wp(300);
    if (isTablet()) width -= this.props.sideBarWidth / 2;
    const blue = '#1B6FED';
    return (
      <>
        <Card style={[Style.Main.container, Style.Main.center, Style.Main.mb5, Style.Main.backgroundWhiteSmoke,
          isTablet() && Style.Main.mr12]}
        >
          <VictoryChart
            width={width}
            padding={{
              top: 15, bottom: 25, left: 20, right: 20,
            }}
            minDomain={{ y: 0 }}
            maxDomain={{ y: 100 }}
            height={height}
          >
            <VictoryAxis
              dependentAxis
              style={{
                axis: { stroke: Colors.nativeBaseBorderGray },
                tickLabels: { ...Style.Main.setFontAlbert(8), fill: Colors.gray83, padding: 3 },
              }}
              tickFormat={t => `${t}%`}
              label={_('Dalam Persentase')}
              axisLabelComponent={<VictoryLabel angle={270} />}
            />
            <VictoryAxis
              style={{
                axis: { stroke: Colors.nativeBaseBorderGray },
                tickLabels: { ...Style.Main.setFontAlbert(8), fill: Colors.gray83, padding: 3 },
              }}
            />
            <VictoryArea
              style={{ data: { fill: blue, fillOpacity: 0.5, stroke: 'none' } }}
              data={history}
              interpolation="monotoneX"
            />
            <VictoryArea
              style={{ data: { fill: Colors.red, fillOpacity: 0.5, stroke: 'none' } }}
              data={current}
              interpolation="monotoneX"
            />
          </VictoryChart>
          <View style={[Style.Main.rowDirectionJustifyCenter, Style.Main.mb10]}>
            {this.renderLegend('Persistensi Lama', Colors.red)}
            {this.renderLegend('Rolling Persistensi', blue)}
          </View>
        </Card>
        <SkeletonText isLoading={this.props.isLoading} width="75%" font={10} color={Colors.gray83}>
          {_('Data ditampilkan 6 bulan lalu dari hari ini')}
        </SkeletonText>
      </>
    );
  }

  render() {
    const {
      value = [], current = [], history = [], label,
    } = this.state;
    const { data, isLoading = false } = this.props;
    const isAvailable = value.length > 1 && current.length > 1 && history.length > 1;
    return (
      <Card style={[Style.Main.padding12, Style.Main.container]}>
        <View style={[Style.Main.container, Style.Main.rowDirection, Style.Main.mb10]}>
          <StyledText bold>{_('RIWAYAT')}</StyledText>
          <View style={[Style.Main.horizontalLine, Style.Main.ml10, Style.Main.fullWidth]} />
        </View>
        <View style={[Style.Main.container]}>
          <StyledText>{_(label)}</StyledText>
          <SkeletonText isLoading={this.props.isLoading} width="70%" font={10} color={Colors.gray83}>
            {!isEmpty(data) && !isEmpty(data.date) ? `${_('Data diperbaharui pada')} ${moment(data.date).format('LLLL')}`
              : _('Data belum diperbarui')}
          </SkeletonText>
          <View style={[Style.Main.horizontalLine, Style.Main.fullWidth, Style.Main.mV10]} />
          {
            isAvailable &&
            <>
              {this.renderGraph()}
              <View style={[Style.Main.fullWidth, Style.Main.rowDirection, Style.Main.mt20]}>
                <StyledText bold style={[Style.Main.mb10, Style.Main.textCenter]}>{_('Persistensi Lama')}</StyledText>
                <StyledText bold style={[Style.Main.mb10, Style.Main.textCenter]}>{_('Rolling Persistensi')}</StyledText>
              </View>
              {
                value.map((item, index) => (
                  <View key={index} style={[Style.Main.rowDirection, Style.Main.pv10]}>
                    <Skeleton
                      isLoading={isLoading}
                      layout={[rowLayout({ w: 100, h: 8, alignSelf: 'center' }), rowLayout({ w: 50, h: 15, alignSelf: 'center' })]}
                    >
                      <View style={[Style.Main.container, Style.Main.centerVertical]}>
                        <Text style={[Style.Main.fontAlbert11]}>{moment(item.period, 'MM-YYYY').format('MMMM YYYY')}</Text>
                        <StyledText bold font={18}>{item.totalPrsctyApiCurrent === -1 ? 0 : item.totalPrsctyApiCurrent}%</StyledText>
                      </View>
                    </Skeleton>
                    <Skeleton
                      isLoading={isLoading}
                      layout={[rowLayout({ w: 100, h: 8, alignSelf: 'center' }), rowLayout({ w: 50, h: 15, alignSelf: 'center' })]}
                    >
                      <View style={[Style.Main.container, Style.Main.centerVertical]}>
                        <Text style={[Style.Main.fontAlbert11]}>{moment(item.period, 'MM-YYYY').format('MMMM YYYY')}</Text>
                        <StyledText bold font={18}>{item.totalPrsctyApiRolling === -1 ? 0 : item.totalPrsctyApiRolling}%</StyledText>
                      </View>
                    </Skeleton>
                  </View>
                ))
              }
            </>
          }
          <StyledText bold color={Colors.red} style={[Style.Main.pt18, Style.Main.pl25, Style.Main.timeStyle]} onPress={this.props.onPress}>
            {_('Lihat Rincian')}
          </StyledText>
        </View>
      </Card>
    );
  }
}

const mapStateToProps = state => ({
  sideBarWidth: state.bootstrap.sideBarWidth,
});

const PersistencyHistory = connect(mapStateToProps, null)(PersistencyHistoryComponent);

export {
  PersistencyHistory,
};
