/* eslint-disable max-len */
import moment from 'moment';
import lodash from 'lodash';
import _ from '../../../lang';
import CustomerStorageService from '../services/CustomerStorageService';
import Caches from '../../../utilities/Caches';

const magnumProductCode = ['U10', 'U11', 'T1P', 'T1Q', 'T1R', 'T1S'];
const productCodePAA = ['U10', 'U11'];
const productCodeROP = ['T1P', 'T1Q', 'T1R', 'T1S', 'E2E', 'L2H', 'L2I', 'L2O', 'T2U', 'R2A', 'H2I', 'T2P', 'T2O'];
const expireCoverageCode = ['U1ZR', 'U1SR', 'U1ZR-HEBAT', 'U1SR-HEBAT'];
const expireProductCode = ['U1Z', 'U1S', 'U1Z-HEBAT', 'U1S-HEBAT'];
const getIdIlustration = (agentCode) => {
  const id = `${new Date().getTime()}${Math.floor((lodash.random(0, 1, true) * 99) + 1)}${agentCode}`;
  return { quotationCode: `Q${id}`, proposalCode: `P${id}`, quickQuoteCode: `QQ${id}` };
};
const getQ = agentCode => `Q${new Date().getTime()}${Math.floor((lodash.random(0, 1, true) * 99) + 1)}${agentCode}`;
const getP = agentCode => `P${new Date().getTime()}${Math.floor((lodash.random(0, 1, true) * 99) + 1)}${agentCode}`;
const getQQ = agentCode => `QQ${new Date().getTime()}${Math.floor((lodash.random(0, 1, true) * 99) + 1)}${agentCode}`;
const genCustomerIdPH = agentCode => `PH${new Date().getTime()}${Math.floor((lodash.random(0, 1, true) * 99) + 1)}${agentCode}`;
const genCustomerIdLA = agentCode => `LA${new Date().getTime()}${Math.floor((lodash.random(0, 1, true) * 99) + 1)}${agentCode}`;
const masterStatus = {
  Ilustration: 'SQS Illustration',
  spajPendingSubmit: 'SPAJ Pending Submit',
  spajPendingSubmitCekatan: 'SPAJ Pending UW - Virtual Tatap Muka',
  spajPendingUWCekatan: 'SPAJ Pending UW - Cekatan Submitted',
  spajPendingUW: 'SPAJ Pending UW',
  spajPendingUWReq: 'SPAJ Pending UW Requirement',
  spajPendingPayment: 'SPAJ Pending Payment',
  spajPendingPaymentAppr: 'SPAJ Payment Approved',
  Others: 'Others',
  // submitted: 'Dalam Proses Submit',
  submitted: 'SPAJ Gagal Submit',
  failedSubmit: 'Gagal Submit',
  counterOfferDraft: 'Dokumen Susulan Draft',
  counterOfferSubmitted: 'Dokumen Susulan Submitted',
  DalamProsesUnderwriting: 'Dalam Proses Underwriting',
  Inforce: 'Inforce',
  DalamProsesInforce: 'Dalam Proses Inforce',
  DalamProsesVerifikasi: 'Dalam Proses Verifikasi (Note:NB)',
  spajPendingProses: 'SPAJ Pending Process',
  'Finish Issued': 'Finish Issued',
  // New From DB, Need Confirmation
  'Not Applicable (Not Pending UW Requirement nor Pending Process)': 'Not Applicable (Not Pending UW Requirement nor Pending Process)',
  TBC: 'TBC',
  'Not Applicable': 'Not Applicable',
  'Not Applicable (Paralel Process)': 'Not Applicable (Paralel Process)',
  'Not Applicable (Completed but not Issued)': 'Not Applicable (Completed but not Issued)',
};
const defaultSortOpt = [
  {
    value: 0,
    label: 'DEFAULT SORT',
  }, {
    value: 1,
    label: 'A-Z',
  }, {
    value: 2,
    label: 'Z-A',
  }, {
    value: 3,
    label: 'Creation Date (Earliest)',
  }, {
    value: 4,
    label: 'Creation Date (Most Recent)',
  },
];
const defaultFilterOpt = [
  {
    value: '',
    label: 'DEFAULT FILTER',
  }, {
    value: 'Ilustration',
    label: 'SQS ILLUSTRATION',
  }, {
    value: 'spajPendingSubmit',
    label: 'SPAJ PENDING SUBMIT (AGENT)',
  }, {
    value: 'spajPendingUW',
    label: 'SPAJ PENDING PROCESS (UW)',
  }, {
    value: 'counterOfferDraft',
    label: 'DOKUMEN SUSULAN DRAFT',
  }, {
    value: 'counterOfferSubmitted',
    label: 'DOKUMEN SUSULAN SUBMITTED',
  }, {
    value: 'submitted',
    label: 'DALAM PROSES SUBMIT',
  }, {
    value: 'failedSubmit',
    label: 'GAGAL SUBMIT',
  },
];

const getInitialData = (agentCode) => {
  const id = getIdIlustration(agentCode);
  return {
    sqs: {
      flagDraft: true,
      doc: {
        type: '',
        id: '',
        spaj: '',
        ri: '',
      },
      ver: '',
      quotationCd: id.quotationCode,
      proposalCd: id.proposalCode,
      updatedDate: '',
      lastState: '',
      selectedQuickQuote: '',
      agentCode,
      quickQuote: [
        {
          quickQuoteCd: id.quickQuoteCode,
          isMainQuotation: true,
          billFreq: '',
          tipe: '',
          clientType: '',
          productCode: '',
          productCodeHPX: '',
          productCategory: '',
          currCd: 'IDR',
          yearlyPremium: '',
          firstPremium: '',
          premium: '',
          premAge: '',
          coverage: [],
          fundRp: [],
          mainCoverage: {
            main: '',
            topup: '',
            GIO: '',
          },
          recommendation: {
            product: [],

          },
          substandard: [],
          isAgreeSubstandard: false,
          substandardNotAgree: {},
          fund: [],
          backDate: '',
          flagBackDate: 'N',
          budget: '',
          budgetTerm: '',
          isSigned: false,
          isPHeqLA: undefined,
          goal: [],
          topup: [],
          withdrawal: [],
          client: {
            ph: {},
            lifeAss: [],
          },
          goalChecksum: '',
          custChecksum: '',
          coverageChecksum: '',
          fundChecksum: '',
          budgetChecksum: '',
        },
      ],
      existingPolicyProtection: [],
      otherPolicy: '',
      investment: [],
      rp: {
        docId: '',
        ver: '',
        quest: [],
        totalScore: '',
        result: '',
      },
      sign: {
        ph: {
          id: '',
          date: '',
          location: '',
          byte: '',
        },
        agent: {
          id: '',
          date: '',
          location: '',
          byte: '',
        },
      },
      disclaimer: [],
      ojkRiplay: [],
      type: 'SQS',
      isOutputStorageExist: false,
    },
    quotationDate: (`${moment(new Date(), 'YYYY-MM-DDTHH:mm:ss.SSS').format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`),
    isCounterOffer: false,
    status: 'Ilustration',
    prop_no: '',
  };
};

const getNewQuickQuote = agentCode => ({
  quickQuoteCd: getQQ(agentCode),
  isMainQuotation: false,
  billFreq: '',
  tipe: '',
  flagBackDate: 'N',
  productCode: '',
  productCodeHPX: '',
  productCategory: '',
  currCd: 'IDR',
  yearlyPremium: '',
  firstPremium: '',
  premium: '',
  premAge: '',
  coverage: [],
  fundRp: [],
  mainCoverage: {
    main: '',
    topup: '',
    GIO: '',
  },
  recommendation: {
    product: [],

  },
  substandard: [],
  isAgreeSubstandard: false,
  substandardNotAgree: {},
  fund: [],
  backDate: '',
  budget: '',
  budgetTerm: '',
  isSigned: false,
  isPHeqLA: undefined,
  goal: [],
  topup: [],
  withdrawal: [],
  client: {
    ph: {},
    lifeAss: [],
  },
  goalChecksum: '',
  custChecksum: '',
  coverageChecksum: '',
  fundChecksum: '',
  budgetChecksum: '',
});

const getCustomerData = (agentCode, isPh) => ({
  Dob: '',
  mobile: '',
  customerId: isPh ? genCustomerIdPH(agentCode) : genCustomerIdLA(agentCode),
  MaritalStatus: '',
  pekerjaanCode: '',
  codeTelp: '',
  age: '',
  anb: '',
  custAge: '',
  custAgeDay: '',
  custAgeMonth: '',
  name: '',
  sex: '',
  smokeStatus: '',
  clazz: '',
  Departement: '',
  Position: '',
  isExisting: '',
  Business: '',
});

const capitalizeProdName = (productName) => {
  let str = '';
  let res = '';
  if (productName.includes('VERSA')) {
    str = productName.split('VERSA');
    if (str[1]) {
      res = `VERSA${str[1].split(' ').map(word => word.substr(0, 1).toUpperCase() + word.substr(1, word.length)).join(' ')}`;
    }
  } else if (productName.includes('PRU')) {
    str = productName.split('PRU');
    if (str[1]) {
      res = `PRU${str[1].split(' ').map(word => word.substr(0, 1).toUpperCase() + word.substr(1, word.length)).join(' ')}`;
    }
  } else if (productName.includes('FLEXI')) {
    str = productName.split('FLEXI');
    if (str[1]) {
      res = `FLEXI${str[1].split(' ').map(word => word.substr(0, 1).toUpperCase() + word.substr(1, word.length)).join(' ')}`;
    }
  } else if (productName.includes('BUILDER')) {
    str = productName.split('BUILDER');
    if (str[1]) {
      res = `BUILDER${str[1].split(' ').map(word => word.substr(0, 1).toUpperCase() + word.substr(1, word.length)).join(' ')}`;
    }
  }
  return res;
};

const ROP = {
  Syariah: ['T1S', 'T1R', 'T2U'],
  Conventional: ['T1P', 'T1Q', 'E2E', 'L2H', 'L2I', 'L2O', 'R2A', 'T2P', 'T2O'],
};

const ROPFreq = {
  SB: ['T1P', 'T1R', 'L2H', 'L2I', 'L2O'],
  PB: ['T1S', 'T1Q'],
  PT: ['T1S', 'T1Q', 'E2E'],
};

const premAgeLabelROP = {
  Syariah: _('Masa Pembayaran Kontribusi'),
  Konvensional: _('Masa Pembayaran Premi'),
};

const UPLabelROP = {
  Syariah: _('Santunan Asuransi'),
  Konvensional: _('Uang Pertanggungan'),
};

const masaPertanggunganLabelROP = {
  Syariah: _('Masa Kepesertaan'),
  Konvensional: _('Masa Pertanggungan'),
};

const ROPPremiLabel = (tipe, billfreq) => {
  let label = '';
  if (tipe === 'Syariah') {
    label = `${_('Total Kontribusi')} ${billfreq}`;
  } else {
    label = _('Total Premi');
  }
  return label;
};

const masterGoals = {
  SCB: {
    UL: {
      min_IDR_PB: 2084000,
      min_IDR_PT: 25000000,
      min_IDR_SB: 12000000,
      max_IDR: 999999999999,
      min_USD_PB: 417,
      min_USD_PT: 5000,
      min_USD_SB: 1500,
      max_USD: 999999999999,
    },
    TRD: {
      min_IDR_PB: 1,
      min_IDR_PT: 24000000,
      min_IDR_SB: 1,
      max_IDR: 999999999999,
      min_USD_PB: 1,
      min_USD_PT: 1,
      min_USD_SB: 75000,
      max_USD: 999999999999,
    },
  },
  UOB: {
    UL: {
      min_IDR_PB: 400000,
      min_IDR_PT: 4800000,
      min_IDR_SB: 12000000,
      max_IDR: 999999999999,
      min_USD_PB: 84,
      min_USD_PT: 1000,
      min_USD_SB: 1500,
      max_USD: 999999999999,
    },
    TRD: {
      min_IDR_PB: 1,
      min_IDR_PT: 24000000,
      min_IDR_SB: 1,
      max_IDR: 999999999999,
      min_USD_PB: 1,
      min_USD_PT: 1,
      min_USD_SB: 1,
      max_USD: 999999999999,
    },
  },
  BUOI: {
    UL: {
      min_IDR_PB: 1,
      min_IDR_PT: 1,
      min_IDR_SB: 1,
      max_IDR: 999999999999,
      min_USD_PB: 1,
      min_USD_PT: 1,
      min_USD_SB: 1,
      max_USD: 999999999999,
    },
    TRD: {
      min_IDR_PT: 3600000,
      min_IDR_PB: 1,
      min_IDR_SB: 1,
      max_IDR: 999999999999,
      min_USD_PT: 1,
      min_USD_PB: 1,
      min_USD_SB: 150000,
      max_USD: 999999999999,
    },
  },
};

const categories = [{ label: 'Unit Link', value: 'UL' }, { label: 'Tradisional', value: 'TRD' }];
const types = [{ label: 'Konvensional', value: 'Konvensional' }, { label: 'Syariah', value: 'Syariah' }];
const terms = [{ label: 'Sekali Bayar', value: 'SB' }, { label: 'Per Bulan', value: 'PB' }, { label: 'Per Tahun', value: 'PT' }];
const currencies = [{ label: 'IDR', value: 'IDR' }, { label: 'USD', value: 'USD' }];
const gender = [{ label: 'Pria', value: 'M' }, { label: 'Wanita', value: 'F' }];
const maritals = [{ label: 'Menikah', value: 'M' }, { label: 'Belum Menikah', value: 'S' }, { label: 'Janda/Duda', value: 'W' }];
const sumberPenghasilanList = [{
  label: 'Laba Perusahaan',
  value: 'Laba Perusahaan',
  isSelected: false,
  isTextInput: true,
  textType: 'default',
  input: '',
}, {
  label: 'Investasi',
  value: 'Investasi',
  isSelected: false,
  isTextInput: true,
  textType: 'default',
  input: '',
}, {
  label: 'Lainnya',
  value: 'Lainnya',
  isSelected: false,
  isTextInput: true,
  textType: 'default',
  input: '',
}];

const bentukBadanUsahaList = [{
  label: 'PT',
  value: 'PT',
}, {
  label: 'Yayasan',
  value: 'Yayasan',
}, {
  label: 'Koperasi',
  value: 'Koperasi',
}, {
  label: 'CV',
  value: 'CV',
}, {
  label: 'Firma',
  value: 'Firma',
}];

const civilServant = [
  'CSRO', 'CSER', 'CSEO',
  'CSET', 'CSEH', 'JUDG',
  'CROK', 'LEGI', 'DSOC',
  'CMSO', 'MISO', 'POSO',
  'GOVE', 'GOVT', 'CSEF',
  'DEAN', 'GVRN', 'HOMI',
  'HSCM', 'ICOS', 'ITAX',
  'MAYR', 'MBPK', 'MGBI',
  'MOJK', 'MDPP', 'MOKY',
  'DPRD', 'DPRI', 'MIGR',
  'POGR', 'PRCT', 'RCTR',
  'RGNT', 'TRGO', 'VGVR',
  'VMYR', 'VMST', 'VRGN',
];

const traditionalType = ['Penyakit Kritis', 'Perlindungan Jiwa', 'Dana Pensiun', 'Dana Warisan', 'Investasi', 'Dana Pendidikan', 'Key Person', 'Kecelakaan'];
const investorType = ['Penyakit Kritis', 'Investasi', 'Perlindungan Jiwa', 'Dana Pensiun', 'Dana Pendidikan', 'Dana Warisan', 'Key Person'];

const errKelipatan = {
  topup: {
    IDR: _('Jumlah topup harus kelipatan 1000'),
  },
  withdrawal: {
    IDR: _('Jumlah withdrawal harus kelipatan 1000'),
  },
};

const errMessageMin = {
  topup: {
    IDR: _('Minimal topup adalah IDR 1.000.000'),
    USD: _('Minimum top up is US$ 250'),
  },
  withdrawal: {
    IDR: _('Minimal withdrawal adalah IDR 500.000'),
    USD: _('Minimum withdrawal is US$ 100'),
  },
};

// const minValue = {
//   Topup: {
//     IDR: 1200000,
//     USD: 250,
//   },
//   Withdrawal: {
//     IDR: 1000000,
//     USD: 100,
//   },
// };

// const valueKelipatan = {
//   Topup: {
//     IDR: 5000,
//     USD: 1,
//   },
//   Withdrawal: {
//     IDR: 5000,
//     USD: 1,
//   },
// };

const substandartConfig = {
  MainLife: {
    index: 0,
    role: '01',
    desc: _('Tertanggung Utama'),
  },
  AdditionalLife1: {
    index: 1,
    role: '02',
    desc: _('Tertanggung Tambahan 1'),
  },
  AdditionalLife2: {
    index: 2,
    role: '03',
    desc: _('Tertanggung Tambahan 2'),
  },
};
const formHealthcare = ['H1Y1', 'H1Y3', 'H1Y5', 'H1X1', 'H1X3', 'H1X5', 'H1Z1', 'H1Z5'];
const formHospital = ['H1TR', 'H1UR', 'H1QR', 'H1RR', 'C12R', 'C13R', 'H2TR'];
const formPayor = [
  'W3C1', 'W3AD', 'W3AR', 'W107', 'W1MD', 'W1MR', 'W1XD', 'W1XR', 'W111', 'W1QR', 'W1QD', 'W109',
  'S1SR', 'S1FR', 'S1FD', 'S1PR', 'S1YD', 'S1Z1', 'W3BR', 'W3BD', 'W3SR', 'S1KR', 'S1KD',
  'W1WR', 'S1YR', 'W1WD',
];
const formPayorCanBeDisabled = ['S1FR', 'S1FD', 'S1PR', 'S1SR', 'S1KR', 'S1KD', 'S1YD', 'S1Z1', 'S1YR'];
const formPayorCannotBeDisabled = ['W107', 'W109', 'W3SR'];
const formPayorTriggerToDisabledPPP = ['W111', 'W1XD', 'W1XR'];
const formPayorTriggerToDisabledPESPP = ['W3AD', 'W3AR', 'W3C1'];
const formPayorTriggerToDisabledWaiver33 = ['W1WR', 'W1WD', 'W1MD', 'W1MR'];
const formPayorTriggerToDisabledPayor33 = ['W1QR', 'W1QD'];
const formPayorTriggerToDisabledPESPayor = ['W3BR', 'W3BD'];
const payorAndWaiverForm = ['W3BR', 'W1WR', 'W1QR', 'W1MD', 'W1MR', 'W3BD', 'W1WD', 'W1QD'];
const parentPayorForm = ['W3AD', 'W3AR', 'W3C1', 'W1XD', 'W1XR', 'W111', 'H2IR'];

const formCover = [
  'T1JR', 'T1JD', 'T1KR', 'C106', 'C107', 'C108', 'C1WD', 'C1WR', 'C11R', 'P1RR', 'P1RD',
  'P1TR', 'P1DD', 'P1DR', 'P1IR', 'C104', 'C103', 'C102', 'H1VR', 'H1WR', 'D1DR', 'D1ER',
  'H2BR', 'P1G1', 'C1L1', 'P1QR', 'C1L2', 'P1G2', 'P1QD', 'I1DR', 'P2CR', 'P2DR', 'C1LR',
  'C1KR', 'C1TR', 'C1LD', 'C1KD', 'C1TD', 'P2CD', 'P2DD',
];
const pruSaverCode = ['U1C3', 'U1CD', 'U1FR', 'U1IR', 'U1I1', 'U2C3', 'U2C4', 'U2C5', 'U2C6', 'U2CR', 'U2CD'];
const mainCoverageCode = {
  U10R: {
    disabled: false,
  },
  U10D: {
    disabled: false,
  },
  U11R: {
    disabled: false,
  },
  U2LR: {
    disabled: true,
  },
  U2LD: {
    disabled: true,
  },
  U2V1: {
    disabled: false,
  },
  U2V2: {
    disabled: false,
  },
  U4D1: {
    disabled: false,
  },
  U4D2: {
    disabled: false,
  },
  U4DR: {
    disabled: false,
  },
  U4K1: {
    disabled: true,
  },
  U4K2: {
    disabled: true,
  },
  U2NR: {
    disabled: true,
  },
  U2ND: {
    disabled: true,
  },
  U2T1: {
    disabled: false,
  },
  U2T2: {
    disabled: false,
  },
  U2Z3: {
    disabled: true,
  },
  U2Z4: {
    disabled: true,
  },
  U2KR: {
    disabled: false,
  },
  U2KD: {
    disabled: false,
  },
  U201: {
    disabled: false,
  },
  U202: {
    disabled: false,
  },
  L2OD: {
    disabled: false,
  },
  T2UR: {
    disabled: false,
  },
  R2AR: {
    disabled: false,
  },
  U251: {
    disabled: false,
  },
  U252: {
    disabled: false,
  },
  T2PR: {
    disabled: false,
  },
  T2OR: {
    disabled: false,
  },
};
const pruBoosterProduct = ['U10', 'U11'];
const backDateProudct = ['U10', 'U11', 'U4D', 'U2L', 'U4K', 'U2N', 'U2Z', 'U2K'];
const productWithoutRider = ['U4K', 'U2L', 'U2N'];

const PPHcode = ['H1Z1', 'H1Z5'];

const excAssBeneficiariesProduct = ['U2L', 'U4K', 'U2N', 'L2I', 'E2E', 'U2Z'];

const InputTypeLabelGenerator = {
  PLANOPTION4: {
    'A+#A': 'A',
    'B+#B': 'B',
    'C+#C': 'C',
    'D+#D': 'D',
    'E+#E': 'E',
    'F+#F': 'F',
    'G+#G': 'G',
    'H+#H': 'H',
  },
  PHCP: {
    A: 'Bronze A - Indonesia - 2 bed',
    B: 'Bronze B - Indonesia - 1 bed',
    C: 'Silver A - Asia (excl JPN, HK, SG) - 2 bed',
    D: 'Silver B - Asia (excl JPN, HK, SG) - 1 bed',
    E: 'Gold A - Asia - 2 bed',
    F: 'Gold B - Asia - 1 bed',
    G: 'Platinum - Worldwide (excl USA) - 1 bed',
    H: 'Diamond - Worldwide - 1 bed',
  },
};

const goalList = {
  Kesehatan: 'Proteksi Kesehatan',
  Kecelakaan: 'Perlindungan Kecelakaan',
  'Penyakit Kritis': 'Proteksi terhadap Penyakit Kritis & Cacat',
  Investasi: 'Dana Investasi/ Tabungan/ Deposito',
  'Perlindungan Jiwa': 'Proteksi Jiwa',
  'Dana Pensiun': 'Dana Pensiun',
  'Dana Pendidikan': 'Proteksi Dana Pendidikan',
  'Dana Warisan': 'Proteksi Dana Warisan',
  'Key Person': 'Key Person',
};

const premAgeLabel = {
  1: 'Sekali Bayar',
  5: '5 Tahun',
  10: '10 Tahun',
  15: '15 Tahun',
};

const nameProductROP = {
  T1P: 'PRUcritical benefit 88',
  T1Q: 'PRUcritical benefit 88',
  T1S: 'PRUsyariah critical benefit 88',
  T1R: 'PRUsyariah critical benefit 88',
  E2E: 'USave PRUStar',
  L2H: 'PRUlife Priority Legacy',
  L2I: 'PRUIncome Premier Protector',
  L2O: 'PRULife Heritage',
  T2U: 'PRUCinta',
  R2A: 'PRULife Harvest Plan',
};

const mapPlanPPH2 = {
  A: 'Bronze A - Indonesia - 2 Bed',
  B: 'Bronze B - Indonesia - 1 Bed',
  C: 'Silver A - Asia (excl JPN, HK, SG) - 2 Bed',
  D: 'Silver B - Asia (excl JPN, HK, SG) - 1 Bed',
  E: 'Gold A - Asia - 2 Bed',
  F: 'Gold B - Asia - 1 Bed',
  G: 'Platinum - Worldwide (excl USA) - 1 Bed',
  H: 'Diamond - Worldwide - 1 Bed',
};

const guid = () => {
  const s4 = () => Math.floor((1 + lodash.random(0, 1, true)) * 0x10000).toString(16).substring(1);
  return `${s4() + s4()}-${s4()}-${s4()}-${s4()}-${s4() + s4() + s4()}`;
};

const proposalHeaderObject = () => ({
  spajStatus: '',
  productCd: '',
  currency: '',
  originStatus: '',
  premium: 0,
  draftId: '',
  reason: '',
  flagActive: '',
  productCategory: '',
  updatedDate: '',
  ver: 0,
  quotId: '',
  createdDate: '',
  sumAssured: 0,
  type: '',
  statusDraft: '',
  agenId: '',
  originCreatedDate: '',
  sha1Data: '',
  phName: '',
  createdBy: '',
  tuName: '',
  flagDraft: '',
  updatedBy: '',
  isSync: true,
  isFromApi: false,
  counterOfferState: '',
});

const routing = {
  'sqs-tertanggung-utama-tanya': 'MainInsuredSQSNSpaj',
  'sqs-tujuan-keuangan': 'InvestmentGoalsSQSNSpaj',
  'sqs-pemegang-polis': 'CustomerDataSQSNSpaj',
  'sqs-product-recomendation': 'BenefitsSQSNSpaj',
  'sqs-calculate-product': 'CalculationSQSNSpaj',
  'sqs-quick-quote': 'QuickQuoteSQSNSpaj',
  'sqs-quick-two-quote': 'QuickQuoteSQSNSpaj',
  'sqs-quick-three-quote': 'QuickQuoteSQSNSpaj',
  'sqs-calon-tertanggung-utama-pembayaran': 'ExistingPolicySQSNSpaj',
  'sqs-profile-investasi-dan-resiko': 'QuestionnaireSQSNSpaj',
  'sqs-output': 'IllustrationSQSNSpaj',
  'sqs-ilustrasi-sign': 'SignatureSQSNSpaj',
  'spaj-pertanyaan-awal': 'IntroSpaj',
  'spaj-pemegang-polis': 'CustomerDataSpaj',
  'spaj-magnum-lifestyle': 'SpajMagnumMedicalData',
  'spaj-magnum-build-habit': 'SpajMagnumMedicalData',
  'spaj-magnum-family-history': 'SpajMagnumMedicalData',
  'spaj-magnum-medical-1': 'SpajMagnumMedicalData',
  'spaj-data-payor': 'PayorDataSpaj',
  'spaj-qna-top-up': 'SpajTopup',
  'spaj-top-up-payor': 'SpajTopupDetail',
  'spaj-beneficiary': 'ProspectiveBeneficiaries',
  'spaj-payor-upload': 'SpajDocument',
  'spaj-tnc-amendemen': 'SpajAmandemen',
  'spaj-ska': 'SuratKeterikatanAsuransi',
  'spaj-tnc-keterangan-penting': 'SpajEula',
  'spaj-pernyataan-sqs': 'SignatureSqs',
  'spaj-pernyataan-spaj': 'SignatureSpaj',
  'spaj-payment': 'SpajPembayaran',
  'spaj-payment-confirm': 'PaymentConfirmation',
  'spaj-reminder': 'SubmitSpaj',
  ReselectFundSQSNSpaj: 'QuickQuoteSQSNSpaj', // needed bcs reselectFund page no longer available on new flow
};

const oldDate = '2011-01-01T00:00:00Z';

const convertRoutingAngularToReact = routingAngular => routing[routingAngular] || routingAngular;

const filterDoubleRule = data => data.filter((item, index) => data.indexOf(item) === index);

const currencyFormat = (num, labelCurrency, dontParse) => (
  // eslint-disable-next-line max-len
  labelCurrency ? `${labelCurrency} ${num ? num.toFixed(labelCurrency === 'IDR' || labelCurrency === 'Rp.' ? 0 : 2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,') : '0'}` :
    `${num ? num.toFixed(dontParse ? 0 : 2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,') : '0'}`);

const availableIllustration = {
  AG: [
    'U10',
  ],
  BUOI: [
    'E2E',
    'L2O',
    'H2I',
    'T2P',
    'T2O',
  ],
  SCB: [
    'U2L',
    'U2V',
    'U4D',
    'U4K',
    'L2H',
    'L2I',
    'R2A',
    'T2U',
  ],
  UOB: [
    'U2T',
    'U2Z',
    'U2N',
    'U2L',
    'U2K',
    'T2U',
    'U25', // BAAMAX Corp
    'R2A',
  ],
  OCBCN: [
    'U20',
  ],
};

const benefitForAdditionalPage = [
  { coverageCode: 'W3AR', amountOfTab: 2, type: 'customer' },
  { coverageCode: 'W3AD', amountOfTab: 2, type: 'customer' },
  { coverageCode: 'S1YR', amountOfTab: 1, type: 'customer' },
  { coverageCode: 'S1YD', amountOfTab: 1, type: 'customer' },
  { coverageCode: 'S1FR', amountOfTab: 1, type: 'customer' },
  { coverageCode: 'S1FD', amountOfTab: 1, type: 'customer' },
  { coverageCode: 'W1XR', amountOfTab: 2, type: 'customer' },
  { coverageCode: 'W1XD', amountOfTab: 2, type: 'customer' },
  { coverageCode: 'S1KR', amountOfTab: 1, type: 'customer' },
  { coverageCode: 'S1KD', amountOfTab: 1, type: 'customer' },
  { coverageCode: 'H2BR', amountOfTab: 1, type: 'salary' },
  { coverageCode: 'H1VR', amountOfTab: 1, type: 'salary' },
  { coverageCode: 'W3C1', amountOfTab: 2, type: 'customer' },
  { coverageCode: 'S1Z1', amountOfTab: 1, type: 'customer' },
  { coverageCode: 'S1PR', amountOfTab: 1, type: 'customer' },
  { coverageCode: 'W111', amountOfTab: 2, type: 'customer' },
  { coverageCode: 'S1SR', amountOfTab: 1, type: 'customer' },
  { coverageCode: 'H1WR', amountOfTab: 1, type: 'salary' },
  { coverageCode: 'H2IR', amountOfTab: 1, type: 'salary' },
  { coverageCode: 'H2IR', amountOfTab: 2, type: 'customer' },
];

const productWithTopUpAllocation = ['U10', 'U11'];
const availableSpaj = ['U10', 'E2E', 'U2L', 'U2V', 'U2T', 'U2Z', 'U2N', 'U4K', 'U2K', 'U4D'];
const productWithChart = ['U10', 'U2L', 'U2V', 'U4D', 'U4K', 'U2T', 'U2Z', 'U2N', 'U2K', 'U20', 'U25'];
const prodWithFundEqTopUp = ['U2L', 'U2V', 'U4D', 'U4K', 'U2T', 'U2Z', 'U2N', 'U2K', 'U20'];
const bancaProduct = ['U2V', 'U2T', 'U25', 'U22', 'U4D', 'U20', 'U24', 'U2K'];

const checkProductType = (productCode) => {
  if (productCodePAA.includes(productCode)) {
    return 'PAA';
  }
  if (productCodeROP.includes(productCode)) {
    return 'ROP';
  }
  return 'PAA';
};

const SIOCoverage = (productCode) => {
  let sioCoverage = [];
  switch (productCode) {
    case 'U2V':
      sioCoverage = ['W1QR', 'C1L1', 'W1WR', 'T1JR', 'W1XR', 'P1G1'];
      break;
    default:
      break;
  }
  return sioCoverage;
};

const withoutCoverage = ['E2E', 'U2L'];
const coverageWithUnit = ['H2BR'];

const checkApplicationType = async (quickQuote, agentCode) => {
  try {
    if (withoutCoverage.includes(quickQuote.productCode)) {
      return 'FULLUW';
    }

    const coverageCode = quickQuote.coverage.map(x => x.coverageCd);
    const isSioCoverage = coverageCode.every(x => SIOCoverage(quickQuote.productCode).includes(x));
    if (!isSioCoverage) return 'FULLUW';

    if (quickQuote.substandard.length > 0) {
      const isSubstandard = quickQuote.substandard.some(x => x.Data_sub.length > 0);
      if (isSubstandard) return 'FULLUW';
    }

    const ccb = quickQuote.coverage.find(x => x.coverageCd === 'C1L1');
    // console.log(ccb);
    const valCcb = ccb ? ccb.custList[0][`value${ccb.custList[0].itemInput[0]}`] : 0;
    // console.log(valCcb);
    if (valCcb > (300 * (10 ** 6))) return 'FULLUW';

    const linkTerm = quickQuote.coverage.find(x => x.coverageCd === 'T1JR');
    console.log(linkTerm);
    const valLinkTerm = linkTerm ? linkTerm.custList[0][`value${linkTerm.custList[0].itemInput[0]}`] : 0;
    console.log(valLinkTerm);
    const totalSA = parseInt(quickQuote.premium, 0) + parseInt(valCcb, 0) + parseInt(valLinkTerm, 0);
    console.log(totalSA);
    if (totalSA > (1.5 * (10 ** 9))) return 'FULLUW';

    const customerIdMap = [];
    quickQuote.client.lifeAss.forEach((x) => {
      customerIdMap[x.role] = x.customerId;
    });
    console.log(`customerIdMap: ${customerIdMap}`);
    const customers = await CustomerStorageService.getCustomerStorageByCustomerMap(global.database.pruSmart, { agentCode, customerIdMap });
    // const mainLife = await CustomerStorageService.getByCode(
    //   global.database.pruSmart, { agentCode, customerId: quickQuote.client.lifeAss[0].customerId },
    // );
    // if (mainLife.anb > 60) return 'FULLUW';
    console.log(`customers: ${customers}`);
    // eslint-disable-next-line consistent-return
    const isCustomerFullUw = customers.some((x) => {
      console.log(`${x.name}:  ${x.anb}`);
      if (x.anb > 60) {
        console.log('Masuk kondisi ini');
        return true;
      }
      return false;
    });
    if (isCustomerFullUw) return 'FULLUW';
    return 'SIO';
  } catch (error) {
    console.log(error);
    throw error;
  }
};

const investorProductUL = ['U2L', 'U4K', 'U1L', 'U1M', 'U2Z', 'U2N'];

const roundingAfterPoint = (number = 0, digitAfterPoint = 2) => Math.round((number * (10 ** digitAfterPoint))) / (10 ** digitAfterPoint);

const sqsProductROP = ['T1P', 'T1Q', 'T1R', 'T1S', 'E2E']; // 'L2H' Need Confirmation because product Traditional and also SinglePremi
const sqsProductSinglePremi = ['U1L', 'U1M', 'T1P', 'T1R', 'U2L', 'U4K', 'U1L', 'U1M', 'U2Z', 'U2N', 'L2H', 'L2I', 'L2O'];
const tidakBekerja = ['STDN', 'NSTN', 'HSWF', 'UNEM', 'RETI'];
const withoutSubstndard = ['E2E', 'L2I', 'R2A', 'H2I'];

const formatDate = (input) => {
  const parts = input.split(input.includes('/') ? '/' : '-');
  const dob = new Date(parts[2], parts[1] - 1, parts[0]);
  return new Date(dob.getFullYear(), dob.getMonth(), dob.getDate());
};

const calculateAnb = (birthDate) => {
  const today = new Date();
  let year;
  const yearTmp = today.getFullYear() - birthDate.getFullYear();
  const monthDOB = today.getMonth() - birthDate.getMonth();
  const dayDOB = today.getDate() - birthDate.getDate();
  if (monthDOB < 0) {
    year = yearTmp - 1;
  } else if (monthDOB >= 0) {
    year = yearTmp;
    if (monthDOB === 0 && dayDOB < 0) {
      year = yearTmp - 1;
    }
  }
  if (today.getMonth() === birthDate.getMonth() && today.getDate() === birthDate.getDate()) {
    year -= 1;
  }
  const anb = year + 1;
  return anb;
};

const checkingAnb = (sqsItem, agentCode, indexQQ) => new Promise(async (resolve) => {
  const quickQuote = indexQQ !== undefined ? sqsItem.sqs.quickQuote[indexQQ] : sqsItem.sqs.quickQuote.find(x => x.isMainQuotation);
  const customerIdMap = {};
  customerIdMap.PH = quickQuote.client.ph.customerId;
  quickQuote.client.lifeAss.forEach((x) => {
    customerIdMap[x.role] = x.customerId;
  });
  const customers = await CustomerStorageService.getCustomerStorageByCustomerMap(global.database.pruSmart, { agentCode, customerIdMap });
  if (!customers.length) {
    resolve(false);
    return;
  }
  customers.forEach((x, i) => {
    if (x.Dob) {
      const formatedDob = formatDate(x.Dob);
      const newAnb = calculateAnb(formatedDob);
      if (x.anb !== newAnb) { resolve(true); }
      if (i === (customers.length - 1)) { resolve(false); }
    }
    resolve(false);
  });
});

const callSetSqsDoc = (sqsParam, qq, agentChannel) => {
  let sqsRes;
  try {
    sqsRes = sqsParam;
    const resChannel = Caches.get('channel').CHANNEL;
    const quickQuote = sqsRes.sqs.quickQuote[qq];
    const prodCat = quickQuote.productCategory ? quickQuote.productCategory : 'UL';
    const { productCode, currCd } = quickQuote;
    let isSubstandard = false;
    let isGIO = false;
    let productList = [];
    if (quickQuote.substandard.length > 0) {
      let flag = 0;
      for (let i = 0; i < quickQuote.substandard.length; i += 1) {
        if (quickQuote.substandard[i].Data_sub.length > 0) {
          flag += 1;
        }
      }

      if (flag > 0) {
        isSubstandard = true;
      } else {
        // Check Kententuan Only
        const dataKetentuan = quickQuote.substandard[0].ketentuan;
        if (dataKetentuan !== '' && dataKetentuan !== undefined) {
          isSubstandard = true;
        }
      }
    }

    if (quickQuote.mainCoverage.GIO !== '') {
      isGIO = true;
    } else {
      isGIO = false;
    }

    for (let i = 0; i < resChannel[agentChannel].PRODUCT_CATEGORY.length; i += 1) {
      if (resChannel[agentChannel].PRODUCT_CATEGORY[i].code === prodCat) {
        productList = resChannel[agentChannel].PRODUCT_CATEGORY[i].PRODUCT;
      }
    }

    for (let i = 0; i < productList.length; i += 1) {
      if (productList[i].code === productCode) {
        const productCurrencyList = productList[i].CURRENCY;
        for (let x = 0; x < productCurrencyList.length; x += 1) {
          if (productCurrencyList[x].code === currCd) {
            sqsRes.sqs.doc.spaj = productCurrencyList[x].docIdSpaj;
            sqsRes.sqs.doc.ri = productCurrencyList[x].docIdRi;
            if (isSubstandard) {
              sqsRes.sqs.doc.id = productCurrencyList[x].docIdSubstandard;
            } else if (isGIO) {
              sqsRes.sqs.doc.spaj = productCurrencyList[x].docIdSpajSio;
              sqsRes.sqs.doc.id = productCurrencyList[x].docIdStandardGIO;
            } else {
              sqsRes.sqs.doc.id = productCurrencyList[x].docIdStandard;
            }
            break;
          }
        }
        break;
      }
    }
  } catch (e) {
    console.log('error at callSetSqsDoc with error: ', e);
  }

  return sqsRes;
};


const generateFieldErrorLabel = (customer, tipe) => {
  const mandatoryField = ['name', 'countryCode', 'maritalStatus', 'birthDate', 'gender', 'isSmoker', 'occupation'];
  const mandatoryFieldCorporate = ['name', 'bidangUsaha'];
  const array = tipe === 'Corporate' ? mandatoryFieldCorporate : mandatoryField;
  const errorFieldName = {
    birthDate: 'Tanggal Lahir',
    maritalStatus: 'Status Pernikahan',
    isSmoker: 'Status Merokok',
    name: tipe === 'Corporate' ? 'Nama Badan Usaha' : 'Nama Lengkap',
    gender: 'Jenis Kelamin',
    occupation: 'Pekerjaan',
    countryCode: 'Kode Negara',
    bidangUsaha: 'Bidang Usaha',
  };
  let tmpFiled = [];
  let errorField = '';
  array.map((x) => {
    if (x === 'occupation') {
      if (!customer[x].code) {
        tmpFiled = [...tmpFiled, errorFieldName[x]];
      }
      if (civilServant.includes(customer[x].code) && customer.department === '') {
        tmpFiled = [...tmpFiled, 'Departmen'];
      }
      if (civilServant.includes(customer[x].code) && !customer.position.code) {
        tmpFiled = [...tmpFiled, 'Jabatan/Pangkat/Golongan'];
      }
    } else if (x === 'countryCode') {
      if (!customer[x].countryCd) {
        tmpFiled = [...tmpFiled, errorFieldName[x]];
      }
    } else if (!customer[x]) {
      tmpFiled = [...tmpFiled, errorFieldName[x]];
    }
    return tmpFiled;
  });
  tmpFiled.forEach((x, i) => {
    if (i === 0) {
      errorField = x;
    } else if (i < tmpFiled.length - 1) {
      errorField = `${errorField}, ${x}`;
    } else {
      errorField = `${errorField}, dan ${x}`;
    }
  });
  return errorField;
};

const questionnaire = [
  {
    questionTitle: 'Sejauh mana pengetahuan Anda terkait investasi?',
    questionCode: 'Q001',
    questionAnswer: [
      {
        label: 'Tidak memiliki pengetahuan dalam hal investasi, kecuali tabungan atau deposito berjangka.',
        value: 0,
      },
      {
        label: 'Memiliki pengetahuan yang cukup dalam hal investasi, seperti reksa dana, obligasi, pendapatan tetap.',
        value: 1,
      },
      {
        label: 'Memiliki pengetahuan sangat baik dalam hal investasi, seperti ekuitas, forex (foreign exchange) / valuta asing (valas).',
        value: 2,
      },
    ],
    answer: '',
    error: false,
  },
  {
    questionTitle: 'Apa tujuan investasi Anda?',
    questionCode: 'Q002',
    questionAnswer: [
      {
        label: 'Lebih fokus untuk menghasilkan pengembalian investasi yang stabil, dibandingkan pada pertumbuhan investasi (potensi tingkat pengembalian yang lebih rendah dan tingkat volatilitas lebih rendah).',
        value: 0,
      },
      {
        label: 'Bersedia menerima dampak yang sedang dari volatilitas pasar dan mengharapkan sejumlah pertumbuhan investasi (potensi tingkat pengembalian sedang dan tingkat volatilitas sedang).',
        value: 1,
      },
      {
        label: 'Fokus pada pertumbuhan investasi, kurang tertarik untuk menghasilkan pengembalian investasi yang stabil dan bersedia menerima dampak volatilitas pasar (potensi tingkat pengembalian dan tingkat volatilitas yang tinggi).',
        value: 2,
      },
    ],
    answer: '',
    error: false,
  },
  {
    questionTitle: 'Sejauh mana toleransi risiko Anda dalam menerima penurunan nilai investasi Anda?',
    questionCode: 'Q003',
    questionAnswer: [
      {
        label: 'Bersedia menerima tingkat pengembalian yang lebih rendah dengan potensi kerugian lebih rendah dari nilai investasi awal.',
        value: 0,
      },
      {
        label: 'Bersedia menerima potensi tingkat pengembalian sedang dan siap menerima potensi kerugian sedang dari nilai investasi awal.',
        value: 1,
      },
      {
        label: 'Ingin memiliki tingkat pengembalian yang lebih tinggi dan bersedia menerima potensi kerugian tinggi (atau bahkan kerugian total) dari nilai investasi awal.',
        value: 2,
      },
    ],
    answer: '',
    error: false,
  },
  {
    questionTitle: 'Sejauh mana pengalaman Anda berinvestasi?\nDalam 3 tahun terakhir, apa mayoritas (>60%) proporsi investasi Anda?',
    questionCode: 'Q004',
    questionAnswer: [
      {
        label: 'Tabungan, deposito berjangka', value: 0,
      },
      {
        label: 'Reksadana, obligasi, pendapatan tetap', value: 1,
      },
      {
        label: 'Ekuitas, foreign exchange (forex) / valas (valuta asing)', value: 2,
      },
    ],
    answer: '',
    error: false,
  },
  {
    questionTitle: 'Berapa lama jangka waktu investasi Anda?\nInvestasi saya ditujukan untuk membiayai kebutuhan saya dalam:',
    questionCode: 'Q005',
    questionAnswer: [
      {
        label: '≤ 5 tahun', value: 0,
      },
      {
        label: '5 < x ≤ 10 tahun', value: 1,
      },
      {
        label: '> 10 tahun', value: 2,
      },
    ],
    answer: '',
    error: false,
  },
];

const statementSign = {
  Individu: {
    firstStatement: 'SAYA sebagai calon pemegang polis menyatakan bahwa memahami mengenai hal-hal tersebut dibawah ini:',
    pointStatementUL: [
      'SAYA mengerti mengenai produk yang SAYA pilih dan menyetujui apabila SAYA mengajukan Surat Pengajuan Asuransi Jiwa (SPAJ) dan pengajuan tersebut disetujui oleh PT Prudential Life Assurance untuk selanjutnya diterbitkan menjadi Polis.',
      'SAYA telah membaca dan memahami hasil analisa dan rekomendasi dan Analisa \'Mengerti Kebutuhan Anda\' ini serta memastikan bahwa semua jawaban atas pertanyaan yang disampaikan adalah jujur benar dan lengkap.',
      'SAYA menyatakan bahwa produk asuransi dan / atau pilihan investasi yang sudah SAYA pilih sepenuhnya merupakan keputusan SAYA sendiri secara mandiri dan segala risiko yang timbul menjadi tanggung jawab SAYA, termasuk apabila SAYA memilih jenis produk dan / atau pilihan investasi yang tidak sesuai dengan hasil analisa rekomendasi dari Analisa \'Mengerti Kebutuhan Anda\' ini.',
    ],
    pointStatementTRD: [
      'SAYA mengerti mengenai produk yang SAYA pilih dan menyetujui apabila SAYA mengajukan Surat Pengajuan Asuransi Jiwa (SPAJ) dan pengajuan tersebut disetujui oleh PT Prudential Life Assurance untuk selanjutnya diterbitkan menjadi Polis.',
      'SAYA telah membaca dan memahami hasil analisa dan rekomendasi dan Analisa \'Mengerti Kebutuhan Anda\' ini serta memastikan bahwa semua jawaban atas pertanyaan yang disampaikan adalah jujur benar dan lengkap.',
      'SAYA menyatakan bahwa produk asuransi yang sudah SAYA pilih sepenuhnya merupakan keputusan SAYA sendiri secara mandiri dan segala risiko yang timbul menjadi tanggung jawab SAYA, termasuk apabila SAYA memilih jenis produk yang tidak sesuai dengan hasil analisa rekomendasi dari Analisa \'Mengerti Kebutuhan Anda\' ini.',
    ],
  },
  Corporate: {
    firstStatement: 'SAYA, dalam kedudukan sebagai Pihak Berwenang dari/yang ditunjuk oleh Calon Pemegang Polis (PT/Yayasan/Koperasi/CV/Firma), bertindak untuk dan atas nama Calon Pemegang Polis menyatakan bahwa mengerti mengenai hal-hal tersebut di bawah ini:',
    pointStatementUL: [
      'Menyetujui apabila SAYA mengajukan Surat Pengajuan Asuransi Jiwa (SPAJ) dan pengajuan tersebut disetujui oleh Prudential Indonesia untuk selanjutnya diterbitkan menjadi Polis, maka jawaban atas pertanyaan “Mengerti Kebutuhan Anda” akan menjadi dasar penerbitan Polis SAYA.',
      'SAYA telah membaca dan memahami hasil Profil Risiko ini serta memastikan bahwa semua jawaban atas pertanyaan yang disampaikan adalah jujur, benar dan lengkap. Segala keputusan investasi yang SAYA lakukan dan segala risiko yang timbul adalah menjadi tanggung jawab SAYA.',
      'SAYA menyadari jika pilihan produk yang akan SAYA beli dapat sama atau berbeda dari hasil pilihan produk dan alokasi dana investasi pada Profil Risiko SAYA.',
    ],
    pointStatementTRD: [
      'Menyetujui apabila SAYA mengajukan Surat Pengajuan Asuransi Jiwa (SPAJ) dan pengajuan tersebut disetujui oleh Prudential Indonesia untuk selanjutnya diterbitkan menjadi Polis, maka jawaban atas pertanyaan “Mengerti Kebutuhan Anda” akan menjadi dasar penerbitan Polis SAYA.',
      'SAYA telah membaca dan memahami hasil Profil Risiko ini serta memastikan bahwa semua jawaban atas pertanyaan yang disampaikan adalah jujur, benar dan lengkap. Segala keputusan investasi yang SAYA lakukan dan segala risiko yang timbul adalah menjadi tanggung jawab SAYA.',
      'SAYA menyadari jika pilihan produk yang akan SAYA beli dapat sama atau berbeda dari hasil pilihan produk dan alokasi dana investasi pada Profil Risiko SAYA.',
    ],
  },
};

const disclaimerSignSqs = (category) => {
  const disclaimer = [
    {
      disclaimerCd: 'DC-001',
      // eslint-disable-next-line max-len
      disclaimerDescription: `SAYA mengikuti rekomendasi ${category === 'UL' ? 'secara penuh sesuatu' : ''} yang dinyatakan pada bagian 'Rekomendasi ${category === 'UL' ? 'Pilihan Produk dan Asuransi Tambahan' : 'Pilihan Produk'}'`,
      disclaimerValue: false,
    },
    {
      disclaimerCd: 'DC-002',
      // eslint-disable-next-line max-len
      disclaimerDescription: `SAYA tidak mengikuti rekomendasi yang dinyatakan pada bagian "Rekomendasi ${category === 'UL' ? 'Produk & Asuransi" Tambahan' : 'Pilihan Produk"'} serta membeli produk asuransi ${category === 'UL' ? 'dan pilihan dana investasi' : ''} sesuai dengan keinginan SAYA sendiri`,
      disclaimerValue: false,
    },
  ];
  return disclaimer;
};

const phSignLabel = {
  Individu: 'Tanda Tangan Pemegang Polis\nSesuai Kartu Identitas yang dilampirkan',
  Corporate: 'Tanda Tangan Pihak berwenang dari/yang ditunjuk\noleh Calon Pemegang Polis',
};

const riskProfileSummary = {
  Moderat: 'SAYA bersedia untuk mempertahankan dan mengembangkan nilai investasi untuk jangka menengah sampai panjang dan SAYA bersedia menerima risiko jika SAYA mengalami kerugian',
  Konservatif: 'SAYA bersedia untuk menerima potensi imbal hasil investasi yang rendah. Dalam kondisi pasar yang kurang baik, SAYA mementingkan untuk menjaga aset dan kas yang dimiliki',
  Agresif: 'SAYA bersedia mengambil risiko jangka panjang untuk memperoleh pertumbuhan nilai investasi yang lebih tinggi serta siap menerima kerugian sebagian atau seluruh aset dan kas SAYA',
};

const RiskProfileStatement = {
  firstStatement: 'Saya memahami pilihan Produk dan Asuransi Tambahan yang saya pilih dapat sesuai atau tidak sesuai dengan rekomendasi Tenaga Pemasar. Saya bersedia untuk menerima segala konsekuensinya.',
  secondStatement: 'Terdapat ketidaksesuaian antara pilihan dana investasi dan profil risiko. Saya memahami pilihan dana investasi yang saya pilih memiliki risiko yang lebih tinggi dari profil risiko saya dan bersedia untuk menerima segala konsekuensinya.',
};

const checkFundRiskProfile = (sqsData, dataQQ) => {
  let isBiggerFund = false;
  dataQQ.fund.forEach((x) => {
    if (x.type !== sqsData.sqs.rp.result.toLowerCase()) {
      if (sqsData.sqs.rp.result.toLowerCase() === 'konservatif') {
        if (x.type === 'moderat' || x.type === 'agresif') {
          isBiggerFund = true;
        }
      } else if (sqsData.sqs.rp.result.toLowerCase() === 'moderat') {
        if (x.type === 'agresif') {
          isBiggerFund = true;
        }
      }
    }
  });
  return isBiggerFund;
};

// SIO: Gak boleh ada substandard
// UP Basic manfaat + linkterm + crisis
// Nilai CI dari PRUBenefit34 tidak boleh lebih dari 350jt

const dateCampaign = {
  SCB: {
    T2U: {
      end: new Date(2021, 11, 31, 23, 59, 59),
    }, // PRUCinta 31 DESEMBER 2021
    R2A: {
      end: new Date(2021, 3, 30, 23, 59, 59),
    }, // PLHP 30 APRIL 2021
    U4K: {
      start: new Date(2021, 6, 19, 23, 59, 59),
      end: new Date(2021, 9, 31, 23, 59, 59),
    },

  },
  UOB: {
    T2U: {
      end: new Date(2021, 11, 31, 23, 59, 59),
    }, // PRUCinta 31 DESEMBER 2021
    R2A: {
      end: new Date(2021, 8, 30, 23, 59, 59),
    }, // PLHP 30 SEPTEMBER 2021
    U2Z: {
      start: new Date(2021, 6, 19, 23, 59, 59),
      end: new Date(2021, 9, 31, 23, 59, 59),
    },
  },
  BUOI: {
    H2I: {
      end: new Date(2021, 8, 30, 23, 59, 59),
    }, // HCP 31 JULI 2021
  },
};

const isCampaignShown = (productCd, channel) => {
  const date = productCd && dateCampaign[channel][productCd];
  console.log('campaign end date: ', date.end);
  if (new Date() <= dateCampaign[channel][productCd].end) { return dateCampaign[channel][productCd]; }
  return false;
};

const newFlowStartDate = {
  UAT: (`${moment(new Date(2021, 2, 8, 23, 59, 59), 'YYYY-MM-DDTHH:mm:ss.SSS').format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`),
  PROD: (`${moment(new Date(2021, 3, 1, 23, 59, 59), 'YYYY-MM-DDTHH:mm:ss.SSS').format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`),
};

export default {
  magnumProductCode,
  productCodeROP,
  expireCoverageCode,
  expireProductCode,
  withoutSubstndard,
  getQQ,
  getQ,
  getP,
  genCustomerIdPH,
  genCustomerIdLA,
  capitalizeProdName,
  masterStatus,
  defaultFilterOpt,
  defaultSortOpt,
  getInitialData,
  getNewQuickQuote,
  getCustomerData,
  ROP,
  ROPFreq,
  // salary,
  categories,
  terms,
  types,
  currencies,
  gender,
  maritals,
  civilServant,
  traditionalType,
  investorType,
  errKelipatan,
  errMessageMin,
  // minValue,
  // valueKelipatan,
  substandartConfig,
  formCover,
  formHealthcare,
  formHospital,
  formPayor,
  formPayorCanBeDisabled,
  formPayorCannotBeDisabled,
  formPayorTriggerToDisabledPPP,
  formPayorTriggerToDisabledPESPP,
  formPayorTriggerToDisabledWaiver33,
  formPayorTriggerToDisabledPayor33,
  formPayorTriggerToDisabledPESPayor,
  payorAndWaiverForm,
  parentPayorForm,
  pruSaverCode,
  mainCoverageCode,
  pruBoosterProduct,
  productWithoutRider,
  backDateProudct,
  PPHcode,
  goalList,
  premAgeLabel,
  nameProductROP,
  mapPlanPPH2,
  guid,
  currencyFormat,
  proposalHeaderObject,
  convertRoutingAngularToReact,
  oldDate,
  availableIllustration,
  productCodePAA,
  checkProductType,
  productWithChart,
  getIdIlustration,
  benefitForAdditionalPage,
  availableSpaj,
  prodWithFundEqTopUp,
  productWithTopUpAllocation,
  masterGoals,
  InputTypeLabelGenerator,
  checkApplicationType,
  filterDoubleRule,
  coverageWithUnit,
  bancaProduct,
  investorProductUL,
  excAssBeneficiariesProduct,
  roundingAfterPoint,
  sqsProductROP,
  sqsProductSinglePremi,
  checkingAnb, // checking anb when continue sqs spaj and choose qq on page 6
  callSetSqsDoc, // init docId on sqs
  generateFieldErrorLabel, // generate error field string for customer form
  premAgeLabelROP,
  ROPPremiLabel,
  UPLabelROP,
  masaPertanggunganLabelROP,
  sumberPenghasilanList,
  bentukBadanUsahaList,
  questionnaire,
  statementSign,
  phSignLabel,
  formatDate,
  calculateAnb,
  routing,
  riskProfileSummary,
  tidakBekerja,
  RiskProfileStatement,
  checkFundRiskProfile,
  isCampaignShown,
  disclaimerSignSqs,
  newFlowStartDate,
};
