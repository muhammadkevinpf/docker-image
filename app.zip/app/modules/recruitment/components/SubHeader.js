import React, { PureComponent } from 'react';
import { View, Text } from 'react-native';
import Styles from '../../../styles';
import StylesRecruitment from '../StyleRecruitment';

class SubHeader extends PureComponent {
  render() {
    return (
      <View style={StylesRecruitment.subHeader}>
        <Text style={[Styles.Main.textRed, Styles.Main.textStrong]}>
          {this.props.text}
        </Text>
      </View>
    );
  }
}

export default SubHeader;
