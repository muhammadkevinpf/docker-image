export const activityAction = (action, value) => ({ type: action, payload: value });
