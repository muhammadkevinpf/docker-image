import { ApiRequestStatus } from '../services/RestClientService';
import { UPDATE_SPAJ_SUBMISSION } from '../actions/types';

const initialState = {
  data: null,
  error: null,
  status: ApiRequestStatus.IDLE,
};

export function submissionReducer(state = initialState, action) {
  if (action.type === UPDATE_SPAJ_SUBMISSION) {
    const newState = { ...initialState, status: action.status };
    switch (action.status) {
      case ApiRequestStatus.SUCCEEDED:
        return { ...newState, data: action.payload };
      case ApiRequestStatus.FAILED:
        return { ...newState, error: action.payload };
      case ApiRequestStatus.LOADING:
      default: return newState;
    }
  }
  return state;
}
