/**
 * @author
 * ahmdichsanb@gmail.com
 */

import { StyleSheet } from 'react-native';
import Styles from '../../styles';

const Style = StyleSheet.create({
  wrapper: {
    width: '100%',
  },
  containerDefault: {
    height: 24,
    width: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: Styles.Color.red,
    alignItems: 'center',
    justifyContent: 'center',
  },
  innerStyleDefault: {
    height: 12,
    width: 12,
    borderRadius: 6,
    backgroundColor: Styles.Color.red,
  },
  colLabelStyle: {
    textAlign: 'left',
    padding: 5,
  },
});

export default Style;
