import MainProposalPolicy from './main-proposal-policy';
import { ProposalPolicyList, ProposalPolicyListByUnit } from './proposal-policy-list';

export default {
  MainProposalPolicy,
  ProposalPolicyList,
  ProposalPolicyListByUnit,
};
