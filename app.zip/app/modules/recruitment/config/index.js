import ConfigAOB from './ConfigAOB';

export {
  ConfigAOB,
};
