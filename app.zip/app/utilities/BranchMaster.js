import { resourceRequest } from './StoreApi';
import { GETBRANCHMASTERAPI } from '../modules/auth/ConfigAuth';
import SQLiteUtils from './SQLiteUtils';
import Database from '../config/Database';
import { saveLog, CONSTANT } from './Logger';
import Caches from './Caches';

export const getBranchMasterFromAPI = (channel, token) => {
  const parameter = {
    params: `["${channel}"]`,
    headers: [
      {
        keyHeader: 'X-CSRF-Token',
        valueHeader: `Bearer ${token}`,
      },
    ],
  };
  resourceRequest(GETBRANCHMASTERAPI, 'post', parameter)
    .then((res) => {
      console.log(res.data);
      if (res.data.responseCode === '200' && res.data.data.length) {
        SQLiteUtils.executeTransaction(
          global.database.pruSmart,
          `DELETE FROM ${Database.pruSmart.tables.branch.name}`,
          [],
        ).then((resDelete) => {
          console.log(resDelete);
          saveLog(CONSTANT.INFO, `DELETE Branch ${resDelete}`);
          const dataToStore = res.data.data.map(x => `("${x.officeCode}","${x.officeName}")`);
          SQLiteUtils.executeTransaction(
            global.database.pruSmart,
            `INSERT INTO ${Database.pruSmart.tables.branch.name} VALUES ${dataToStore.join(',')}`,
            [],
          ).then((resInsert) => {
            console.log(resInsert);
            saveLog(CONSTANT.INFO, `Insert Branch ${resInsert}`);
          }, (err) => {
            console.log(err);
            saveLog(CONSTANT.ERROR, `Insert Branch ${JSON.stringify(err)}`);
          });
        }, (err) => {
          console.log(err);
          saveLog(CONSTANT.ERROR, `DELETE Branch ${JSON.stringify(err)}`);
        });
        Caches.set('Branch', res.data.data);
        console.log(Caches.dumpCache());
      } else {
        console.log('No Data For Branch From API');
        saveLog(CONSTANT.INFO, 'No Data For Branch From API');
      }
    }, (err) => {
      console.log(err);
      getBranchMasterFromLocalDB();
      saveLog(CONSTANT.ERROR, `API Branch Error ${JSON.stringify(err)}`);
    });
};

export const getBranchMasterFromLocalDB = () => {
  SQLiteUtils.executeQuery(
    global.database.pruSmart,
    `SELECT * FROM ${Database.pruSmart.tables.branch.name}`,
    [],
  ).then((res) => {
    console.log(res.rows);
    const branches = [];
    for (let i = 0; i < res.rows.length; i += 1) {
      const branch = res.rows.item(i);
      branches.push({ officeCode: branch.OFFICE_CODE, officeName: branch.OFFICE_NAME });
    }
    Caches.set('Branch', branches);
    console.log(Caches.dumpCache());
  }, (err) => {
    console.log(err);
    saveLog(CONSTANT.ERROR, `Get branch from local db error ${JSON.stringify(err)}`);
  });
};
