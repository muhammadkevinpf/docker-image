import * as MainPage from './activity-main-page';
import * as Prospect from './prospect';
import * as Dashboard from './dashboard';
import * as DashboardDetails from './dashboard-details';
import AMCalendar from './calendar';

export default {
  ...MainPage,
  ...Prospect,
  ...Dashboard,
  ...DashboardDetails,
  AMCalendar,
};
