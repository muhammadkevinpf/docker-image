/**
 * @author: dwi.setiyadi@gmail.com
*/

import { NavigationActions, StackActions } from 'react-navigation';

let navigator;

function setTopLevelNavigator(navigatorRef) {
  navigator = navigatorRef;
}

function getRouteName(navigationState) {
  if (!navigationState) {
    return null;
  }

  const route = navigationState.routes[navigationState.index];
  // dive into nested navigators
  if (route.routes) {
    return getRouteName(route);
  }

  return route.routeName;
}

function navigate(routeName, params) {
  if (params === 'undefined') {
    navigator.dispatch(NavigationActions.navigate(routeName));
  } else {
    navigator.dispatch(NavigationActions.navigate({
      routeName,
      params,
    }));
  }
}

function goBack() {
  navigator.dispatch(NavigationActions.back());
}

/**
 * @description This function acts in the same way as the replace function.
 * Use this function instead of the replace function for handling nested stack navigation issue.
 */
function resetTo(routeName, params) {
  const resetAction = StackActions.reset({
    index: 0,
    actions: [NavigationActions.navigate({ routeName, params })],
  });
  navigator.dispatch(resetAction);
}

function gotoDashboard() { resetTo('MainDashboard'); }

export default {
  setTopLevelNavigator,
  getRouteName,
  navigate,
  goBack,
  gotoDashboard,
  resetTo,
};
