/* eslint-disable no-console */
/* eslint-disable no-unused-vars */
import moment from 'moment';
import SQLiteUtils from '../../../utilities/SQLiteUtils';
import Database from '../../../config/Database';
import ApiService from './ApiService';

// const allProcedure = ApiService.getAllProcedure();

/**
 * TABLE SERVICE
 */

const method = 'rec_exam_result';

const openDatabase = () => new Promise(async (resolve, reject) => {
  try {
    const queryCreateTable = 'CREATE TABLE IF NOT EXISTS aob (method, agentCode, data, createDate)';
    const dbName = Database.pruSmart.name;
    const db = await SQLiteUtils.openDatabase(dbName, 'default');
    // await SQLiteUtils.executeTransaction(db, `DROP TABLE IF EXISTS ${quotation.name}`, []);
    await SQLiteUtils.executeTransaction(db, queryCreateTable, []);
    resolve(db);
  } catch (error) {
    reject(error);
  }
});

const getAll = (db, param) => new Promise(async (resolve, reject) => {
  try {
    const querySelect = 'SELECT * FROM aob WHERE method = ? and agentCode = ? and params = ? and options = ?';
    const options = {
      exact: false,
    };
    const res = await SQLiteUtils.executeQuery(db, querySelect, [method, param.agentCode, param.data, options]);
    const data = [];
    for (let i = 0; i < res.rows.length; i += 1) {
      data.push(JSON.parse(res.rows.item(i).data));
    }
    resolve(data);
  } catch (error) {
    reject(error);
  }
});

const insert = (db, param) => new Promise(async (resolve, reject) => {
  try {
    const queryInsert = 'INSERT INTO aob VALUES (?,?,?,?)';
    const currentDate = moment(new Date()).format('DD/MM/YYYY HH:mm');
    const res = await SQLiteUtils.executeTransaction(
      db,
      queryInsert,
      [method, param.agentCode, JSON.stringify(param.data), currentDate],
    );
    resolve(res);
  } catch (error) {
    reject(error);
  }
});

const updateDataToStore = (collection, request, response) => new Promise(async (resolve, reject) => {
  try {
    const listData = getResponseData(response);
    const currentDate = moment(new Date()).format('DD/MM/YYYY HH:mm');

    const data = {
      invocationResult: listData,
      agentId: request.agentCode,
      retrieveDate: currentDate,
    };
    if (request.procedure === 'getDocByNPA' || request.procedure === 'getSuppDoc') {
      resolve(data);
    } else {
      const queryCreateTable = `CREATE TABLE IF NOT EXISTS ${collection.table} (method, agentCode, data, createDate)`;
      const querySelect = `SELECT * FROM ${collection.table} WHERE method = ? and agentCode = ?`;
      const queryInsert = `INSERT INTO ${collection.table} VALUES (?,?,?,?)`;
      const queryUpdate = `UPDATE ${collection.table} SET data = ?,createDate = ? WHERE method = ? and agentCode = ?`;
      const selectParam = [collection.method, request.agentCode];
      const updateParam = [JSON.stringify(listData), currentDate, collection.method, request.agentCode];
      const insertParam = [collection.method, request.agentCode, JSON.stringify(listData), currentDate];

      const db = await SQLiteUtils.openDatabase(collection.db, 'default');
      await SQLiteUtils.executeTransaction(db, queryCreateTable, []);

      const res = await SQLiteUtils.executeQuery(db, querySelect, selectParam);
      if (res.rows.length > 0) {
        const resUpdate = await SQLiteUtils.executeTransaction(db, queryUpdate, updateParam);
      } else {
        const resInsert = await SQLiteUtils.executeTransaction(db, queryInsert, insertParam);
      }
      resolve(listData);
    }
  } catch (error) {
    reject(error);
  }
});

const getDataFromStore = (request, isOnline) => new Promise(async (resolve, reject) => {
  try {
    const allProcedure = ApiService.getAllProcedure();
    const collection = allProcedure[request.procedure];
    const currentDate = moment(new Date()).format('DD/MM/YYYY HH:mm');
    const queryCreateTable = `CREATE TABLE IF NOT EXISTS ${collection.table} (method, agentCode, data, createDate)`;
    const querySelect = `SELECT * FROM ${collection.table} WHERE method = ? and agentCode = ?`;
    const selectParam = [collection.method, request.agentCode];

    const db = await SQLiteUtils.openDatabase(collection.db, 'default');
    await SQLiteUtils.executeTransaction(db, queryCreateTable, []);
    const res = await SQLiteUtils.executeQuery(db, querySelect, selectParam);

    const result = res.rows.item(0).data;
    if (result.length > 0) {
      resolve(JSON.parse(result));
    } else {
      // eslint-disable-next-line no-lonely-if
      if (isOnline) {
        // get from API
        resolve(getDataFromAPI(request, isOnline));
      }
    }
  } catch (error) {
    reject(error);
  }
});

/**
 * API SERVICE
 */

const getDataFromAPI = (request, isOnline) => new Promise(async (resolve, reject) => {
  try {
    const allProcedure = ApiService.getAllProcedure();
    const responseApi = await ApiService.requestToApi(request);
    console.log(responseApi);
    if (isOnline) {
      resolve(responseApi);
    } else {
      const collection = allProcedure[request.procedure];
      resolve(updateDataToStore(collection, request, responseApi));
    }
  } catch (error) {
    reject(error);
  }
});

const getResponseData = (request, response) => {
  const currentDate = moment(new Date()).format('DD/MM/YYYY HH:mm');
  let result;
  switch (request.procedure) {
    case 'getDataProvince':
      result = response.result.TI028;
      break;
    case 'getDataEducation':
      result = response.result.TI183;
      break;
    case 'getBankAccount':
      result = response.result.MSTBABRPF;
      break;
    case 'collectapplpackstatusdata':
    case 'getDataFaststart':
    case 'getDataApplicationPack':
      result = response;
      break;
    case 'getToken':
      result = response;
      // eslint-disable-next-line no-case-declarations
      let reqParam = reqParam.replace('[', '').replace(']', '');
      reqParam = reqParam.split(',');
      result.password = reqParam[3].replace("'", '').replace("'", '');

      result.lastOnlineLogin = currentDate;
      break;
    case 'getAAJIScheduleList':
      result = response.array;
      break;
    case 'getDocByNPA':
      try {
        const listData = [];
        for (let i = 0; i < response.array.length; i += 1) {
          listData[i] = {
            docId: response.array[i].docid,
            fileBase64: response.array[i].filebase64,
          };
        }
        result = {};
        result.result = listData;
      } catch (error) {
        result = [];
      }
      break;
    default:
      result = response;
  }

  return result;
};

export default {
  openDatabase,
  getAll,
  insert,
  getDataFromAPI,
};
