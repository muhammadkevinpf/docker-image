import SwitchingPolicy from './snr';
import TopupPolicy from './topup';

export default {
  SwitchingPolicy,
  TopupPolicy,
};
