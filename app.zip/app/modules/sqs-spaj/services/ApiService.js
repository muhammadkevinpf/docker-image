/* eslint-disable no-param-reassign */
/* eslint-disable no-return-assign */
/* eslint-disable no-unused-vars */
/* eslint-disable func-names */
/* eslint-disable prefer-arrow-callback */
/* eslint-disable no-restricted-syntax */
// import Analytics from 'appcenter-analytics';
import { resourceRequest } from '../../../utilities/StoreApi';
import { sagaWatcherErrorHandling as errorHandling } from '../../../utilities/ErrorHandling';
import Database from '../../../config/Database';

const serviceName = 'ApiService';
const requestToApi = request => new Promise(async (resolve, reject) => {
  try {
    const requestParams = {};
    requestParams.headers = request.data.headers;
    if (typeof request.parameters.params === 'string') {
      requestParams.params = request.parameters.params;
    } else if (typeof request.parameters.params === 'object') {
      let data = JSON.stringify(request.parameters.params);
      data = data.replace(/'/g, function (value) { return value = '##PTK##'; });
      data = data.replace(/\\n/g, function (value) { return value = '##ENT##'; });
      data = data.replace(/\\r/g, function (value) { return value = '##ENT##'; });
      data = data.replace(/%/g, '%25');
      data = data.replace(/[+]/g, '%2B');
      requestParams.params = `['${data}']`;
    } else {
      requestParams.params = request.parameters.params;
    }
    const resAccessToken = await resourceRequest(request.adapter, request.method, requestParams);
    if ((resAccessToken.status === '200' || resAccessToken.status === 200)) {
      resolve(resAccessToken.data);
    } else {
      reject(new Error(resAccessToken.data.message));
    }
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    const parseError = errorHandling(error);
    console.log(error);
    reject(parseError);
  }
});

const getAllProcedure = () => {
  const {
    newSqs, pruSmart, inquiries, general, pruForce,
  } = Database;
  const result = {};

  // get all db
  Object.assign(result, getProcedureInDB(newSqs));
  Object.assign(result, getProcedureInDB(pruSmart));
  Object.assign(result, getProcedureInDB(inquiries));
  Object.assign(result, getProcedureInDB(general));
  Object.assign(result, getProcedureInDB(pruForce));

  return result;
};

const getProcedureInDB = (db) => {
  const resultDB = {};
  // extract procedure from table
  for (const key in db) {
    if (Object.prototype.hasOwnProperty.call(db, key)) {
      if (key !== 'name') {
        Object.assign(resultDB, getAllProcedureFromTable(db[key], db.name));
      }
    }
  }
  return resultDB;
};

const getAllProcedureFromTable = (tables, dbName) => {
  const procedure = {};
  // extract procedure from table
  for (const key in tables) {
    if (Object.prototype.hasOwnProperty.call(tables, key)) {
      if (key !== 'name') {
        // eslint-disable-next-line guard-for-in
        for (const procedureKey in tables[key]) {
          if (procedureKey !== 'name') {
            procedure[procedureKey] = tables[key][procedureKey];
            if (tables[key].name !== undefined) {
              procedure[procedureKey].table = tables[key].name;
            } else if (tables[key][procedureKey].name !== undefined) {
              procedure[procedureKey].table = tables[key][procedureKey].name;
            }
            procedure[procedureKey].db = dbName;
          }
        }
      }
    }
  }
  return procedure;
};

export default {
  requestToApi,
  getAllProcedure,
};
