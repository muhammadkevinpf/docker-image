import React, { PureComponent } from 'react';
import { Text, View } from 'native-base';
import { DatabaseUtils, toFixedCurrency, toTitleCase } from '../../../utilities';
import {
  Collapsible, CoverageText, rowLayout, Skeleton, SkeletonText, StyledText,
} from '../../../components';
import Style from '../../../styles';
import Colors from '../../../styles/Colors';

export class PersistencyIndividuCard extends PureComponent {
  renderAPI = ({ type, value }) => (
    <View style={[Style.Main.container, Style.Main.rowDirection]}>
      <View style={[Style.Main.setSize({ w: 3, h: '100%', backgroundColor: Colors.red })]} />
      <View style={[Style.Main.container, Style.Main.px10, Style.Main.mV5]}>
        <View style={[Style.Main.rowDirectionSpaceBetween]}>
          <SkeletonText isLoading={this.props.isLoading} width="15%" font={11} color={Colors.gray83}>
            <StyledText italic={type === 'Issued' || type === 'Lapsed'} font={10} color={Colors.gray83}>{type}</StyledText> API
          </SkeletonText>
          <SkeletonText isLoading={this.props.isLoading} width="30%" font={11}>Rp. {toFixedCurrency(value, 2)}</SkeletonText>
        </View>
      </View>
    </View>
  );

  render() {
    const {
      data, showDetail, isLoading, onExpand = () => {}, onPress = () => {},
    } = this.props;
    return (
      <Collapsible
        isLoading={isLoading}
        title={data.policyHolderName}
        rightTitle={data.policyStatus}
        rightTitleStyle={[Style.Main.fontAlbert11, Style.Main.textRed]}
        content={
          <Skeleton isLoading={isLoading} layout={[rowLayout({ h: 8, w: '15%' }), rowLayout({ h: 8, w: '45%' })]}>
            <Text style={[Style.Main.fontAlbert11]}>{data.policyNo}</Text>
            <CoverageText style={[Style.Main.fontAlbert11]} desc={DatabaseUtils.toCoverageFormat(toTitleCase(data.productCode || ''))} />
          </Skeleton>
        }
        expandedContent={
          <View style={[Style.Main.container, Style.Main.setBorder()]}>
            <this.renderAPI type="Issued" value={data.issuedAPI} />
            <this.renderAPI type="Kenaikan" value={data.incrementAPI} />
            <this.renderAPI type="Penurunan" value={data.decrementAPI} />
            <this.renderAPI type="Lapsed" value={data.lapsedAPI} />
          </View>
        }
        isExpanded={showDetail}
        onExpand={onExpand}
        onDetail={onPress}
      />
    );
  }
}
