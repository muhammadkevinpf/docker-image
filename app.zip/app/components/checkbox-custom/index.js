/**
 * @author: ahmdichsanb@gmail.com
*/

import React, { PureComponent, Fragment } from 'react';
import { TouchableOpacity, Text } from 'react-native';
import UnCheckIcon from 'react-native-vector-icons/Feather';
import CheckIcon from 'react-native-vector-icons/AntDesign';
import PropTypes from 'prop-types';
import { Row, Col } from 'react-native-easy-grid';
import Style from '../../styles';
import PruText from '../pru-text';

import StyleCheckBoxCustom from './StyleCheckBoxCustom';

class CheckBoxCustom extends PureComponent {
  render() {
    const {
      value, label, isChecked,
      // eslint-disable-next-line no-unused-vars
      fontStyle, size, color,
      colIconStyle, colLabelStyle,
      colIconSize, colLabelSize, activeOpacity,
    } = this.props;
    const unCheck = <UnCheckIcon name="square" type="Feather" style={[Style.Main.font21, Style.Main.gray83]} />;
    const check = <CheckIcon
      name="checksquareo"
      type="AntDesign"
      style={[Style.Main.font20, Style.Main.textRed, Style.Main.ml1]}
    />;
    const benefit = label.split('PRU')[1];
    let afterPru = benefit.split(' ');
    // const pruPair = afterPru[0];
    // afterPru.shift();
    const theAfterPru = afterPru.map(s => s.substring(0, 1).toUpperCase() + s.substring(1));
    afterPru = theAfterPru.join(' ');
    return (
      <Fragment>
        <TouchableOpacity
          onPress={() => this.props.onPress(value)}
          activeOpacity={activeOpacity}
          style={[StyleCheckBoxCustom.container]}
        >
          <Row>
            <Col size={colIconSize} style={[colIconStyle]}>
              {(isChecked)
                ? check
                : unCheck }
            </Col>
            {
              label && (
                <Col size={colLabelSize} style={[colLabelStyle]}>
                  <PruText
                    label={(
                      <React.Fragment>
                        {/* <Text style={[Style.Main.gray83, Style.Main.font14, Style.Main.fontAlbert]}>{pruPair}</Text> */}
                        <Text style={[Style.Main.gray83, Style.Main.font14, Style.Main.fontAlbert]}>{afterPru}</Text>
                      </React.Fragment>
                    )}
                    pruStyle={[Style.Main.textRed, Style.Main.fontAlbert, Style.Main.font14]}
                    labelStyle={[Style.Main.gray83, Style.Main.fontAlbert, Style.Main.font14]}
                  />
                </Col>
              )
            }
          </Row>
        </TouchableOpacity>
      </Fragment>
    );
  }
}

CheckBoxCustom.propTypes = {
  size: PropTypes.number,
  activeOpacity: PropTypes.number,
  color: PropTypes.string,
  label: PropTypes.string,
  value: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
    PropTypes.bool,
  ]).isRequired,
  isChecked: PropTypes.bool.isRequired,
  colIconSize: PropTypes.number,
  colLabelSize: PropTypes.number,
  onPress: PropTypes.func.isRequired,
  fontStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  colIconStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  colLabelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
};

CheckBoxCustom.defaultProps = {
  size: 22,
  activeOpacity: 0.3,
  color: 'red',
  label: 'Checkbox Label',
  colIconSize: 10,
  colLabelSize: 90,
  fontStyle: StyleCheckBoxCustom.fontStyle,
  colIconStyle: StyleCheckBoxCustom.colIconStyle,
  colLabelStyle: StyleCheckBoxCustom.colLabelStyle,
};

export default CheckBoxCustom;
