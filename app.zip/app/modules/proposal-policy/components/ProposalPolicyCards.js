import React, { PureComponent, Component } from 'react';
import moment from 'moment';
import { VictoryPie } from 'victory-native';
import { Text, View, Card } from 'native-base';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { inquiriesType } from '../ConfigProposalPolicy';
import { DatabaseUtils } from '../../../utilities';
import {
  CoverageText, Skeleton, StyledText, rowLayout, UpdateDate, SkeletonText,
} from '../../../components';
import LoadingModal from '../../../components/loading_modal';
import Style from '../../../styles';
import Colors from '../../../styles/Colors';
import _ from '../../../lang';

export class ProposalPolicyChart extends Component {
  legendStyle = { width: 15, height: 15 };

  render() {
    const {
      data, onPress, type, date,
    } = this.props;
    const isProposal = type === inquiriesType.proposal;
    let graph = [{ x: '', y: 0, color: Colors.whiteSmoke }];
    if (isProposal) {
      graph = [
        { x: _('Proposal'), y: data.P, color: Colors.redPastel },
        { x: _('Underwriting Approval'), y: data.UA, color: Colors.orangePastel },
        { x: _('Declined'), y: data.DC, color: Colors.yellowPastel },
        { x: _('Postponed'), y: data.PO, color: Colors.greenPastel },
        { x: _('Withdrawn/NTU'), y: data.WD, color: Colors.bluePastel },
      ];
    } else {
      graph = [
        { x: _('In Force'), y: data.inForce, color: Colors.redPastel },
        { x: _('Lapsed'), y: data.lapsed, color: Colors.orangePastel },
        { x: _('Surrender'), y: data.surrender, color: Colors.yellowPastel },
        { x: _('Cancel'), y: data.cancelled, color: Colors.greenPastel },
        { x: _('Lain-lain'), y: data.others, color: Colors.bluePastel },
      ];
    }
    const size = 140;
    const circleWidth = 65;
    const innerRadius = Math.round((size - circleWidth) / 2);
    const isLoading = this.props.isLoading && graph.every(item => item.y === 0);
    return (
      <Card style={[Style.Main.padding12, Style.Main.container]}>
        <View style={[Style.Main.container, Style.Main.rowDirection, Style.Main.mb10]}>
          <StyledText bold>{_(isProposal ? 'STATUS PROPOSAL' : 'STATUS POLIS')}</StyledText>
          <View style={[Style.Main.horizontalLine, Style.Main.ml10, Style.Main.fullWidth]} />
        </View>
        <View style={[Style.Main.container]}>
          <UpdateDate isLoading={this.props.isLoading} date={date ? moment(new Date(date)).format('LLL') : null} />
          <View style={[Style.Main.container, Style.Main.padding12]}>
            <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.mV15]}>
              <View style={[Style.Main.container, Style.Main.center, Style.Main.mr15]}>
                <VictoryPie
                  padding={0}
                  style={{ labels: { ...Style.Main.fontAlbert, ...Style.Main.font8, fill: Colors.white } }}
                  width={size}
                  height={size}
                  innerRadius={innerRadius}
                  labels={() => null}
                  colorScale={[Colors.redPastel, Colors.orangePastel, Colors.yellowPastel, Colors.greenPastel, Colors.bluePastel]}
                  data={graph}
                />
                <Skeleton
                  isLoading={isLoading}
                  layout={[rowLayout({ w: circleWidth - 20, h: 7 }), rowLayout({ w: circleWidth - 30, h: 13 })]}
                  style={[Style.Main.absolute, Style.Main.center, Style.Main.setSize({ bottom: innerRadius + 15 })]}
                >
                  <StyledText font={10} color={Colors.gray83}>{_(isProposal ? 'Total SPAJ' : 'Total Polis')}</StyledText>
                  <StyledText font={16} bold>{data.total}</StyledText>
                </Skeleton>
              </View>
              <View style={[Style.Main.container, Style.Main.alignRight, Style.Main.mh15, Style.Main.mV15]}>
                {
                  graph.map((item, index) => (
                    <View key={index.toString()} style={[Style.Main.rowDirectionSpaceBetween, Style.Main.container, Style.Main.mV2, Style.Main.pl2]}>
                      <View style={[this.legendStyle, Style.Main.mr10, Style.Main.alignCenter, { backgroundColor: item.color }]} />
                      <Skeleton
                        isLoading={isLoading}
                        layout={[rowLayout({
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                          children: [rowLayout({ w: '35%', h: 8 }), rowLayout({ w: '15%', h: 8 })],
                        })]}
                        style={[Style.Main.container, Style.Main.rowDirectionSpaceBetween]}
                      >
                        <StyledText font={11}>{item.x}</StyledText>
                        <StyledText font={11} bold style={[Style.Main.timeStyle]}>{item.y}</StyledText>
                      </Skeleton>
                    </View>
                  ))
                }
              </View>
            </View>
            <StyledText bold color={Colors.red} style={[Style.Main.pt18, Style.Main.pl25, Style.Main.timeStyle]} onPress={onPress || (() => { })}>
              {_('Lihat Rincian')}
            </StyledText>
          </View>
        </View>
      </Card>
    );
  }
}

export class ProposalPolicyValue extends PureComponent {
  render() {
    const {
      data, type, isByUnit, isLoading,
    } = this.props;
    return (
      <Skeleton
        isLoading={isLoading}
        layout={[
          rowLayout({ w: '90%', h: 12 }), rowLayout({ w: '65%', h: 9 }), rowLayout({ w: '45%', h: 9 }),
          rowLayout({ w: '80%', h: 9 }), rowLayout({ w: '75%', h: 9 }),
        ]}
      >
        <Text style={[Style.Main.fontAlbertBold14]}>{data.policyHolderName}</Text>
        <Text style={[Style.Main.fontAlbert11]}>
          {type === inquiriesType.proposal ? `${_('Nomor SPAJ')}: ${data.proposalNumber}`
            : `${_('Nomor Polis')}: ${data.policyNumber}`}
        </Text>
        {!isByUnit && <Text style={[Style.Main.fontAlbert11]}>{data.mainLifeAssured}</Text>}
        {/* <Text style={[Style.Main.fontAlbert11]}>{data.productName}</Text> */}
        <CoverageText style={[Style.Main.fontAlbert11]} desc={data.productName ? DatabaseUtils.toCoverageFormat(data.productName) : ''} />
        {data.policyIssuedDate &&
          <Text style={[Style.Main.fontAlbert11]}>{_('Issued Date')}: {moment(data.policyIssuedDate, 'YYYY-MM-DD').format('DD MMMM YYYY')}</Text>}
      </Skeleton>
    );
  }
}

export class ProposalPolicyCard extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    };
  }

  render() {
    const { onCardClicked, isLoading } = this.props;
    return (
      <Card style={[Style.Main.container, Style.Main.mb5, Style.Main.padding10]}>
        <TouchableOpacity
          activeOpacity={onCardClicked ? 0.5 : 1}
          onPress={onCardClicked || (() => { })}
          style={[Style.Main.fullWidth, Style.Main.rowDirectionSpaceBetween]}
        >
          <ProposalPolicyValue {...this.props} />
          <Skeleton isLoading={isLoading} style={[Style.Main.alignEnd]} layout={[rowLayout({ w: '50%', h: 8 })]}>
            <Text style={[Style.Main.fontAlbert11, Style.Main.textRed]}>{this.props.data.status}</Text>
          </Skeleton>
        </TouchableOpacity>
        <LoadingModal show={this.state.isLoading} size="large" color="white" />
      </Card>
    );
  }
}

export class ProposalPolicylUnitCard extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    };
  }

  render() {
    const { data, onCardClicked, isLoading } = this.props;
    return (
      <Card style={[Style.Main.container, Style.Main.mb5, Style.Main.padding10]}>
        <TouchableOpacity
          activeOpacity={onCardClicked ? 0.5 : 1}
          onPress={onCardClicked || (() => { })}
          style={[Style.Main.fullWidth]}
        >
          <SkeletonText isLoading={isLoading} width="60%" font={14} bold>{data.clientName || 'N/A'}</SkeletonText>
          <View style={[Style.Main.fullWidth, Style.Main.mt5, Style.Main.alignContentCenter, Style.Main.rowDirectionSpaceBetween]}>
            <Skeleton isLoading={isLoading} layout={[rowLayout({ w: '25%', h: 8 })]} style={[Style.Main.rowDirection]}>
              {data.agentType &&
                <Text
                  style={[Style.Main.textWhite, Style.Main.fontAlbert11, Style.Main.ph5, Style.Main.pv2, Style.Main.borderRadius5, Style.Main.mr5,
                    { backgroundColor: Colors[data.agentType] }]}
                >{data.agentType}
                </Text>
              }
              <Text style={[Style.Main.pv2, Style.Main.fontAlbert11]}>{data.agentNumber || 'N/A'}</Text>
            </Skeleton>
            <View style={[Style.Main.alignEnd]}>
              <SkeletonText isLoading={isLoading} width="30%" font={11} style={[Style.Main.pv2]}>
                {data.total || 0}
              </SkeletonText>
            </View>
          </View>
        </TouchableOpacity>
        <LoadingModal show={this.state.isLoading} size="large" color="white" />
      </Card>
    );
  }
}

export class ProposalPolicyByUnitCard extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    };
  }

  render() {
    const { onCardClicked } = this.props;
    return (
      <Card style={[Style.Main.container, Style.Main.mb5, Style.Main.padding10]}>
        <TouchableOpacity
          activeOpacity={onCardClicked ? 0.5 : 1}
          onPress={onCardClicked || (() => { })}
          style={[Style.Main.fullWidth, Style.Main.rowDirectionSpaceBetween]}
        >
          <ProposalPolicyValue {...this.props} isByUnit />
          <Text style={[Style.Main.fontAlbert11, Style.Main.textGreen]}>{this.props.data.status}</Text>
        </TouchableOpacity>
        <LoadingModal show={this.state.isLoading} size="large" color="white" />
      </Card>
    );
  }
}
