import {
  FIRST_BANNER_FETCH, FIRST_BANNER_SUCCESS, FIRST_BANNER_FAILED,
  SECOND_BANNER_FETCH, SECOND_BANNER_SUCCESS, SECOND_BANNER_FAILED,
  THIRD_BANNER_FETCH, THIRD_BANNER_SUCCESS, THIRD_BANNER_FAILED, STORE_NEWS_BANNER, RESET_STATUS,
  CHANGE_PASSWORD_FETCH, CHANGE_PASSWORD_SUCCESS, CHANGE_PASSWORD_FAILED,
  CAMPAIGN_BANNER_FETCH, CAMPAIGN_BANNER_SUCCESS, CAMPAIGN_BANNER_FAILED,
  FIRST_CAMPAIGN_FETCH, FIRST_CAMPAIGN_FAILED, FIRST_CAMPAIGN_SUCCESS,
  SECOND_CAMPAIGN_FETCH, SECOND_CAMPAIGN_SUCCESS, SECOND_CAMPAIGN_FAILED, UPDATE_DICTIONARY_FLAG,
  THIRD_CAMPAIGN_FETCH, THIRD_CAMPAIGN_SUCCESS, THIRD_CAMPAIGN_FAILED, RESET_ALL_STATE, UPDATE_DASHBOARD_ICONS,
} from './ConfigDashboard';
// Main production
import {
  PROD_INDIVIDU_YTD, PROD_GRAPH_DETAIL_INDIVIDU, PROD_GRAPH_DETAIL_UNIT, PROD_INDIVIDU_BY_RANGE, PROD_UNIT_BY_RANGE, PROD_UNIT_YTD,
} from '../production/ConfigProduction';
// Main persistency
import { PERSISTENCY_MAIN_CURRENT, PERSISTENCY_MAIN_HISTORY } from '../persistency/ConfigPersistency';
// Main proposal-policy
import { PROPOSAL_GRAPH, POLICY_GRAPH, LAST_FETCH_STATUS } from '../proposal-policy/ConfigProposalPolicy';

import { requestStatus } from '../../utilities/ApiConnection';
import { TOTALNOTIFICATIONSUCCESS } from '../notification/ConfigNotification';
import { TOTALTODOSUCCESS } from '../todo-list/ConfigTodoList';
import { GET_DICTIONARY } from '../dictionary/ConfigDictionary';
import { isEmpty } from '../../utilities';

/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

const initialBannerState = {
  lastFetchTodo: null,
  lastFetchNotif: null,
  totalTodo: null,
  totalNotif: null,

  // news banner
  lastFetchNews: null,
  newsBanner: [],
  firstBannerStatus: requestStatus.IDLE,
  secondBannerStatus: requestStatus.IDLE,
  thirdBannerStatus: requestStatus.IDLE,
  firstBanner: '',
  secondBanner: '',
  thirdBanner: '',
  err: null,

  // campaign banner
  lastFetchCampaign: null,
  campaignList: [],
  campaignListStatus: requestStatus.IDLE,
  firstCampaignStatus: requestStatus.IDLE,
  secondCampaignStatus: requestStatus.IDLE,
  thirdCampaignStatus: requestStatus.IDLE,
  campaignImages: [],

  // main production
  prodYTD: {},
  prodByRange: {},
  individuGraph: [],
  prodYTDUnit: {},
  prodByRangeUnit: {},
  unitGraph: [],
  historyLastUpdate: null,
  prodLastUpdate: null,

  // main persistency
  mainCurrent: {},
  mainHistory: {},

  // main proposal policy
  proposalGraph: {
    P: 0, UA: 0, DC: 0, PO: 0, WD: 0, total: 0,
  },
  policyGraph: {
    inForce: 0, lapsed: 0, surrender: 0, cancelled: 0, others: 0, total: 0,
  },

  // dashboard icons
  dashboardIcons: [],
  dictionary: {},
  dictionaryStatus: requestStatus.IDLE,
  dictionaryTnCflag: true,
};

export function ReducerDashboard(state = initialBannerState, action) {
  switch (action.type) {
    case RESET_ALL_STATE: return initialBannerState;

    case TOTALNOTIFICATIONSUCCESS: return { ...state, lastFetchNotif: new Date(), totalNotif: action.res };
    case TOTALTODOSUCCESS: return { ...state, lastFetchTodo: new Date(), totalTodo: action.res };

    case STORE_NEWS_BANNER:
      return {
        ...state,
        newsBanner: action.payload,
        lastFetchNews: new Date(),
      };

    case RESET_STATUS:
      return {
        ...state,
        firstBannerStatus: requestStatus.IDLE,
        secondBannerStatus: requestStatus.IDLE,
        thirdBannerStatus: requestStatus.IDLE,
        firstBanner: '',
        secondBanner: '',
        thirdBanner: '',
      };

    case FIRST_BANNER_FETCH:
      return {
        ...state,
        firstBannerStatus: requestStatus.FETCH,
      };

    case FIRST_BANNER_SUCCESS:
      return {
        ...state,
        firstBannerStatus: requestStatus.SUCCESS,
        firstBanner: action.payload,
      };

    case FIRST_BANNER_FAILED:
      return {
        ...state,
        firstBannerStatus: requestStatus.FAILED,
        err: action.payload,
      };

    case SECOND_BANNER_FETCH:
      return {
        ...state,
        secondBannerStatus: requestStatus.FETCH,
      };

    case SECOND_BANNER_SUCCESS:
      return {
        ...state,
        secondBannerStatus: requestStatus.SUCCESS,
        secondBanner: action.payload,
      };

    case SECOND_BANNER_FAILED:
      return {
        ...state,
        secondBannerStatus: requestStatus.FAILED,
        err: action.payload,
      };

    case THIRD_BANNER_FETCH:
      return {
        ...state,
        thirdBannerStatus: requestStatus.FETCH,
      };

    case THIRD_BANNER_SUCCESS:
      return {
        ...state,
        thirdBannerStatus: requestStatus.SUCCESS,
        thirdBanner: action.payload,
      };

    case THIRD_BANNER_FAILED:
      return {
        ...state,
        thirdBannerStatus: requestStatus.FAILED,
        err: action.payload,
      };

    case CAMPAIGN_BANNER_FETCH:
      return {
        ...state,
        campaignListStatus: requestStatus.FETCH,
      };

    case CAMPAIGN_BANNER_SUCCESS:
      return {
        ...state,
        campaignListStatus: requestStatus.SUCCESS,
        campaignList: action.payload && action.payload !== state.campaignList ? action.payload : state.campaignList || [],
        lastFetchCampaign: new Date(),
      };

    case CAMPAIGN_BANNER_FAILED:
      return {
        ...state,
        campaignListStatus: requestStatus.FAILED,
      };

    case FIRST_CAMPAIGN_FETCH:
      return {
        ...state,
        firstCampaignStatus: requestStatus.FETCH,
      };

    case FIRST_CAMPAIGN_SUCCESS: {
      let newImages = [...state.campaignImages];
      if (!newImages.some(x => x === action.payload)) newImages.push(action.payload);
      if (newImages.length > 3) newImages = newImages.slice(-3, newImages.length);
      return {
        ...state,
        firstCampaignStatus: requestStatus.SUCCESS,
        campaignImages: newImages,
        lastFetchCampaign: new Date(),
      };
    }

    case FIRST_CAMPAIGN_FAILED:
      return {
        ...state,
        firstCampaignStatus: requestStatus.FAILED,
      };

    case SECOND_CAMPAIGN_FETCH:
      return {
        ...state,
        secondCampaignStatus: requestStatus.FETCH,
      };

    case SECOND_CAMPAIGN_SUCCESS: {
      let newImages = [...state.campaignImages];
      if (!newImages.some(x => x === action.payload)) newImages.push(action.payload);
      if (newImages.length > 3) newImages = newImages.slice(-3, newImages.length);
      return {
        ...state,
        secondCampaignStatus: requestStatus.SUCCESS,
        campaignImages: newImages,
        lastFetchCampaign: new Date(),
      };
    }

    case SECOND_CAMPAIGN_FAILED:
      return {
        ...state,
        secondCampaignStatus: requestStatus.FAILED,
      };

    case THIRD_CAMPAIGN_FETCH:
      return {
        ...state,
        thirdCampaignStatus: requestStatus.FETCH,
      };

    case THIRD_CAMPAIGN_SUCCESS: {
      let newImages = [...state.campaignImages];
      if (!newImages.some(x => x === action.payload)) newImages.push(action.payload);
      if (newImages.length > 3) newImages = newImages.slice(-3, newImages.length);
      return {
        ...state,
        thirdCampaignStatus: requestStatus.SUCCESS,
        campaignImages: newImages,
        lastFetchCampaign: new Date(),
      };
    }

    case THIRD_CAMPAIGN_FAILED:
      return {
        ...state,
        thirdCampaignStatus: requestStatus.FAILED,
      };

    // Reducer Main Production - FETCH //
    case PROD_INDIVIDU_BY_RANGE.FETCH: return { ...state, send: action.payload };
    case PROD_INDIVIDU_YTD.FETCH: return { ...state, send: action.payload };
    case PROD_UNIT_BY_RANGE.FETCH: return { ...state, send: action.payload };
    case PROD_UNIT_YTD.FETCH: return { ...state, send: action.payload };
    case PROD_GRAPH_DETAIL_INDIVIDU.FETCH: return { ...state, send: action.payload };
    case PROD_GRAPH_DETAIL_UNIT.FETCH: return { ...state, send: action.payload };

    // Reducer Main Production - SUCCESS //
    case PROD_INDIVIDU_BY_RANGE.SUCCESS: return { ...state, prodByRange: action.payload, prodLastUpdate: new Date() };
    case PROD_INDIVIDU_YTD.SUCCESS: return { ...state, prodYTD: action.payload, prodLastUpdate: new Date() };
    case PROD_UNIT_BY_RANGE.SUCCESS: return { ...state, prodByRangeUnit: action.payload, prodLastUpdate: new Date() };
    case PROD_UNIT_YTD.SUCCESS: return { ...state, prodYTDUnit: action.payload, prodLastUpdate: new Date() };
    case PROD_GRAPH_DETAIL_INDIVIDU.SUCCESS: return { ...state, individuGraph: action.payload, historyLastUpdate: new Date() };
    case PROD_GRAPH_DETAIL_UNIT.SUCCESS: return { ...state, unitGraph: action.payload, historyLastUpdate: new Date() };

    // Reducer Main Production - FAILED //
    case PROD_INDIVIDU_BY_RANGE: return { ...state, error: action.payload };
    case PROD_INDIVIDU_YTD.FAILED: return { ...state, error: action.payload };
    case PROD_UNIT_BY_RANGE.FAILED: return { ...state, error: action.payload };
    case PROD_UNIT_YTD.FAILED: return { ...state, error: action.payload };
    case PROD_GRAPH_DETAIL_INDIVIDU.FAILED: return { ...state, error: action.payload };
    case PROD_GRAPH_DETAIL_UNIT.FAILED: return { ...state, error: action.payload };

    // Main persistency
    case PERSISTENCY_MAIN_CURRENT.FETCH: return { ...state, send: action.payload };
    case PERSISTENCY_MAIN_CURRENT.SUCCESS: return { ...state, mainCurrent: action.payload };
    case PERSISTENCY_MAIN_CURRENT.FAILED: return { ...state, error: action.payload };

    case PERSISTENCY_MAIN_HISTORY.FETCH: return { ...state, send: action.payload };
    case PERSISTENCY_MAIN_HISTORY.SUCCESS: return { ...state, mainHistory: action.payload };
    case PERSISTENCY_MAIN_HISTORY.FAILED: return { ...state, error: action.payload };

    // Main proposal policy
    case PROPOSAL_GRAPH.FETCH: return { ...state, send: action.payload };
    case PROPOSAL_GRAPH.FAILED: return { ...state, error: action.payload };
    case PROPOSAL_GRAPH.SUCCESS: return { ...state, proposalGraph: action.payload };

    case POLICY_GRAPH.FETCH: return { ...state, send: action.payload };
    case POLICY_GRAPH.FAILED: return { ...state, error: action.payload };
    case POLICY_GRAPH.SUCCESS: return { ...state, policyGraph: action.payload };

    case LAST_FETCH_STATUS.PROPOSAL: return { ...state, lastFetchProposal: action.payload };
    case LAST_FETCH_STATUS.POLICY: return { ...state, lastFetchPolicy: action.payload };

    case UPDATE_DASHBOARD_ICONS: return { ...state, dashboardIcons: action.payload };

    case UPDATE_DICTIONARY_FLAG: return { ...state, dictionaryTnCflag: action.payload };

    case GET_DICTIONARY.FETCH: return { ...state, send: action.payload, dictionaryStatus: requestStatus.FETCH };
    case GET_DICTIONARY.SUCCESS: {
      if (!isEmpty(action.payload) && !isEmpty(action.payload.data)) {
        const tempMedical = action.payload.data.filter(x => x.type === 'Medis');
        const tempInsurance = action.payload.data.filter(x => x.type === 'Asuransi');
        const medical = [];
        const insurance = [];
        if (!isEmpty(tempMedical)) {
          for (let i = 10; i < 36; i += 1) {
            const data = tempMedical.filter(x => x.istilah.toLowerCase().startsWith(i.toString(36)));
            if (!isEmpty(data)) medical.push({ title: i.toString(36).toUpperCase(), data });
          }
        }
        if (!isEmpty(tempInsurance)) {
          for (let i = 10; i < 36; i += 1) {
            const data = tempInsurance.filter(x => x.istilah.toLowerCase().startsWith(i.toString(36)));
            if (!isEmpty(data)) insurance.push({ title: i.toString(36).toUpperCase(), data });
          }
        }
        return { ...state, dictionary: { insurance, medical }, dictionaryStatus: requestStatus.SUCCESS };
      }
      return { ...state, dictionaryStatus: requestStatus.SUCCESS };
    }
    case GET_DICTIONARY.FAILED: return { ...state, error: action.payload, dictionaryStatus: requestStatus.FAILED };

    default:
      return state;
  }
}

const initialSettingState = {
  changePasswordStatus: requestStatus.IDLE,
  changePasswordError: '',
};

export function ReducerSetting(state = initialSettingState, action) {
  switch (action.type) {
    case CHANGE_PASSWORD_FETCH:
      return {
        ...state,
        changePasswordStatus: requestStatus.FETCH,
        changePasswordError: '',
      };

    case CHANGE_PASSWORD_SUCCESS:
      return {
        ...state,
        changePasswordStatus: requestStatus.SUCCESS,
        changePasswordError: '',
      };

    case CHANGE_PASSWORD_FAILED:
      return {
        ...state,
        changePasswordStatus: requestStatus.FAILED,
        changePasswordError: action.payload,
      };

    default:
      return state;
  }
}
