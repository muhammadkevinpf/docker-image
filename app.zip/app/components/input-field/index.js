/**
 * @author: ahmdichsanb@gmail.com
*/

import React, { Component, Fragment } from 'react';
import { TextInput, Text } from 'react-native';
import PropTypes from 'prop-types';
import StyleInputField from './StyleInputField';

class InputField extends Component {
  constructor(props) {
    super(props);
    this.state = {
      errorMessage: '',
    };
  }

  emailValidation = (val) => {
    const regex = /.+@.+\.[A-Za-z]+$/;
    if (!regex.test(val)) {
      this.setState({
        errorMessage: 'Invalid email address!',
      });
    } else {
      this.setState({
        errorMessage: '',
      });
    }

    this.props.onChangeText(val, this.state.errorMessage);
  }

  numberOrCurrencyValidation = (val, minVal, maxVal) => {
    const regex = /[^0-9]/gi;
    let value = val.replace(regex, '');
    value = value.length === 0 ? 0 : value;
    value = parseInt(value, 0);

    if (maxVal !== null || minVal) {
      const max = parseInt(maxVal, 0);
      const min = parseInt(minVal, 0);

      if (value > max) {
        this.setState({
          errorMessage: `Maximum value for this field is ${max}`,
        });
      } else {
        this.setState({
          errorMessage: '',
        });
      }

      if (value < min) {
        this.setState({
          errorMessage: `Minimum value for this field is ${min}`,
        });
      } else {
        this.setState({
          errorMessage: '',
        });
      }
    }

    this.props.onChangeText(value.toString(), this.state.errorMessage);
  }

  convertToCurrency = val => val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');

  validationOnFocus = (inputType) => {
    let { value } = this.props;
    const { isValidated } = this.props;

    if (!isValidated && !this.props.onFocus) return;

    if (!isValidated && this.props.onFocus) {
      this.props.onFocus(value);
      return;
    }

    if (inputType === 'currency' || inputType === 'number') {
      const regex = /[^0-9]/gi;
      value = value.replace(regex, '');
      value = value.length > 0 ? parseInt(value, 0) : value;
      value = value.toString();
      value = value.length === 0 ? '0' : value;
      this.props.onChangeText(value.toString(), this.state.errorMessage);
    }
  }

  validationOnChange = (val, inputType, minLength, maxLength, minVal, maxVal) => {
    const { isValidated } = this.props;

    if (!isValidated) {
      this.props.onChangeText(val);
      return;
    }

    if (maxLength) {
      const max = parseInt(maxLength, 0);
      if (val.length >= max) {
        this.setState({
          errorMessage: `Maximum character for this field is ${max}`,
        });
        this.props.onChangeText(val.toString());
        return;
      }

      if (val.length < max) {
        this.setState({
          errorMessage: '',
        });
      }
    }

    if (minLength) {
      const min = parseInt(minLength, 0);
      if (val.length < min) {
        this.setState({
          errorMessage: `Minimum character for this field is ${min}`,
        });
      }

      if (val.length >= min) {
        this.setState({
          errorMessage: '',
        });
      }
    }

    if (inputType === 'currency' || inputType === 'number') {
      this.numberOrCurrencyValidation(val, minVal, maxVal);
    } else if (inputType === 'email') {
      this.emailValidation(val);
    } else {
      this.props.onChangeText(val, this.state.errorMessage);
    }
  }

  validationOnBlur = (inputType, isRequired, minLength) => {
    let { value } = this.props;
    const { isValidated } = this.props;

    if (!isValidated && !this.props.onBlur) return;

    if (!isValidated && this.props.onBlur) {
      this.props.onBlur(value);
      return;
    }

    if (isRequired) {
      if (minLength) {
        const min = parseInt(minLength, 0);
        if (value.length < minLength) {
          this.setState({
            errorMessage: `Minimun character for this field is ${min}`,
          });
        } else {
          this.setState({
            errorMessage: '',
          });
        }
      } else if (value.length < 1 && (inputType !== 'currency' && inputType !== 'number')) {
        this.setState({
          errorMessage: 'This field cannot be null!',
        });
      }
    }

    if (inputType === 'currency' || inputType === 'number') {
      if (value.length < 1) {
        value = '0';
      }
      if (isRequired && value === '0') {
        this.setState({
          errorMessage: 'This field cannot be zero!',
        });
      }
      value = parseInt(value, 0);
      value = value.toString();
      const regex = /[^0-9]/gi;
      value = value.replace(regex, '');
    }

    value = inputType === 'currency' ? this.convertToCurrency(value) : value;
    if (this.props.onBlur) this.props.onBlur(value.toString(), this.state.errorMessage);
    else this.props.onChangeText(value.toString(), this.state.errorMessage);
  }

  focus = () => {
    this._input.focus();
  }

  blur = () => {
    this._input.blur();
  }

  render() {
    const {
      allowFontScaling, autoFocus, editable,
      keyboardType, maxLength, multiline, numberOfLines, type, isRequired,
      minLength, minVal, maxVal, placeholder, placeholderTextColor, secureTextEntry,
      styleTextInput, textAlignVertical, value, isErrorMessageNeeded,
    } = this.props;

    const {
      errorMessage,
    } = this.state;

    let keyboardType_;
    switch (type) {
      case 'number' || 'currency':
        keyboardType_ = 'numeric';
        break;
      case 'email':
        keyboardType_ = 'email-address';
        break;
      default:
        keyboardType_ = keyboardType;
        break;
    }

    let secureTextEntry_ = secureTextEntry;
    if (type === 'password') {
      secureTextEntry_ = true;
    }

    return (
      <Fragment>
        <TextInput
          allowFontScaling={allowFontScaling}
          autoFocus={autoFocus}
          editable={editable}
          keyboardType={keyboardType_}
          maxLength={maxLength}
          multiline={multiline}
          numberOfLines={numberOfLines}
          onBlur={() => this.validationOnBlur(type, isRequired, minLength)}
          onChangeText={val => this.validationOnChange(val, type, minLength, maxLength, minVal, maxVal)}
          onFocus={() => this.validationOnFocus(type)}
          placeholder={placeholder}
          placeholderTextColor={placeholderTextColor}
          secureTextEntry={secureTextEntry_}
          style={styleTextInput}
          textAlignVertical={textAlignVertical}
          value={value}
          ref={(ref) => { this._input = ref; }}
        />
        {isErrorMessageNeeded && (<Text>{errorMessage}</Text>)}
      </Fragment>
    );
  }
}

InputField.propTypes = {
  allowFontScaling: PropTypes.bool,
  autoFocus: PropTypes.bool,
  keyboardType: PropTypes.string,
  maxLength: PropTypes.number,
  minLength: PropTypes.number,
  multiline: PropTypes.bool,
  numberOfLines: PropTypes.number,
  type: PropTypes.string,
  isRequired: PropTypes.bool,
  isValidated: PropTypes.bool,
  minVal: PropTypes.number,
  maxVal: PropTypes.number,
  placeholder: PropTypes.string,
  placeholderTextColor: PropTypes.string,
  secureTextEntry: PropTypes.bool,
  styleTextInput: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  textAlignVertical: PropTypes.string,
  value: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  isErrorMessageNeeded: PropTypes.bool,
  editable: PropTypes.bool,
  onChangeText: PropTypes.func,
  onFocus: PropTypes.func,
  onBlur: PropTypes.func,
};

InputField.defaultProps = {
  allowFontScaling: false,
  autoFocus: false,
  keyboardType: 'default',
  maxLength: null,
  minLength: null,
  multiline: false,
  numberOfLines: null,
  type: 'default',
  isRequired: false,
  isValidated: false,
  placeholder: '',
  textAlignVertical: 'top',
  secureTextEntry: false,
  editable: true,
  styleTextInput: StyleInputField.styleTextInput,
  isErrorMessageNeeded: false,
  maxVal: null,
  minVal: null,
  value: null,
  placeholderTextColor: '#636363',
  onChangeText: () => {},
  onFocus: () => {},
  onBlur: () => {},
};

export default InputField;
