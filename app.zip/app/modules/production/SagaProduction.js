/* eslint-disable no-console */
import { takeLatest } from 'redux-saga/effects';
import { apiSagaFunction } from '../../utilities/Functions';
import { productionAction } from './ActionProduction';
import {
  FIND_TRANSACTION_INDIVIDU_MONTHLY, FIND_TRANSACTION_INDIVIDU_YEARLY, FIND_TRANSACTION_UNIT_MONTHLY,
  FIND_TRANSACTION_UNIT_YEARLY, FIND_TRANSACTION_LIST_FILTER, FIND_AGENT_TYPE_LIST_FILTER, PROD_GRAPH_DETAIL_INDIVIDU, PROD_GRAPH_DETAIL_UNIT,
  PROD_HISTORY_LIST_INDIVIDU, PROD_HISTORY_LIST_UNIT, PROD_INDIVIDU_YTD, PROD_INDIVIDU_BY_RANGE, PROD_UNIT_BY_RANGE, PROD_UNIT_YTD,
} from './ConfigProduction';

const config = { resAttribute: 'data' };

export const watcherProduction = [
  takeLatest(FIND_TRANSACTION_INDIVIDU_MONTHLY.FETCH,
    params => apiSagaFunction(params.payload, productionAction, FIND_TRANSACTION_INDIVIDU_MONTHLY, config)),
  takeLatest(FIND_TRANSACTION_INDIVIDU_YEARLY.FETCH,
    params => apiSagaFunction(params.payload, productionAction, FIND_TRANSACTION_INDIVIDU_YEARLY, config)),
  takeLatest(FIND_TRANSACTION_UNIT_MONTHLY.FETCH,
    params => apiSagaFunction(params.payload, productionAction, FIND_TRANSACTION_UNIT_MONTHLY, config)),
  takeLatest(FIND_TRANSACTION_UNIT_YEARLY.FETCH,
    params => apiSagaFunction(params.payload, productionAction, FIND_TRANSACTION_UNIT_YEARLY, config)),
  takeLatest(FIND_TRANSACTION_LIST_FILTER.FETCH,
    params => apiSagaFunction(params.payload, productionAction, FIND_TRANSACTION_LIST_FILTER, config)),
  takeLatest(FIND_AGENT_TYPE_LIST_FILTER.FETCH,
    params => apiSagaFunction(params.payload, productionAction, FIND_AGENT_TYPE_LIST_FILTER, config)),

  // MAIN PRODUCTION
  takeLatest(PROD_INDIVIDU_BY_RANGE.FETCH,
    params => apiSagaFunction(params.payload, productionAction, PROD_INDIVIDU_BY_RANGE, config)),
  takeLatest(PROD_INDIVIDU_YTD.FETCH, params => apiSagaFunction(params.payload, productionAction, PROD_INDIVIDU_YTD, config)),
  takeLatest(PROD_UNIT_BY_RANGE.FETCH, params => apiSagaFunction(params.payload, productionAction, PROD_UNIT_BY_RANGE, config)),
  takeLatest(PROD_UNIT_YTD.FETCH, params => apiSagaFunction(params.payload, productionAction, PROD_UNIT_YTD, config)),
  takeLatest(PROD_GRAPH_DETAIL_INDIVIDU.FETCH,
    params => apiSagaFunction(params.payload, productionAction, PROD_GRAPH_DETAIL_INDIVIDU, config)),
  takeLatest(PROD_GRAPH_DETAIL_UNIT.FETCH,
    params => apiSagaFunction(params.payload, productionAction, PROD_GRAPH_DETAIL_UNIT, config)),

  takeLatest(PROD_HISTORY_LIST_INDIVIDU.FETCH,
    params => apiSagaFunction(params.payload, productionAction, PROD_HISTORY_LIST_INDIVIDU, config)),
  takeLatest(PROD_HISTORY_LIST_UNIT.FETCH,
    params => apiSagaFunction(params.payload, productionAction, PROD_HISTORY_LIST_UNIT, config)),
];
