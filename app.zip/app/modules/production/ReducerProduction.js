import { requestStatus } from '../../utilities/ApiConnection';
import {
  FIND_TRANSACTION_INDIVIDU_MONTHLY, FIND_TRANSACTION_INDIVIDU_YEARLY, FIND_TRANSACTION_UNIT_MONTHLY,
  FIND_TRANSACTION_UNIT_YEARLY, FIND_TRANSACTION_LIST_FILTER, FIND_AGENT_TYPE_LIST_FILTER, PROD_INDIVIDU_YTD, PROD_GRAPH_DETAIL_INDIVIDU,
  PROD_GRAPH_DETAIL_UNIT, PROD_HISTORY_LIST_INDIVIDU, PROD_HISTORY_LIST_UNIT, RESET_PRODUCTION, PROD_INDIVIDU_BY_RANGE,
  PROD_UNIT_YTD, PROD_UNIT_BY_RANGE,
} from './ConfigProduction';
import { RESET_ALL_STATE } from '../dashboard/ConfigDashboard';
import { isArrayEmpty } from '../../utilities';

const initialStateProduction = {
  // Production List Status
  individuListStatus: requestStatus.IDLE,
  unitListStatus: requestStatus.IDLE,
  filterStatus: requestStatus.IDLE,

  // Main Production Status
  individuRangeStatus: requestStatus.IDLE,
  individuStatus: requestStatus.IDLE,
  individuGraphStatus: requestStatus.IDLE,

  unitRangeStatus: requestStatus.IDLE,
  unitStatus: requestStatus.IDLE,
  unitGraphStatus: requestStatus.IDLE,

  // result
  filterList: [],
  individuList: [],
  unitList: [],

  error: null,
  send: null,
};

export function ReducerProduction(state = initialStateProduction, action) {
  switch (action.type) {
    case RESET_ALL_STATE: return initialStateProduction;

    // Reducer Main Production - FETCH //
    case PROD_INDIVIDU_YTD.FETCH: return { ...state, individuStatus: requestStatus.FETCH };
    case PROD_INDIVIDU_BY_RANGE.FETCH: return { ...state, individuRangeStatus: requestStatus.FETCH };
    case PROD_UNIT_YTD.FETCH: return { ...state, unitStatus: requestStatus.FETCH };
    case PROD_UNIT_BY_RANGE.FETCH: return { ...state, unitRangeStatus: requestStatus.FETCH };
    case PROD_GRAPH_DETAIL_INDIVIDU.FETCH: return { ...state, individuGraphStatus: requestStatus.FETCH };
    case PROD_GRAPH_DETAIL_UNIT.FETCH: return { ...state, unitGraphStatus: requestStatus.FETCH };

    // Reducer Main Production - SUCCESS //
    case PROD_INDIVIDU_YTD.SUCCESS: return { ...state, individuStatus: requestStatus.SUCCESS };
    case PROD_INDIVIDU_BY_RANGE.SUCCESS: return { ...state, individuRangeStatus: requestStatus.SUCCESS };
    case PROD_UNIT_YTD.SUCCESS: return { ...state, unitStatus: requestStatus.SUCCESS };
    case PROD_UNIT_BY_RANGE.SUCCESS: return { ...state, unitRangeStatus: requestStatus.SUCCESS };
    case PROD_GRAPH_DETAIL_INDIVIDU.SUCCESS: return { ...state, individuGraphStatus: requestStatus.SUCCESS };
    case PROD_GRAPH_DETAIL_UNIT.SUCCESS: return { ...state, unitGraphStatus: requestStatus.SUCCESS };

    // Reducer Main Production - FAILED //
    case PROD_INDIVIDU_YTD.FAILED: return { ...state, individuStatus: requestStatus.FAILED };
    case PROD_INDIVIDU_BY_RANGE.FAILED: return { ...state, individuRangeStatus: requestStatus.FAILED };
    case PROD_UNIT_YTD.FAILED: return { ...state, unitStatus: requestStatus.FAILED };
    case PROD_UNIT_BY_RANGE.FAILED: return { ...state, unitRangeStatus: requestStatus.FAILED };
    case PROD_GRAPH_DETAIL_INDIVIDU.FAILED: return { ...state, individuGraphStatus: requestStatus.FAILED };
    case PROD_GRAPH_DETAIL_UNIT.FAILED: return { ...state, unitGraphStatus: requestStatus.FAILED };

    // Reducer Find List Transaction - FETCH //
    case FIND_TRANSACTION_INDIVIDU_MONTHLY.FETCH: return { ...state, individuListStatus: requestStatus.FETCH, send: action.payload };
    case FIND_TRANSACTION_INDIVIDU_YEARLY.FETCH: return { ...state, individuListStatus: requestStatus.FETCH, send: action.payload };
    case FIND_TRANSACTION_UNIT_YEARLY.FETCH: return { ...state, unitListStatus: requestStatus.FETCH, send: action.payload };
    case FIND_TRANSACTION_UNIT_MONTHLY.FETCH: return { ...state, unitListStatus: requestStatus.FETCH, send: action.payload };

    case FIND_TRANSACTION_LIST_FILTER.FETCH: return { ...state, filterStatus: requestStatus.FETCH, send: action.payload };
    case FIND_AGENT_TYPE_LIST_FILTER.FETCH: return { ...state, filterStatus: requestStatus.FETCH, send: action.payload };

    // Reducer Find List Transaction - SUCCESS //
    case FIND_TRANSACTION_INDIVIDU_MONTHLY.SUCCESS:
      return {
        ...state,
        individuListStatus: requestStatus.SUCCESS,
        individuList: state.individuList.length ?
          [...state.individuList, ...action.payload.filter(x => !state.individuList.some(item => item.policyNumber === x.policyNumber))]
          : action.payload,
      };

    case FIND_TRANSACTION_INDIVIDU_YEARLY.SUCCESS:
      return {
        ...state,
        individuListStatus: requestStatus.SUCCESS,
        individuList: state.individuList.length ?
          [...state.individuList, ...action.payload.filter(x => !state.individuList.some(item => item.policyNumber === x.policyNumber))]
          : action.payload,
      };

    case FIND_TRANSACTION_UNIT_MONTHLY.SUCCESS:
      return {
        ...state,
        unitListStatus: requestStatus.SUCCESS,
        unitList: state.unitList.length ?
          [...state.unitList, ...action.payload.filter(x => !state.unitList.some(item => item.agentNumber === x.agentNumber))]
          : action.payload,
      };

    case FIND_TRANSACTION_UNIT_YEARLY.SUCCESS:
      return {
        ...state,
        unitListStatus: requestStatus.SUCCESS,
        unitList: state.unitList.length ?
          [...state.unitList, ...action.payload.filter(x => !state.unitList.some(item => item.agentNumber === x.agentNumber))]
          : action.payload,
      };

    case FIND_TRANSACTION_LIST_FILTER.SUCCESS: return { ...state, filterList: action.payload, filterStatus: requestStatus.SUCCESS };
    case FIND_AGENT_TYPE_LIST_FILTER.SUCCESS: return { ...state, filterList: action.payload, filterStatus: requestStatus.SUCCESS };

    // Reducer Find List Transaction - FAILED //
    case FIND_TRANSACTION_INDIVIDU_MONTHLY.FAILED: return { ...state, individuListStatus: requestStatus.FAILED, error: action.payload };
    case FIND_TRANSACTION_INDIVIDU_YEARLY.FAILED: return { ...state, individuListStatus: requestStatus.FAILED, error: action.payload };
    case FIND_TRANSACTION_UNIT_MONTHLY.FAILED: return { ...state, unitListStatus: requestStatus.FAILED, error: action.payload };
    case FIND_TRANSACTION_UNIT_YEARLY.FAILED: return { ...state, unitListStatus: requestStatus.FAILED, error: action.payload };

    case FIND_TRANSACTION_LIST_FILTER.FAILED: return { ...state, filterStatus: requestStatus.FAILED, error: action.payload };
    case FIND_AGENT_TYPE_LIST_FILTER.FAILED: return { ...state, filterStatus: requestStatus.FAILED, error: action.payload };

    // Reducer Find History List Production - FETCH //
    case PROD_HISTORY_LIST_INDIVIDU.FETCH: return { ...state, individuListStatus: requestStatus.FETCH, send: action.payload };
    case PROD_HISTORY_LIST_UNIT.FETCH: return { ...state, unitListStatus: requestStatus.FETCH, send: action.payload };

    // Reducer Find History List Transaction - SUCCESS //
    case PROD_HISTORY_LIST_INDIVIDU.SUCCESS:
      return {
        ...state,
        individuListStatus: requestStatus.SUCCESS,
        individuList: !isArrayEmpty(state.individuList) ?
          [...state.individuList, ...action.payload.filter(x => !state.individuList.some(item => item.policyNumber === x.policyNumber))]
          : action.payload,
      };

    case PROD_HISTORY_LIST_UNIT.SUCCESS:
      return {
        ...state,
        unitListStatus: requestStatus.SUCCESS,
        unitList: state.unitList.length ?
          [...state.unitList, ...action.payload.filter(x => !state.unitList.some(item => item.agentNumber === x.agentNumber))]
          : action.payload,
      };

    // Reducer Find History List Transaction - FAILED //
    case PROD_HISTORY_LIST_INDIVIDU.FAILED: return { ...state, individuListStatus: requestStatus.FAILED, error: action.payload };
    case PROD_HISTORY_LIST_UNIT.FAILED: return { ...state, unitListStatus: requestStatus.FAILED, error: action.payload };

    // Reducer Clear List
    case RESET_PRODUCTION.MAIN: return initialStateProduction;
    case RESET_PRODUCTION.INDIVIDU: return { ...state, individuListStatus: requestStatus.IDLE, individuList: [] };
    case RESET_PRODUCTION.UNIT: return { ...state, unitListStatus: requestStatus.IDLE, unitList: [] };
    case RESET_PRODUCTION.FILTER: return { ...state, filterStatus: requestStatus.IDLE, filterList: [] };
    case RESET_PRODUCTION.HISTORY:
      return {
        ...state,
        individuDetailStatus: requestStatus.IDLE,
        unitDetailStatus: requestStatus.IDLE,
        unitDetail: [],
      };

    default:
      return state;
  }
}
