/* eslint-disable max-len */
import { requestStatus } from '../../utilities/ApiConnection';
import { RESET_ALL_STATE } from '../dashboard/ConfigDashboard';
import {
  GET_PROSPECT_LIST, CLEAR_PROSPECT, GET_CONTACT, POST_CONTACT, UPDATE_CONTACT_CHECK, POST_PROSPECT,
  PROSPECT_DETAIL, INPUT_FEEDBACK_LIST, FEEDBACK_POINT, ADD_FEEDBACK_AM,
  GET_POINT_INDIVIDU, GET_CONVERTION_INDIVIDU, GET_HISTORY_INDIVIDU, AM_DASHBOARD, AM_CALENDAR_DATA, CLEAR_DASHBOARD, EDIT_PROSPECT,
} from './ConfigActivity';

// const asDefault = {
//   arrIdle: { status: requestStatus.IDLE, data: [] },
//   arrFetch: { status: requestStatus.FETCH, data: [] },
//   arrFailed: { status: requestStatus.FAILED, data: [] },
//   objIdle: { status: requestStatus.IDLE, data: {} },
//   objFetch: { status: requestStatus.FETCH, data: {} },
//   objFailed: { status: requestStatus.FAILED, data: {} },
// };

const initialStateActivity = {
  // status
  prospectListStatus: requestStatus.IDLE,
  contactListStatus: requestStatus.IDLE,
  postContactStatus: requestStatus.IDLE,
  postProspectStatus: requestStatus.IDLE,
  editProspectStatus: requestStatus.IDLE,

  // result
  prospectList: [],
  contactList: [],

  error: null,
  send: null,

  inputFeedback: { status: requestStatus.IDLE, data: [] },
  prospectDetail: { status: requestStatus.IDLE, data: {} },
  feedbackPoint: { status: requestStatus.IDLE, data: [] },
  addFeedback: { status: requestStatus.IDLE, data: null },

  // dashboard
  pointDetails: { status: requestStatus.IDLE, data: [], filter: [] },
  convertionDetails: { status: requestStatus.IDLE, data: [], filter: [] },
  historyDetails: { status: requestStatus.IDLE, data: [], filter: [] },
  dashboard: { status: requestStatus.IDLE, data: {} },
  calendar: { status: requestStatus.IDLE, data: {} },
};

export function ReducerActivity(state = initialStateActivity, action) {
  switch (action.type) {
    case RESET_ALL_STATE: return initialStateActivity;

    case GET_PROSPECT_LIST.FETCH: return { ...state, prospectListStatus: requestStatus.FETCH, send: action.payload };
    case GET_PROSPECT_LIST.SUCCESS: return {
      ...state,
      prospectListStatus: requestStatus.SUCCESS,
      prospectList: state.prospectList.length ? [...state.prospectList, ...action.payload.filter(x => !state.prospectList.some(item => item.id === x.id))]
        : action.payload,
    };
    case GET_PROSPECT_LIST.FAILED: return { ...state, prospectListStatus: requestStatus.FAILED, error: action.payload };
    case CLEAR_PROSPECT.LIST: return { ...state, prospectListStatus: requestStatus.IDLE, prospectList: [] };

    case GET_CONTACT.FETCH: return { ...state, contactListStatus: requestStatus.FETCH, send: action.payload };
    case GET_CONTACT.SUCCESS: return {
      ...state,
      contactListStatus: requestStatus.SUCCESS,
      contactList: state.contactList.length ? [...state.contactList, ...action.payload.body.data.filter(x => !state.prospectList.some(item => item.id === x.id))]
        : action.payload.body.data,
    };
    case GET_CONTACT.FAILED: return { ...state, contactListStatus: requestStatus.FAILED, error: action.payload };
    case CLEAR_PROSPECT.CONTACT: return { ...state, contactListStatus: requestStatus.IDLE, contactList: [] };

    case POST_CONTACT.FETCH: return { ...state, postContactStatus: requestStatus.FETCH, send: action.payload };
    case POST_CONTACT.SUCCESS: return { ...state, postContactStatus: requestStatus.SUCCESS };
    case POST_CONTACT.FAILED: return { ...state, postContactStatus: requestStatus.FAILED, error: action.payload };

    case POST_PROSPECT.FETCH: return { ...state, postProspectStatus: requestStatus.FETCH, send: action.payload };
    case POST_PROSPECT.SUCCESS: return { ...state, postProspectStatus: requestStatus.SUCCESS };
    case POST_PROSPECT.FAILED: return { ...state, postProspectStatus: requestStatus.FAILED, error: action.payload };

    case EDIT_PROSPECT.FETCH: return { ...state, editProspectStatus: requestStatus.FETCH, send: action.payload };
    case EDIT_PROSPECT.SUCCESS: return { ...state, editProspectStatus: requestStatus.SUCCESS };
    case EDIT_PROSPECT.FAILED: return { ...state, editProspectStatus: requestStatus.FAILED, error: action.payload };

    case UPDATE_CONTACT_CHECK: return { ...state, contactList: action.payload };

    case PROSPECT_DETAIL.RESET: return { ...state, prospectDetail: initialStateActivity.prospectDetail };
    case PROSPECT_DETAIL.FETCH: return { ...state, prospectDetail: { status: requestStatus.FETCH, data: {} } };
    case PROSPECT_DETAIL.SUCCESS: return { ...state, prospectDetail: { status: requestStatus.SUCCESS, data: action.payload } };
    case PROSPECT_DETAIL.FAILED: return { ...state, error: action.payload, prospectDetail: { status: requestStatus.FETCH, data: {} } };
    case PROSPECT_DETAIL.SET: return { ...state, prospectDetail: { status: requestStatus.IDLE, data: action.payload } };

    case INPUT_FEEDBACK_LIST.FETCH: return { ...state, inputFeedback: { status: requestStatus.FETCH, data: [] } };
    case INPUT_FEEDBACK_LIST.SUCCESS: return { ...state, inputFeedback: { status: requestStatus.SUCCESS, data: action.payload } };
    case INPUT_FEEDBACK_LIST.FAILED: return { ...state, error: action.payload, inputFeedback: { status: requestStatus.FAILED, data: [] } };

    case FEEDBACK_POINT.FETCH: return { ...state, feedbackPoint: { status: requestStatus.FETCH, data: [] } };
    case FEEDBACK_POINT.SUCCESS: return { ...state, feedbackPoint: { status: requestStatus.SUCCESS, data: action.payload.body.data } };
    case FEEDBACK_POINT.FAILED: return { ...state, error: action.payload, feedbackPoint: { status: requestStatus.FAILED, data: [] } };

    case ADD_FEEDBACK_AM.FETCH: return { ...state, addFeedback: { status: requestStatus.FETCH, data: null } };
    case ADD_FEEDBACK_AM.SUCCESS: return { ...state, addFeedback: { status: requestStatus.SUCCESS, data: action.payload } };
    case ADD_FEEDBACK_AM.FAILED: return { ...state, error: action.payload, addFeedback: { status: requestStatus.FAILED, data: null } };

    case GET_POINT_INDIVIDU.FETCH: return { ...state, pointDetails: { ...state.pointDetails, status: requestStatus.FETCH } };
    case GET_POINT_INDIVIDU.SUCCESS: return {
      ...state,
      pointDetails: {
        status: requestStatus.SUCCESS,
        data: state.pointDetails.data.length ? [...state.pointDetails.data, ...action.payload.body.data.filter(x => !state.pointDetails.data.some(item => item.id === x.id))]
          : action.payload.body.data,
        filter: action.payload.body.filterList.feedback,
      },
    };
    case GET_POINT_INDIVIDU.FAILED: return { ...state, error: action.payload, pointDetails: { status: requestStatus.FAILED, data: [] } };
    case CLEAR_DASHBOARD.POINT: return { ...state, pointDetails: { status: requestStatus.IDLE, data: [] } };

    case GET_CONVERTION_INDIVIDU.FETCH: return { ...state, convertionDetails: { ...state.convertionDetails, status: requestStatus.FETCH } };
    case GET_CONVERTION_INDIVIDU.SUCCESS: return {
      ...state,
      convertionDetails: {
        status: requestStatus.SUCCESS,
        data: state.convertionDetails.data.length ? [...state.convertionDetails.data, ...action.payload.filter(x => !state.convertionDetails.data.some(item => item.id === x.id))]
          : action.payload,
      },
    };
    case GET_CONVERTION_INDIVIDU.FAILED: return { ...state, error: action.payload, convertionDetails: { status: requestStatus.FAILED, data: [] } };
    case CLEAR_DASHBOARD.CONVERTION: return { ...state, convertionDetails: { status: requestStatus.IDLE, data: [] } };

    case GET_HISTORY_INDIVIDU.FETCH: return { ...state, historyDetails: { ...state.historyDetails, status: requestStatus.FETCH } };
    case GET_HISTORY_INDIVIDU.SUCCESS: return {
      ...state,
      historyDetails: {
        status: requestStatus.SUCCESS,
        data: state.historyDetails.data.length ? [...state.historyDetails.data, ...action.payload.filter(x => !state.historyDetails.data.some(item => item.id === x.id))]
          : action.payload,
      },
    };
    case GET_HISTORY_INDIVIDU.FAILED: return { ...state, error: action.payload, historyDetails: { status: requestStatus.FAILED, data: [] } };
    case CLEAR_DASHBOARD.HISTORY: return { ...state, historyDetails: { status: requestStatus.IDLE, data: [] } };

    case AM_DASHBOARD.FETCH: return { ...state, dashboard: { status: requestStatus.FETCH, data: {} } };
    case AM_DASHBOARD.SUCCESS: return { ...state, dashboard: { status: requestStatus.SUCCESS, data: action.payload !== null ? action.payload : {} } };
    case AM_DASHBOARD.FAILED: return { ...state, error: action.payload, dashboard: { status: requestStatus.FAILED, data: {} } };

    case AM_CALENDAR_DATA.FETCH: return { ...state, calendar: { status: requestStatus.FETCH, data: {} } };
    case AM_CALENDAR_DATA.SUCCESS: return { ...state, calendar: { status: requestStatus.SUCCESS, data: action.payload } };
    case AM_CALENDAR_DATA.FAILED: return { ...state, error: action.payload, calendar: { status: requestStatus.FAILED, data: {} } };

    default:
      return state;
  }
}
