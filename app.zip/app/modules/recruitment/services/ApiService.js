/* eslint-disable no-restricted-syntax */
import { resourceRequest } from '../../../utilities/StoreApi';
import { sagaWatcherErrorHandling as errorHandling } from '../../../utilities/ErrorHandling';

import Database from '../../../config/Database';
import { isArrayEmpty } from '../../../utilities';

const requestToApi = request => new Promise(async (resolve, reject) => {
  try {
    const requestParams = {};
    requestParams.headers = request.data.headers;
    if (typeof request.parameters.params === 'string') {
      requestParams.params = request.parameters;
    } else if (typeof request.parameters.params === 'object') {
      requestParams.params = JSON.stringify(request.parameters.params);
    } else if (isArrayEmpty(request.parameters)) {
      requestParams.params = '[""]';
    } else {
      requestParams.params = request.parameters;
    }
    console.log(`REQUEST PARAMS ${request.adapter}: `, requestParams);
    const resAccessToken = await resourceRequest(request.adapter, request.method, requestParams, 300000);
    console.log(`RESULT ${request.adapter}`, resAccessToken);
    if ((resAccessToken.status === '200' || resAccessToken.status === 200)) {
      resolve(resAccessToken.data);
    } if (resAccessToken.data.respDesc) {
      reject(resAccessToken.data.respDesc);
    } else {
      resolve(resAccessToken.data);
    }
  } catch (error) {
    const parseError = errorHandling(error);
    console.log(`ERROR ${request.adapter}`, parseError);
    reject(parseError);
  }
});

const getAllProcedure = () => {
  const {
    general, pruForce,
  } = Database;
  const result = {};

  // get all db
  // Object.assign(result, getProcedureInDB(newSqs));
  // Object.assign(result, getProcedureInDB(pruSmart));
  // Object.assign(result, getProcedureInDB(inquiries));
  Object.assign(result, getProcedureInDB(general));
  Object.assign(result, getProcedureInDB(pruForce));

  return result;
};

const getProcedureInDB = (db) => {
  const resultDB = {};
  // extract procedure from table
  for (const key in db) {
    if (Object.prototype.hasOwnProperty.call(db, key)) {
      if (key !== 'name') {
        Object.assign(resultDB, getAllProcedureFromTable(db[key], db.name));
      }
    }
  }
  return resultDB;
};

const getAllProcedureFromTable = (tables, dbName) => {
  const procedure = {};
  // extract procedure from table
  for (const key in tables) {
    if (Object.prototype.hasOwnProperty.call(tables, key)) {
      if (key !== 'name') {
        // eslint-disable-next-line guard-for-in
        for (const procedureKey in tables[key]) {
          if (procedureKey !== 'name') {
            procedure[procedureKey] = tables[key][procedureKey];
            if (tables[key].name !== undefined) {
              procedure[procedureKey].table = tables[key].name;
            } else if (tables[key][procedureKey].name !== undefined) {
              procedure[procedureKey].table = tables[key][procedureKey].name;
            }
            procedure[procedureKey].db = dbName;
          }
        }
      }
    }
  }
  return procedure;
};

export default {
  requestToApi,
  getAllProcedure,
};
