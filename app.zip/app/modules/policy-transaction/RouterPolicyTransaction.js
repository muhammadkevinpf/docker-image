import Views from './views';

export default {
  SwitchingPolicy: Views.SwitchingPolicy,
  TopupPolicyFirstPage: Views.TopupPolicy.FirstPage,
  TopupPolicySecondPage: Views.TopupPolicy.SecondPage,
  TopupPolicyThirdPage: Views.TopupPolicy.ThirdPage,
};
