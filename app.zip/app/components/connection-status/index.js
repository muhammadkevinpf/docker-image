/* eslint-disable no-console */
/**
 * @author: ecomindo
*/

import React, { PureComponent, Fragment } from 'react';
import { Icon } from 'native-base';
import { connect } from 'react-redux';
import BackgroundTimer from 'react-native-background-timer';
import Style from '../../styles';
import { getConnectionStatus } from '../../utilities/ApiConnection';
import { updateConnectionStatus } from '../../modules/auth/ActionAuth';
import { CONNECTIONONLINE, CONNECTIONOFFLINE } from '../../modules/auth/ConfigAuth';

// CONFIGURATION
const INTERVAL_ATTEMPT = 3000;

class ConnectionStatus extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isConnected: props.isOnline,
    };
  }

  componentDidMount() {
    this._mounted = true;
    this._interval = BackgroundTimer.setInterval(async () => {
      try {
        // let SERVER_URL = await WLClient.getServerUrl();
        // let index = SERVER_URL.lastIndexOf('pruforce');
        // if (SERVER_URL.includes('https')) index = (SERVER_URL.lastIndexOf('api') - 1);
        // SERVER_URL = SERVER_URL.substring(0, index);
        // const status = await getConnectionStatus(SERVER_URL);
        const status = await getConnectionStatus();
        this.isConnected(status);
      } catch (error) {
        console.log('GET CONNECTION STATUS ERROR: ', error);
        this.isConnected(false);
      }
    }, INTERVAL_ATTEMPT);
  }

  componentWillUnmount() {
    this.mounted = false;
    BackgroundTimer.clearInterval(this._interval);
  }

  isConnected = (isConnected) => {
    if (this.state.isConnected !== isConnected) {
      if (this._mounted) {
        this.setState({ isConnected }, () => this.props.updateConnectionStatus(isConnected ? CONNECTIONONLINE : CONNECTIONOFFLINE, isConnected));
      }
    }
  }

  render() {
    const { isConnected } = this.state;
    return (
      <Fragment>
        <Icon
          name="lens"
          type="MaterialIcons"
          style={[(isConnected === true ? Style.Main.textOnline : Style.Main.textOffline), Style.Main.font18]}
        />
      </Fragment>
    );
  }
}

const mapStateToProps = state => ({
  isOnline: state.connectionStatus.isOnline,
});

const mapDispatchToProps = dispatch => ({
  updateConnectionStatus: (type, status) => dispatch(updateConnectionStatus(type, status)),
});
export default connect(mapStateToProps, mapDispatchToProps)(ConnectionStatus);
