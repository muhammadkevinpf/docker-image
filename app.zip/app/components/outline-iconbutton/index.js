/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { PureComponent } from 'react';
import {
  View, Text, TouchableOpacity, Image,
} from 'react-native';
import PropTypes from 'prop-types';
// import { Thumbnail } from 'native-base';
import { isTablet } from '../../utilities';
import Style from '../../styles';

class OutlineIconbutton extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  render() {
    // const iosOnPressIn = Platform.OS === 'android' ? (() => this.props.onPressIn()) : (() => {});
    // const iosOnPressOut = Platform.OS === 'android' ? (() => this.props.onPressOut()) : (() => {});
    return (
      <View style={[Style.Main.container, this.props.disable && Style.Main.quarterOpacity, Style.Main.center]}>
        <TouchableOpacity
          activeOpacity={this.props.disable ? 1 : 0.5}
          onPress={this.props.disable ? (() => {}) : (() => this.props.onPress())}
          // onPressIn={this.props.disable ? (() => {}) : iosOnPressIn}
          // onPressOut={this.props.disable ? (() => {}) : iosOnPressOut}
          style={[Style.Main.alignCenter, Style.Main.container, Style.Main.center, this.props.buttonstyle]}
        >
          <Image
            source={this.props.iconImage}
            style={[Style.Main.alignCenter, Style.Main.outlineIconButton, Style.Main.resizeContain]}
          />
          <Text style={[Style.Main.textCenter, Style.Main.font11, !isTablet() && Style.Main.mb10, Style.Main.mt3,
            Style.Main.textLineHeight15, Style.Main.fontAlbert, this.props.labelstyle]}
          >{this.props.label}
          </Text>
        </TouchableOpacity>
      </View>
    );
  }
}

OutlineIconbutton.propTypes = {
  label: PropTypes.string,
  onPress: PropTypes.func,
  // onPressIn: PropTypes.func,
  // onPressOut: PropTypes.func,
  labelstyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  iconImage: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  buttonstyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  disable: PropTypes.bool,
};

OutlineIconbutton.defaultProps = {
  label: '',
  onPress: () => {},
  // onPressIn: () => {},
  // onPressOut: () => {},
  labelstyle: {},
  iconImage: '',
  buttonstyle: {},
  disable: false,
};

export default OutlineIconbutton;
