const subMenuGroups = {
  achievement: 'achievement',
  cps: 'cps',
  leads: 'leads',
  document: 'document',
};

const ProductionRoutes = [
  'MainProduction',
  'ProductionHistoryDetail',
  'ProductionUnitList',
  'ProductionIndividuList',
];

const PersitencyRoutes = [
  'MainPersistency',
  'PersistencyGroupUnit',
  'PersistencyIndividu',
  'PersistencyHistoryScreen',
];

const ProposalPolicyRoutes = [
  'MainProposalPolicy',
  'ProposalPolicyList',
  'ProposalPolicyListByUnit',
];

const CommissionEstimationRoutes = [
  'MainCommissionEstimation',
];

const IncomeStatementRoutes = [
  'MainIncomeStatement',
  'IncomeStatement',
  'CommissionDetail',
  'IncomeHistoryDetail',
  'TaxSlipPreview',
  'TaxSlipList',
];

const ProspectRoutes = [
  'ProspectList',
  'ActivitySyncContact',
  'ProspectInputFeedback',
  'ProspectDetail',
  'AddProspect',
  'EditProspect',
];

const DashboardRoutes = [
  'AMDashboard',
  'DashboardPointDetails',
  'DashboardConvertionDetails',
  'DashboardHistoryDetails',
];

const CalendarRoutes = [
  'AMCalendar',
];

const CorrespondenceRoutes = [
  'CorrespondenceList',
  'CorrespondenceDocPreview',
];

const DownloadFileRoutes = [
  'DownloadFileList',
  'DownloadDocPreview',
];

export default {
  subMenuGroups,
  ProductionRoutes,
  PersitencyRoutes,
  ProposalPolicyRoutes,
  CommissionEstimationRoutes,
  IncomeStatementRoutes,
  ProspectRoutes,
  DashboardRoutes,
  CalendarRoutes,
  CorrespondenceRoutes,
  DownloadFileRoutes,
};
