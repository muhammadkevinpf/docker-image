/**
 * @author: dwi.setiyadi@gmail.com
*/

import {
  call, put, takeLatest,
} from 'redux-saga/effects';
import {
  SIGNINFETCH, SIGNINAPI,
  USERPROFILEFETCH, USERPROFILEAPI,
  USERAVATARFETCH, USERAVATARAPI,
  SIGNOUTFETCH, SIGNOUTAPI, VAAPI, VAFETCH,
} from './ConfigAuth';
import {
  signInSuccess,
  signInFailed,
  userProfileFetch,
  userProfileSuccess,
  userProfileFailed,
  userAvatarFetch,
  userAvatarSuccess,
  userAvatarFailed,
  signOutSuccess,
  signOutFailed,
  vaSuccess,
  vaFailed,
} from './ActionAuth';
import {
  totalToDoFetch,
} from '../todo-list/ActionTodoList';
import {
  totalNotificationFetch,
} from '../notification/ActionNotification';
import { resourceRequest } from '../../utilities/StoreApi';
import { sagaWatcherErrorHandling } from '../../utilities/ErrorHandling';

function* workerSagaSignIn(params) {
  try {
    const resAccessToken = yield call(resourceRequest, SIGNINAPI, 'post', params.send);
    const {
      message, statusCode, errorCode, errorMessage,
    } = resAccessToken.data;
    if (
      (resAccessToken.status === '200' || resAccessToken.status === 200) &&
      (resAccessToken.data.access_token !== undefined)) {
      if (resAccessToken.data.agent_channelType === '1' || resAccessToken.data.agent_channelType === 1) {
        yield put.resolve(signInFailed({ code: '004', message: 'PRUFast ID atau Password salah' }));
        return;
      }
      const paramsProfile = {
        headers: [
          {
            keyHeader: 'X-CSRF-Token',
            valueHeader: `Bearer ${resAccessToken.data.access_token}`,
          },
        ],
        accessToken: resAccessToken.data,
      };
      yield put(userProfileFetch(paramsProfile));
      yield put.resolve(signInSuccess(resAccessToken.data));
    } else {
      yield put.resolve(signInFailed({ code: errorCode || statusCode, message: message || errorMessage }));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(signInFailed({ code: '999', message: parseError }));
  }
}

function* workerSagaUserProfile(params) {
  try {
    const { accessToken } = params.send;
    delete params.send.accessToken; // eslint-disable-line no-param-reassign

    const resProfile = yield call(resourceRequest, USERPROFILEAPI, 'post', params.send);

    if ((resProfile.status === '200' || resProfile.status === 200)) {
      const paramsAvatar = {
        headers: [
          {
            keyHeader: 'X-CSRF-Token',
            valueHeader: `Bearer ${accessToken.access_token}`,
          },
        ],
        params: `["${accessToken.username}", "${resProfile.data.agentCode}", "Image_${resProfile.data.agentCode}.jpg", "agentProfile"]`, // eslint-disable-line
      };
      yield put(userAvatarFetch(paramsAvatar));

      const paramsTotalToDo = {
        headers: [
          {
            keyHeader: 'X-CSRF-Token',
            valueHeader: `Bearer ${accessToken.access_token}`,
          },
        ],
        params: `["${resProfile.data.agentCode}", "${accessToken.username}"]`,
      };
      yield put(totalToDoFetch(paramsTotalToDo));

      const paramsTotalNotification = {
        headers: [
          {
            keyHeader: 'X-CSRF-Token',
            valueHeader: `Bearer ${accessToken.access_token}`,
          },
        ],
        params: `["${resProfile.data.agentCode}", "All"]`,
      };
      yield put(totalNotificationFetch(paramsTotalNotification));

      yield put.resolve(userProfileSuccess(resProfile.data));
    } else {
      yield put.resolve(userProfileFailed(resProfile.data.errorMessage));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(userProfileFailed(parseError));
  }
}

function* workerSagaUserAvatar(params) {
  try {
    const resAvatar = yield call(resourceRequest, USERAVATARAPI, 'post', params.send);

    if ((resAvatar.status === '200' || resAvatar.status === 200)) {
      yield put.resolve(userAvatarSuccess(resAvatar.data));
    } else {
      yield put.resolve(userAvatarFailed(resAvatar.data.errorMessage));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(userAvatarFailed(parseError));
  }
}

function* workerSagaSignOut(params) {
  try {
    const resSignOut = yield call(resourceRequest, SIGNOUTAPI, 'post', params.send);

    if ((resSignOut.status === '200' || resSignOut.status === 200)) {
      yield put.resolve(signOutSuccess(resSignOut.data));
    } else {
      yield put.resolve(signInFailed(resSignOut.data.errorMessage));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(signOutFailed(parseError));
  }
}

function* workerSagaVaNumber(params) {
  try {
    const res = yield call(resourceRequest, VAAPI, 'post', params.send);
    if ((res.status === '200' || res.status === 200) && res.data.vaList) {
      yield put.resolve(vaSuccess(res.data));
    } else {
      yield put.resolve(vaFailed(res.data.responseMessage));
    }
  } catch (error) {
    const parseError = sagaWatcherErrorHandling(error);
    yield put.resolve(vaFailed(parseError));
  }
}

export const watcherAuth = [
  takeLatest(SIGNINFETCH, workerSagaSignIn),
  takeLatest(USERPROFILEFETCH, workerSagaUserProfile),
  takeLatest(USERAVATARFETCH, workerSagaUserAvatar),
  takeLatest(SIGNOUTFETCH, workerSagaSignOut),
  takeLatest(VAFETCH, workerSagaVaNumber),
];
