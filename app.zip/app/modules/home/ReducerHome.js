import {
  // Branch office
  CITYBRANCHOFFICEFETCH,
  CITYBRANCHOFFICESUCCESS,
  CITYBRANCHOFFICEFAILED,

  BRANCHOFFICEFETCH,
  BRANCHOFFICESUCCESS,
  BRANCHOFFICEFAILED,

  // Hospital
  CITYHOSPITALFETCH,
  CITYHOSPITALSUCCESS,
  CITYHOSPITALFAILED,

  HOSPITALFETCH,
  HOSPITALSUCCESS,
  HOSPITALFAILED,

  CLEARHOSPITALANDOFFICELIST,

  // Forget
  FORGOT_PASSWORD, CHECK_AGENT_VERIFICATION, FORGOT_ID_CANDIDATE, SMS_VERIFICATION_AGENT, SMS_VERIFICATION_CANDIDATE,
  CHECK_EMAIL_VERIFICATION, CHECK_USER_ID, FORGOT_CHANGE_PASSWORD, GET_USER_ID, GET_SECURITY_QUESTIONS,
  CHECK_AGENT_BANCA_BY_AGENT_CODE, CHECK_AGENT_BANCA_BY_SALES_FORCE_ID, VERIFY_AGENT, CREATE_PRUFAST_ID, VERIFY_SECQUEST,
} from './ConfigHome';
import { requestStatus } from '../../utilities';

const initialStateHome = {
  fetchCityBranchOffice: false,
  fetchBranchOffice: false,
  fetchCityHospital: false,
  fetchHospital: false,

  forgotPasswordStatus: requestStatus.IDLE,
  checkAgentStatus: requestStatus.IDLE,
  forgotIdCandidateStatus: requestStatus.IDLE,

  smsVerificationStatus: requestStatus.IDLE,
  checkEmailStatus: requestStatus.IDLE,
  checkUserIdStatus: requestStatus.IDLE,
  getUserIdStatus: requestStatus.IDLE,
  verifyAgentStatus: requestStatus.IDLE,
  changePasswordStatus: requestStatus.IDLE,
  sequrityQuestionsStatus: requestStatus.IDLE,
  createIdStatus: requestStatus.IDLE,
  verifySqStatus: requestStatus.IDLE,

  checkAgentTypeStatus: requestStatus.IDLE,
  verifyBanca: false,

  forgotPassword: {},
  checkAgent: {},
  forgotIdCandidate: {},

  smsVerification: {},
  checkEmail: {},
  checkUserId: {},
  getUserId: {},
  verifyAgent: {},
  changePassword: {},
  createId: {},
  verifySq: {},

  sequrityQuestions: [],

  send: null,
  res: null,
  err: null,
};

export function ReducerHome(state = initialStateHome, action) {
  switch (action.type) {
    case CITYBRANCHOFFICEFETCH:
      return {
        ...state,
        fetchCityBranchOffice: true,
        send: action.send,
        action: action.type,
      };

    case CITYBRANCHOFFICESUCCESS:
      return {
        ...state,
        fetchCityBranchOffice: false,
        res: {
          ...state.res,
          cityBranchOffice: action.res,
        },
        err: null,
        action: action.type,
      };

    case CITYBRANCHOFFICEFAILED:
      return {
        ...state,
        fetchCityBranchOffice: false,
        err: action.err,
        action: action.type,
      };

    case BRANCHOFFICEFETCH:
      return {
        ...state,
        fetchBranchOffice: true,
        send: action.send,
        action: action.type,
      };

    case BRANCHOFFICESUCCESS:
      return {
        ...state,
        fetchBranchOffice: false,
        res: {
          ...state.res,
          branchOffice: state.res && state.res.branchOffice
            ? [...state.res.branchOffice, ...action.res] : action.res,
        },
        err: null,
        action: action.type,
      };

    case BRANCHOFFICEFAILED:
      return {
        ...state,
        fetchBranchOffice: false,
        err: action.err,
        action: action.type,
      };

    case CITYHOSPITALFETCH:
      return {
        ...state,
        fetchCityHospital: true,
        send: action.send,
        action: action.type,
      };

    case CITYHOSPITALSUCCESS:
      return {
        ...state,
        fetchCityHospital: false,
        res: {
          ...state.res,
          cityHospital: action.res,
        },
        err: null,
        action: action.type,
      };

    case CITYHOSPITALFAILED:
      return {
        ...state,
        fetchCityHospital: false,
        err: action.err,
        action: action.type,
      };

    case HOSPITALFETCH:
      return {
        ...state,
        fetchHospital: true,
        send: action.send,
        action: action.type,
      };

    case HOSPITALSUCCESS:
      return {
        ...state,
        fetchHospital: false,
        res: {
          ...state.res,
          hospital: state.res && state.res.hospital
            ? [...state.res.hospital, ...action.res] : action.res,
        },
        err: null,
        action: action.type,
      };

    case HOSPITALFAILED:
      return {
        ...state,
        fetchHospital: false,
        err: action.err,
        action: action.type,
      };

    case CLEARHOSPITALANDOFFICELIST:
      return {
        ...state,
        res: {
          ...state.res,
          hospital: [],
          branchOffice: [],
        },
      };

    case FORGOT_PASSWORD.FETCH: return { ...state, forgotPasswordStatus: requestStatus.FETCH };
    case FORGOT_PASSWORD.SUCCESS: return { ...state, forgotPassword: action.payload, forgotPasswordStatus: requestStatus.SUCCESS };
    case FORGOT_PASSWORD.FAILED: return { ...state, error: action.payload, forgotPasswordStatus: requestStatus.FAILED };

    case CHECK_AGENT_VERIFICATION.FETCH: return { ...state, checkAgentStatus: requestStatus.FETCH };
    case CHECK_AGENT_VERIFICATION.SUCCESS: return { ...state, checkAgent: action.payload, checkAgentStatus: requestStatus.SUCCESS };
    case CHECK_AGENT_VERIFICATION.FAILED: return { ...state, error: action.payload, checkAgentStatus: requestStatus.FAILED };

    case FORGOT_ID_CANDIDATE.FETCH: return { ...state, forgotIdCandidateStatus: requestStatus.FETCH };
    case FORGOT_ID_CANDIDATE.SUCCESS: return { ...state, forgotIdCandidate: action.payload, forgotIdCandidateStatus: requestStatus.SUCCESS };
    case FORGOT_ID_CANDIDATE.FAILED: return { ...state, error: action.payload, forgotIdCandidateStatus: requestStatus.FAILED };

    case SMS_VERIFICATION_AGENT.FETCH: return { ...state, smsVerificationStatus: requestStatus.FETCH };
    case SMS_VERIFICATION_AGENT.SUCCESS: return { ...state, smsVerification: action.payload, smsVerificationStatus: requestStatus.SUCCESS };
    case SMS_VERIFICATION_AGENT.FAILED: return { ...state, error: action.payload, smsVerificationStatus: requestStatus.FAILED };

    case SMS_VERIFICATION_CANDIDATE.FETCH: return { ...state, smsVerificationStatus: requestStatus.FETCH };
    case SMS_VERIFICATION_CANDIDATE.SUCCESS: return { ...state, smsVerification: action.payload, smsVerificationStatus: requestStatus.SUCCESS };
    case SMS_VERIFICATION_CANDIDATE.FAILED: return { ...state, error: action.payload, smsVerificationStatus: requestStatus.FAILED };

    case CHECK_EMAIL_VERIFICATION.FETCH: return { ...state, checkEmailStatus: requestStatus.FETCH };
    case CHECK_EMAIL_VERIFICATION.SUCCESS: return { ...state, checkEmail: action.payload, checkEmailStatus: requestStatus.SUCCESS };
    case CHECK_EMAIL_VERIFICATION.FAILED: return { ...state, error: action.payload, checkEmailStatus: requestStatus.FAILED };

    case CHECK_USER_ID.FETCH: return { ...state, checkUserIdStatus: requestStatus.FETCH };
    case CHECK_USER_ID.SUCCESS: return { ...state, checkUserId: action.payload, checkUserIdStatus: requestStatus.SUCCESS };
    case CHECK_USER_ID.FAILED: return { ...state, error: action.payload, checkUserIdStatus: requestStatus.FAILED };

    case GET_USER_ID.FETCH: return { ...state, getUserIdStatus: requestStatus.FETCH };
    case GET_USER_ID.SUCCESS: return { ...state, getUserId: action.payload, getUserIdStatus: requestStatus.SUCCESS };
    case GET_USER_ID.FAILED: return { ...state, error: action.payload, getUserIdStatus: requestStatus.FAILED };

    case VERIFY_AGENT.FETCH: return { ...state, verifyAgentStatus: requestStatus.FETCH };
    case VERIFY_AGENT.SUCCESS: return { ...state, verifyAgent: action.payload, verifyAgentStatus: requestStatus.SUCCESS };
    case VERIFY_AGENT.FAILED: return { ...state, error: action.payload, verifyAgentStatus: requestStatus.FAILED };

    case CREATE_PRUFAST_ID.FETCH: return { ...state, createIdStatus: requestStatus.FETCH };
    case CREATE_PRUFAST_ID.SUCCESS: return { ...state, createId: action.payload, createIdStatus: requestStatus.SUCCESS };
    case CREATE_PRUFAST_ID.FAILED: return { ...state, error: action.payload, createIdStatus: requestStatus.FAILED };

    case VERIFY_SECQUEST.FETCH: return { ...state, verifySqStatus: requestStatus.FETCH };
    case VERIFY_SECQUEST.SUCCESS: return { ...state, verifySq: action.payload, verifySqStatus: requestStatus.SUCCESS };
    case VERIFY_SECQUEST.FAILED: return { ...state, error: action.payload, verifySqStatus: requestStatus.FAILED };

    case FORGOT_CHANGE_PASSWORD.FETCH: return { ...state, changePasswordStatus: requestStatus.FETCH };
    case FORGOT_CHANGE_PASSWORD.SUCCESS: return { ...state, changePassword: action.payload, changePasswordStatus: requestStatus.SUCCESS };
    case FORGOT_CHANGE_PASSWORD.FAILED: return { ...state, error: action.payload, changePasswordStatus: requestStatus.FAILED };

    case GET_SECURITY_QUESTIONS.FETCH: return { ...state, sequrityQuestionsStatus: requestStatus.FETCH };
    case GET_SECURITY_QUESTIONS.SUCCESS: return { ...state, sequrityQuestions: action.payload, sequrityQuestionsStatus: requestStatus.SUCCESS };
    case GET_SECURITY_QUESTIONS.FAILED: return { ...state, error: action.payload, sequrityQuestionsStatus: requestStatus.FAILED };

    case CHECK_AGENT_BANCA_BY_SALES_FORCE_ID.FETCH: return {
      ...state, checkAgentTypeStatus: requestStatus.FETCH, verifyBanca: false, error: null,
    };
    case CHECK_AGENT_BANCA_BY_SALES_FORCE_ID.SUCCESS: return { ...state, checkAgentTypeStatus: requestStatus.SUCCESS, verifyBanca: action.payload };
    case CHECK_AGENT_BANCA_BY_SALES_FORCE_ID.FAILED: return { ...state, checkAgentTypeStatus: requestStatus.FAILED, error: action.payload };

    case CHECK_AGENT_BANCA_BY_AGENT_CODE.FETCH: return {
      ...state, checkAgentTypeStatus: requestStatus.FETCH, verifyBanca: false, error: null,
    };
    case CHECK_AGENT_BANCA_BY_AGENT_CODE.SUCCESS: return { ...state, checkAgentTypeStatus: requestStatus.SUCCESS, verifyBanca: action.payload };
    case CHECK_AGENT_BANCA_BY_AGENT_CODE.FAILED: return { ...state, checkAgentTypeStatus: requestStatus.FAILED, error: action.payload };

    default:
      return state;
  }
}
