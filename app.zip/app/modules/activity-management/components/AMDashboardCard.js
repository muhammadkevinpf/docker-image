/* eslint-disable react/no-array-index-key */
import React from 'react';
import { defaultTo } from 'lodash';
import { Text, View, Button } from 'native-base';
import { VictoryPie } from 'victory-native';
import {
  TabContainer, CardRedHeader, Skeleton, rowLayout,
} from '../../../components';
import Style from '../../../styles';
import Colors from '../../../styles/Colors';
import _ from '../../../lang';
import { FeedbackPointInfo } from './FeedbackPointInfo';

const HistoryGraph = ({ data = {}, isLoading = false }) => {
  const graph = [
    { x: _('Aktif'), y: defaultTo(data.active, 0), color: Colors.redPastel },
    { x: _('Proses'), y: defaultTo(data.process, 0), color: Colors.yellowPastel },
    { x: _('Gagal Menjual'), y: defaultTo(data.failed, 0), color: Colors.grayce },
    { x: _('Berhasil Menjual'), y: defaultTo(data.success, 0), color: Colors.greenPastel },
  ];

  const total = defaultTo(data.active, 0) + defaultTo(data.process, 0) + defaultTo(data.failed, 0) + defaultTo(data.success, 0);
  return (
    <Skeleton
      isLoading={isLoading}
      layout={[rowLayout({ w: '25%', h: 12 })]}
      style={[Style.Main.center, Style.Main.container, Style.Main.mt12, Style.Main.mb12]}
    >
      <Text style={[Style.Main.fontAlbert14]}>{total} {_('Prospek')}</Text>
      {
        !graph.every(item => item.y === 0) &&
        <View style={[Style.Main.rowDirection, Style.Main.mV15]}>
          <View style={[Style.Main.container, Style.Main.centerVertical, Style.Main.mr15]}>
            <VictoryPie
              padding={0}
              style={{ labels: { ...Style.Main.fontAlbert, ...Style.Main.font8, fill: Colors.white } }}
              width={130}
              height={130}
              labelRadius={140}
              labels={({ datum }) => `${datum.y}`}
              labelPosition="endAngle"
              colorScale={[Colors.redPastel, Colors.yellowPastel, Colors.grayce, Colors.greenPastel]}
              data={graph}
            />
          </View>
          <View style={[Style.Main.centerVertical, Style.Main.container]}>
            <View>
              {
                graph.map((item, index) => (
                  <View key={index} style={[Style.Main.rowDirection, Style.Main.mV2, Style.Main.pl2]}>
                    <View style={[Style.Main.legendStyle, Style.Main.alignCenter, { backgroundColor: item.color }]} />
                    <Text style={[Style.Main.ml10, Style.Main.fontAlbert11]}>{item.y} {item.x}</Text>
                  </View>
                ))
              }
            </View>
          </View>
        </View>
      }
    </Skeleton>
  );
};

const PointGraph = ({ data = {} }) => {
  const point = defaultTo(data.point, 0);
  const target = defaultTo(data.targetPoint, 0);
  return (
    <View>
      <View style={[Style.Main.overflowHide, Style.Main.container, Style.Main.height100, Style.Main.pt10, Style.Main.alignCenter]}>
        <View style={[Style.Main.alignCenter, Style.Main.center, Style.Main.mt15]}>
          <VictoryPie
            width={170}
            height={170}
            data={[
              { x: 1, y: point },
              { x: 2, y: target - point },
            ]}
            labels={() => null}
            innerRadius={60}
            cornerRadius={0}
            startAngle={-90}
            endAngle={90}
            style={{
              parent: { marginLeft: -3 },
              data: { fill: ({ datum }) => (datum.x === 1 ? Colors.redPastel : Colors.grayNearWhite) },
            }}
          />
        </View>
        <Text style={[Style.Main.fontAlbertBold12, Style.Main.fontAlbert, Style.Main.absolute, Style.Main.bottom20,
          Style.Main.alignCenter, Style.Main.displayFlex]}
        >{point} / {target}
        </Text>
      </View>
      <Text style={[Style.Main.fontAlbert11, Style.Main.alignCenter, Style.Main.mt12, Style.Main.mb12]}>
        {_(`Anda perlu mendapatkan ${target - point} poin lagi untuk mencapai target`)}
      </Text>
    </View>
  );
};

const DashboardCard = ({ title = '', Tag = View, ...props }) => {
  const tabs = [
    {
      key: 0, title: _('Hari Ini'), scene: <Tag data={props.data.today} isLoading={props.isLoading} />, value: 'day',
    },
    {
      key: 1, title: _('Minggu Ini'), scene: <Tag data={props.data.wtd} isLoading={props.isLoading} />, value: 'week',
    },
    {
      key: 2, title: _('MTD'), scene: <Tag data={props.data.mtd} isLoading={props.isLoading} />, value: 'month',
    },
    {
      key: 3, title: _('YTD'), scene: <Tag data={props.data.ytd} isLoading={props.isLoading} />, value: 'year',
    },
  ];

  return (
    <CardRedHeader header={props.isPoint ? (
      <View style={[Style.Main.rowDirectionSpaceBetween]}>
        <Text style={[Style.Main.fontAlbert16, Style.Main.textWhite]}>
          {_(title)}
        </Text>
        <FeedbackPointInfo iconStyle={[Style.Main.textWhite]} />
      </View>) : title}
    >
      <TabContainer
        routes={tabs}
        sceneMap={tabs}
        parentFunction={props.onIndexChange ? index => props.onIndexChange(tabs[index].value) : () => { }}
      />
      <Button block style={[Style.Main.btnPrimary, Style.Main.mV15, Style.Main.alignCenter]} onPress={props.onPress}>
        <Text style={[Style.Main.fontAlbert14]}>{_(`Lihat Rincian ${title}`)} </Text>
      </Button>
    </CardRedHeader>
  );
};

// eslint-disable-next-line max-len
const History = ({
  data = {}, onPress, onIndexChange, isLoading = false,
}) => <DashboardCard Tag={HistoryGraph} data={data} isLoading={isLoading} onPress={onPress} onIndexChange={onIndexChange} title="Riwayat" />;

const Point = ({ data = {}, onPress }) => <DashboardCard Tag={PointGraph} data={data} isPoint onPress={onPress} title="Poin" />;

const ConvertionCard = ({
  label, total = 0, lastCard, isLoading = false,
}) => (
  <Skeleton
    isLoading={isLoading}
    layout={[rowLayout({ w: '25%', h: 9 }), rowLayout({ w: '15%', h: 9 })]}
    style={[Style.Main.container, Style.Main.center, !lastCard && Style.Main.borderRightNativeBase]}
  >
    <Text style={[Style.Main.fontAlbert12]}>{_(label)}</Text>
    <Text style={[Style.Main.fontAlbert12]}>{total}</Text>
  </Skeleton>
);

const Convertion = ({ data = {}, onPress, isLoading = false }) => (
  <CardRedHeader header="Konversi">
    <View style={[Style.Main.rowDirection, Style.Main.py15, Style.Main.borderBottomNativeBase]}>
      <ConvertionCard isLoading={isLoading} label="Prospek" total={data.prospect} />
      <ConvertionCard isLoading={isLoading} label="Follow Up" total={data.followUp} />
      <ConvertionCard isLoading={isLoading} label="Closing" total={data.closing} lastCard />
    </View>
    <Button block style={[Style.Main.btnPrimary, Style.Main.mV15, Style.Main.alignCenter]} onPress={onPress}>
      <Text style={[Style.Main.fontAlbert14]}>{_('Lihat Rincian Konversi')} </Text>
    </Button>
  </CardRedHeader>
);

export const AMDashboardCard = {
  History,
  Convertion,
  Point,
};
