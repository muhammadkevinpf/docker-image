export function updateTopup(type, payload) { return { type, payload }; }
