/* eslint-disable prefer-destructuring */
/* eslint-disable no-nested-ternary */
/* eslint-disable max-len */
/* eslint-disable no-mixed-operators */
/* eslint-disable no-bitwise */
/* eslint-disable no-sequences */
/* eslint-disable no-multi-assign */
/* eslint-disable no-param-reassign */
/* eslint-disable no-unused-expressions */
/* eslint-disable eqeqeq */
/* eslint-disable react-native/no-inline-styles */
import React, { PureComponent, Fragment } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import PropTypes from 'prop-types';
import Icon from 'react-native-vector-icons/FontAwesome';
import {
  Menu, MenuOptions,
  MenuOption, MenuTrigger,
} from 'react-native-popup-menu';

import ModalCustom from '../modal-custom';
import StyleMorePopupMenu from './StyleMorePopupMenu';
import Styles from '../../styles';

class MorePopupMenu extends PureComponent {
  render() {
    const {
      menus, disabled, size,
      onPress, onDismiss, opened,
      color,
      defaultPopUpMenu, label,
    } = this.props;
    return (
      <Fragment>
        {
          defaultPopUpMenu
            ? (
              <Menu
                opened={opened}
                onBackdropPress={onDismiss}
                style={[Styles.Main.alignRight]}
              >
                <MenuTrigger
                  disabled={disabled}
                  onPress={onPress}
                >
                  <TouchableOpacity
                    activeOpacity={1}
                    style={[StyleMorePopupMenu.touchArea(this.props.size), this.props.menuStyle]}
                    disabled={disabled}
                  >
                    {label || (
                      <Icon
                        name="ellipsis-h"
                        size={size}
                        color={color}
                        style={{ alignSelf: 'center' }}
                      />
                    )}
                  </TouchableOpacity>
                </MenuTrigger>

                <MenuOptions>
                  {
                    menus.map((item, index) => (
                      <MenuOption
                        key={index.toString()}
                        value={index}
                        disabled={item.disabled}
                        disableTouchable={item.disableTouchable}
                        onSelect={() => { item.onPress(); onDismiss(); }}
                      >
                        <Text style={[StyleMorePopupMenu.menuContent]}>{item.text}</Text>
                        <View style={[StyleMorePopupMenu.menuSeparator]} />
                      </MenuOption>
                    ))
                  }
                </MenuOptions>
              </Menu>
            )
            : (
              <Fragment>
                <TouchableOpacity
                  activeOpacity={0.8}
                  style={[StyleMorePopupMenu.touchArea(this.props.touchArea ?? this.props.size), Styles.Main.alignRight, {
                    justifyContent: 'center',
                  }]}
                  disabled={disabled}
                  onPress={onPress}
                >
                  {label || (
                    <Icon
                      name="ellipsis-v"
                      size={size}
                      color={this.props.color}
                      style={{ alignSelf: 'center', opacity: disabled ? 0.5 : 1 }}
                    />
                  )}
                </TouchableOpacity>
                <ModalCustom
                  isVisible={opened}
                  content={
                    <View style={[StyleMorePopupMenu.container]}>
                      {
                        menus.map((item, index) => (
                          <TouchableOpacity
                            key={index.toString()}
                            disabled={item.disabled}
                            onPress={() => { item.onPress(); onDismiss(); }}
                            style={[StyleMorePopupMenu.textWrapper]}
                          >
                            <Text style={[StyleMorePopupMenu.textStyle]}>{item.text}</Text>
                          </TouchableOpacity>
                        ))
                      }
                    </View>
                  }
                  animationType="fade"
                  onPress={() => onDismiss()}
                />
              </Fragment>
            )
        }
      </Fragment>
    );
  }
}

MorePopupMenu.propTypes = {
  menus: PropTypes.arrayOf(PropTypes.object).isRequired,
  size: PropTypes.number,
  color: PropTypes.string,
  disabled: PropTypes.bool,
  opened: PropTypes.bool.isRequired,
  onPress: PropTypes.func.isRequired,
  onDismiss: PropTypes.func.isRequired,
  defaultPopUpMenu: PropTypes.bool,
  menuStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
};

MorePopupMenu.defaultProps = {
  disabled: false,
  size: 25,
  color: '#ff0000',
  defaultPopUpMenu: false,
  menuStyle: null,
};

export default MorePopupMenu;
