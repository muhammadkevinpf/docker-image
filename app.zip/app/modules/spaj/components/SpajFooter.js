import React, { Component } from 'react';
import {
  Footer,
  FooterTab,
  Button,
  Text,
} from 'native-base';
import Style from '../../../styles';
import _ from '../../../lang';
import LoadingModal from '../../../components/loading_modal';

export default class SpajFooter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    };
  }

  shouldComponentUpdate(nextProps) {
    if (JSON.stringify(nextProps) !== JSON.stringify(this.props)) return true;
    return false;
  }

  render() {
    return (
      <Footer style={[Style.Main.footerHeight, this.props.footerStyle]}>
        <FooterTab>
          <Button
            // onPressIn={() => this.setState({ isLoading: true })}
            // onPressOut={() => this.setState({ isLoading: false })}
            style={[Style.Main.btnLanjutkan, this.props.buttonStyle, this.props.disabled && Style.Main.halfOpacity]}
            onPress={this.props.onProceed}
            disabled={this.props.disabled}
          >
            <Text
              style={[
                Style.Main.font16, Style.Main.textWhite, Style.Main.fontAlbert, this.props.textStyle,
              ]}
            >{_(this.props.label || 'LANJUTKAN')}
            </Text>
          </Button>
          <LoadingModal show={this.state.isLoading} size="large" color="white" />
        </FooterTab>
      </Footer>
    );
  }
}
