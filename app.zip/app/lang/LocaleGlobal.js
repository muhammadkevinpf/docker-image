/**
 * @author: dwi.setiyadi@gmail.com
*/

export default [
  // {
  //   id: 'Ya',
  //   en: 'Yes',
  // },
  // {
  //   id: 'Tidak',
  //   en: 'No',
  // },
];
