import iconProduction from './produksi.png';
import iconPersistency from './persistensi.png';
import iconSqs from './esqs.png';
import iconRss from './rss.png';
import iconRecrutmen from './rekrutmen.png';
import iconTodo from './daftartugas.png';
import iconClientList from './listklien.png';
import iconStatus from './StatusProposal.png';
import iconOthers from './lainnya.png';
import iconOCR from './simulasiocr.png';
import iconCommision from './EstimasiKomisi.png';
import iconIncome from './LaporanPendapatan.png';
import iconPlus from './plus.png';
import iconMyAccount from './icon-account.png';
import iconEmptyFolder from './empty-news.png';
import iconEmptyImage from './empty-campaign.png';
import iconPhone from './phone.png';
import iconOffice from './office.png';
import iconHospital from './hospital.png';
import iconInfo from './info.png';
import logoPru from './Prudential-logo-Face.png';
import iconPHF from './icon_phf.png';
import iconFeedback from './Feedback.png';
import iconCorrespondence from './Korespondensi.png';
import iconCounterOffer from './CounterOffer.png';
import iconSpajSubmission from './Illustration_for_SPAJ.gif';
import iconLeads from './PRULeads.png';
import iconPruexpertModule from './PRUExpert.png';
import iconLeader from './icon.png';
import iconSoftSkill from './Icon-Skill.png';
import iconVideo from './Icon-Video.png';
import iconDictionary from './Dictionary.png';

import NotFound from './EmptyStateDictionary.png';
import EmptyTodo from './empty-todo.png';
import EmptyNotification from './empty-notification.png';

import HWNIBasic from './HNWI_Basic.png';
import HNWIPotential from './HNWI_Potential.png';
import HNWIPrestige from './HNWI_Prestige.png';
import HNWIList from './HNWIcard_List.png';

import HWNIBasicTab from './HNWI_Basic_Tab.png';
import HNWIPotentialTab from './HNWI_Potential_Tab.png';
import HNWIPrestigeTab from './HNWI_Prestige_Tab.png';
import HNWIListTab from './HNWIcard_List_Tab.png';

import CatalogDisable from './Icon-Catalog-Disable.png';
import HomeDisable from './Icon-Home-Disable.png';
import ScheduleDisable from './Icon-Schedule-Disable.png';
import TrainingDisable from './Icon-Teach-Disable.png';

import CatalogEnable from './Icon-Catalog-Enable.png';
import HomeEnable from './Icon-Home.png';
import ScheduleEnable from './Icon-Schedule-Enable.png';
import TrainingEnable from './Icon-Teach-Enable.png';

import PRUexpertRed from './PRUexpert_red.png';
import PRUexpertBlue from './PRUexpert_blue.png';
import PRUexpertGreen from './PRUexpert_green.png';
import PRUexpertCatalog from './PRUexpert_catalog.png';
import PRUexpertCatalogTab from './PRUexpert_catalogtab.png';
import PRUexpertCatalogOnline from './PRUexpert_catalog_online.png';
import PRUexpertCatalogTabOnline from './PRUexpert_catalogtab_online.png';

import BgMainPageMobile from './BgMainPage.png';
import BgMainPageTab from './BgMainPageTab.png';
import RevampMainPage from './RevampMainPage.png';
import IncomeAgentBanner from './Laporan-Pendapatan-Agen.png';

import { isTablet } from '../../utilities';

const BackgroundHNWITablet = {
  BASIC: HWNIBasicTab,
  POTENTIAL: HNWIPotentialTab,
  PRESTIGE: HNWIPrestigeTab,
  LIST: HNWIListTab,
};

export const BgMainPage = isTablet() ? BgMainPageTab : BgMainPageMobile;

export const BackgroundHNWI = isTablet() ? BackgroundHNWITablet : {
  BASIC: HWNIBasic,
  POTENTIAL: HNWIPotential,
  PRESTIGE: HNWIPrestige,
  LIST: HNWIList,
};

export const iconPruexpert = {
  CatalogDisable,
  CatalogEnable,
  HomeDisable,
  HomeEnable,
  ScheduleDisable,
  ScheduleEnable,
  TrainingDisable,
  TrainingEnable,
};

export const BackgroundPruexpert = {
  RED: PRUexpertRed,
  BLUE: PRUexpertBlue,
  GREEN: PRUexpertGreen,
  CATALOG: PRUexpertCatalog,
  CATALOGTAB: PRUexpertCatalogTab,
  CATALOG_OL: PRUexpertCatalogOnline,
  CATALOGTAB_OL: PRUexpertCatalogTabOnline,
};

export {
  iconProduction,
  iconEmptyImage,
  iconPersistency,
  iconSqs,
  iconRss,
  iconRecrutmen,
  iconTodo,
  iconClientList,
  iconStatus,
  iconOthers,
  iconOCR,
  iconCommision,
  iconIncome,
  iconPlus,
  iconMyAccount,
  iconEmptyFolder,
  iconPhone,
  iconOffice,
  iconHospital,
  iconInfo,
  logoPru,
  iconPHF,
  iconFeedback,
  iconCorrespondence,
  iconCounterOffer,
  iconSpajSubmission,
  iconLeads,
  iconPruexpertModule,
  iconLeader,
  iconSoftSkill,
  iconVideo,
  iconDictionary,
  NotFound,
  EmptyTodo,
  EmptyNotification,
  RevampMainPage,
  IncomeAgentBanner,
};
