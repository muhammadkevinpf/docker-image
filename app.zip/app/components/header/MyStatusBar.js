import React from 'react';
import { View, StatusBar, Platform } from 'react-native';
import { statusBarHeight } from '../../config/Platform';
import Styles from '../../styles';

const getBarStyle = (backgroundColor) => {
  const lightColors = [Styles.Color.white];
  if (lightColors.includes(backgroundColor)) return 'dark-content';
  return Platform.OS === 'ios' ? 'default' : 'light-content';
};

export const StatusBarDefault = ({ backgroundColor, ...props }) => (
  <StatusBar
    translucent
    barStyle={getBarStyle(backgroundColor)}
    backgroundColor={backgroundColor}
    {...props}
  />
);

const MyStatusBar = ({ backgroundColor, ...props }) => (
  <View style={[{ height: statusBarHeight }, { backgroundColor }]}>
    <StatusBarDefault backgroundColor={backgroundColor || Styles.Color.darkRed} {...props} />
  </View>
);

export default MyStatusBar;
