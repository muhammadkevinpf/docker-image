/* eslint-disable max-len */
/* eslint-disable camelcase */
/* eslint-disable no-console */
/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import { Alert, BackHandler } from 'react-native';
import {
  Container, Content, Button, Text, Footer, FooterTab, View,
} from 'native-base';
import { connect } from 'react-redux';
import { NavigationEvents } from 'react-navigation';
import Icon from 'react-native-vector-icons/FontAwesome';
import _ from '../../../lang';
import Style from '../../../styles';
import {
  InputFieldNew, DropdownNew, HeaderWithTodo, SideBarMenu,
} from '../../../components';
import UserProfileService from '../services/UserProfileService';
import LoadingModal from '../../../components/loading_modal';
import { isTablet } from '../../../utilities';

class EditEmergencyContact extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      relationship: '',
      telephone: '',
      address: '',
      rt: '',
      city: '',
      relationshipList: [],
      isLoading: false,
    };
  }

  componentDidMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleOnBack();
      return true;
    });
    this.setState({ isLoading: true });
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  handleBack = () => {
    this.props.navigation.replace('MyAccountDetail');
  }

  initialLoad = async () => {
    try {
      const { access_token, userProfile } = this.props.resAuth;

      const emergencyData = await UserProfileService.showEmergency(access_token, userProfile.agentCode);
      const relationship = await UserProfileService.getRelation(access_token);

      const emergencyContact = emergencyData.array[0];

      this.setState({
        relationshipList: relationship.relation,
        name: emergencyContact.contactName,
        relationship: emergencyContact.relation,
        telephone: emergencyContact.phoneNumber,
        address: emergencyContact.address1,
        rt: emergencyContact.address2,
        city: emergencyContact.address3,
      });
    } catch (e) {
      console.log('error at initialLoad with error: ', e);
    }
    this.setState({ isLoading: false });
  }

  handleOnSubmit = async () => {
    // TODO: uncomment this
    const { access_token, userProfile } = this.props.resAuth;
    const {
      name, relationship, telephone, address, rt, city,
    } = this.state;

    await UserProfileService.updateEmergency(access_token, userProfile.agentNumber, name, relationship, telephone, address, rt, city)
      .then(() => {
        Alert.alert(
          '',
          'Your data has been saved!',
          [
            {
              text: 'Ok',
              onPress: () => { this.props.navigation.replace('MyAccountDetail'); },
            },
          ],
        );
      });
  }

  handleName = (name) => { this.setState({ name }); }

  handleTelephone = (telephone) => { this.setState({ telephone }); }

  handleAddress = (address) => { this.setState({ address }); }

  handleRT = (rt) => { this.setState({ rt }); }

  handleCity = (city) => { this.setState({ city }); }

  handleRelationship = (relationship) => { this.setState({ relationship }); }

  relationshipList = () => {
    const { relationshipList } = this.state;

    const newRelation = relationshipList.map((val) => {
      const obj = { value: val, label: val };

      return obj;
    });

    return newRelation;
  }

  handleOnBack = () => {
    this.props.navigation.replace('MyAccountDetail');
    this.backHandler.remove();
  }

  render() {
    return (
      <React.Fragment>
        <NavigationEvents
          onDidFocus={() => this.initialLoad()}
        />
        <Container style={[isTablet() && Style.Main.rowDirection]}>
          <SideBarMenu visible={isTablet()} navigation={this.props.navigation} />
          <View style={[Style.Main.container]}>
            <HeaderWithTodo {...this.props} onBackClicked={this.handleOnBack} headerTitle="AKUN SAYA" subHeader="KONTAK DARURAT" />
            <Content
              keyboardDismissMode="on-drag"
              enableResetScrollToCoords={false}
              style={[isTablet() ? Style.Main.containerWithPaddingTablet : Style.Main.containerWithPadding12]}
            >
              <View style={[Style.Main.rowDirectionSpaceBetween]}>
                <View style={[Style.Main.flex1, Style.Main.alignCenter, Style.Main.justifyCenter, Style.Main.ml5]}>
                  <Icon name="user" style={[Style.Main.textAlmostBlack, Style.Main.font18, Style.Main.mt26]} />
                </View>
                <View style={[Style.Main.flex10]}>
                  <InputFieldNew
                    value={this.state.name}
                    label={_('Nama')}
                    onChangeText={this.handleName}
                    isRequired={false}
                  />
                </View>
              </View>
              <View style={[Style.Main.rowDirectionSpaceBetween]}>
                <View style={[Style.Main.flex1, Style.Main.alignCenter, Style.Main.justifyCenter, Style.Main.ml5]}>
                  <Icon name="users" style={[Style.Main.textAlmostBlack, Style.Main.font18, Style.Main.mt26]} />
                </View>
                <View style={[Style.Main.flex10]}>
                  <DropdownNew
                    mode="dialog"
                    iosIcon="angle-down"
                    dropdownData={this.relationshipList()}
                    selectedValue={this.state.relationship}
                    onValueChange={this.handleRelationship}
                    label="Hubungan"
                    labelProp="label"
                    valueProp="value"
                  />
                </View>
              </View>
              <View style={[Style.Main.rowDirectionSpaceBetween]}>
                <View style={[Style.Main.flex1, Style.Main.alignCenter, Style.Main.justifyCenter, Style.Main.ml5]}>
                  <Icon name="phone" style={[Style.Main.textAlmostBlack, Style.Main.font18, Style.Main.mt26]} />
                </View>
                <View style={[Style.Main.flex10]}>
                  <InputFieldNew
                    value={this.state.telephone}
                    label={_('Nomor telepon yang dapat dihubungi')}
                    onChangeText={this.handleTelephone}
                    isRequired={false}
                  />
                </View>
              </View>
              <View style={[Style.Main.rowDirectionSpaceBetween]}>
                <View style={[Style.Main.flex1, Style.Main.alignCenter, Style.Main.justifyCenter, Style.Main.ml5]}>
                  <Icon name="home" style={[Style.Main.textAlmostBlack, Style.Main.font18, Style.Main.mt26]} />
                </View>
                <View style={[Style.Main.flex10]}>
                  <InputFieldNew
                    value={this.state.address}
                    label={_('Jalan/Perumahan/Nomor')}
                    onChangeText={this.handleAddress}
                    isRequired={false}
                  />
                </View>
              </View>
              <View style={[Style.Main.rowDirectionSpaceBetween]}>
                <View style={[Style.Main.flex1, Style.Main.alignCenter, Style.Main.justifyCenter, Style.Main.ml5]} />
                <View style={[Style.Main.flex10]}>
                  <InputFieldNew
                    value={this.state.rt}
                    label={_('RT/RW')}
                    onChangeText={this.handleRT}
                    isRequired={false}
                  />
                </View>
              </View>
              <View style={[Style.Main.rowDirectionSpaceBetween]}>
                <View style={[Style.Main.flex1, Style.Main.alignCenter, Style.Main.justifyCenter, Style.Main.ml5]} />
                <View style={[Style.Main.flex10]}>
                  <InputFieldNew
                    value={this.state.city}
                    label={_('Kelurahan/Kecamatan/Kota')}
                    onChangeText={this.handleCity}
                    isRequired={false}
                  />
                </View>
              </View>
            </Content>
            <Footer style={[Style.Main.footerHeight]}>
              <FooterTab>
                <Button
                  style={[Style.Main.btnLanjutkan]}
                  onPress={this.handleOnSubmit}
                >
                  <Text
                    style={[Style.Main.font16, Style.Main.textWhite, Style.Main.fontAlbert]}
                  >{_('SIMPAN')}
                  </Text>
                </Button>
              </FooterTab>
            </Footer>
          </View>
        </Container>
        <LoadingModal show={this.state.isLoading} size="large" color="white" />
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  resAuth: state.auth.res,
});

export default connect(mapStateToProps, null)(EditEmergencyContact);
