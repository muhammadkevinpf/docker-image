/**
 * @author: ahmdichsanb@gmail.com
*/

import React, { Component, Fragment } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { Row, Col } from 'react-native-easy-grid';
import PropTypes from 'prop-types';

import StyleRadioButton from './StyleRadioButton';

class RadioButton extends Component {
  render() {
    const {
      style,
      innerStyle,
      isSelected,
      value,
      colRadioSize,
      colRadioStyle,
      label,
      colLabelSize,
      colLabelStyle,
      fontStyle,
      activeOpacity,
      onPress,
      wrapper,
    } = this.props;
    return (
      <Fragment>
        <TouchableOpacity
          onPress={() => onPress(value)}
          activeOpacity={activeOpacity}
          style={[wrapper]}
        >
          <Row>
            <Col size={colRadioSize} style={[colRadioStyle]}>
              <View style={[style]}>
                {isSelected ? <View style={[innerStyle]} /> : null}
              </View>
            </Col>
            {
              label && (
                <Col size={colLabelSize} style={[colLabelStyle]}>
                  <Text style={[fontStyle]}>{label}</Text>
                </Col>
              )
            }
          </Row>
        </TouchableOpacity>
      </Fragment>
    );
  }
}

RadioButton.propTypes = {
  isSelected: PropTypes.bool.isRequired,
  value: PropTypes.string.isRequired,
  onPress: PropTypes.func.isRequired,
  label: PropTypes.string.isRequired,
  activeOpacity: PropTypes.number,
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  innerStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  colRadioSize: PropTypes.number,
  colRadioStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  colLabelSize: PropTypes.number,
  colLabelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  fontStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  wrapper: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
};

RadioButton.defaultProps = {
  activeOpacity: 0.3,
  style: StyleRadioButton.containerDefault,
  innerStyle: StyleRadioButton.innerStyleDefault,
  colRadioSize: 10,
  colRadioStyle: null,
  colLabelSize: 90,
  colLabelStyle: StyleRadioButton.colLabelStyle,
  fontStyle: null,
  wrapper: StyleRadioButton.wrapper,
};

export default RadioButton;
