/* eslint-disable import/no-cycle */
import moment from 'moment';
// import Analytics from 'appcenter-analytics';
import CryptoJS from 'crypto-js';
import SQLiteUtils from '../../../utilities/SQLiteUtils';
import Database from '../../../config/Database';
import HeaderService from './HeaderService';

const { spaj } = Database.pruSmart.tables;

// const querySelect = `SELECT * FROM ${spaj.name} WHERE method = ? and agentCode = ?`;
// const querySelectByKey = `SELECT * FROM ${spaj.name} WHERE method = ? and agentCode = ? and spajCode = ?`;

const whereClause = 'WHERE method = ? and agentCode = ? and spajCode = ?';
const whereClauseByCode = 'WHERE method = ? and agentCode = ? and spajCode = ?';

const queryDelete = `DELETE FROM ${spaj.name} ${whereClauseByCode}`;
const queryUpdateByKey = `UPDATE ${spaj.name} SET data = ?, createDate = ? ${whereClauseByCode}`;
const queryInsert = `INSERT INTO ${spaj.name} VALUES (?,?,?,?,?)`;
const serviceName = 'NewSPAJStorageService';

const openDatabase = () => new Promise(async (resolve, reject) => {
  try {
    const dbName = Database.pruSmart.name;
    const db = await SQLiteUtils.openDatabase(`${dbName}.db`, 'default');
    resolve(db);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error.message);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const getAll = (db, agentCode) => new Promise(async (resolve, reject) => {
  try {
    const codes = await SQLiteUtils.executeQuery(db, `SELECT spajCode FROM ${spaj.name} ${whereClause}`);
    const data = [];
    for (let i = 0; i < codes.rows.length; i += 1) {
      // eslint-disable-next-line no-await-in-loop
      const res = await SQLiteUtils.executeAdvanceQuery(
        db,
        spaj.name,
        'data',
        whereClauseByCode,
        [spaj.method, agentCode, codes.rows.item(i).spajCode],
      );
      data.push(JSON.parse(CryptoJS.AES.decrypt(res, SQLiteUtils.DBKEY).toString(CryptoJS.enc.Utf8)).invocationResult);
    }
    resolve(data);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error.message);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const getByCode = (db, param) => new Promise(async (resolve, reject) => {
  try {
    let res = await SQLiteUtils.executeAdvanceQuery(
      db,
      spaj.name,
      'data',
      whereClauseByCode,
      [spaj.method, param.agentCode, param.spajCode],
    );
    const dataDecrypt = CryptoJS.AES.decrypt(res, SQLiteUtils.DBKEY).toString(CryptoJS.enc.Utf8);
    if (res) res = JSON.parse(dataDecrypt).invocationResult;
    resolve(res);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error.message);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const deleteByCode = (db, param) => new Promise(async (resolve, reject) => {
  try {
    // const checkData = await getByCode(db, param);
    // if (!checkData) { reject(new Error(`${serviceName} Data not found`)); }
    const res = await SQLiteUtils.executeTransaction(
      db,
      queryDelete,
      [spaj.method, param.agentCode, param.spajCode],
    );
    resolve(res);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error.message);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const upsert = (db, param = { data: {}, agentCode: '', spajCode: '' }) => new Promise(async (resolve, reject) => {
  try {
    const data = {};
    // eslint-disable-next-line no-param-reassign
    param.data.policy.updatedDate = (`${moment(new Date(), 'YYYY-MM-DDTHH:mm:ss.SSS').format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`);
    data.invocationResult = param.data;
    data.agentId = param.agentCode;
    data.spajCd = param.spajCode;
    data.retrieveDate = new Date();

    let queryToProcess = queryInsert;

    let parameterToInput = [
      param.agentCode,
      spaj.method,
      param.spajCode,
      CryptoJS.AES.encrypt(JSON.stringify(data), SQLiteUtils.DBKEY).toString(),
      moment().format('DD/MM/YYYY hh:mm'),
    ];

    const res = await getByCode(db, { agentCode: param.agentCode, spajCode: param.spajCode });

    if (res) {
      // data = res;
      data.invocationResult = param.data;
      data.spajCd = param.spajCode;
      queryToProcess = queryUpdateByKey;
      parameterToInput = [
        CryptoJS.AES.encrypt(JSON.stringify(data), SQLiteUtils.DBKEY).toString(),
        moment().format('DD/MM/YYYY hh:mm'),
        spaj.method,
        param.agentCode,
        param.spajCode,
      ];
    }
    let headerUpdate = '';
    if (!param.isFromApi) {
      headerUpdate = await HeaderService.convertSqsToHeader(
        param.data.sqs, param.agentCode,
        param.agentCode, param.data.policy.spajStatus,
        param.data.policy.prop_no, param.data.counterOfferFlag,
        param.data,
      );
    }
    const resUpsert = await SQLiteUtils.executeTransaction(
      db,
      queryToProcess,
      parameterToInput,
    );
    resolve(`UPSERT ${resUpsert} ${headerUpdate}`);
    // resolve(`UPSERT ${resUpsert}`);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error.message);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

export default {
  openDatabase,
  getAll,
  getByCode,
  deleteByCode,
  upsert,
};
