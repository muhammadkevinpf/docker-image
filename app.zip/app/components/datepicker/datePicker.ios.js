/**
 * @author: ahmdichsanb@gmail.com
*/

import React, { Component, Fragment } from 'react';
import {
  DatePickerIOS,
} from 'react-native';
import ModalCustom from '../modal-custom';
import AlertTemplate from '../alert-template';
import ButtonCustom from '../button-custom';
import StyleDatePicker from './StyleDatePicker';

class IosDatePicker extends Component {
  constructor(props) {
    super(props);
    this.state = {
      tempDateValue: props.dateValue,
    };
  }

  setDate = (tempDateValue) => {
    this.setState({ tempDateValue });
  }

  confirmDate = () => {
    const { tempDateValue } = this.state;
    this.props.onDateChange(tempDateValue);
  }

  cancelDate = () => {
    const { dateValue } = this.props;
    const tempDateValue = null;

    this.props.onDateChange(tempDateValue);
    this.setState({ tempDateValue: dateValue });
  }

  render() {
    const { tempDateValue } = this.state;
    const {
      maximumDate, minimumDate, mode, isDatePickerOpen, component, onPress,
    } = this.props;

    const bodyContent = (
      <DatePickerIOS
        date={tempDateValue}
        onDateChange={this.setDate}
        maximumDate={maximumDate}
        minimumDate={minimumDate}
        mode={mode}
      />
    );

    const buttonLeftContent = (
      <ButtonCustom
        buttonStyle={[StyleDatePicker.buttonCancel]}
        buttonLabel="Cancel"
        buttonLabelStyle={[StyleDatePicker.textAlignCenter]}
        onPress={() => this.cancelDate()}
        activeOpacity={0.5}
      />
    );

    const buttonRightContent = (
      <ButtonCustom
        buttonStyle={[StyleDatePicker.buttonConfirm]}
        buttonLabel="Confirm"
        buttonLabelStyle={[StyleDatePicker.textAlignCenter]}
        onPress={() => this.confirmDate()}
        activeOpacity={0.5}
      />
    );

    const contentModal = (
      <AlertTemplate
        bodyContent={bodyContent}
        buttonRightContent={buttonRightContent}
        buttonLeftContent={buttonLeftContent}
      />
    );
    return (
      <Fragment>
        <ModalCustom
          isVisible={isDatePickerOpen}
          content={contentModal}
          animationType="fade"
          onPress={() => onPress()}
        />
        {component}
      </Fragment>
    );
  }
}

export default IosDatePicker;
