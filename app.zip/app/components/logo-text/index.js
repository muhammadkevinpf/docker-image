/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import { View, Text } from 'react-native';
import PropTypes from 'prop-types';
import StyleLogoText from './StyleLogoText';

class LogoHeader extends Component {
  constructor(props) {
    super(props);

    this.state = {
      leftColor: null,
      rightColor: null,
    };
  }

  async componentDidMount() {
    switch (this.props.color) {
      case ('gray'):
        await this.setState({
          leftColor: StyleLogoText.leftGray,
          rightColor: StyleLogoText.rightGray,
        });
        break;
      case ('white'):
        await this.setState({
          leftColor: StyleLogoText.leftWhite,
          rightColor: StyleLogoText.rightWhite,
        });
        break;
      case ('red'):
        await this.setState({
          leftColor: StyleLogoText.leftRed,
          rightColor: StyleLogoText.rightRed,
        });
        break;
      default:
        await this.setState({
          leftColor: StyleLogoText.leftGray,
          rightColor: StyleLogoText.rightGray,
        });
        break;
    }
  }

  render() {
    return (
      <View style={StyleLogoText.container}>
        <Text style={this.state.leftColor}>{this.props.left}</Text><Text style={this.state.rightColor}>{this.props.right}</Text>
      </View>
    );
  }
}

LogoHeader.propTypes = {
  right: PropTypes.string.isRequired,
  left: PropTypes.string.isRequired,
};

export default LogoHeader;
