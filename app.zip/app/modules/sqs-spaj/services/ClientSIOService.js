import moment from 'moment';
import SQLiteUtils from '../../../utilities/SQLiteUtils';
import Database from '../../../config/Database';

const { clientSIO } = Database.inquiries.tables;

const querySelectByKey = `SELECT clientNumber,createdDate, data FROM ${clientSIO} WHERE clientNumber = ?`;
const queryInsert = `INSERT INTO ${clientSIO} (clientNumber, data, createdDate, modifiedDate) VALUES (?, ?, ?, ?)`;
const queryCreateTable = `CREATE TABLE IF NOT EXISTS ${clientSIO} (clientNumber TEXT, data TEXT, createdDate TEXT, modifiedDate TEXT)`;
const queryUpdateByKey = `UPDATE ${clientSIO} SET data = ?, modifiedDate = ? where clientNumber = ?`;

const openDatabase = () => new Promise(async (resolve, reject) => {
  try {
    const db = await SQLiteUtils.openDatabase(Database.inquiries.name, 'default');
    resolve(db);
  } catch (error) {
    reject(error);
  }
});

const createTable = db => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeTransaction(db, queryCreateTable, []);
    resolve(res);
  } catch (error) {
    reject(error);
  }
});

const getByCode = (db, param) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(db, querySelectByKey, [param.code]);
    if (res.rows.length > 0) {
      resolve(JSON.parse(res.rows.item(0).data));
    } else {
      resolve(res.rows.length);
    }
  } catch (error) {
    reject(error);
  }
});

const insert = (db, param) => new Promise(async (resolve, reject) => {
  try {
    const currentDate = moment(new Date()).format('DD/MM/YYYY HH:mm');
    const res = await SQLiteUtils.executeTransaction(
      db,
      queryInsert,
      [param.clientNumber, param.dataSIO, currentDate, currentDate],
    );
    resolve(res);
  } catch (error) {
    reject(error);
  }
});

const update = (db, param) => new Promise(async (resolve, reject) => {
  try {
    const currentDate = moment(new Date()).format('DD/MM/YYYY HH:mm');
    const res = await SQLiteUtils.executeTransaction(
      db,
      queryUpdateByKey,
      [param.dataSIO, currentDate, param.clientNumber],
    );
    resolve(res);
  } catch (error) {
    reject(error);
  }
});

export default {
  openDatabase,
  createTable,
  getByCode,
  insert,
  update,
};
