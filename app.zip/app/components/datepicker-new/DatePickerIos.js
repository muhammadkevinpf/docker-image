/* eslint-disable react-native/no-inline-styles */
import React, { Component } from 'react';
import {
  Modal,
  View,
  Text,
  Dimensions,
} from 'react-native';
import DatePicker from '@react-native-community/datetimepicker';
import Style from '../../styles';

const deviceWidth = Dimensions.get('window').width;
class DatePickerIos extends Component {
  static defaultProps = {
    disabled: false,
  };

  constructor(props) {
    super(props);
    this.state = {
      modalVisible: false,
      defaultDate: props.defaultDate ? props.defaultDate : new Date(),
      chosenDate:
        !props.placeHolderText && props.defaultDate
          ? props.defaultDate
          : undefined,
    };
  }

  setDate = (event, selectedDate) => {
    console.log('ini selected date', selectedDate);
    console.log('ini event', event);
    const date = selectedDate || new Date();
    this.setState({ chosenDate: date });
    if (this.props.onDateChange) {
      this.props.onDateChange(selectedDate);
    }
  }

  showDatePicker = () => {
    this.setState({ modalVisible: true });
  };

  formatChosenDate(date) {
    if (this.props.formatChosenDate) {
      return this.props.formatChosenDate(date);
    }
    return [date.getDate(), date.getMonth() + 1, date.getFullYear()].join('/');
  }

  render() {
    const {
      animationType,
      disabled,
      locale,
      maximumDate,
      minimumDate,
      modalTransparent,
      placeHolderText,
      placeHolderTextStyle,
      textStyle,
      timeZoneOffsetInMinutes,
    } = this.props;

    return (
      <View>
        <View>
          <Text
            onPress={() => (!disabled ? this.showDatePicker() : undefined)}
            style={[
              Style.Main.padding10,
              Style.Color.black,
              this.state.chosenDate ? textStyle : placeHolderTextStyle,
            ]}
          >
            {this.state.chosenDate
              ? this.formatChosenDate(this.state.chosenDate)
              : placeHolderText || 'Select Date'}
          </Text>
          <View>
            <Modal
              supportedOrientations={['portrait', 'landscape']}
              animationType={animationType}
              transparent={modalTransparent} // from api
              visible={this.state.modalVisible}
              onRequestClose={() => {}}
            >
              <Text
                onPress={() => this.setState({ modalVisible: false })}
                style={[
                  Style.Main.backgroundTransparent,
                  Style.Main.flex1,
                ]}
              />
              <View style={deviceWidth > 400 ? { paddingLeft: 0.12 * deviceWidth } : { paddingLeft: 0.07 * deviceWidth }}>
                <DatePicker
                  value={
                  this.state.chosenDate
                    ? this.state.chosenDate
                    : this.state.defaultDate
                }
                  onChange={this.setDate}
                  minimumDate={minimumDate}
                  maximumDate={maximumDate}
                  mode="date"
                  locale={locale}
                  // timeZoneOffsetInMinutes={timeZoneOffsetInMinutes}
                  // remove code below and set back value to undefined if datepicker ios still have problem -1 or +1 day
                  timeZoneOffsetInMinutes={(-1 * new Date().getTimezoneOffset()) || timeZoneOffsetInMinutes}
                />
              </View>
            </Modal>
          </View>
        </View>
      </View>
    );
  }
}
export default DatePickerIos;
