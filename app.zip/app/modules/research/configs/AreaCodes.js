const aceh = require('./11-aceh.json');
const sumateraUtara = require('./12-sumatera-utara.json');
const sumateraBarat = require('./13-sumatera-barat.json');
const riau = require('./14-riau.json');
const jambi = require('./15-jambi.json');
const sumateraSelatan = require('./16-sumatera-selatan.json');
const bengkulu = require('./17-bengkulu.json');
const lampung = require('./18-lampung.json');
const bangkaBelitung = require('./19-kepulauan-bangka-belitung.json');
const kepulauanRiau = require('./21-kepulauan-riau.json');
const jakarta = require('./31-dki-jakarta.json');
const jawaBarat = require('./32-jawa-barat.json');
const jawaTengah = require('./33-jawa-tengah.json');
const yogyakarta = require('./34-daerah-istimewa-yogyakarta.json');
const jawaTimur = require('./35-jawa-timur.json');
const banten = require('./36-banten.json');
const bali = require('./51-bali.json');
const ntb = require('./52-nusa-tenggara-barat.json');
const ntt = require('./53-nusa-tenggara-timur.json');
const kalimantanBarat = require('./61-kalimantan-barat.json');
const kalimantanTengah = require('./62-kalimantan-tengah.json');
const kalimantanSelatan = require('./63-kalimantan-selatan.json');
const kalimantanTimur = require('./64-kalimantan-timur.json');
const kalimantanUtara = require('./65-kalimantan-utara.json');
const sulawesiUtara = require('./71-sulawesi-utara.json');
const sulawesiTengah = require('./72-sulawesi-tengah.json');
const sulawesiSelatan = require('./73-sulawesi-selatan.json');
const sulawesiTenggara = require('./74-sulawesi-tenggara.json');
const gorontalo = require('./75-gorontalo.json');
const sulawesiBarat = require('./76-sulawesi-barat.json');
const maluku = require('./81-maluku.json');
const malukuUtara = require('./82-maluku-utara.json');
const papua = require('./91-papua.json');
const papuaBarat = require('./92-papua-barat.json');

export const areaCodes = [
  {
    code: '11',
    type: 'provinsi',
    name: 'ACEH',
    value: 'NAD',
    district: aceh,
  },
  {
    code: '12',
    type: 'provinsi',
    name: 'SUMATERA UTARA',
    value: 'SUMUT',
    district: sumateraUtara,
  },
  {
    code: '13',
    type: 'provinsi',
    name: 'SUMATERA BARAT',
    value: 'SUMBAR',
    district: sumateraBarat,
  },
  {
    code: '14',
    type: 'provinsi',
    name: 'RIAU',
    value: 'RIAU',
    district: riau,
  },
  {
    code: '15',
    type: 'provinsi',
    name: 'JAMBI',
    value: 'JAMBI',
    district: jambi,
  },
  {
    code: '16',
    type: 'provinsi',
    name: 'SUMATERA SELATAN',
    value: 'SUMSEL',
    district: sumateraSelatan,
  },
  {
    code: '17',
    type: 'provinsi',
    name: 'BENGKULU',
    value: 'BENGKULU',
    district: bengkulu,
  },
  {
    code: '18',
    type: 'provinsi',
    name: 'LAMPUNG',
    value: 'LAMPUNG',
    district: lampung,
  },
  {
    code: '19',
    type: 'provinsi',
    name: 'KEPULAUAN BANGKA BELITUNG',
    value: 'BABEL',
    district: bangkaBelitung,
  },
  {
    code: '21',
    type: 'provinsi',
    name: 'KEPULAUAN RIAU',
    value: 'RIAUKEP',
    district: kepulauanRiau,
  },
  {
    code: '31',
    type: 'provinsi',
    name: 'DKI JAKARTA',
    value: 'DIJKT',
    district: jakarta,
  },
  {
    code: '32',
    type: 'provinsi',
    name: 'JAWA BARAT',
    value: 'JABAR',
    district: jawaBarat,
  },
  {
    code: '33',
    type: 'provinsi',
    name: 'JAWA TENGAH',
    value: 'JATENG',
    district: jawaTengah,
  },
  {
    code: '34',
    type: 'provinsi',
    name: 'DAERAH ISTIMEWA YOGYAKARTA',
    value: 'DIY',
    district: yogyakarta,
  },
  {
    code: '35',
    type: 'provinsi',
    name: 'JAWA TIMUR',
    value: 'JATIM',
    district: jawaTimur,
  },
  {
    code: '36',
    type: 'provinsi',
    name: 'BANTEN',
    value: 'BANTEN',
    district: banten,
  },
  {
    code: '51',
    type: 'provinsi',
    name: 'BALI',
    value: 'BALI',
    district: bali,
  },
  {
    code: '52',
    type: 'provinsi',
    name: 'NUSA TENGGARA BARAT',
    value: 'NTB',
    district: ntb,
  },
  {
    code: '53',
    type: 'provinsi',
    name: 'NUSA TENGGARA TIMUR',
    value: 'NTT',
    district: ntt,
  },
  {
    code: '61',
    type: 'provinsi',
    name: 'KALIMANTAN BARAT',
    value: 'KALBAR',
    district: kalimantanBarat,
  },
  {
    code: '62',
    type: 'provinsi',
    name: 'KALIMANTAN TENGAH',
    value: 'KALTENG',
    district: kalimantanTengah,
  },
  {
    code: '63',
    type: 'provinsi',
    name: 'KALIMANTAN SELATAN',
    value: 'KALSEL',
    district: kalimantanSelatan,
  },
  {
    code: '64',
    type: 'provinsi',
    name: 'KALIMANTAN TIMUR',
    value: 'KALTIM',
    district: kalimantanTimur,
  },
  {
    code: '65',
    type: 'provinsi',
    name: 'KALIMANTAN UTARA',
    value: 'KALTARA',
    district: kalimantanUtara,
  },
  {
    code: '71',
    type: 'provinsi',
    name: 'SULAWESI UTARA',
    value: 'SULUT',
    district: sulawesiUtara,
  },
  {
    code: '72',
    type: 'provinsi',
    name: 'SULAWESI TENGAH',
    value: 'SULTENG',
    district: sulawesiTengah,
  },
  {
    code: '73',
    type: 'provinsi',
    name: 'SULAWESI SELATAN',
    value: 'SULSEL',
    district: sulawesiSelatan,
  },
  {
    code: '74',
    type: 'provinsi',
    name: 'SULAWESI TENGGARA',
    value: 'SULTENGG',
    district: sulawesiTenggara,
  },
  {
    code: '75',
    type: 'provinsi',
    name: 'GORONTALO',
    value: 'GRTLO',
    district: gorontalo,
  },
  {
    code: '76',
    type: 'provinsi',
    name: 'SULAWESI BARAT',
    value: 'SULBAR',
    district: sulawesiBarat,
  },
  {
    code: '81',
    type: 'provinsi',
    name: 'MALUKU',
    value: 'MALUKU',
    district: maluku,
  },
  {
    code: '82',
    type: 'provinsi',
    name: 'MALUKU UTARA',
    value: 'MALUT',
    district: malukuUtara,
  },
  {
    code: '91',
    type: 'provinsi',
    name: 'PAPUA',
    value: 'PAPUA',
    district: papua,
  },
  {
    code: '92',
    type: 'provinsi',
    name: 'PAPUA BARAT',
    value: 'PAPBRT',
    district: papuaBarat,
  },
];
