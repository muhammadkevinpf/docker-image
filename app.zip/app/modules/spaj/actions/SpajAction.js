import { UPDATE_SPAJ_SUBMISSION, UPDATE_VIDEO_UPLOADER } from './types';

export function updateSpajAction(type, payload) {
  return { type, payload };
}

export function spajSubmissionAction(status, payload) {
  return { status, payload, type: UPDATE_SPAJ_SUBMISSION };
}

export function nonf2fVideoAction(status, payload) {
  return { status, payload, type: UPDATE_VIDEO_UPLOADER };
}
