/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { PureComponent, Fragment } from 'react';
import {
  Content, CheckBox, Button,
} from 'native-base';
import {
  View, Text,
} from 'react-native';
import { Grid, Row, Col } from 'react-native-easy-grid';
import moment from 'moment';

import { TouchableOpacity } from 'react-native-gesture-handler';
import _ from '../../../lang';

import Styles from '../../../styles';
import StyleSQSNSpaj from '../StyleSQSNSpaj';
import {
  DatePicker, SearchBar, Dropdown, InputField,
} from '../../../components';
import { ConfigProduct } from '../config';

const { defaultSortOpt, defaultFilterOpt } = ConfigProduct;

class AdvanceSearchSQSNSpaj extends PureComponent {
  constructor() {
    super();
    this.state = {
      isDatePickerFromOpen: false,
      isDatePickerToOpen: false,
    };
    this.handleDatePicker = this.handleDatePicker.bind(this);
    this.handleDateChange = this.handleDateChange.bind(this);
  }

  handleDatePicker = (isFrom) => {
    if (isFrom) {
      this.setState({ isDatePickerFromOpen: true });
    } else {
      this.setState({ isDatePickerToOpen: true });
    }
  }

  handleDateChange = (isFrom, date) => {
    if (isFrom) {
      this.setState({ isDatePickerFromOpen: false });
    } else {
      this.setState({ isDatePickerToOpen: false });
    }
    if (date) {
      this.props.handleDatePicker(isFrom, date);
    }
  }

  focus = () => {
    this._searchBar.focus();
  }

  blur = () => {
    this._searchBar.blur();
  }

  render() {
    const {
      searchBarValue,
      proposalDate,
      premium,
      coverage,
      currency,
      product,
      sortValue,
      filterValue,
      handleChangeProduct,
      handleCoverage,
      handlePremium,
      handleCurrency,
      handleReset,
      handleSearch,
      onSearchBarValueChange,
      onSortValueChange,
      onFilterValueChange,
    } = this.props;
    return (
      <Fragment>
        <Content keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
          <Grid>
            <Row>
              <Col>
                <View>
                  <Row style={[Styles.Main.mb20]}>
                    <Col>
                      <View>
                        <SearchBar
                          onSearchBarValue={val => onSearchBarValueChange(val)}
                          placeholder={_('Ketik nomor polis atau nama pemegang polis')}
                          value={searchBarValue}
                          ref={(ref) => { this._searchBar = ref; }}
                          editable
                        />
                      </View>
                    </Col>
                  </Row>

                  {/* <Row style={Style.Main.mb15}>
                  <Col>
                    <Text>{_('Masukan Rincian Pencarian Lebih Lanjut yang Anda Kehendaki')}</Text>
                  </Col>
                </Row> */}

                  <Row style={[Styles.Main.mb10, Styles.Main.ml15, Styles.Main.mr15]}>
                    <Col>
                      <Text>{_('Periode Pembuatan Proposal')}</Text>
                    </Col>
                  </Row>

                  <Row style={[Styles.Main.mb30, Styles.Main.ml15, Styles.Main.mr15]}>
                    <Col size={42}>
                      <DatePicker
                        component={(
                          <View style={[Styles.Main.textCenter, Styles.Main.alignCenter, Styles.Main.mt15, Styles.Main.borderRed]}>
                            <Text onPress={() => this.handleDatePicker(true)}>
                              {proposalDate.from ? moment(new Date(proposalDate.from)).format('DD-MM-YYYY') : _('Pilih Tanggal')}
                            </Text>
                          </View>
                      )}
                        isDatePickerOpen={this.state.isDatePickerFromOpen}
                        onDateChange={e => this.handleDateChange(true, e)}
                        dateValue={proposalDate.from}
                        modeIos="date"
                        modeAndroid="default"
                        maximumDate={proposalDate.to}
                        onPress={() => this.setState({ isDatePickerFromOpen: false })}
                      />
                    </Col>
                    <Col size={16}>
                      <Text style={[Styles.Main.font14, Styles.Main.mt15, Styles.Main.textCenter]}>{_('Hingga')}</Text>
                    </Col>
                    <Col size={42}>
                      <DatePicker
                        component={(
                          <View style={[Styles.Main.textCenter, Styles.Main.alignCenter, Styles.Main.mt15]}>
                            <Text onPress={() => this.handleDatePicker(false)}>
                              {proposalDate.to ? moment(new Date(proposalDate.to)).format('DD-MM-YYYY') : _('Pilih Tanggal')}
                            </Text>
                          </View>
                      )}
                        isDatePickerOpen={this.state.isDatePickerToOpen}
                        onDateChange={e => this.handleDateChange(false, e)}
                        dateValue={proposalDate.to}
                        modeIos="date"
                        modeAndroid="default"
                        minimumDate={proposalDate.from}
                        onPress={() => this.setState({ isDatePickerToOpen: false })}
                      />
                    </Col>
                  </Row>

                  <Row style={[Styles.Main.ml15, Styles.Main.mr15]}>
                    <Text>{_('Nilai Premi (Tahunan)')}</Text>
                  </Row>
                  <Row style={[Styles.Main.mb20, Styles.Main.ml15, Styles.Main.mr15]}>
                    <View style={Styles.Main.textWrap}>
                      <Col size={42}>
                        <TouchableOpacity
                          onPress={() => this._premiFrom.focus()}
                        >
                          <InputField
                            type="currency"
                            onChangeText={text => handlePremium(true, text)}
                            value={premium.from}
                            keyboardType="numeric"
                            ref={(ref) => { this._premiFrom = ref; }}
                            styleTextInput={[Styles.Main.borderBottomLightGray, Styles.Main.borderBottomWidth1]}
                          />
                        </TouchableOpacity>
                      </Col>
                      <Col size={16}>
                        <Text style={[Styles.Main.font14, Styles.Main.mt15, Styles.Main.textCenter]}>{_('Hingga')}</Text>
                      </Col>
                      <Col size={42}>
                        <TouchableOpacity
                          onPress={() => this._premiTo.focus()}
                        >
                          <InputField
                            type="currency"
                            onChangeText={text => handlePremium(false, text)}
                            value={premium.to}
                            keyboardType="numeric"
                            ref={(ref) => { this._premiTo = ref; }}
                            styleTextInput={[Styles.Main.borderBottomLightGray, Styles.Main.borderBottomWidth1]}
                          />
                        </TouchableOpacity>
                      </Col>
                    </View>
                  </Row>

                  <Row style={[Styles.Main.ml15, Styles.Main.mr15]}>
                    <Text>{_('Nilai Pertanggungan')}</Text>
                  </Row>
                  <Row style={[Styles.Main.mb30, Styles.Main.ml15, Styles.Main.mr15]}>
                    <View style={Styles.Main.textWrap}>
                      <Col size={42}>
                        <TouchableOpacity
                          onPress={() => this._coverageFrom.focus()}
                        >
                          <InputField
                            type="currency"
                            onChangeText={text => handleCoverage(true, text)}
                            value={coverage.from}
                            keyboardType="numeric"
                            ref={(ref) => { this._coverageFrom = ref; }}
                            styleTextInput={[Styles.Main.borderBottomLightGray, Styles.Main.borderBottomWidth1]}
                          />
                        </TouchableOpacity>
                      </Col>
                      <Col size={16}>
                        <Text style={[Styles.Main.font14, Styles.Main.mt15, Styles.Main.textCenter]}>{_('Hingga')}</Text>
                      </Col>
                      <Col size={42}>
                        <TouchableOpacity
                          onPress={() => this._coverageTo.focus()}
                        >
                          <InputField
                            type="currency"
                            onChangeText={text => handleCoverage(false, text)}
                            value={coverage.to}
                            keyboardType="numeric"
                            ref={(ref) => { this._coverageTo = ref; }}
                            styleTextInput={[Styles.Main.borderBottomLightGray, Styles.Main.borderBottomWidth1]}
                          />
                        </TouchableOpacity>
                      </Col>
                    </View>
                  </Row>

                  <Row style={[Styles.Main.mb20, Styles.Main.ml15, Styles.Main.mr15]}>
                    <Col size={40}>
                      <Text>
                        {_('Mata Uang')}
                      </Text>
                    </Col>
                    <Col size={30}>
                      <Row>
                        <Col size={10}>
                          <CheckBox
                            color={Styles.Color.red}
                            checked={currency === 'IDR'}
                            onPress={() => handleCurrency('IDR')}
                          />
                        </Col>
                        <Col size={20}>
                          <Text>{_('IDR')}</Text>
                        </Col>
                      </Row>
                    </Col>
                    <Col size={30}>
                      <Row>
                        <Col size={10}>
                          <CheckBox
                            color={Styles.Color.red}
                            checked={currency === 'USD'}
                            onPress={() => handleCurrency('USD')}
                          />
                        </Col>
                        <Col size={20}>
                          <Text>{_('USD')}</Text>
                        </Col>
                      </Row>
                    </Col>
                  </Row>
                  <Row style={[Styles.Main.mb20]}>
                    <Col>
                      <Dropdown
                        dropdownData={[
                          { label: 'Produk Dasar', value: 0 },
                          { label: 'PRUlink Generasi Baru', value: 1 },
                          { label: 'PRUlink syariah assurance account', value: 2 },
                          { label: 'PRUlink syariah generasi baru', value: 3 },
                          { label: 'PRUlink syariah assurance account - Hebat', value: 4 },
                          { label: 'PRUlink assurance account', value: 5 },
                          { label: 'PRUlink assurance account - Hebat', value: 6 },
                        ]}
                        selectedValue={product}
                        handleDropdownValue={handleChangeProduct}
                        textColor={Styles.Main.textGray.color}
                        stylePickerView={[
                          Styles.Main.borderBottomLightGray,
                          Styles.Main.borderBottomWidth1,
                          Styles.Main.ml10,
                          Styles.Main.mr10,
                        ]}
                      />
                    </Col>
                  </Row>
                  <Row style={[Styles.Main.mb20]}>
                    <Col size={50}>
                      <Dropdown
                        dropdownData={defaultSortOpt}
                        selectedValue={sortValue}
                        handleDropdownValue={onSortValueChange}
                        textColor={Styles.Main.textGray.color}
                        stylePickerBody={[Styles.Main.borderBottomLightGray, Styles.Main.borderBottomWidth1]}
                        styleTextInput={[Styles.Main.borderBottomLightGray, Styles.Main.borderBottomWidth1]}
                        stylePickerView={[
                          Styles.Main.borderBottomLightGray,
                          Styles.Main.borderBottomWidth1,
                          Styles.Main.ml10,
                          Styles.Main.mr5,
                        ]}
                      />
                    </Col>
                    <Col size={50}>
                      <Dropdown
                        dropdownData={defaultFilterOpt}
                        selectedValue={filterValue}
                        handleDropdownValue={onFilterValueChange}
                        textColor={Styles.Main.textGray.color}
                        stylePickerView={[
                          Styles.Main.borderBottomLightGray,
                          Styles.Main.borderBottomWidth1,
                          Styles.Main.mr10,
                          Styles.Main.ml5,
                        ]}
                      />
                    </Col>
                  </Row>
                </View>
              </Col>
            </Row>
          </Grid>
        </Content>
        <Button
          block
          onPress={handleReset}
          style={[Styles.Main.backgroundLightGray, StyleSQSNSpaj.borderRadius0]}
        >
          <Text style={[Styles.Main.textStrongWhite]}>{_('Ulangi')}</Text>
        </Button>

        <Button
          block
          onPress={handleSearch}
          style={[Styles.Main.backgroundRed, StyleSQSNSpaj.borderRadius0]}
        >
          <Text style={[Styles.Main.textStrongWhite]}>{_('Cari')}</Text>
        </Button>
      </Fragment>
    );
  }
}

export default AdvanceSearchSQSNSpaj;
