import Axios from 'axios';
import { WLClient } from 'react-native-ibm-mobilefirst';
import { SUBMIT_PHS } from './ConfigPolicyTransaction';

export const submitPHS = async (object, token, action) => {
  action(SUBMIT_PHS.FETCH, object);
  const serverUrl = await WLClient.getServerUrl();
  const config = {
    method: 'POST',
    data: JSON.stringify(object),
    url: `${serverUrl}/adapters/HTTPAdapterCommonJavaPDNF2F/resource/submitSwitching`,
    headers: {
      'Content-Type': 'application/json',
      'X-CSRF-Token': `Bearer ${token}`,
    },
    timeout: 10000,
  };
  try {
    Axios.defaults.timeout = setTimeout || 10000;
    const res = await Axios(config);
    if (res.data && String(res.data.responseCode) === '200') action(SUBMIT_PHS.SUCCESS, res.data);
    else action(SUBMIT_PHS.FAILED, `${res.data.responseMessage} [${res.data.responseCode}].`);
  } catch (err) {
    action(SUBMIT_PHS.FAILED, `${err.message} [999].`);
  }
};
