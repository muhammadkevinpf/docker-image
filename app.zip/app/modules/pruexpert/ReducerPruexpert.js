import { RESET_ALL_STATE } from '../dashboard/ConfigDashboard';

const initialState = {

};

export function ReducerPRUExpert(state = initialState, action) {
  switch (action.type) {
    case RESET_ALL_STATE: return initialState;
    default: return state;
  }
}
