import moment from 'moment';
// import Analytics from 'appcenter-analytics';
import CryptoJS from 'crypto-js';
import SQLiteUtils from '../../../utilities/SQLiteUtils';
import Database from '../../../config/Database';
import { ConfigProduct } from '../config';
// eslint-disable-next-line import/no-cycle
import { ConfigProductSPAJ } from '../../spaj/configs';
import CustomerStorageService from './CustomerStorageService';

const { headerProposal } = Database.pruSmart.tables;

const querySelectById = `SELECT * FROM ${headerProposal.name} WHERE agentCode = ? AND method = ? AND draftId = ?`;
const querySelectAll = `SELECT * FROM ${headerProposal.name} WHERE agentCode = ? AND method = ?`;
const queryInsert = `INSERT INTO ${headerProposal.name} ${headerProposal.column} VALUES (?, ?, ?, ?, ?)`;
const queryUpdate = `UPDATE ${headerProposal.name} SET data = ?, updatedDate = ? WHERE method = ? AND agentCode = ? AND draftId = ?`;
const queryDelete = `DELETE FROM ${headerProposal.name} WHERE agentCode = ? AND method = ? AND draftId = ?`;
const serviceName = 'HeaderService';

const masterCoState = {
  SQS: 'SQS',
  AMEND: 'Amandemen',
  DOC_UPL: 'Dokumen Pendukung',
};

const getHeaderDataByDraftId = (agentCode, draftId) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(global.database.pruSmart, querySelectById, [agentCode, headerProposal.method, draftId]);
    if (res.rows.length > 0) {
      resolve(JSON.parse(CryptoJS.AES.decrypt(res.rows.item(0).data, SQLiteUtils.DBKEY).toString(CryptoJS.enc.Utf8)));
    } else {
      resolve(res.rows.length);
    }
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const getHeadersData = agentCode => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(global.database.pruSmart, querySelectAll, [agentCode, headerProposal.method]);
    const data = [];
    for (let i = 0; i < res.rows.length; i += 1) {
      data.push(JSON.parse(CryptoJS.AES.decrypt(res.rows.item(i).data, SQLiteUtils.DBKEY).toString(CryptoJS.enc.Utf8)));
    }
    resolve(data);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const upsert = (agentCode, data) => new Promise(async (resolve, reject) => {
  try {
    // eslint-disable-next-line no-param-reassign
    data.draftId = data.quotId.trim().substr(1);
    let queryToProcess = queryInsert;
    let param = [
      headerProposal.method,
      agentCode,
      CryptoJS.AES.encrypt(JSON.stringify(data), SQLiteUtils.DBKEY).toString(),
      moment().format('DD/MM/YYYY HH:mm'),
      data.draftId,
    ];
    const check = await SQLiteUtils.executeQuery(global.database.pruSmart, querySelectById, [agentCode, headerProposal.method, data.draftId]);
    if (check.rows.length > 0) {
      queryToProcess = queryUpdate;
      param = [
        CryptoJS.AES.encrypt(JSON.stringify(data), SQLiteUtils.DBKEY).toString(),
        moment().format('DD/MM/YYYY HH:mm'),
        headerProposal.method,
        agentCode,
        data.draftId,
      ];
    }
    const res = await SQLiteUtils.executeTransaction(global.database.pruSmart, queryToProcess, param);
    resolve(`res upsert header proposal ${res}`);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const remove = (agentCode, draftId) => new Promise(async (resolve, reject) => {
  try {
    const checkData = await getHeaderDataByDraftId(agentCode, draftId);
    if (!checkData) { reject(new Error(`${serviceName} Data not found`)); }
    const res = await SQLiteUtils.executeTransaction(global.database.pruSmart, queryDelete, [agentCode, headerProposal.method, draftId]);
    resolve(`res delete header proposal ${res}`);
  } catch (error) {
    reject(new Error(`${serviceName} ${error.message}`));
  }
});

const convertSqsToHeader = (sqsData, username, agentCode, status, propNo, coState, spaj) => new Promise(async (resolve, reject) => {
  try {
    let header = await getHeaderDataByDraftId(agentCode, sqsData.sqs.quotationCd.substr(1));
    if (!header) {
      header = ConfigProduct.proposalHeaderObject();
    }
    let quotId = sqsData.sqs.quotationCd;
    if (sqsData.sqs.type === 'SPAJ') {
      quotId = sqsData.sqs.proposalCd;
      if ([...ConfigProductSPAJ.viewModeSpaj, 'counterOfferDraft', 'counterOfferSubmitted'].includes(status)) {
        header.propNo = propNo;
      }
    }

    const counterOfferState = masterCoState[coState] ? masterCoState[coState] : '';
    const quickQuote = sqsData.sqs.quickQuote.find(x => x.isMainQuotation);
    const customerIdMap = {};
    customerIdMap.PH = quickQuote.client.ph.customerId;
    quickQuote.client.lifeAss.forEach((x) => {
      customerIdMap[x.role] = x.customerId;
    });
    const customers = await CustomerStorageService.getCustomerStorageByCustomerMap(global.database.pruSmart, { agentCode, customerIdMap });
    Object.keys(customerIdMap).forEach((x) => {
      if (customerIdMap[x]) {
        customerIdMap[`name${x}`] = customers.find(y => y.customerId === customerIdMap[x]).name;
      }
    });
    header.productCd = quickQuote.productCode;
    header.currency = quickQuote.currCd;
    header.draftId = sqsData.sqs.quotationCd.substr(1);
    header.agenId = agentCode;
    header.type = sqsData.sqs.type;
    header.createdBy = username;
    // eslint-disable-next-line no-nested-ternary
    header.createdDate = coState ? (spaj ? spaj.policy.counterOfferDate : sqsData.quotationDate) : sqsData.quotationDate;
    header.updatedBy = username;
    header.updatedDate =
    sqsData.sqs.updatedDate instanceof Date ?
      (`${moment(sqsData.sqs.updatedDate, 'YYYY-MM-DDTHH:mm:ss.SSS').format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`)
      : sqsData.sqs.updatedDate;
    // header.reason = quickQuote.reason;
    header.originCreatedDate = sqsData.quotationDate;
    header.originSubmitedDate = sqsData.submitedDate;
    header.premium = quickQuote.premiBerkala;
    header.productCategory = quickQuote.productCategory;
    header.quotId = quotId;
    header.sumAssured = quickQuote.premium;
    header.originStatus = status || 'Ilustration';
    header.phName = spaj ? spaj.client.ph.name || '' : customerIdMap.namePH || '';
    header.tuName = customerIdMap.name01 || '';
    header.flagDraft = sqsData.sqs.flagDraft;
    header.counterOfferState = counterOfferState || '';
    header.isNF2F = spaj ? spaj.flgNonf2f : false;
    const res = await upsert(agentCode, header, header.draftId);
    resolve(res);
  } catch (error) {
    // Analytics.trackEvent(serviceName, error);
    reject(new Error(`${serviceName} ${error.message}`));
  }
});


export default {
  getHeadersData,
  upsert,
  remove,
  getHeaderDataByDraftId,
  convertSqsToHeader,
};
