export const commissionEstimationAction = (action, value) => ({ type: action, payload: value });

export const COMMISSION_ESTIMATION = {
  API: 'adapters/HTTPAdapter3/findAllComissionEstimationByAgentNumber',
  FETCH: 'COMMISSION_ESTIMATION_FETCH',
  SUCCESS: 'COMMISSION_ESTIMATION_SUCCESS',
  FAILED: 'COMMISSION_ESTIMATION_FAILED',
};
