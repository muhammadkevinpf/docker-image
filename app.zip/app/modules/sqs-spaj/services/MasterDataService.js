import Database from '../../../config/Database';
import SQLiteUtils from '../../../utilities/SQLiteUtils';

const newSqsDB = Database.newSqs;
const pruSmartDB = Database.pruSmart;

const querySelect = (tableName, whereClause) => `SELECT * FROM ${tableName} ${whereClause ? `WHERE ${whereClause}` : ''}`;
const queryDelete = (tableName, whereClause) => `DELETE FROM ${tableName} ${whereClause ? `WHERE ${whereClause}` : ''}`;

const openDatabase = () => new Promise(async (resolve, reject) => {
  try {
    const db = await SQLiteUtils.openDatabase(newSqsDB.name, 'default', 1);
    resolve(db);
  } catch (error) {
    reject(error);
  }
});

const getPublishExisting = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.publish), []);
    resolve(JSON.parse(res.rows.item(0).data));
  } catch (error) {
    reject(error);
  }
});

const getPublishByVersion = (newSqs, publishVersion) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.publish, 'publishVersion=?'), [publishVersion]);
    resolve(JSON.parse(res.rows.item(0).data));
  } catch (error) {
    reject(error);
  }
});

const getAllPublish = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.publish), []);
    resolve(JSON.parse(res.rows.item(0).data));
  } catch (error) {
    reject(error);
  }
});

const deletePublish = (newSqs, publishVersion) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeTransaction(newSqs, queryDelete(newSqsDB.tables.publish, 'publishVersion = ?'), [publishVersion]);
    resolve(`Delete Publish With publishVersion: ${publishVersion}, ${res}`);
  } catch (error) {
    reject(error);
  }
});

const getFormula = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.formula), []);
    resolve(JSON.parse(res.rows.item(0).data));
  } catch (error) {
    reject(error);
  }
});

const getPdfBySqsId = (newSqs, sqsId) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect('pdfstore', 'sqsid = ?'), [sqsId]);
    resolve(JSON.parse(res.rows.item(0).data));
  } catch (error) {
    reject(error);
  }
});

const deletePdfBySqsId = (newSqs, sqsId) => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeTransaction(newSqs, queryDelete('pdfstore', 'sqsid = ?'), [sqsId]);
    resolve(`Delete PDF With SQSID: ${sqsId}, ${res}`);
  } catch (error) {
    reject(error);
  }
});

const getRule = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeTransaction(newSqs, querySelect(newSqsDB.tables.rule), []);
    resolve(JSON.parse(res.rows.item(0).data));
  } catch (error) {
    reject(error);
  }
});

const getPosition = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.position), []);
    resolve(JSON.parse(res.rows.item(0).data_json).POSITION);
  } catch (error) {
    reject(error);
  }
});

const getChannel = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.channel), []);
    resolve(JSON.parse(res.rows.item(0).data_json).CHANNEL);
  } catch (error) {
    reject(error);
  }
});

const getOccupation = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.occupation), []);
    resolve(JSON.parse(res.rows.item(0).data_json).OCCUPATION);
  } catch (error) {
    reject(error);
  }
});

const getLoad = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.load), []);
    resolve(JSON.parse(res.rows.item(0).data));
  } catch (error) {
    reject(error);
  }
});

const getBusiness = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.business), []);
    resolve(JSON.parse(res.rows.item(0).data));
  } catch (error) {
    reject(error);
  }
});

const getIncome = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.income), []);
    resolve(JSON.parse(res.rows.item(0).data));
  } catch (error) {
    reject(error);
  }
});

const getFund = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.fund), []);
    resolve(JSON.parse(res.rows.item(0).data_json).FUND);
  } catch (error) {
    reject(error);
  }
});

const getCoverage = newSqs => new Promise(async (resolve, reject) => {
  try {
    const length = await SQLiteUtils.executeQuery(newSqs, 'SELECT length(data_json) as length FROM coverage', []);
    const lengthData = 1000000;
    let result = '';

    for (let i = 1; i <= length.rows.item(0).length; i += lengthData) {
      // eslint-disable-next-line no-await-in-loop
      const res = await SQLiteUtils.executeQuery(newSqs, `SELECT substr(data_json, ${i}, ${lengthData}) as DATA from coverage`, []);
      result += res.rows.item(0).DATA;
    }

    resolve(JSON.parse(result).COVERAGE);
  } catch (error) {
    reject(error);
  }
});

const getCoverageGroup = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.coverageGroup), []);
    resolve(JSON.parse(res.rows.item(0).data));
  } catch (error) {
    reject(error);
  }
});

const getPaymentFreq = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.paymentFrequency), []);
    resolve(JSON.parse(res.rows.item(0).data));
  } catch (error) {
    reject(error);
  }
});

const getFundGroup = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.fundGroup), []);
    resolve(JSON.parse(res.rows.item(0).data));
  } catch (error) {
    reject(error);
  }
});

const getInput = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.input), []);
    resolve(JSON.parse(res.rows.item(0).data));
  } catch (error) {
    reject(error);
  }
});

const getAllRiderRecommendation = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.allRiderRecommendation), []);
    resolve(JSON.parse(res.rows.item(0).data_json).ALL_RIDER_RECOMENDATION);
  } catch (error) {
    reject(error);
  }
});

const getDisclaimer = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.disclaimer), []);
    resolve(JSON.parse(res.rows.item(0).data));
  } catch (error) {
    reject(error);
  }
});

const getProductRecommendation = pruSmart => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(pruSmart, querySelect(pruSmartDB.name, 'method = ?'), [pruSmartDB.name]);
    resolve(JSON.parse(res.rows.item(0).data));
  } catch (error) {
    reject(error);
  }
});

const getQuestionare = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.questionnaire), []);
    resolve(JSON.parse(res.rows.item(0).data));
  } catch (error) {
    reject(error);
  }
});

const getZipCode = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.zipCode), []);
    resolve(JSON.parse(res.rows.item(0).data));
  } catch (error) {
    reject(error);
  }
});

const getAllCountry = newSqs => new Promise(async (resolve, reject) => {
  try {
    const res = await SQLiteUtils.executeQuery(newSqs, querySelect(newSqsDB.tables.allCountry), []);
    resolve(JSON.parse(res.rows.item(0).data_json).ALL_COUNTRY);
  } catch (error) {
    reject(error);
  }
});

export default {
  openDatabase,
  getAllCountry,
  getAllPublish,
  getAllRiderRecommendation,
  getBusiness,
  getChannel,
  getCoverage,
  getCoverageGroup,
  getDisclaimer,
  getFormula,
  getFund,
  getFundGroup,
  getIncome,
  getInput,
  getLoad,
  getOccupation,
  getPaymentFreq,
  getPdfBySqsId,
  getPosition,
  getProductRecommendation,
  getPublishByVersion,
  getPublishExisting,
  getQuestionare,
  getRule,
  getZipCode,
  deletePdfBySqsId,
  deletePublish,
};
