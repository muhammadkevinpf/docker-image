/* eslint-disable react-native/no-color-literals */
/**
 * @author: dwi.setiyadi@gmail.com
*/

import { StyleSheet } from 'react-native';
import { statusBarHeight } from '../../config/Platform';

export default StyleSheet.create({
  areaSave: {
    flex: 1,
    backgroundColor: 'transparent',
    paddingTop: statusBarHeight,
  },
  container: {
    backgroundColor: 'transparent',
  },
  sideBarStyle: {
    backgroundColor: '#ffffff',
  },
  image: {
    height: 27,
    width: 27,
  },
  containerItem: {
    height: 38,
  },
  containerHeader: {
    height: 56,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#c9c9c9',
  },
  left: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  right: {
    justifyContent: 'center',
  },
  separator: {
    height: 48,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#c9c9c9',
    paddingBottom: 10,
    marginBottom: 10,
  },
});
