import { API_ACTION_TYPES } from '../../utilities';

export const GET_LETTER_TYPE = {
  API: 'adapters/HTTPAdapterCorrespondence/getLetterType',
  FETCH: 'GET_LETTER_TYPE_FETCH',
  SUCCESS: 'GET_LETTER_TYPE_SUCCESS',
  FAILED: 'GET_LETTER_TYPE_FAILED',
};

export const GET_UNIT_AGENT = {
  API: 'adapters/HTTPAdapterCorrespondence/getUnitAgent',
  FETCH: 'GET_UNIT_AGENT_FETCH',
  SUCCESS: 'GET_UNIT_AGENT_SUCCESS',
  FAILED: 'GET_UNIT_AGENT_FAILED',
};

export const GET_UNIT_AGENT_LEADER = {
  API: 'adapters/HTTPAdapterCorrespondence/getUnitAgentAndLeader',
  FETCH: 'GET_UNIT_AGENT_LEADER_FETCH',
  SUCCESS: 'GET_UNIT_AGENT_LEADER_SUCCESS',
  FAILED: 'GET_UNIT_AGENT_LEADER_FAILED',
};

export const GET_DOCUMENT_CATEGORY = {
  API: 'adapters/HTTPAdapterCorrespondence/getDocumentCategory',
  FETCH: 'GET_DOCUMENT_CATEGORY_FETCH',
  SUCCESS: 'GET_DOCUMENT_CATEGORY_SUCCESS',
  FAILED: 'GET_DOCUMENT_CATEGORY_FAILED',
};

export const GET_CORRESPONDENCE = {
  API: 'adapters/HTTPAdapterCorrespondence/getCorrespondenceResults',
  FETCH: 'GET_CORRESPONDENCE_FETCH',
  SUCCESS: 'GET_CORRESPONDENCE_SUCCESS',
  FAILED: 'GET_CORRESPONDENCE_FAILED',
};

export const GET_PASSWORD_INFO = {
  API: 'adapters/HTTPAdapterCorrespondence/getInfoPassword',
  FETCH: 'GET_PASSWORD_INFO_FETCH',
  SUCCESS: 'GET_PASSWORD_INFO_SUCCESS',
  FAILED: 'GET_PASSWORD_INFO_FAILED',
};

export const GET_PDF_DOCUMENT = {
  API: 'adapters/HTTPAdapterCorrespondence/getPDFDocument',
  FETCH: 'GET_PDF_DOCUMENT_FETCH',
  SUCCESS: 'GET_PDF_DOCUMENT_SUCCESS',
  FAILED: 'GET_PDF_DOCUMENT_FAILED',
};

export const SEND_CORRESPONDENCE_DOC = {
  API: 'adapters/HTTPAdapterCorrespondence/sendCorrespondenceDoc',
  FETCH: 'SEND_CORRESPONDENCE_DOC_FETCH',
  SUCCESS: 'SEND_CORRESPONDENCE_DOC_SUCCESS',
  FAILED: 'SEND_CORRESPONDENCE_DOC_FAILED',
};

export const CLEAR_CORRESPONDENCE = {
  LIST: 'CLEAR_CORRESPONDENCE_LIST',
  LETTER_TYPE: 'CLEAR_LETTER_TYPE',
  DOC_CATEGORY: 'CLEAR_DOC_CATEGORY',
  PASS_INFO: 'CLEAR_PASSWORD_INFO',
  PDF_DOC: 'CLEAR_PDF_DOC',
  DOWNLOAD_LIST: 'CLEAR_DOWNLOAD_LIST',
};

// download file
export const GET_DOC_CATEGORY = API_ACTION_TYPES('GET_DOC_CATEGORY', 'adapters/HTTPAdapterDocumentManagement/getCollateralAllCategory');
export const GET_DOC_BY_ID = API_ACTION_TYPES('GET_DOC_BY_ID', 'adapters/HTTPAdapterDocumentManagement/getCollateralDocument');
export const GET_DOC_BASE64 = API_ACTION_TYPES('GET_DOC_BASE64', 'adapters/HTTPAdapterDocumentManagement/getCollateralDocumentView');
export const SEND_DOC_BY_EMAIL = API_ACTION_TYPES('SEND_DOC_BY_EMAIL', 'adapters/HTTPAdapterDocumentManagement/sendCollateralDocumentByEmail');
