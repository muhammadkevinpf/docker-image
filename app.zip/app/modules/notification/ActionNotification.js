import {
  LISTNOTIFICATIONFAILED,
  LISTNOTIFICATIONFETCH,
  LISTNOTIFICATIONSUCCESS,

  TOTALNOTIFICATIONFAILED,
  TOTALNOTIFICATIONFETCH,
  TOTALNOTIFICATIONSUCCESS,

  UPDATENOTIFICATIONFAILED,
  UPDATENOTIFICATIONFETCH,
  UPDATENOTIFICATIONSUCCESS,
} from './ConfigNotification';

export const totalNotificationFetch = value => ({ type: TOTALNOTIFICATIONFETCH, send: value });
export const totalNotificationSuccess = value => ({ type: TOTALNOTIFICATIONSUCCESS, res: value });
export const totalNotificationFailed = value => ({ type: TOTALNOTIFICATIONFAILED, err: value });

export const listNotificationFetch = value => ({ type: LISTNOTIFICATIONFETCH, send: value });
export const listNotificationSuccess = value => ({ type: LISTNOTIFICATIONSUCCESS, res: value });
export const listNotificationFailed = value => ({ type: LISTNOTIFICATIONFAILED, err: value });

export const updateNotificationFetch = value => ({ type: UPDATENOTIFICATIONFETCH, send: value });
export const updateNotificationSuccess = value => ({ type: UPDATENOTIFICATIONSUCCESS, res: value });
export const updateNotificationFailed = value => ({ type: UPDATENOTIFICATIONFAILED, err: value });
