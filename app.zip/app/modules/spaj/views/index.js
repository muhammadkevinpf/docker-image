import IntroSpaj_ from './intro-spaj';
import { CustomerDataSpaj, PayorDataSpaj } from './customer-data';
import BMISpaj from './bmi';
import LandingTest_ from './LandingTest';
import { SpajTopup, SpajTopupDetail } from './top-up';
import SpajDocument from './document';
import ProspectiveBeneficiaries from './prospective-beneficiaries';
import NavigationsSpaj from './navigation-spaj';
import MagnumMedicalData from './magnum-medical-data';
import SpajAmandemen from './amandemen';
import { SignatureSqs, SignatureSpaj } from './sign-spaj';
import SpajEula from './eula-spaj';
import SpajPembayaran from './payment';
import PaymentConfirmation from './payment-confirmation';
import SubmitSpaj from './submit-spaj';
import SuratKeterikatanAsuransi from './surat-keterangan-asuransi';

const IntroSpaj = IntroSpaj_;
const LandingTest = LandingTest_;

export default {
  IntroSpaj,
  CustomerDataSpaj,
  BMISpaj,
  PayorDataSpaj,
  LandingTest,
  SpajTopup,
  SpajTopupDetail,
  SpajDocument,
  ProspectiveBeneficiaries,
  NavigationsSpaj,
  MagnumMedicalData,
  SignatureSqs,
  SignatureSpaj,
  SpajAmandemen,
  SpajEula,
  SpajPembayaran,
  PaymentConfirmation,
  SubmitSpaj,
  SuratKeterikatanAsuransi,
};
