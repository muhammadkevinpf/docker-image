export function fundAction(type, payload) {
  return { type, payload };
}
