/* eslint-disable react/no-array-index-key */
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
// import { Platform } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import {
  View, Text, Icon,
} from 'native-base';
import { isText } from '../../../utilities';
import LoadingModal from '../../../components/loading_modal';
import Style from '../../../styles';
import _ from '../../../lang';
import { CoverageText } from '../../../components';

export class InformationTouchable extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
    };
  }

  render() {
    return (
      <TouchableOpacity
        disabled={this.props.disabled}
        onPress={() => (this.props.disabled ? {} : this.props.onClick())}
        style={[Style.Main.container, Style.Main.alignContentCenter, Style.Main.mV10, Style.Main.pb15,
          Style.Main.borderBottomWidth1, Style.Main.borderBottomWhiteSmoke, this.props.style]}
      >
        <View style={[Style.Main.rowDirectionSpaceBetween]}>
          <View style={[Style.Main.container, Style.Main.rowDirection]}>
            { this.props.iconName !== undefined &&
            <Icon
              name={this.props.iconName}
              type={this.props.iconType}
              style={[Style.Main.textGray, Style.Main.font18, Style.Main.ml2, Style.Main.mr5, Style.Main.mt2, Style.Main.mt2, this.props.iconStyle]}
            />
          }
            <Text style={[Style.Main.fontAlbert11, Style.Main.sh, this.props.leftStyle]}>{this.props.leftContent}</Text>
          </View>
          <View style={[Style.Main.rowDirection, Style.Main.ml15]}>
            {isText(this.props.rightContent) ?
              <Text style={[Style.Main.fontAlbert11, Style.Main.alignCenter, this.props.rightStyle]}>{this.props.rightContent}</Text>
              : this.props.rightContent}
            {
            this.props.showRightIcon && !this.props.disabled &&
            <Icon name="angle-right" type="FontAwesome" style={[Style.Main.textGray, Style.Main.font18, Style.Main.ml12, Style.Main.alignCenter]} />
          }
          </View>
        </View>
        {this.props.extraLabel && <Text style={[Style.Main.fontAlbert, Style.Main.font10, this.props.extraLabelStyle]}>{this.props.extraLabel}</Text>}
        <LoadingModal show={this.state.isLoading} size="large" color="white" />
      </TouchableOpacity>
    );
  }
}

export class InformationCard extends PureComponent {
  render() {
    return (
      <View style={[Style.Main.mV10, Style.Main.pb15, Style.Main.borderBottomNativeBase, this.props.style]}>
        <View style={[Style.Main.rowDirectionFlexStart, Style.Main.justifyCenter]}>
          { this.props.iconName !== undefined &&
          <Icon
            name={this.props.iconName}
            type={this.props.iconType}
            style={[Style.Main.textGray, Style.Main.font18, Style.Main.container, this.props.iconStyle, Style.Main.mt2]}
          />
        }
          <View style={[Style.Main.flex8, Style.Main.justifyCenter]}>
            <Text style={[Style.Main.fontAlbert11, this.props.labelStyle]}>{_(this.props.label)}</Text>
            {isText(this.props.data) ?
              <Text onPress={this.props.onPress} style={[Style.Main.fontAlbert11, this.props.dataStyle]}>
                <CoverageText style={[Style.Main.fontAlbert11, this.props.dataStyle]} desc={this.props.data} />
              </Text> : this.props.data}
            {this.props.children}
          </View>
        </View>
        {this.props.extraLabel && <Text style={[Style.Main.fontAlbert, Style.Main.font10]}>{_(this.props.extraLabel)}</Text>}
      </View>
    );
  }
}

export class InformationCardRow extends PureComponent {
  render() {
    return (
      <View style={[
        Style.Main.container,
        Style.Main.padding10,
        Style.Main.rowDirectionSpaceBetween,
        Style.Main.borderBottomWhiteSmoke,
        Style.Main.borderBottomWidth1,
        this.props.style]}
      >
        <View style={[Style.Main.rowDirection, Style.Main.width187]}>
          {
            this.props.iconName !== undefined &&
            <Icon
              name={this.props.iconName}
              type={this.props.iconType}
              style={[Style.Main.textGray, Style.Main.font18, Style.Main.container, Style.Main.mr15, this.props.iconStyle]}
            />
          }
          <Text style={[Style.Main.fontAlbert11, Style.Main.flex8, this.props.labelStyle]}>{_(this.props.label)}</Text>
        </View>
        <Text onPress={this.props.onPress} style={[Style.Main.fontAlbert11, this.props.dataStyle]}>
          {this.props.data}
        </Text>
      </View>
    );
  }
}

InformationTouchable.propTypes = {
  iconName: PropTypes.string,
  iconType: PropTypes.string,
  showRightIcon: PropTypes.bool,
  iconStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  leftContent: PropTypes.oneOfType([PropTypes.string, PropTypes.element, PropTypes.number]),
  rightContent: PropTypes.oneOfType([PropTypes.string, PropTypes.element, PropTypes.number]),
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  leftStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  rightStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  onClick: PropTypes.func,
};

InformationTouchable.defaultProps = {
  iconName: undefined,
  iconType: 'FontAwesome',
  iconStyle: null,
  showRightIcon: true,
  leftContent: '',
  rightContent: '',
  style: null,
  leftStyle: null,
  rightStyle: null,
  onClick: () => {},
};

InformationCard.propTypes = {
  data: PropTypes.oneOfType([PropTypes.string, PropTypes.number, PropTypes.object, PropTypes.array]),
  style: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  iconStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  labelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  dataStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  iconName: PropTypes.string,
  iconType: PropTypes.string,
  label: PropTypes.string,
};

InformationCard.defaultProps = {
  data: '',
  style: null,
  iconStyle: null,
  labelStyle: null,
  dataStyle: null,
  iconName: undefined,
  iconType: 'FontAwesome',
  label: '',
};

InformationCardRow.propTypes = {
  ...InformationCard.propTypes,
};

InformationCardRow.defaultProps = {
  ...InformationCard.defaultProps,
};
