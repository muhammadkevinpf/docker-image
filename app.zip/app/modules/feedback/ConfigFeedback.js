export const sortFeedback = [
  {
    value: '01', orderBy: 'policyHolderName', direction: 'asc', label: 'Nama Pemegang Polis A-Z',
  },
  {
    value: '02', orderBy: 'policyHolderName', direction: 'desc', label: 'Nama Pemegang Polis Z-A',
  },
  {
    value: '03', orderBy: 'submitDate', direction: 'desc', label: 'Tanggal Kirim Terkini',
  },
  {
    value: '04', orderBy: 'submitDate', direction: 'asc', label: 'Tanggal Kirim Terlampau',
  },
];

export const GET_ALL_FEEDBACK = {
  API: 'adapters/HTTPAdapterFeedbackForm/getAllFeedback',
  FETCH: 'GET_ALL_FEEDBACK_FETCH',
  SUCCESS: 'GET_ALL_FEEDBACK_SUCCESS',
  FAILED: 'GET_ALL_FEEDBACK_FAILED',
};

export const GET_DETAIL_FEEDBACK = {
  API: 'adapters/HTTPAdapterFeedbackForm/getDetailFeedback',
  FETCH: 'GET_DETAIL_FEEDBACK_FETCH',
  SUCCESS: 'GET_DETAIL_FEEDBACK_SUCCESS',
  FAILED: 'GET_DETAIL_FEEDBACK_FAILED',
};

export const GET_SUB_TRANSACTION_TYPE = {
  API: 'adapters/HTTPAdapterFeedbackForm/getSubTransactionType',
  FETCH: 'GET_SUB_TRANSACTION_TYPE_FETCH',
  SUCCESS: 'GET_SUB_TRANSACTION_TYPE_SUCCESS',
  FAILED: 'GET_SUB_TRANSACTION_TYPE_FAILED',
};

export const GET_AGENT_DATA = {
  API: 'adapters/HTTPAdapterFeedbackForm/getAgentData',
  FETCH: 'GET_AGENT_DATA_FETCH',
  SUCCESS: 'GET_AGENT_DATA_SUCCESS',
  FAILED: 'GET_AGENT_DATA_FAILED',
};

export const FIND_TRANSACTION_TYPE = {
  API: 'adapters/HTTPAdapterFeedbackForm/findTransactionType',
  FETCH: 'FIND_TRANSACTION_TYPE_FETCH',
  SUCCESS: 'FIND_TRANSACTION_TYPE_SUCCESS',
  FAILED: 'FIND_TRANSACTION_TYPE_FAILED',
};

export const FIND_SUB_TRANSACTION_TYPE = {
  API: 'adapters/HTTPAdapterFeedbackForm/findSubTransactionType',
  FETCH: 'FIND_SUB_TRANSACTION_TYPE_FETCH',
  SUCCESS: 'FIND_SUB_TRANSACTION_TYPE_SUCCESS',
  FAILED: 'FIND_SUB_TRANSACTION_TYPE_FAILED',
};

export const GET_FILE_BASE64 = {
  API: 'adapters/HTTPAdapterFeedbackForm/getFileBase64',
  FETCH: 'GET_FILE_BASE64_FETCH',
  SUCCESS: 'GET_FILE_BASE64_SUCCESS',
  FAILED: 'GET_FILE_BASE64_FAILED',
};

export const SUBMIT_FEEDBACK = {
  API: 'adapters/HTTPAdapterFeedbackForm/sendFeedback',
  FETCH: 'SUBMIT_FEEDBACK_FETCH',
  SUCCESS: 'SUBMIT_FEEDBACK_SUCCESS',
  FAILED: 'SUBMIT_FEEDBACK_FAILED',
};

export const CLEAR_ALL_FEEDBACK = 'CLEAR_ALL_FEEDBACK';
export const CLEAR_SUB_TRANSACTION_TYPE = 'CLEAR_SUB_TRANSACTION_TYPE';
export const CLEAR_DETAIL_FEEDBACK = 'CLEAR_DETAIL_FEEDBACK';
