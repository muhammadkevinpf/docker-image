export const inquiriesType = {
  proposal: 'proposal',
  policy: 'policy',
};

export const proposalIndividuSort = [
  { label: 'Nama Pemegang Polis', value: 'policyHolderName' },
  { label: 'Nomor SPAJ', value: 'proposalNumber' },
];

export const proposalUnitSort = [
  { label: 'Total Proposal ASC', value: 'asc' },
  { label: 'Total Proposal DESC', value: 'desc' },
];

export const policyIndividuSort = [
  { label: 'Nama Pemegang Polis A-Z', value: 'policyHolderName' },
  { label: 'Nama Pemegang Polis Z-A', value: 'policyHolderNameDesc' },
  { label: 'Nomor Polis A-Z', value: 'policyNumber' },
  { label: 'Nomor Polis Z-A', value: 'policyNumberDesc' },
  { label: 'Issued Date (Terlama)', value: 'policyByDate' },
  { label: 'Issued Date (Terbaru)', value: 'policyByDateDesc' },
];

export const policyUnitSort = [
  { label: 'Total Polis ASC', value: 'asc' },
  { label: 'Total Polis DESC', value: 'desc' },
];

// MAIN PROPOSAL POLICY

export const PROPOSAL_GRAPH = {
  API: 'adapters/HTTPAdapterInquiry/findProposalHomeGraph',
  FETCH: 'PROPOSAL_GRAPH_FETCH',
  SUCCESS: 'PROPOSAL_GRAPH_SUCCESS',
  FAILED: 'PROPOSAL_GRAPH_FAILED',
};

export const POLICY_GRAPH = {
  API: 'adapters/HTTPAdapterInquiry/findTotalPolicyGraph',
  FETCH: 'POLICY_GRAPH_FETCH',
  SUCCESS: 'POLICY_GRAPH_SUCCESS',
  FAILED: 'POLICY_GRAPH_FAILED',
};

export const PROPOSAL_POLICY_UPDATED_DATE = {
  API: 'adapters/HTTPAdapterInquiry/findLastUpdateProposalPolicy',
  FETCH: 'PROPOSAL_POLICY_UPDATED_DATE_FETCH',
  SUCCESS: 'PROPOSAL_POLICY_UPDATED_DATE_SUCCESS',
  FAILED: 'PROPOSAL_POLICY_UPDATED_DATE_FAILED',
};

// LIST PROPOSAL POLICY

export const PROPOSAL_POLICY = {
  API: 'adapters/HTTPAdapterInquiry/findListProposalPolicy',
  FETCH: 'PROPOSAL_POLICY_FETCH',
  SUCCESS: 'PROPOSAL_POLICY_SUCCESS',
  FAILED: 'PROPOSAL_POLICY_FAILED',
  RESET: 'CLEAR_PROPOSAL_POLICY',
};

export const PROPOSAL_POLICY_FILTER = {
  API: 'adapters/HTTPAdapterInquiry/findFilterListProposalPolicy',
  FETCH: 'PROPOSAL_POLICY_FILTER_FETCH',
  SUCCESS: 'PROPOSAL_POLICY_FILTER_SUCCESS',
  FAILED: 'PROPOSAL_POLICY_FILTER_FAILED',
};

export const PROPOSAL_POLICY_UNIT = {
  API: 'adapters/HTTPAdapterInquiry/findUnitProposalPolicy',
  FETCH: 'PROPOSAL_POLICY_UNIT_FETCH',
  SUCCESS: 'PROPOSAL_POLICY_UNIT_SUCCESS',
  FAILED: 'PROPOSAL_POLICY_UNIT_FAILED',
  RESET: 'CLEAR_PROPOSAL_POLICY_UNIT',
};

export const PROPOSAL_POLICY_UNIT_FILTER = {
  API: 'adapters/HTTPAdapterInquiry/findFilterUnitProposalPolicy',
  FETCH: 'PROPOSAL_POLICY_UNIT_FILTER_FETCH',
  SUCCESS: 'PROPOSAL_POLICY_UNIT_FILTER_SUCCESS',
  FAILED: 'PROPOSAL_POLICY_UNIT_FILTER_FAILED',
};

export const LAST_FETCH_STATUS = {
  PROPOSAL: 'LAST_FETCH_STATUS_PROPOSAL',
  POLICY: 'LAST_FETCH_STATUS_POLICY',
};
