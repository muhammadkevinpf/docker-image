/* eslint-disable import/no-cycle */
/* eslint-disable max-len */
/* eslint-disable no-console */
import moment from 'moment';
// import _ from 'lodash';
import SqsSpajService from './SqsSpajService';
import { componentCodeUuid } from '../views/magnum-medical-data/mappers/newMappers';
import ConfigProduct from '../../sqs-spaj/config/ConfigProduct';
import { ConfigProductSPAJ } from '../configs';
// import { WLClient } from 'react-native-ibm-mobilefirst';

/* eslint-disable prefer-destructuring */
/* eslint-disable camelcase */

// DOC ID
const eff_docid = '20171117';
// const versionSQS = '2.0.0';
// const docIdIlustration = '17060307';
const docIdRp = '17060334';
// const docIdBackdate = '17060306';
const docIdSpaj = '99999999';
const docIdPayor = '17060345';
const docIdAmend = '17060194';
const docIdTopup = '17060193';
const docIdSKA = '17060397';
// DOC ID FORM Kesehatan
const docIdEscc = '17080209';
const docIdDiges = '17080210';
const docIdRespi = '17080211';
const docIdTumor = '17080212';
const docIdDropHS = '14570901';
const docIdLampung = '17060369';
const versionLampung = 'v0217';

const isSubstandard = false;
const flagSA = '';
const isAgreeSubstandard = '';

// const pruForceVersion = WLClient
const channelType = {
  AG: 'Agency',
  BA: 'Bancassurance',
};

const salutMap = {
  F: 'IBU',
  M: 'BAPAK',
};

const surplusMap = {
  O: 'Mentransfer jumlah yang diterima ke Dana Investasi SAYA',
  T: "Mengembalikan jumlah yang diterima ke Dana Tabarru'",
  C: 'Mendonasikan jumlah yang diterima ke Dana Corporate Social Responsibility (CSR) Prudential Indonesia',
};

const rpQuestionMap = {
  Q001: 'Pengetahuan Saya tentang Investasi',
  Q002: 'Tujuan Saya Investasi adalah',
  Q003: 'Jika Saya menginvestasikan dana pada sebuah instrumen investasi (obligasi, saham, dan lainnya) Bagaimana Saya menggambarkan tingkat risiko investasi terhadap perkembangan dananya?',
  Q004: 'Saya sudah berinvestasi dalam obligasi/ reksadana/ saham/ investasi lainnya ( tanah, emas, dan lain-lain ) selama',
  Q005: 'Investasi yang Saya lakukan saat ini bertujuan untuk membiayai kebutuhan Saya dalam jangka waktu',
};

// const goalMapID = {
//   Kesehatan: 'A',
//   Kecelakaan: '2',
//   'Penyakit Kritis': 'Z',
//   Investasi: '4',
//   'Perlindungan Jiwa': 'Y',
//   'Dana Pensiun': 'D',
//   'Dana Pendidikan': 'C',
//   'Dana Warisan': '3',
// };

const { sqsProductROP, sqsProductSinglePremi } = ConfigProduct;

const goalMapID = {
  Kesehatan: 'X',
  Kecelakaan: '2',
  'Penyakit Kritis': 'Z',
  Investasi: '4',
  'Perlindungan Jiwa': 'Y',
  'Dana Pensiun': 'D',
  'Dana Pendidikan': 'C',
  'Dana Warisan': '3',
};

// function stringDivider(strParam, l) {
//   let str = strParam;

//   const address_line = [];
//   while (str.length > l) {
//     let pos = str.substring(0, l).lastIndexOf(' ');
//     pos = l;
//     address_line.push(str.substring(0, pos));
//     let i = str.indexOf(' ', pos) + 1;
//     // if(i < pos || i > pos+l)
//     i = pos;
//     str = str.substring(i);
//   }
//   address_line.push(str);
//   return address_line;
// }

function getOccpID(occpCode) {
  let occpID = 'Y';
  // Ibu rumah tangga, Pengangguran/Tidak Bekerja, Pelajar/Mahasiswa, Bukan Pelajar/Mahasiswa
  if (occpCode === 'HSWF' || occpCode === 'UNEM' || occpCode === 'STDN' || occpCode === 'NSTN' || occpCode === '') {
    occpID = 'N';
  }

  return occpID;
}

const mappingOccp = (clientParam) => {
  const clientOccp = clientParam;

  clientOccp.id = getOccpID(clientOccp.code);
  clientOccp.address.type = 'B';
  clientOccp.work_stat = '';
  clientOccp.cat = '';
  clientOccp.desc = clientOccp.desc_occp;

  return clientOccp;
};

const mappingSameAsAnotherClient = (clientParam, anotherClient) => {
  const client = clientParam;

  client.salut = anotherClient.salut;
  client.name = anotherClient.name;
  client.pob = anotherClient.pob;
  client.dob = anotherClient.dob;
  client.cob = anotherClient.cob;
  client.desc_cob = anotherClient.desc_cob;

  client.id = anotherClient.id;
  client.natlty = anotherClient.natlty;
  client.desc_natlty = anotherClient.desc_natlty;
  client.sex = anotherClient.sex;
  client.desc_sex = anotherClient.desc_sex;
  client.marryd = anotherClient.marryd;
  client.desc_marryd = anotherClient.desc_marryd;
  client.religion = anotherClient.religion;
  client.desc_religion = anotherClient.desc_religion;
  client.edu = anotherClient.edu;
  client.desc_edu = anotherClient.desc_edu;
  client.npwp = anotherClient.npwp;
  client.npwp_flag = anotherClient.npwp_flag;

  const newAddress = anotherClient.address;
  client.address = newAddress;
  client.occp = anotherClient.occp;
  client.contact = anotherClient.contact;
  client.income = anotherClient.income;
  client.type = anotherClient.type;
  client.number = anotherClient.number;
  client.corp_type = anotherClient.corp_type;
  client.age = anotherClient.age;
  client.anb = anotherClient.anb;
  client.xIns = anotherClient.xIns;

  return client;
};

const mappingPhoneNumber = (clientParam) => {
  let clientPhone = clientParam;

  clientPhone = clientPhone.map((val) => {
    const code = val.code.substr(1, val.code.length);
    const phoneNumber = val.number;
    const number = phoneNumber ? code + phoneNumber : '';
    const newPhone = { ...val, number };

    return newPhone;
  });

  console.log(clientPhone);

  let mobilePhone = clientPhone.filter(x => x.type === 'mobile');
  const notMobilePhone = clientPhone.filter(x => x.type !== 'mobile');

  // mapping phone type mobile => gsm
  mobilePhone = mobilePhone.map((val, i) => {
    const type = `gsm${i + 1}`;
    const newPhone = { ...val, type };

    return newPhone;
  });

  clientPhone = [...notMobilePhone, ...mobilePhone];

  console.log(clientPhone);

  return clientPhone;
};

const mappingSalut = (clientParam) => {
  const client = clientParam;

  client.type = 'P';
  client.id.type = 'A';
  client.salut = client.sex ? salutMap[client.sex] : '';

  return client;
};

const mappingTaxBoolean = (taxParam) => {
  let tax = taxParam;
  if (tax === true) {
    tax = 'Y';
  } else { tax = 'N'; }

  return tax;
};

const mappingTax = (clientParam) => {
  const clientTax = clientParam;

  clientTax.fatca_doc[0].code = 'NOTAX';
  clientTax.fatca_doc[0].stat = 'R';

  // RI TAX
  const riTax = mappingTaxBoolean(clientTax.ri_tax.stat);
  clientTax.ri_tax.stat = riTax;
  // US TAX
  const usTax = mappingTaxBoolean(clientTax.us_tax.stat);
  clientTax.us_tax.stat = usTax;
  // Tax Lainnya
  const foreignTax = mappingTaxBoolean(clientTax.foreign_tax);
  clientTax.foreign_tax = foreignTax;

  // Residency TAX
  if (clientTax.ri_tax.stat === 'N' && clientTax.us_tax.stat === 'N') {
    clientTax.residency_tax.stat = 'Y';
  } else {
    clientTax.residency_tax.stat = 'N';
  }

  // Change ph residency tax to Array
  const tempResidencyTax = clientTax.residency_tax;
  clientTax.residency_tax = [];
  clientTax.residency_tax.push(tempResidencyTax);

  return clientTax;
};

const mappingExpDate = (clientParam) => {
  const clientId = clientParam;

  if (clientId.flag === 'N') {
    const expDate = moment(clientId.exp_date, ['DD/MM/YYYY', 'YYYYMMDD']);
    const newExpDate = moment(expDate, 'DD/MM/YYYY').format('YYYYMMDD');
    clientId.exp_date = newExpDate;
  } else {
    clientId.exp_date = '';
  }
};

const mappingForAllClient = (clientParam) => {
  const client = clientParam;

  // mapping occp
  mappingOccp(client.occp);
  // mapping phone number
  const phone = mappingPhoneNumber(client.contact.phone);
  client.contact.phone = phone;
  // mapping salut
  mappingSalut(client);

  return client;
};

const mappingMailingAddress = (mailingAddress, sameAddress) => {
  let address = mailingAddress;
  address = { ...sameAddress };

  return address;
};

const mappingPHData = (spajParam) => {
  const spajData = spajParam;
  const { ph, despatch } = spajData.client;
  const isCounterOffer = spajData.counterOfferFlag !== '';
  mappingForAllClient(ph);

  // mapping tax
  mappingTax(ph.tax);

  // mapping Id
  mappingExpDate(ph.id);

  ph.role = 'OW';
  ph.relation = 'OW';

  if (!isCounterOffer) {
    let mappingAddress = ph.address[1];
    let despatchAddress = despatch[0].address;
    // mapping additional address
    if (ph.address[1].type === 'address1') {
      mappingAddress = mappingMailingAddress(ph.address[1], { ...ph.address[0], type: 'P' });
      despatchAddress = mappingMailingAddress(despatch[0].address, ph.address[0]);
    } else if (ph.address[1].type === 'address2') {
      mappingAddress = mappingMailingAddress(ph.address[1], { ...ph.occp.address, type: 'P' });
      despatchAddress = mappingMailingAddress(despatch[0].address, ph.occp.address);
    } else {
      mappingAddress = mappingMailingAddress(ph.address[1], { ...ph.address.find(x => x.type === 'address3'), type: 'P' });
      despatchAddress = mappingMailingAddress(despatch[0].address, { ...ph.address.find(x => x.type === 'address3'), type: 'P' });
    }

    ph.address[1] = mappingAddress;
    despatch[0].address = despatchAddress;

    // delete this after UAT
    // ph.contact.email = 'Mailbox2@pru.intranet.asia';
  }

  return spajData;
};

const mappingLAData = (spajParam) => {
  const spajData = spajParam;
  const { lifeAss, ph } = spajData.client;

  const newLifeAss = lifeAss.map((value) => {
    const lifeA = value;

    if (lifeA.customerId === ph.customerId) {
      mappingSameAsAnotherClient(lifeA, ph);
      lifeA.relation = 'OW';
      lifeA.desc_relation = ph.desc_relation;
      lifeA.next_age = ph.next_age;
      lifeA.flag_role = ph.flag_role;
      lifeA.desc_flag_role = ph.desc_flag_role;
    }

    if (lifeA.customerId !== ph.customerId) {
      mappingForAllClient(lifeA);

      // mapping Id
      mappingExpDate(lifeA.id);
    }
    return lifeA;
  });

  spajData.client.lifeAss = newLifeAss;

  return spajData;
};

const mappingPayorData = (spajParam) => {
  const spajData = spajParam;
  const { payor } = spajData.policy;
  const { ph, lifeAss } = spajData.client;
  const payorRole = payor.flag_role;
  const sameLifeAss = lifeAss.find(x => x.role === payorRole);

  payor.eff_docid = eff_docid;

  if (payorRole === 'PH') {
    payor.relationship = '';
    payor.desc_relationship = 'Diri Sendiri';
    mappingSameAsAnotherClient(payor, ph);
  } else if (sameLifeAss) {
    payor.relationship = '';
    payor.desc_relationship = sameLifeAss.desc_relation;
    mappingSameAsAnotherClient(payor, sameLifeAss);
  } else {
    mappingForAllClient(payor);
  }

  return spajData;
};

const mappingPolicySign = (spajParam, auth) => {
  const spajData = spajParam;
  const clientData = SqsSpajService.getPersonalInformation(spajData);
  const { isInputManual } = spajData.policy;
  const newSign = spajData.policy.sign.filter(x => x.value).map((val) => {
    let signValue = val.value.replace(/\\\\n/g, '');
    signValue = val.value.replace(/\\\\r/g, '');
    signValue = val.value.replace(/\\r/g, '');
    signValue = val.value.replace(/\\n/g, '');
    if (val.role === 'PH') {
      return {
        ...val, value: signValue, role: 'OW', date: moment(val.date, 'DD-MMM-YYYY hh:mm:ss').format('YYYYMMDD'), name: clientData.ph.name,
      };
    }
    if (val.role === '07') {
      return {
        ...val, value: signValue, role: 'AG', date: moment(val.date, 'DD-MMM-YYYY hh:mm:ss').format('YYYYMMDD'), name: auth.clientName,
      };
    }
    if (val.role === '01' || val.role === 'A1') {
      return {
        ...val, value: signValue, date: moment(val.date, 'DD-MMM-YYYY hh:mm:ss').format('YYYYMMDD'), name: clientData.lifeAss1.name,
      };
    }
    if (val.role === '02' || val.role === 'A2') {
      return {
        ...val, value: signValue, date: moment(val.date, 'DD-MMM-YYYY hh:mm:ss').format('YYYYMMDD'), name: isInputManual ? '' : clientData.lifeAss2.name,
      };
    }
    if (val.role === '03' || val.role === 'A3') {
      return {
        ...val, value: signValue, date: moment(val.date, 'DD-MMM-YYYY hh:mm:ss').format('YYYYMMDD'), name: isInputManual ? '' : clientData.lifeAss3.name,
      };
    }
    if (val.role === '04') {
      return {
        ...val, value: signValue, role: 'PT', date: moment(val.date, 'DD-MMM-YYYY hh:mm:ss').format('YYYYMMDD'), name: clientData.topupPayor.name,
      };
    }
    if (val.role === 'PY') {
      return {
        ...val, value: signValue, date: moment(val.date, 'DD-MMM-YYYY hh:mm:ss').format('YYYYMMDD'), name: isInputManual ? '' : clientData.payor.name,
      };
    }
    return { ...val, value: signValue, date: moment(val.date, 'DD-MMM-YYYY hh:mm:ss').format('YYYYMMDD') };
  });
  const topUpSign = newSign.filter(x => x.role === '04');
  if (topUpSign.length > 0) {
    spajData.policy.topUp.sign = topUpSign;
  }
  spajData.policy.sign = newSign;

  if (spajData.policy.ska) {
    if (spajData.policy.ska.sign.length > 0) {
      const skaSign = spajData.policy.ska.sign.filter(item => item.value !== '' && item.value).map((val) => {
        if (val.role === 'PH') {
          return {
            ...val, role: 'OW', date: moment(val.date, 'DD-MMM-YYYY hh:mm:ss').format('YYYYMMDD'), name: clientData.ph.name,
          };
        }
        return { ...val, date: moment(val.date, 'DD-MMM-YYYY hh:mm:ss').format('YYYYMMDD') };
      });
      spajData.policy.ska.sign = skaSign;
    }
  }

  return spajData;
};


const mappingTopupSameAsAnotherClient = (clientParam, anotherClient) => {
  const spajTopup = clientParam;

  spajTopup.salut = anotherClient.salut;
  spajTopup.name = anotherClient.name;
  spajTopup.sex = anotherClient.sex;
  spajTopup.marryd = anotherClient.marryd;
  spajTopup.occp = anotherClient.occp;
  spajTopup.income = anotherClient.income;

  return spajTopup;
};

const mappingPayorTopupData = (spajParam) => {
  const spajData = spajParam;
  const { payor, fund } = spajData.policy.topUp;
  const { ph, lifeAss } = spajData.client;
  const pyr = spajData.policy.payor;
  const sameLifeAss = lifeAss.find(x => x.role === payor.type);

  spajData.policy.topUp.payor.salut = payor.sex ? salutMap[payor.sex] : '';

  // mapping occp
  mappingOccp(payor.occp);

  if (spajData.policy.topUp.is_topup === 'true') {
    spajData.policy.topUp.fund = fund.map(x => ({ ...x, code: '' }));
    spajData.policy.topUp.amount += '00';
    spajData.policy.topUp.doc_id = docIdTopup;
    spajData.policy.topUp.eff_docid = eff_docid;
    if (payor.type === 'PH') {
      payor.relationship = 'OW';
      payor.desc_relationship = 'Diri Sendiri';
      mappingTopupSameAsAnotherClient(payor, ph);
    } else if (payor.type === 'PY') {
      payor.relationship = pyr.relationship;
      payor.desc_relationship = pyr.desc_relationship;
      mappingTopupSameAsAnotherClient(payor, pyr);
    } else if (payor.type === 'others') {
      payor.type = 'Lainnya';
    } else if (sameLifeAss) {
      payor.relationship = sameLifeAss.relationship;
      payor.desc_relationship = sameLifeAss.desc_relation;
      mappingTopupSameAsAnotherClient(payor, sameLifeAss);
    }
  }

  if (spajData.policy.topUp.payor.why_topUp.length < 1) {
    spajData.policy.topUp.payor.why_topUp.push({ data: '-', desc_why_topUp: '-' });
  }

  return spajData;
};

const mappingBenefData = (spajParam) => {
  const spajData = spajParam;

  for (let i = 0; i < spajData.client.benef.length; i += 1) {
    if (spajData.client.benef[i].dob === 'Invalid date') {
      spajData.client.benef[i].dob = '';
    }

    spajData.client.benef[i].salut = spajData.client.benef[i].sex ? salutMap[spajData.client.benef[i].sex] : '';
    spajData.client.benef[i].flag_role = 'BN';
    spajData.client.benef[i].desc_flag_role = 'Beneficiary';
  }

  return spajData;
};

const mappingDocUpl = (spajParam) => {
  const spajData = spajParam;

  const tempDocUpl = [];
  for (let i = 0; i < spajData.policy.doc_upl.length; i += 1) {
    if (spajData.policy.doc_upl[i].type !== '' && spajData.policy.doc_upl[i].file_name !== '') {
      spajData.policy.doc_upl[i].eff_docid = eff_docid;
      tempDocUpl.push(spajData.policy.doc_upl[i]);
    }
  }
  spajData.policy.doc_upl = tempDocUpl;
};

const mappingSPAJ = (spajParam, auth) => {
  const spajData = spajParam;
  const dataQQ = spajData.sqs.sqs.quickQuote.find(x => x.isMainQuotation);
  const flagCounterOffer = ''; // TODO: set as parameter

  // Mapping PH
  mappingPHData(spajData);
  // Mapping Life Ass
  mappingLAData(spajData);
  // Mapping Payor
  mappingPayorData(spajData);


  // Mapping Topup
  mappingPayorTopupData(spajData);
  // Mapping benef Data
  mappingBenefData(spajData);
  // Mapping Doc Upl
  mappingDocUpl(spajData);


  // Mapping Policy Sign
  mappingPolicySign(spajData, auth);
  // Mapping DropHs
  mappingDropHS(spajData, auth, flagCounterOffer);
  // Mapping Lampung
  mappingLampung(spajData, auth, flagCounterOffer);

  // DOC ID
  spajData.policy.payor.doc_id = docIdPayor;

  // SKA
  if (SqsSpajService.mappingStep1SKA(spajData) || SqsSpajService.mappingStep5SKA(spajData) || spajData.counterOfferFlag === 'SKA') {
    spajData.policy.ska.doc_id = docIdSKA;
  } else {
    spajData.policy.ska = ConfigProductSPAJ.createSka();
    spajData.policy.ska.sign = [];
  }
  // const tmpDate = spajData.policy.sign.find(x => x.role === 'OW').date;
  // spajData.policy.prop_date = tmpDate ? moment(tmpDate).format('YYYYMMDD') : moment().format('YYYYMMDD');
  spajData.policy.prop_date = moment().format('YYYYMMDD');

  if (spajData.amend.remark !== '') {
    spajData.amend.doc_id = docIdAmend;
    spajData.amend.eff_docid = eff_docid;
  }

  spajData.add_hq.diges.doc_id = docIdDiges;
  spajData.add_hq.diges.eff_docid = eff_docid;

  spajData.add_hq.respi.doc_id = docIdRespi;
  spajData.add_hq.respi.eff_docid = eff_docid;

  spajData.add_hq.tumor.doc_id = docIdTumor;
  spajData.add_hq.tumor.eff_docid = eff_docid;

  spajData.add_hq.escc.doc_id = docIdEscc;
  spajData.add_hq.escc.eff_docid = eff_docid;

  // spajData.policy.pruforce_version = $rootScope.PRUforceVersion ? $rootScope.PRUforceVersion : '';
  // Change amend tax residency to Array
  for (let i = 0; i < spajData.amend.client.length; i += 1) {
    const tempResidencyAmendTax = spajData.amend.client[i].tax.residency_tax;
    spajData.amend.client[i].tax.residency_tax = [];
    spajData.amend.client[i].tax.residency_tax.push(tempResidencyAmendTax);
  }

  // Policy Agent
  spajData.agent.code = auth.agentCode;
  spajData.agent.name = auth.clientName;
  spajData.agent.type = auth.agentType;
  spajData.agent.unit = auth.leaderName;
  spajData.agent.ofc = spajData.agent.ofc || auth.officeCode;
  spajData.agent.contact.email = auth.agentEmailAddress;

  // Agent Leader
  spajData.agent.leader = { name: auth.leaderName, number: auth.leaderNumber };

  // set agent.bank for WF
  spajData.agent.bank.ref_code = spajData.bank.referralCode;
  spajData.agent.bank.ref_type = spajData.bank.referralType;
  spajData.agent.bank.rm_psid = spajData.bank.rmPsid;
  spajData.agent.bank.rel_id = spajData.bank.relId;
  spajData.agent.bank.rm_name = spajData.bank.rmName;
  spajData.agent.bank.master_no = spajData.bank.masterNumber;
  spajData.agent.bank.ref_no = spajData.bank.partnerBankNumber;
  spajData.agent.bank.sal_name = spajData.bank.branchOfficeName;
  spajData.agent.bank.sal_unit = spajData.bank.branchOfficeCode;

  // Policy
  spajData.policy.eff_docid = eff_docid;
  // spajData.policy.ver = 'E0520';
  // eslint-disable-next-line no-nested-ternary
  spajData.policy.ver = !spajData.policy.isInputManual ?
    (ConfigProductSPAJ.deployCode.find(x => x.channel === auth.agentChannel).data.find(z => z.product.includes(dataQQ.productCode)) ? ConfigProductSPAJ.deployCode.find(x => x.channel === auth.agentChannel).data.find(z => z.product.includes(dataQQ.productCode)).code : '') : '';
  spajData.policy.vendor = 'EPOS2';
  spajData.policy.agnt_kyc = 'Y';

  const now = new Date();
  spajData.policy.rcd = moment(now).format('YYYYMMDD');
  spajData.policy.dmc_scan_date = moment(now).format('YYYYMMDD');
  spajData.policy.dmc_capture_date = moment(now).format('YYYYMMDD');
  spajData.policy.submission_date = now; // moment(now).format('YYYYMMDD');

  spajData.policy.sob.channel = auth.agentChannel;
  spajData.policy.sob.desc = channelType[auth.agentChannel];

  // RP Mapping
  spajData.policy.rp.doc_id = docIdRp;
  spajData.policy.rp.eff_docid = eff_docid;
  spajData.policy.rp.suitability = 'Y';
  if (spajData.sqs.sqs.rp.result === 'konservatif') {
    spajData.policy.rp.result = 'L';
  } else if (spajData.sqs.sqs.rp.result === 'moderat') {
    spajData.policy.rp.result = 'M';
  } else {
    spajData.policy.rp.result = 'H';
  }
  spajData.policy.rp.desc_result = spajData.sqs.sqs.rp.result;

  // SET RP GOAL Whyins
  spajData.policy.rp.whyIns = [];
  for (let i = 0; i < dataQQ.goal.length; i += 1) {
    spajData.policy.rp.whyIns.push({
      data: goalMapID[dataQQ.goal[i]],
      desc_whyIns: dataQQ.goal[i],
    });
  }

  // SET RP Question
  spajData.policy.rp.quest = [];
  spajData.policy.rp.total_score = spajData.sqs.sqs.rp.totalScore;
  for (let i = 0; i < spajData.sqs.sqs.rp.quest.length; i += 1) {
    spajData.policy.rp.quest.push({
      no: i + 1,
      quest_code: spajData.sqs.sqs.rp.quest[i].questCode,
      desc_quest: rpQuestionMap[spajData.sqs.sqs.rp.quest[i].questCode],
      score: spajData.sqs.sqs.rp.quest[i].score,
      desc_answ: spajData.sqs.sqs.rp.quest[i].descAnswer,
    });
  }
  // RP SIGN
  // SQS Sign
  const sqsSignDatePH = moment(spajData.sqs.sqs.sign.ph.date, 'DD-MMM-YYYY hh:mm:ss').format('YYYYMMDD');
  const sqsSignDateAG = moment(spajData.sqs.sqs.sign.agent.date, 'DD-MMM-YYYY hh:mm:ss').format('YYYYMMDD');

  spajData.policy.rp.sign[0].loc = spajData.sqs.sqs.sign.ph.location;
  spajData.policy.rp.sign[0].date = sqsSignDatePH;
  spajData.policy.rp.sign[0].value = '';
  spajData.policy.rp.sign[0].role = 'OW';
  spajData.policy.rp.sign[0].name = spajData.client.ph.name;// Select from Json Store

  spajData.policy.rp.sign.push({
    loc: spajData.sqs.sqs.sign.agent.location,
    date: sqsSignDateAG,
    role: 'AG',
    value: '',
    name: auth.clientName,
  });

  // Smoking
  // spajData.policy.uw_questionnaire.smoking[0].role="01";
  // spajData.policy.uw_questionnaire.smoking[0].stat="N";

  // Change topUp to Array
  const tempTopUp = spajData.policy.topUp;
  spajData.policy.topUp = [];
  spajData.policy.topUp.push(tempTopUp);

  // spajData.policy.flagCo = $rootScope.co_status;


  // set ClientType
  spajData.policy.clientType = dataQQ.clientType === 'Individu' ? 'P' : 'C';

  return spajData;
};

const mappingDropHS = (spajParam, auth, flagCounterOffer) => {
  const spajData = spajParam;

  if (spajData.policy.dropHS !== undefined) {
    spajData.policy.dropHS.prop_no = spajData.policy.prop_no;

    let newOwnerDob = '';
    if (spajData.policy.dropHS.ownerDob !== '') {
      newOwnerDob = moment(spajData.policy.dropHS.ownerDob, 'YYYY-MM-DD').format('YYYYMMDD');
    } else {
      newOwnerDob = spajData.client.ph.dob;
    }
    spajData.policy.dropHS.ownerDob = newOwnerDob;

    const newSignDate = moment(spajData.policy.dropHS.sign.ph.date, 'DD-MMM-YYYY hh:mm:ss').format('YYYYMMDD');
    spajData.policy.dropHS.signDate = newSignDate;
    spajData.policy.dropHS.signPlace = spajData.policy.dropHS.sign.ph.location;
    spajData.policy.dropHS.phSign = spajData.policy.dropHS.sign.ph.byte;
    spajData.policy.dropHS.agentSign = spajData.policy.dropHS.sign.agent.byte;
    spajData.policy.dropHS.agentCode = auth.agentCode;
    spajData.policy.dropHS.agentName = auth.clientName;
    spajData.policy.dropHS.ownerName = spajData.client.ph.name;
    spajData.policy.dropHS.laName = spajData.client.lifeAss[0].name;
    if (spajData.policy.dropHS.existingPHName === undefined || spajData.policy.dropHS.existingPHName === '') {
      spajData.policy.dropHS.existingPHName = spajData.client.ph.name;
    }

    let isDropHS = false;
    for (let i = 0; i < spajData.sqs.sqs.quickQuote.length; i += 1) {
      if (spajData.sqs.sqs.quickQuote[i].isMainQuotation === true) {
        isDropHS = spajData.sqs.sqs.quickQuote[i].isDropHS;
        break;
      }
    }
    if (flagCounterOffer === 'UW62') {
      isDropHS = true;
    }

    spajData.policy.dropHS.doc_id = isDropHS ? docIdDropHS : '';
  }

  return spajData;
};

const mappingLampung = (spajParam, auth, flagCounterOffer) => {
  const spajData = spajParam;

  if (spajData.policy.lampung !== undefined) {
    spajData.policy.lampung.prop_no = spajData.policy.prop_no;

    const newOwnerDob = spajData.client.ph.dob;

    spajData.policy.lampung.ownerDob = newOwnerDob;

    const newSignDate = moment(spajData.policy.lampung.sign.ph.date, 'DD-MMM-YYYY hh:mm:ss').format('YYYYMMDD');
    spajData.policy.lampung.signDate = newSignDate;
    spajData.policy.lampung.signPlace = spajData.policy.lampung.sign.ph.location;
    spajData.policy.lampung.phSign = spajData.policy.lampung.sign.ph.byte;
    spajData.policy.lampung.agentSign = spajData.policy.lampung.sign.agent.byte;
    spajData.policy.lampung.agentCode = auth.agentCode;
    spajData.policy.lampung.agentName = auth.clientName;
    spajData.policy.lampung.ownerName = spajData.client.ph.name;
    spajData.policy.lampung.laName = spajData.client.lifeAss[0].name;

    let isLampung = false;
    for (let i = 0; i < spajData.sqs.sqs.quickQuote.length; i += 1) {
      if (spajData.sqs.sqs.quickQuote[i].isMainQuotation === true) {
        isLampung = spajData.sqs.sqs.quickQuote[i].isLampung ? spajData.sqs.sqs.quickQuote[i].isLampung : false;
        break;
      }
    }

    if (flagCounterOffer === 'UW61') {
      spajData.policy.lampung.flagLoosemail = 'Y';
      isLampung = true;
    } else {
      spajData.policy.lampung.flagLoosemail = 'N';
    }

    spajData.policy.lampung.version = versionLampung;
    spajData.policy.lampung.doc_id = isLampung ? docIdLampung : '';
  }

  return spajData;
};

const mappingPayment = (spajParam) => {
  const spajData = spajParam;
  const productCode = SqsSpajService.getProductCode(spajData);

  // Mapp Cif
  spajData.policy.cif.number = spajData.policy.payment[0].cifNo;
  spajData.policy.cif.code = 'CF';

  for (let i = 0; i < spajData.policy.payment.length; i += 1) {
    if (spajData.policy.payment[i].type === 'premi') {
      spajData.policy.payment[i].method = 'C';
      spajData.policy.recurring.method = spajData.policy.payment[i].method;
      spajData.policy.recurring.desc_method = spajData.policy.payment[i].desc_method;
      spajData.policy.recurring.amount = spajData.policy.payment[i].amount;
      spajData.policy.recurring.period_plan = spajData.policy.payment[i].period_plan;
      spajData.policy.recurring.desc_method = spajData.policy.payment[i].desc_method;
      spajData.policy.recurring.curr = spajData.policy.payment[i].curr;
      spajData.policy.recurring.cardholder_name = spajData.policy.payment[i].cardholder_name;
      spajData.policy.recurring.cardholder_role = spajData.policy.payment[i].cardholer_role;
      spajData.policy.recurring.status = spajData.policy.payment[i].status;
      spajData.policy.recurring.cardholder_relationship = spajData.policy.payment[i].cardholder_relationship;

      if (sqsProductSinglePremi.includes(productCode)) {
        spajData.policy.payment[i].method = 'N';
        spajData.policy.payment[i].bil_freq = '00';
        spajData.policy.payment[i].desc_bil_freq = 'Sekali Bayar';
        spajData.policy.recurring.desc_bil_freq = 'Sekali Bayar';
        spajData.policy.recurring.bil_freq = '00';
        spajData.policy.recurring.method = 'N';
      } else {
        spajData.policy.recurring.method = spajData.policy.payment[i].method;
        spajData.policy.recurring.desc_bil_freq = spajData.policy.payment[i].desc_bil_freq;
        spajData.policy.recurring.bil_freq = spajData.policy.payment[i].bil_freq;
      }

      // Recurring
      if (spajData.policy.isRecurring === '1') {
        spajData.policy.recurring.method = 'K';
      }
      break;
    }
  }
  return spajData;
};

const mappingYNValue = (valueParam) => {
  let value = valueParam;
  if (value !== '') {
    if (value === true) {
      value = 'Y';
    } else if (value === false) {
      value = 'N';
    } else if (value.toLowerCase() === 'true' || value.toLowerCase() === 'yes' || value.toLowerCase() === 'ya') {
      value = 'Y';
    } else if (value.toLowerCase() === 'false' || value.toLowerCase() === 'no' || value.toLowerCase() === 'tidak') {
      value = 'N';
    }
  }
  return value;
};

function sortingQuestionBySeq(question) {
  question.sort((a, b) => a.seq - b.seq);
  return question;
}

function sortingQuestionForm(questionForm) {
  const unique = {};
  const distinct = [];
  const newData = [];
  const resultData = [];

  // get Form Distinct
  for (let i = 0; i < questionForm.length; i += 1) {
    if (typeof (unique[questionForm[i].form]) === 'undefined') {
      distinct.push(questionForm[i].form);
    }
    unique[questionForm[i].form] = 0;
  }

  // Mapping Data each form
  for (let x = 0; x < distinct.length; x += 1) {
    const dataForm = [];
    for (let i = 0; i < questionForm.length; i += 1) {
      if (questionForm[i].form === distinct[x]) {
        dataForm.push(questionForm[i]);
      }
    }
    newData.push(dataForm);
  }

  // Sorting By Seq
  for (let x = 0; x < newData.length; x += 1) {
    sortingQuestionBySeq(newData[x]);
    for (let y = 0; y < newData[x].length; y += 1) {
      resultData.push(newData[x][y]);
    }
  }

  return resultData;
}

function sortingMedCheck(questionForm) {
  const unique = {};
  const distinct = [];
  const newData = [];
  const resultData = [];

  // get Form Distinct
  for (let i = 0; i < questionForm.length; i += 1) {
    if (typeof (unique[questionForm[i].name]) === 'undefined') {
      distinct.push(questionForm[i].name);
    }
    unique[questionForm[i].name] = 0;
  }

  // Mapping Data each form
  for (let x = 0; x < distinct.length; x += 1) {
    const dataForm = [];
    for (let i = 0; i < questionForm.length; i += 1) {
      if (questionForm[i].name === distinct[x]) {
        dataForm.push(questionForm[i]);
      }
    }
    newData.push(dataForm);
  }
  // Sorting By Seq
  for (let x = 0; x < newData.length; x += 1) {
    sortingQuestionBySeq(newData[x]);
    for (let y = 0; y < newData[x].length; y += 1) {
      resultData.push(newData[x][y]);
    }
  }

  return resultData;
}

function checkGIOCampaignCode(spajParam, code) {
  const spajData = spajParam;
  const sqs = spajData.sqs.sqs;
  let validGIO = false;

  let campaignCode = '';

  if (sqs.campaign !== undefined) {
    const campaignData = sqs.campaign.campaignInfo;
    if (Object.prototype.toString.call(campaignData) === '[object Object]') {
      campaignCode = campaignData.campaignCode ? campaignData.campaignCode : '';
    }
    if (campaignCode !== '' && code === campaignCode) {
      validGIO = true;
    }
  }
  return validGIO;
}

function mappingUWQuestion(spajParam) {
  const spajData = spajParam;

  // IF BMI height or weight empty, set to default
  for (let i = 0; i < spajData.policy.uw_questionnaire.bmiheight.length; i += 1) {
    if (!spajData.policy.uw_questionnaire.bmiheight[i].height) {
      spajData.policy.uw_questionnaire.bmiheight[i].height = '170';
    }
    if (!spajData.policy.uw_questionnaire.bmiweight[i].weight) {
      spajData.policy.uw_questionnaire.bmiweight[i].weight = '60';
    }
  }

  // SMOKING
  for (let i = 0; i < spajData.policy.uw_questionnaire.smoking.length; i += 1) {
    if (!spajData.policy.uw_questionnaire.smoking[i].stat) {
      spajData.policy.uw_questionnaire.smoking[i].stat = spajData.client.lifeAss.find(y => y.role === spajData.policy.uw_questionnaire.smoking[i].role).smokeStatus;
    }
    if (spajData.policy.uw_questionnaire.smoking[i].stat === 'S') {
      spajData.policy.uw_questionnaire.smoking[i].stat = 'Y';
    } else if (spajData.policy.uw_questionnaire.smoking[i].stat === 'NS') {
      spajData.policy.uw_questionnaire.smoking[i].stat = 'N';
    }
  }

  // DRUGS
  for (let i = 0; i < spajData.policy.uw_questionnaire.drugs.length; i += 1) {
    const drugsAnsw = spajData.policy.uw_questionnaire.drugs[i].answ;
    spajData.policy.uw_questionnaire.drugs[i].answ = mappingYNValue(drugsAnsw);
  }

  // HOBBY
  for (let i = 0; i < spajData.policy.uw_questionnaire.hobby.length; i += 1) {
    const hobbyAnsw = spajData.policy.uw_questionnaire.hobby[i].answ;
    spajData.policy.uw_questionnaire.hobby[i].answ = mappingYNValue(hobbyAnsw);

    for (let j = 0; j < spajData.policy.uw_questionnaire.hobby[i].data.length; j += 1) {
      const hobbyAnswDetail = spajData.policy.uw_questionnaire.hobby[i].data[j].answ;
      spajData.policy.uw_questionnaire.hobby[i].data[j].answ = mappingYNValue(hobbyAnswDetail);
    }
  }

  // GENDER
  for (let i = 0; i < spajData.policy.uw_questionnaire.gender.length; i += 1) {
    const genderAnsw = spajData.policy.uw_questionnaire.gender[i].answ;
    spajData.policy.uw_questionnaire.gender[i].answ = mappingYNValue(genderAnsw);

    const resultSorting = sortingMedCheck(spajData.policy.uw_questionnaire.gender[i].data);
    spajData.policy.uw_questionnaire.gender[i].data = resultSorting;
  }

  // Med Check
  for (let i = 0; i < spajData.policy.uw_questionnaire.med_check.length; i += 1) {
    const medCheckAnsw = spajData.policy.uw_questionnaire.med_check[i].answ;
    spajData.policy.uw_questionnaire.med_check[i].answ = mappingYNValue(medCheckAnsw);

    if (spajData.policy.uw_questionnaire.med_check[i].data.length > 0) {
      const resultSorting = sortingMedCheck(spajData.policy.uw_questionnaire.med_check[i].data);
      spajData.policy.uw_questionnaire.med_check[i].data = resultSorting;
    }
  }

  // FAM HIS
  // for(let i=0;i<spajData.policy.uw_questionnaire.fam_history.length;i += 1){
  // var famHisAnsw = spajData.policy.uw_questionnaire.fam_history[i].answ;
  // spajData.policy.uw_questionnaire.fam_history[i].answ = mappingYNValue(famHisAnsw);
  // // Empty question id
  // spajData.policy.uw_questionnaire.fam_history[i].questionid="";
  // }

  // Exist Condition
  for (let i = 0; i < spajData.policy.uw_questionnaire.exist_condition.length; i += 1) {
    const existConAnsw = spajData.policy.uw_questionnaire.exist_condition[i].answ;
    spajData.policy.uw_questionnaire.exist_condition[i].answ = mappingYNValue(existConAnsw);

    // sortingQuestionBySeq(spajData.policy.uw_questionnaire.exist_condition[i].data);
    const resultSorting = sortingQuestionForm(spajData.policy.uw_questionnaire.exist_condition[i].data);
    spajData.policy.uw_questionnaire.exist_condition[i].data = resultSorting;
  }

  // specific_condition
  for (let i = 0; i < spajData.policy.uw_questionnaire.specific_condition.length; i += 1) {
    if (spajData.policy.uw_questionnaire.specific_condition[i].answ.toLowerCase() === 'true'
      || spajData.policy.uw_questionnaire.specific_condition[i].answ === true
      || spajData.policy.uw_questionnaire.specific_condition[i].answ.toLowerCase() === 'ya') {
      spajData.policy.uw_questionnaire.specific_condition[i].answ = 'Y';
      for (let j = 0; j < spajData.policy.uw_questionnaire.specific_condition[i].data.length; j += 1) {
        const speciAnsw = spajData.policy.uw_questionnaire.specific_condition[i].data[j].answ;
        if (speciAnsw !== undefined) {
          spajData.policy.uw_questionnaire.specific_condition[i].data[j].answ = mappingYNValue(speciAnsw);
        }
      }
    } else {
      spajData.policy.uw_questionnaire.specific_condition[i].answ = 'N';
    }
  }
}

function setFlagBOMapping(spajParam) {
  const spajData = spajParam;
  const isCounterOffer = spajData.counterOfferFlag !== '';
  const productCode = SqsSpajService.getProductCode(spajData);
  const quickQuote = spajData.sqs.sqs.quickQuote.find(x => x.isMainQuotation);
  const componentCode = quickQuote.mainCoverage.GIO || quickQuote.mainCoverage.main;
  let productType;
  if (!isCounterOffer) {
    productType = componentCodeUuid[componentCode].type;
  }

  let flagSubstandard = 'N';
  let hq_cmplt_1 = ''; let hq_cmplt_2 = ''; let hq_cmplt_3 = ''; let hq_cmplt_4 = ''; let
    hq_cmplt_5 = '';
  let med_doc_1 = ''; let med_doc_2 = ''; let med_doc_3 = ''; let med_doc_4 = ''; let
    med_doc_5 = '';

  if (isSubstandard) {
    flagSubstandard = 'Y';
  }

  for (let i = 0; i < spajData.client.lifeAss.length; i += 1) {
    if (i === 0) {
      hq_cmplt_1 = 'Y';
      med_doc_1 = 'N';
    } else if (i === 1) {
      hq_cmplt_2 = 'Y';
      med_doc_2 = 'N';
    } else if (i === 2) {
      hq_cmplt_3 = 'Y';
      med_doc_3 = 'N';
    } else if (i === 3) {
      hq_cmplt_4 = 'Y';
      med_doc_4 = 'N';
    } else if (i === 4) {
      hq_cmplt_5 = 'Y';
      med_doc_5 = 'N';
    }
  }

  // Surplus uw
  const surplus = spajData.policy.surplus ? spajData.policy.surplus : '';

  if (surplus !== '') {
    spajData.policy.surplus_desc = surplusMap[surplus];
  } else {
    spajData.policy.surplus_desc = '';
  }

  const dataBOMapping = [
    {
      bo_mapping: 'saauto_increase',
      desc: 'Sum Assured Increase Flag',
      value: flagSA,
    },
    {
      bo_mapping: 'campaign_type',
      desc: 'Campaign Type',
      value: '',
    },
    {
      bo_mapping: 'surplus_uw',
      desc: 'Surplus UW',
      value: surplus,
    },
    {
      desc: '',
      value: '0',
      bo_mapping: 'fund_ual',
    },
    {
      desc: '',
      value: '0',
      bo_mapping: 'sqs_ver',
    },
    {
      desc: '',
      value: '0',
      bo_mapping: 'sqs',
    },
    {
      desc: '',
      value: '0',
      bo_mapping: 'spaj',
    },
    {
      desc: 'Y',
      value: 'Y',
      bo_mapping: 'temp_flag_1',
    },
    {
      desc: '',
      value: 'E',
      bo_mapping: 'temp_flag_2',
    },
    {
      desc: 'Twisting 1',
      value: 'N',
      bo_mapping: 'temp_flag_4',
    },
    {
      desc: 'Twisting 2',
      value: 'N',
      bo_mapping: 'temp_flag_5',
    },
    {
      desc: 'STP Flag',
      value: '',
      bo_mapping: 'temp_flag_6',
    },
    {
      desc: spajData.flgNonf2f,
      value: spajData.flgNonf2f,
      bo_mapping: 'temp_flag_7',
    },
    {
      desc: spajData.flagPaymentPIPP,
      value: spajData.flagPaymentPIPP,
      bo_mapping: 'temp_flag_8',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'temp_flag_9',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'temp_flag_10',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'temp_flag_11',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'temp_flag_13',
    },
    {
      desc: 'Magnum Pure Flag',
      value: 'Y',
      bo_mapping: 'temp_flag_14',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'temp_flag_15',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'temp_field_1',
    },
    {
      desc: '',
      value: 'N',
      bo_mapping: 'temp_field_3',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'temp_field_6',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'temp_field_7',
    },
    {
      desc: 'Kurir/Pos',
      value: 'S',
      bo_mapping: 'temp_field_8',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'temp_field_10',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'temp_field_11',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'temp_field_12',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'temp_field_13',
    },
    {
      desc: 'Y',
      value: 'Y',
      bo_mapping: 'id_processable_1',
    },
    {
      desc: 'Y',
      value: 'Y',
      bo_mapping: 'id_processable_4',
    },
    {
      desc: 'Y',
      value: 'Y',
      bo_mapping: 'id_processable_5',
    },
    {
      desc: '',
      value: 'Y',
      bo_mapping: 'sign_cmplt_ow',
    },
    {
      desc: '',
      value: 'Y',
      bo_mapping: 'sign_cmplt_lifeAss_1',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'sign_cmplt_lifeAss_2',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'sign_cmplt_lifeAss_3',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'sign_cmplt_lifeAss_4',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'sign_cmplt_lifeAss_5',
    },
    {
      desc: '',
      value: 'Y',
      bo_mapping: 'spaj_cmplt',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'spaj_incmplt_page1',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'spaj_incmplt_page2',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'spaj_incmplt_page3',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'spaj_incmplt_page4',
    },
    {
      desc: '',
      value: 'Y',
      bo_mapping: 'sqs_cmplt',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'sqs_incmplt_page1',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'sqs_incmplt_page2',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'sqs_incmplt_page3',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'sqs_incmplt_page4',
    },
    {
      desc: '',
      value: 'Y',
      bo_mapping: 'support_doc_cmplt',
    },
    {
      desc: '',
      value: 'N',
      bo_mapping: 'sign_fraud',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'prod_syariah',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'quest_fulluw',
    },
    {
      desc: '',
      value: 'Y',
      bo_mapping: 'disclaimer_flag',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'counter_offer',
    },
    {
      desc: '',
      value: flagSubstandard,
      bo_mapping: 'substandard',
    },
    {
      desc: '',
      value: '1',
      bo_mapping: 'dmc_sub',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'edd',
    },
    {
      desc: '',
      value: hq_cmplt_1,
      bo_mapping: 'hq_cmplt_1',
    },
    {
      desc: '',
      value: hq_cmplt_2,
      bo_mapping: 'hq_cmplt_2',
    },
    {
      desc: '',
      value: hq_cmplt_3,
      bo_mapping: 'hq_cmplt_3',
    },
    {
      desc: '',
      value: hq_cmplt_4,
      bo_mapping: 'hq_cmplt_4',
    },
    {
      desc: '',
      value: hq_cmplt_5,
      bo_mapping: 'hq_cmplt_5',
    },
    {
      desc: '',
      value: med_doc_1,
      bo_mapping: 'med_doc_1',
    },
    {
      desc: '',
      value: med_doc_2,
      bo_mapping: 'med_doc_2',
    },
    {
      desc: '',
      value: med_doc_3,
      bo_mapping: 'med_doc_3',
    },
    {
      desc: '',
      value: med_doc_4,
      bo_mapping: 'med_doc_4',
    },
    {
      desc: '',
      value: med_doc_5,
      bo_mapping: 'med_doc_5',
    },
    {
      desc: 'EDD',
      value: 'Y',
      bo_mapping: 'policy_temp6',
    },
    {
      desc: 'PWD',
      value: 'Y',
      bo_mapping: 'policy_temp7',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'policy_temp8',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'policy_temp9',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'policy_temp10',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'policy_temp11',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'policy_temp12',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'policy_temp13',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'policy_temp14',
    },
    {
      desc: '',
      value: '',
      bo_mapping: 'policy_temp15',
    },
    {
      desc: '',
      value: isAgreeSubstandard,
      bo_mapping: 'agree-substandard',
    },
  ];

  spajData.flag = dataBOMapping;

  let tmpFlag4 = 'N';
  let tmpFlag5 = 'N';
  let spajPengganti = '0';
  let spajNoBefore = '';

  if (spajData.client.ph.other_info[0].answ === 'True') {
    tmpFlag4 = 'Y';
    if (spajData.client.ph.other_info[1].answ === 'True') {
      tmpFlag5 = 'Y';
    }
  }
  if (spajData.client.ph.other_info[2] !== undefined) {
    if (spajData.client.ph.other_info[2].answ === 'True') {
      spajPengganti = '1';
      if (spajData.policy.prop_no_before) {
        spajNoBefore = spajData.policy.prop_no_before;
      } else {
        spajData.policy.prop_no_before = '';
      }
    }
  }

  spajData.flag.push({
    desc: '',
    value: spajNoBefore,
    bo_mapping: 'temp_field_11',
  });

  let deliv = '';

  if (spajData.policy.deliv === 'E') {
    deliv = 'S';
    spajData.policy.delivOri = 'E';
  } else {
    // Kurir
    deliv = 'C';
    spajData.policy.delivOri = 'P';
  }

  // Deliv, from PH
  if (spajData.client.ph.contact.email !== '') {
    spajData.policy.deliv = 'E';
  } else {
    spajData.policy.deliv = 'P';
  }

  // wakaf
  if (spajData.policy.isWakaf !== undefined) {
    if (spajData.policy.isWakaf === true) {
      spajData.flag.push({
        desc: 'Wakaf Flag',
        value: 'Y',
        bo_mapping: 'temp_flag_12',
      });
    } else {
      spajData.flag.push({
        desc: 'Wakaf Flag',
        value: 'N',
        bo_mapping: 'temp_flag_12',
      });
    }
  } else {
    spajData.flag.push({
      desc: 'Wakaf Flag',
      value: 'N',
      bo_mapping: 'temp_flag_12',
    });
  }

  // Campaign ROP
  // if (sqsProductROP.indexOf(productCode) !== -1) {
  //   // A B N
  //   if (spajData.client.lifeAss[0].isGIO) {
  //     spajData.flag.push({
  //       desc: 'GIO',
  //       value: 'B',
  //       bo_mapping: 'temp_field_9',
  //     });
  //   } else if (spajData.client.lifeAss[0].isCis) {
  //     spajData.flag.push({
  //       desc: 'SIO',
  //       value: 'A',
  //       bo_mapping: 'temp_field_9',
  //     });
  //   } else {
  //     spajData.flag.push({
  //       desc: 'Full UW',
  //       value: 'N',
  //       bo_mapping: 'temp_field_9',
  //     });
  //   }
  // } else if (productCode === 'U11' || productCode === 'U10') {
  //   if (spajData.client.lifeAss[0].isGIO) {
  //     spajData.flag.push({
  //       desc: 'GIO',
  //       value: 'B',
  //       bo_mapping: 'temp_field_9',
  //     });
  //   } else {
  //     spajData.flag.push({
  //       desc: '',
  //       value: 'N',
  //       bo_mapping: 'temp_field_9',
  //     });
  //   }
  // }

  if (!isCounterOffer) {
    if (productType === 'GIO') {
      spajData.flag.push({
        desc: 'GIO',
        value: 'B',
        bo_mapping: 'temp_field_9',
      });
    } else if (productType === 'SIO') {
      spajData.flag.push({
        desc: 'SIO',
        value: 'A',
        bo_mapping: 'temp_field_9',
      });
    } else {
      spajData.flag.push({
        desc: 'Full UW',
        value: 'N',
        bo_mapping: 'temp_field_9',
      });
    }
  }

  // Check Easy Campaign
  let valueEasyCampaign = 'N';
  if (checkGIOCampaignCode(spajData, 'PLS-001')) {
    if (spajData.client.lifeAss[0].isGIO) {
      valueEasyCampaign = 'Y';
    }
  }
  spajData.flag.push({
    desc: 'Easy Campaign',
    value: valueEasyCampaign,
    bo_mapping: 'temp_field_14',
  });

  // FORM LAMPUNG UW61
  let valueLampung = 'N';
  if (spajData.policy.lampung !== undefined) {
    if (spajData.policy.lampung.doc_id !== '') {
      valueLampung = 'Y';
    }
  }

  spajData.flag.push({
    desc: 'Form Lampung UW61',
    value: valueLampung,
    bo_mapping: 'temp_field_15',
  });

  // BO PROCESSABLE
  const countLA = spajData.client.lifeAss.length;
  let valueProcessable2 = '';
  let valueProcessable3 = '';

  if (countLA === 2) {
    valueProcessable2 = 'Y';
    valueProcessable3 = 'Y';
  } else if (countLA === 3) {
    valueProcessable2 = 'Y';
    valueProcessable3 = 'Y';
  }

  spajData.flag.push({
    desc: 'Y',
    value: valueProcessable2,
    bo_mapping: 'id_processable_2',
  });
  spajData.flag.push({
    desc: 'Y',
    value: valueProcessable3,
    bo_mapping: 'id_processable_3',
  });

  // added by Lulu
  const valuestp = spajData.flag[7] ? spajData.flag[7].value : 'Y';

  for (let i = 0; i < spajData.flag.length; i += 1) {
    if (spajData.flag[i].bo_mapping === 'temp_flag_6') {
      spajData.flag[i].desc = 'STP Flag';
      spajData.flag[i].value = valuestp;
    } else if (spajData.flag[i].bo_mapping === 'policy_temp6') {
      spajData.flag[i].desc = 'EDD';
      spajData.flag[i].value = 'Y';
    } else if (spajData.flag[i].bo_mapping === 'policy_temp7') {
      spajData.flag[i].desc = 'PWD';
      spajData.flag[i].value = 'Y';
    } else if (spajData.flag[i].bo_mapping === 'temp_flag_4') {
      spajData.flag[i].desc = 'Twisting 1';
      spajData.flag[i].value = tmpFlag4;
    } else if (spajData.flag[i].bo_mapping === 'temp_flag_5') {
      spajData.flag[i].desc = 'Twisting 2';
      spajData.flag[i].value = tmpFlag5;
    } else if (spajData.flag[i].bo_mapping === 'temp_field_8') {
      spajData.flag[i].desc = 'Kurir/Pos';
      spajData.flag[i].value = deliv;
    } else if (spajData.flag[i].bo_mapping === 'spaj') {
      spajData.flag[i].value = spajPengganti;
    } else if (spajData.flag[i].bo_mapping === 'campaign_type') {
      if (sqsProductROP.indexOf(productCode) === -1) {
        if (spajData.client.lifeAss[0].isCis !== undefined) {
          if (spajData.client.lifeAss[0].isCis) {
            spajData.flag[i].value = 'Y';
          } else {
            spajData.flag[i].value = 'N';
          }
        }
      }
    }
  }

  // Gajadi di set N kata mas Anung
  // if (!spajData.policy.sign.filter(x => x.value).find(y => y.role === 'OW')) {
  //   spajData.flag.find(z => z.bo_mapping === 'sign_cmplt_ow').value = 'N';
  // }

  return spajData;
}

// const mappingCovid19 = (spajParam) => {
//   const spajData = spajParam;
//   spajData.covid19.quest = spajData.covid19.quest.map(val => ({ ...val, answ: val.answ ? 'Ya' : 'Tidak' }));

//   return spajData;
// };

const mappingSPAJData = (spajParam, auth) => {
  const spajData = { ...spajParam };
  // resetVar();
  // $rootScope.co_status="";
  try {
    if (!spajData.sqs.sqs.doc.spaj) {
      spajData.policy.doc_id = docIdSpaj;
    } else {
      spajData.policy.doc_id = spajData.sqs.sqs.doc.spaj;
    }

    spajData.flgNonf2f = spajData.flgNonf2f ? 'Y' : 'N';
    spajData.otp_flag = spajData.flgNonf2f;
    spajData.policy.nf2fFlag = spajData.flgNonf2f;
    spajData.policy.otpFlag = spajData.otp_flag;

    mappingSPAJ(spajData, auth);
    // Mapping BO MAPPING
    setFlagBOMapping(spajData);

    // Mapping UW
    mappingUWQuestion(spajData);
    // Mapping Policy Payment
    mappingPayment(spajData);

    // // Mapping covid19
    // mappingCovid19(spajData);

    return spajData;
  } catch (error) {
    throw error;
  }
};

export default {
  mappingSPAJData,
};
