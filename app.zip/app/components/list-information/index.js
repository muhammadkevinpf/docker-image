import React, { PureComponent } from 'react';
import { ActivityIndicator, Image } from 'react-native';
import { View, Text } from 'native-base';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import noContent from '../../assets/images/no_content.png';
import Style from '../../styles';
import _ from '../../lang';
import { iconEmptyFolder } from '../../assets/images';
import { isEmpty, isTablet, isText } from '../../utilities';
import { rowLayout, Skeleton } from '../skeleton-loading';

class MessageNoDataComponent extends PureComponent {
  render() {
    if (this.props.showLoading) {
      return (
        <View style={[Style.Main.center, Style.Main.rowDirection]}>
          <ActivityIndicator color="red" />
          <Text style={[Style.Main.fontAlbert12, Style.Main.textAlignCenter, Style.Main.ml12, this.props.style]}>
            {_('Sedang Mengambil Data..')}
          </Text>
        </View>
      );
    }
    const Tag = !this.props.isOnline || isEmpty(this.props.text) || isText(this.props.text) ? Text : View;
    return (
      <Tag style={[Style.Main.fontAlbert12, Style.Main.textAlignCenter, this.props.style]}>
        {this.props.isOnline ? this.props.text || _('Data tidak tersedia') : _('Jaringan tidak tersedia. Silakan periksa kembali')}
      </Tag>
    );
  }
}

const mapStateToProps = state => ({
  isOnline: state.connectionStatus.isOnline,
});

export const MessageNoData = connect(mapStateToProps, null)(MessageNoDataComponent);

export class ListEmptyComponent extends PureComponent {
  getImage = () => {
    if (this.props.image) return this.props.image;
    return isTablet() ? iconEmptyFolder : noContent;
  }

  render() {
    if (this.props.showIndicator) {
      return (
        <View style={[Style.Main.container, Style.Main.justifyCenter, Style.Main.alignCenter, Style.Main.py15]}>
          <ActivityIndicator color="red" size="large" />
        </View>
      );
    }
    return (
      <View style={[
        Style.Main.container,
        Style.Main.pt15, Style.Main.pb15,
        Style.Main.center,
        Style.Main.alignCenter,
        this.props.style,
      ]}
      >
        {
          this.props.showImage &&
          <Image
            source={this.getImage()}
            style={[isTablet() ? Style.Main.height150 : Style.Main.height252, Style.Main.mb10, Style.Main.alignCenter,
              this.props.image && !isTablet() && Style.Main.height200, this.props.imageStyle]}
            resizeMode="contain"
          />
        }
        {
          this.props.showText &&
          <Text style={[Style.Main.fontAlbert12, Style.Main.textAlignCenter]}>
            {this.props.isOnline || this.props.online ? _('Data tidak tersedia') : _('Jaringan tidak tersedia. Silakan periksa kembali')}
          </Text>
        }
      </View>
    );
  }
}

const mapListStateToProps = state => ({
  online: state.connectionStatus.isOnline,
});

export const ListEmpty = connect(mapListStateToProps, null)(ListEmptyComponent);

export class RenderFooter extends PureComponent {
  render() {
    if (this.props.showIndicator) {
      return (
        <View style={[Style.Main.container, Style.Main.justifyCenter, Style.Main.alignCenter, Style.Main.mb20, Style.Main.mt15]}>
          <ActivityIndicator color="red" size="large" />
        </View>
      );
    } if (this.props.isLastData) {
      return (
        <Text style={[Style.Main.fontAlbert12, Style.Main.textAlignCenter, Style.Main.mt10]}>
          {this.props.isOnline ? _('Sudah mencapai data terakhir') : _('Jaringan tidak tersedia. Data tidak dapat dimuat.')}
        </Text>
      );
    } return <View />;
  }
}

class UpdateDateInfo extends PureComponent {
  render() {
    if (this.props.visible) {
      return (
        <Skeleton
          isLoading={this.props.isLoading}
          style={[Style.Main.mV10, this.props.style]}
          layout={[rowLayout({ w: '70%', h: 7 })]}
        >
          <Text style={[Style.Main.fontAlbert11, this.props.textStyle]}>
            {!isEmpty(this.props.date) ? `${_('Data diperbaharui pada')} ${this.props.date}` : _('Data belum diperbarui')}
            {this.props.showOnFailed && !this.props.isLoading && _('. Gagal menghubungkan ke server.')}
          </Text>
        </Skeleton>
      );
    }
    return <View style={[Style.Main.displayNone]} />;
  }
}

export const UpdateDate = connect(mapStateToProps, null)(UpdateDateInfo);

UpdateDateInfo.propTypes = {
  date: PropTypes.oneOfType([PropTypes.string, PropTypes.object, PropTypes.func]),
  visible: PropTypes.bool,
  isLoading: PropTypes.bool,
  showOnFailed: PropTypes.bool,
};

UpdateDateInfo.defaultProps = {
  date: undefined,
  visible: true,
  isLoading: false,
  showOnFailed: false,
};

ListEmpty.propTypes = {
  showIndicator: PropTypes.bool,
  showText: PropTypes.bool,
  showImage: PropTypes.bool,
};

ListEmpty.defaultProps = {
  showIndicator: false,
  showText: true,
  showImage: true,
};

RenderFooter.propTypes = {
  ...RenderFooter.propTypes,
};

RenderFooter.defaultProps = {
  ...RenderFooter.defaultProps,
};
