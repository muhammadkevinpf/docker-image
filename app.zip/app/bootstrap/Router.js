/**
 * @author: dwi.setiyadi@gmail.com
*/

import { createAppContainer, createStackNavigator } from 'react-navigation';
import RouterConfig from '../config/Router';

const AppContainer = createStackNavigator(RouterConfig.modules, RouterConfig.settings);
export default createAppContainer(AppContainer);
