/* eslint-disable react-native/no-color-literals */
import { StyleSheet } from 'react-native';
import Styles from '../../styles';
import Fonts from '../../styles/Fonts';

const Style = StyleSheet.create({
  content: {
    paddingLeft: 1,
    marginTop: 15,
    // borderColor: '#D9D5DC',
    // borderBottomWidth: 1 / PixelRatio.getPixelSizeForLayoutSize(1) * 2,
    // flexDirection: 'column',
  },
  styleTextLabel: {
    flex: 1,
    marginTop: 4,
    fontSize: 11,
    color: Styles.Color.gray,
    fontFamily: Fonts.FSAlbertPro,
  },
  styleTextLabelValEmpty: {
    color: Styles.Color.gray,
  },
  styleBottomLabel: {
    fontFamily: Fonts.FSAlbertPro,
    // marginBottom: 15,
    color: Styles.Color.red,
    fontSize: 10,
    marginLeft: 15,
  },
  item: {
    // paddingBottom: 2,
    // backgroundColor: Styles.Color.mediumGray,

    height: 30,
    paddingLeft: 0,
  },
  iconStyle: {
    marginBottom: 20,
  },
  placeholderColor: {
    fontFamily: Fonts.FSAlbertPro,
    color: Styles.Color.gray,
  },
  fieldStyle: {
    fontFamily: Fonts.FSAlbertPro,
    fontSize: 14,
    // backgroundColor: Styles.Color.yellow,
    paddingLeft: 0,
    marginLeft: 0,
  },
});

export default Style;
