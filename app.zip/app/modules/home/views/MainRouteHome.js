/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import { BackHandler } from 'react-native';
import { Button, Text } from 'native-base';
import _ from '../../../lang';
import Style from '../../../styles';
import HomeScreen from '../components/HomeScreen';
import { pageType as page } from '../ConfigHome';

class MainRouteHome extends Component {
  componentDidMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleBack();
      return true;
    });
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  handleBack = () => {
    const route = this.props.navigation.getParam('route', 'SignInHome');
    this.props.navigation.replace(route);
  }

  renderTitle = () => {
    let title = '';
    const pageType = this.props.navigation.getParam('pageType', '');
    switch (pageType) {
      case page.createPRUFastID:
        title = 'Belum Memiliki PRUFast ID';
        break;
      case page.forgetSecurityQuestion:
        title = 'Lupa Pertanyaan Rahasia';
        break;
      default:
        title = 'Lupa PRUFast ID';
        break;
    }

    return title;
  }

  render() {
    const pageType = this.props.navigation.getParam('pageType', '');
    return (
      <HomeScreen
        title={this.renderTitle()}
        onBackClicked={this.handleBack}
        content={
          <React.Fragment>
            <Button
              rounded
              danger
              style={[Style.Main.mt20, Style.Main.buttonBorderRed]}
              onPress={() => this.props.navigation.replace('AgentDataVerification', { pageType })}
            >
              <Text style={[Style.Main.fontAlbert14, Style.Main.textGray]}>{_('AGEN')}</Text>
            </Button>
            {/* <Button
              rounded
              danger
              style={[Style.Main.mt20, Style.Main.buttonBorderRed]}
              onPress={() => this.props.navigation.replace('ForgotPruIDNonAgentHome', { pageType })}
            >
              <Text style={[Style.Main.fontAlbert14, Style.Main.textGray]}>{_('CALON AGEN')}</Text>
            </Button> */}
          </React.Fragment>
        }
      />
    );
  }
}

export default MainRouteHome;
