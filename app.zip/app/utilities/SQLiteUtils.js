import SQLite from 'react-native-sqlite-storage';

const openDatabase = (name, location, createFromLocation) => new Promise((resolve, reject) => {
  let param = { name, key: DBKEY };
  if (createFromLocation) param = { ...param, createFromLocation };
  if (location) param = { ...param, location };
  try {
    SQLite.openDatabase(param, db => resolve(db), err => reject(err));
  } catch (error) {
    reject(error);
  }
});

const closeDatabase = db => new Promise((resolve, reject) => {
  try {
    db.close();
    resolve('DB CLOSED');
  } catch (error) {
    reject(error);
  }
});

const deleteDatabase = (name, location) => new Promise((resolve, reject) => {
  SQLite.deleteDatabase({ name, location }, x => resolve(x), y => reject(y));
});

const executeQuery = (db, query, params) => new Promise((resolve, reject) => {
  db.executeSql(query, params, x => resolve(x), y => reject(y));
});

const executeTransaction = (db, query, params) => new Promise((resolve, reject) => {
  db.transaction(
    tx => tx.executeSql(query, params),
    error => reject(error),
    () => resolve('OK'),
  );
});

/**
 * This function created for resolving the size limitation when queryin data, maximum is 512KB
 * @param {*} db : the database object that you want to execute
 * @param {*} table : table that you want to query
 * @param {*} column : the BIG SIZE COLUMN that you want to get the data
 * @param {*} whereClause : where clause for query specific data
 * @param {*} params : parameter for your statement
 */
const executeAdvanceQuery = (db, table = '', column = '', whereClause = '', params = []) => new Promise(async (resolve, reject) => {
  try {
    const length = await executeQuery(db, `SELECT length(${column}) as length FROM ${table} ${whereClause}`, params);
    let result = '';
    const lengthData = QUERY_SIZE;
    if (length.rows.length) {
      for (let j = 1; j <= length.rows.item(0).length; j += lengthData) {
        // eslint-disable-next-line no-await-in-loop
        const res = await executeQuery(db, `SELECT substr(${column}, ${j}, ${lengthData}) as DATA from ${table} ${whereClause}`, params);
        result += res.rows.item(0).DATA;
      }
    }
    resolve(result);
  } catch (error) {
    reject(error);
  }
});

// eslint-disable-next-line no-undef
const DBKEY = 'pawd12mdmwpdm';
const QUERY_SIZE = 0.5 * 1000 * 1024;

export default {
  openDatabase,
  closeDatabase,
  deleteDatabase,
  executeQuery,
  executeTransaction,
  executeAdvanceQuery,
  DBKEY,
  QUERY_SIZE,
};
