/**
 * @author Dwi Setiyadi
 */


import { StyleSheet } from 'react-native';
import Styles from '../../styles';

const Style = StyleSheet.create({
  container: {
    height: 56,
  },
  borderHair: {
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderStyle: 'solid',
    borderBottomColor: Styles.Color.darkRed,
  },
  borderNone: {
    borderBottomWidth: 0,
  },
  subHeader: {
    backgroundColor: Styles.Color.darkWhite,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderStyle: 'solid',
    borderBottomColor: Styles.Color.lightGray,
  },
  subHeaderContent: {
    backgroundColor: Styles.Color.darkWhite,
    height: 56,
    // padding: 15,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderStyle: 'solid',
    borderBottomColor: Styles.Color.lightGray,
  },
  buttonRight: {
    textAlign: 'center',
    padding: 10,
  },
  buttonBadgeWrapper: {
    width: '100%',
    height: '100%',
    flex: 1,
    position: 'absolute',
    alignItems: 'center',
    marginLeft: 10,
    marginTop: 5,
  },
});

export default Style;
