/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import { View, Text } from 'react-native';
import PropTypes from 'prop-types';
import Style from '../../styles';

class ErrorMessage extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  render() {
    return (
      <View style={[(this.props.show)
        ? Style.Main.displayFlex
        : Style.Main.displayNone,
      ]}
      >
        <Text style={[this.props.labelStyle]}>
          {this.props.label}
        </Text>
      </View>
    );
  }
}

ErrorMessage.propTypes = {
  label: PropTypes.string,
  labelStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
  show: PropTypes.bool,
};

ErrorMessage.defaultProps = {
  label: '',
  labelStyle: null,
  show: false,
};

export default ErrorMessage;
