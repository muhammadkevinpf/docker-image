/* eslint-disable max-len */
/* eslint-disable react/no-array-index-key */
/* eslint-disable no-console */
/* eslint-disable camelcase */

import React, { Component } from 'react';
import { BackHandler } from 'react-native';
import { connect } from 'react-redux';
import {
  Container, Content, Text, View,
} from 'native-base';
import { Row, Col } from 'react-native-easy-grid';
import { NavigationEvents } from 'react-navigation';
import Icon from 'react-native-vector-icons/FontAwesome';
// import _ from '../../../lang';
import Style from '../../../styles';
import UserProfileService from '../services/UserProfileService';
import { HeaderWithTodo, SideBarMenu } from '../../../components';
import { isTablet } from '../../../utilities';
import LoadingModal from '../../../components/loading_modal';

class CPDDetail extends Component {
  constructor(props) {
    super(props);
    this.state = {
      cpdCode: '',
      data: [],
      isLoading: false,
    };
  }

  componentDidMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleOnBack();
      return true;
    });
    this.setState({ isLoading: true });
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  handleBack = () => {
    this.props.navigation.replace('MyAccountDetail');
  }

  initialLoad = async () => {
    try {
      const { access_token, userProfile } = this.props.resAuth;

      const agentCPDSummary = await UserProfileService.getAgentCPDSummary(access_token, userProfile.agentCode);
      console.log('agentCPDSummary: ', agentCPDSummary);
      const agentCPD = await UserProfileService.getAgentCPD(access_token, userProfile.agentCode);
      console.log('agentCPD: ', agentCPD);

      this.setState({
        cpdCode: agentCPDSummary.data.data[0].lastAgentCpdCode,
        data: agentCPD.data.data,
      });
    } catch (e) {
      console.log('error at initialLoad with error: ', e);
    }
    this.setState({ isLoading: false });
  }

  handleOnBack = () => {
    this.props.navigation.replace('MyAccountDetail');
    this.backHandler.remove();
  }

  render() {
    const { cpdCode, data } = this.state;
    const dataAAJI = data.filter(x => x.status === 'APPROVED');
    const dataCPD = data.filter(x => x.status !== 'APPROVED');

    const totalAAJI = dataAAJI.map(item => item.point).reduce((prev, curr) => prev + curr, 0);
    const totalCPD = dataCPD.map(item => item.point).reduce((prev, curr) => prev + curr, 0);
    return (
      <React.Fragment>
        <NavigationEvents
          onDidFocus={() => this.initialLoad()}
        />
        <Container style={[isTablet() && Style.Main.rowDirection]}>
          <SideBarMenu visible={isTablet()} navigation={this.props.navigation} />
          <View style={[Style.Main.container]}>
            <HeaderWithTodo {...this.props} onBackClicked={this.handleOnBack} headerTitle="CPD" />
            {
              !this.state.isLoading && (
                <Content style={[Style.Main.mb20]} keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
                  <View style={[Style.Main.backgroundWhite, Style.Main.mt12, Style.Main.ml10, Style.Main.mr10, Style.Main.justifyCenter]}>
                    <Row>
                      <Col size={1} style={[Style.Main.alignCenter, Style.Main.justifyCenter, Style.Main.textWhite]}>
                        <Icon name="user" style={[Style.Main.textAlmostBlack, Style.Main.font14]} />
                      </Col>
                      <Col size={19}>
                        <Text style={[Style.Main.textAlmostBlack]}>CPD Code Anda</Text>
                      </Col>
                    </Row>
                  </View>
                  <View style={[
                    Style.Main.backgroundBarPink, Style.Main.mt12, Style.Main.mb15, Style.Main.padding20, Style.Main.justifyCenter, Style.Main.height65]}
                  >
                    <Text style={[Style.Main.textStrongWhite25, Style.Main.textCenter, Style.Main.textAlignCenter]}>{cpdCode}</Text>
                  </View>
                  <View style={[Style.Main.mt14, Style.Main.ml20, Style.Main.mr20]}>
                    <Text style={[Style.Main.font14, Style.Main.textAlmostBlack]}>
                      Poin CPD yang sudah didaftarkan AAJI:
                    </Text>
                    {
                      dataAAJI.map((val, i) => (
                        <View key={i} style={[Style.Main.rowDirectionSpaceBetween, Style.Main.container, Style.Main.ml12]}>
                          <Text style={[Style.Main.font14, Style.Main.textAlmostBlack, Style.Main.my5]}>{val.cpdCode}</Text>
                          <Text style={[Style.Main.font14, Style.Main.textGreen, Style.Main.my5]}>+ {val.point}</Text>
                        </View>
                      ))
                    }
                    <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.container, Style.Main.borderTopCustom, Style.Main.mt5]}>
                      <Text style={[Style.Main.font16, Style.Main.textAlmostBlack, Style.Main.ml30, Style.Main.my5]} />
                      <Text style={[Style.Main.font16, Style.Main.textAlmostBlack, Style.Main.ml70, Style.Main.my5]}>Total CPD AAJI:</Text>
                      <Text style={[Style.Main.font16, Style.Main.textGreen, Style.Main.my5]}>{totalAAJI}</Text>
                    </View>
                    <Text style={[Style.Main.font14, Style.Main.textAlmostBlack, Style.Main.mt35]}>
                      Training modul efektif untuk CPD yang sudah diikuti:
                    </Text>
                    {
                      dataCPD.map((val, i) => (
                        <View key={i} style={[Style.Main.rowDirectionSpaceBetween, Style.Main.container, Style.Main.ml12]}>
                          <Text style={[Style.Main.font14, Style.Main.textAlmostBlack, Style.Main.my5]}>{val.cpdCode}</Text>
                          <Text style={[Style.Main.font14, Style.Main.textGreen, Style.Main.my5]}>+ {val.point}</Text>
                        </View>
                      ))
                    }
                    <View style={[Style.Main.rowDirectionSpaceBetween, Style.Main.container, Style.Main.borderTopCustom, Style.Main.mt5]}>
                      <Text style={[Style.Main.font16, Style.Main.textAlmostBlack, Style.Main.ml30, Style.Main.my5]} />
                      <Text style={[Style.Main.font16, Style.Main.textAlmostBlack, Style.Main.ml70, Style.Main.my5]}>Total CPD yang diikuti:</Text>
                      <Text style={[Style.Main.font16, Style.Main.textGreen, Style.Main.my5]}>{totalCPD}</Text>
                    </View>
                  </View>
                </Content>
              )
            }
          </View>
        </Container>
        <LoadingModal show={this.state.isLoading} size="large" color="white" />
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  resAuth: state.auth.res,
  connectionStatus: state.connectionStatus,
});

export default connect(mapStateToProps, null)(CPDDetail);
