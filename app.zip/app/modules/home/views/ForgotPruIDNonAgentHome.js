/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import { Button, Text, View } from 'native-base';
import { BackHandler, Alert } from 'react-native';
import { connect } from 'react-redux';
import _ from '../../../lang';

import Style from '../../../styles';
import { authAction } from '../ActionHome';
import { FORGOT_ID_CANDIDATE } from '../ConfigHome';
import { requestStatus } from '../../../utilities';
import LoadingModal from '../../../components/loading_modal';
import HomeScreen from '../components/HomeScreen';
import { InputFieldNew } from '../../../components';

class ForgotPruIDNonAgentHome extends Component {
  constructor(props) {
    super(props);
    this.state = {
      npa: '',
      name: '',
      id: '',
      isLoading: false,
    };
  }

  componentDidMount() {
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      this.handleBack();
      return true;
    });
  }

  componentDidUpdate(prevProps) {
    if (this.props !== prevProps) {
      if (this.props.status === requestStatus.FETCH) { this.handleLoading(true); } else if (this.props.status === requestStatus.SUCCESS) {
        this.handleLoading(false, () => {
          if (prevProps.forgotId.respCode === 200) {
            // temp
            Alert.alert('', 'Berhasil!', [{ text: 'Ok', onPress: () => { } }]);
          } else {
            Alert.alert(
              '',
              'Data yang Anda masukkan tidak sesuai dengan database kami. Silakan hubungi Agency Administration Support.',
              [{ text: 'Ok', onPress: () => { } }],
            );
          }
        });
      } else {
        Alert.alert('', 'Gagal menginput data.', [{ text: 'Ok', onPress: () => { this.handleLoading(false); } }]);
      }
    }
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  handleLoading = (val, func) => {
    const callbackFunc = func || (() => { });
    this.setState({ isLoading: val }, callbackFunc);
  }

  handleBack = () => {
    this.props.navigation.replace('MainRouteHome');
  }

  onVerify = () => {
    const { npa, name, id } = this.state;
    const checksalesforceidflag = 'N'; // angular reference

    if (npa === '' || name === null || id === '') {
      Alert.alert('', 'Mohon mengisi semua kolom isian', [{ text: 'Ok', onPress: () => { } }]);
      // }
      // else if (!this.props.isOnline) {
      //   Alert.alert('', 'Mohon periksa jaringan anda', [{ text: 'Ok', onPress: () => { } }]);
    } else {
      const data = {
        headers: [
          {
            keyHeader: 'X-CSRF-Token',
            valueHeader: 'Bearer undefined',
          },
        ],
        // { "params": [npa, name, idno, checksalesforceidflag] }
        params: `["${npa}", "${name}", "${id}", "${checksalesforceidflag}"]`,
      };

      this.props.verifyForgotId(data);
    }
  }

  render() {
    return (
      <React.Fragment>
        <HomeScreen
          title="Verifikasi Data Calon Agen"
          onBackClicked={this.handleBack}
          content={
            <View style={[Style.Main.width200, Style.Main.alignCenter]}>
              <InputFieldNew
                value={this.state.npa}
                label={_('Nomor Pengajuan Agen (NPA)')}
                onChangeText={npa => this.setState({ npa })}
                isRequired={false}
              />
              <InputFieldNew
                value={this.state.id}
                label={_('Nomor KTP')}
                onChangeText={id => this.setState({ id })}
                isRequired={false}
              />
              <InputFieldNew
                value={this.state.npa}
                label={_('Nomor Pengajuan Agen (NPA)')}
                onChangeText={npa => this.setState({ npa })}
                isRequired={false}
              />
              <Button
                rounded
                danger
                style={[Style.Main.mt35, Style.Main.buttonRed]}
                onPress={this.onVerify}
              >
                <Text style={[Style.Main.fontAlbert14, Style.Main.textWhite]}>{_('VERIFIKASI')}</Text>
              </Button>
            </View>
          }
        />
        <LoadingModal
          show={this.state.isLoading}
          size="large"
          color="white"
        />
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  isOnline: state.connectionStatus.isOnline,
  forgotId: state.home.forgotIdCandidate,
  status: state.home.forgotIdCandidateStatus,
});

const mapDispatchToProps = dispatch => ({
  verifyForgotId: value => dispatch(authAction(FORGOT_ID_CANDIDATE.FETCH, value)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ForgotPruIDNonAgentHome);
