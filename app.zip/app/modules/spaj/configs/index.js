// eslint-disable-next-line import/no-cycle
import ConfigProductSPAJ from './ConfigProductSPAJ';
import Disclaimer from './Disclaimer';

export {
  ConfigProductSPAJ,
  Disclaimer,
};
