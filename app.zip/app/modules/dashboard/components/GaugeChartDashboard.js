/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import {
  Content, View,
} from 'native-base';
import { Row, Col } from 'react-native-easy-grid';
import GaugeChart from 'react-native-speedometer-chart';
// import {
//   VictoryPie,
//   VictoryContainer,
// } from 'victory-native';

import Style from '../../../styles';
// import StyleDashboard from '../StyleDashboard';

class GaugeChartDashboard extends Component {
  render() {
    return (
      <Content keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
        <View>
          <Row>
            <Col size={50}>
              <View style={[Style.Main.textCenter, Style.Main.mr0]}>
                <GaugeChart
                  value={50}
                  totalValue={100}
                  size={120}
                  outerColor="#d3d3d3"
                  internalColor="#ff0000"
                  showText
                  textStyle={Style.Main.textGray}
                  showLabels
                  labelStyle={Style.Main.textGray}
                  showPercent
                  percentStyle={Style.Main.textGray}
                />
              </View>
            </Col>
            <Col size={50}>
              <View style={[Style.Main.textCenter, Style.Main.mr0]}>
                <GaugeChart
                  value={50}
                  totalValue={100}
                  size={120}
                  outerColor="#d3d3d3"
                  internalColor="#ff0000"
                  showText
                  textStyle={Style.Main.textGray}
                  showLabels
                  labelStyle={Style.Main.textGray}
                  showPercent
                  percentStyle={Style.Main.textGray}
                />
              </View>
            </Col>
            {/* <Col size={50}>
              <VictoryPie
                colorScale={['gray', 'green', 'red', 'yellow', 'purple']}
                innerRadius={100}
                data={[
                  { SPAJ: 'Proposal', Total: 35 },

                ]}
                x="SPAJ"
                y="Total"
                startAngle={90}
                endAngle={-90}
                // labels={d => d.y}
                // style={{ labels: { fill: 'transparent' } }}
                // padding={{
                //   top: 15, bottom: 15,
                // }}
                // containerComponent={<VictoryContainer responsive={false} />}
                // width={135}
                // height={135}
              />
            </Col>
            <Col size={50} /> */}
          </Row>
        </View>
      </Content>
    );
  }
}

export default GaugeChartDashboard;
