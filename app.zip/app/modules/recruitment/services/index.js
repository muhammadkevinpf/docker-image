import RecruitmentDetailService from './RecruitmentDetailServices';
import AOBServices from './AOBServices';
import CandidateServices from './CandidateServices';
import ApiService from './ApiService';

export {
  RecruitmentDetailService,
  AOBServices,
  CandidateServices,
  ApiService,

};
