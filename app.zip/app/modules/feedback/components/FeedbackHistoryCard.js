/* eslint-disable max-len */
/* eslint-disable react/no-array-index-key */
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { Text, Card } from 'native-base';
import Style from '../../../styles';

export class FeedbackHistoryCard extends PureComponent {
  render() {
    const { data } = this.props;
    return (
      <Card style={this.props.cardStyle}>
        <TouchableOpacity
          onPress={this.props.onCardClicked}
          style={[Style.Main.alignContentCenter, Style.Main.mV10, Style.Main.pb5, Style.Main.ph12]}
        >
          <Text style={[Style.Main.fontAlbertBold12]}>{(data.policyHolderName && data.policyHolderName !== 'undefined') ? data.policyHolderName : 'N/A'}</Text>
          <Text style={[Style.Main.fontAlbert12]}>Nomor Polis: {(data.policyNumber && data.policyNumber !== 'undefined') ? data.policyNumber : 'N/A'}</Text>
          <Text style={[Style.Main.fontAlbert12]}>Jenis Sub-Transaksi: {(data.subTransactionType && data.subTransactionType !== 'undefined') ? data.subTransactionType : 'N/A'}</Text>
          <Text style={[Style.Main.fontAlbertBold12]}>Tanggal Kirim: {(data.submitDate && data.submitDate !== 'undefined') ? moment(data.submitDate).format('Do MMMM YYYY') : 'N/A'}</Text>
          <Text style={[Style.Main.fontAlbert12]}>Pertanyaan dan Masukan: {(data.comment && data.comment !== 'undefined') ? data.comment : 'N/A'}</Text>
        </TouchableOpacity>
      </Card>
    );
  }
}

FeedbackHistoryCard.propTypes = {
  onCardClicked: PropTypes.func,
};

FeedbackHistoryCard.defaultProps = {
  onCardClicked: () => { },
};
