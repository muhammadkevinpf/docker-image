/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import {
  Text, TextInput, Modal,
} from 'react-native';
import {
  Container, Content,
  Button, View, Header,
} from 'native-base';
import { Dropdown } from 'react-native-material-dropdown';
import _ from '../../../lang';
import Style from '../../../styles';

class MyAccountSecretQuestion extends Component {
  constructor(props) {
    super(props);
    this.state = {
      jawaban1: '',
      jawaban2: '',
      showConfirm: false,
    };
  }

  componentDidMount() {
  }

  setShowConfirm(visible) {
    this.setState({ showConfirm: visible });
  }

  render() {
    return (
      <Container>
        <Modal
          animationType="slide"
          visible={this.state.showConfirm}
          transparent
        >
          <View style={[Style.Main.modalOverlay, Style.Main.justifyCenter]}>
            <View style={[Style.Main.margin10, Style.Main.backgroundWhite,
              Style.Main.borderRadius5, Style.Main.pl12, Style.Main.pr12, Style.Main.pb15, Style.Main.pt15]}
            >
              <View style={[Style.Main.pt0, Style.Main.pl10, Style.Main.pr10, Style.Main.mb12, Style.Main.mt30]}>
                <Text style={[Style.Main.textAlignCenter, Style.Main.fontAlbert]}>
                  {_('Kata Pertanyaan Rahasia akan berganti dengan pergantian yang terbaru, apakah anda yakin?')}
                </Text>
              </View>
              <View style={[Style.Main.dialogBtnCnt, Style.Main.mb10, Style.Main.mt15]}>
                <Button
                  bordered
                  danger
                  block
                  style={[Style.Main.dialogOutlineBtn, Style.Main.ml12]}
                  onPress={() => {
                    this.setShowConfirm(false);
                  }}
                >
                  <Text style={[Style.Main.textRed]}>{_('Tidak')}</Text>
                </Button>
                <Button
                  style={[Style.Main.btnLanjutkan, Style.Main.dialogBtnwidth]}
                  block
                  onPress={() => {
                    this.setShowConfirm(false);
                    this.props.navigation.navigate('MyAccount');
                  }}
                >
                  <Text style={[Style.Main.font16, Style.Main.textWhite]}>{_('Ya')}</Text>
                </Button>
              </View>
            </View>
          </View>
        </Modal>
        <Header noShadow>
          <Text
            style={[Style.Main.font16, Style.Main.textWhite, Style.Main.ml6,
              Style.Main.pt15, Style.Main.textLeft, Style.Main.fontAlbert]}
            onPress={() => this.props.navigation.goBack()}
          >
            &lt; &nbsp; {_('Ubah Pertanyaan Rahasia')}
          </Text>
        </Header>
        <Content style={[Style.Main.padding12]} keyboardDismissMode="on-drag" enableResetScrollToCoords={false}>
          <View>
            <Dropdown
              data={[{
                value: 'Nama Ibu Kandung sebelum menikah',
              }, {
                value: 'Nama orang yang Anda kagumi',
              }, {
                value: 'Warna favorit Anda',
              }]}
              value={_('Nama Ibu Kandung sebelum menikah')}
              fontSize={13}
              style={[Style.Main.fontAlbert]}
              itemTextStyle={[Style.Main.fontAlbert]}
              onChangeText={() => {
                this.setState({
                });
              }}
              dropdownPosition={-4}
            />
          </View>
          <View style={[Style.Main.mt15]}>
            <TextInput
              style={[Style.Main.grayBorderBottom, Style.Main.padding0, Style.Main.fontAlbert]}
              placeholder={_('Jawaban 1')}
              maxLength={35}
              onChangeText={jawaban1 => this.setState({ jawaban1 })}
            />
          </View>
          <View>
            <Dropdown
              data={[{
                value: 'Kota tempat Anda lulus Sekolah Dasar',
              }, {
                value: 'Nama hewan peliharaan Anda',
              }, {
                value: 'Makanan favorit Anda',
              }]}
              value={_('Kota tempat Anda lulus Sekolah Dasar')}
              fontSize={13}
              style={[Style.Main.fontAlbert]}
              itemTextStyle={[Style.Main.fontAlbert]}
              onChangeText={() => {
                this.setState({
                });
              }}
              dropdownPosition={-4}
            />
          </View>
          <View style={[Style.Main.mt15, Style.Main.mb15]}>
            <TextInput
              style={[Style.Main.grayBorderBottom, Style.Main.padding0, Style.Main.fontAlbert]}
              placeholder={_('Jawaban 2')}
              maxLength={35}
              onChangeText={jawaban2 => this.setState({ jawaban2 })}
            />
          </View>
          <View style={[Style.Main.mt15]}>
            <Button
              style={[Style.Main.radius8,
                (this.state.jawaban1 === '' || this.state.jawaban2 === '')
                  ? Style.Main.backgroundGrayCe
                  : Style.Main.backgroundRed,
              ]}
              block
              onPress={() => {
                if (this.state.jawaban1 !== '' && this.state.jawaban2 !== '') {
                  this.setState({
                    showConfirm: true,
                  });
                }
              }}
            >
              <Text
                style={[Style.Main.textWhite]}
              >{_('UBAH PERTANYAAN RAHASIA')}
              </Text>
            </Button>
          </View>
        </Content>
      </Container>
    );
  }
}

export default MyAccountSecretQuestion;
