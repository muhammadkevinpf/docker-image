/**
 * @author
 * Dwi Setiyadi
 * ahmdichsanb@gmail.com
 */

import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import ButtonCustom from '../button-custom';

class Btn extends Component {
  render() {
    return (
      <Fragment>
        <ButtonCustom
          iconName={this.props.icon}
          iconSize={30}
          iconColor="white"
          iconStyle={[this.props.iconStyle]}
          onPress={this.props.link}
        />
      </Fragment>
    );
  }
}

Btn.propTypes = {
  icon: PropTypes.string.isRequired,
  link: PropTypes.func.isRequired,
  iconStyle: PropTypes.oneOfType([PropTypes.object, PropTypes.arrayOf(PropTypes.object)]),
};

Btn.defaultProps = {
  iconStyle: null,
};

export default Btn;
