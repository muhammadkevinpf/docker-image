/* eslint-disable react/no-array-index-key */
import React from 'react';
import {
  Icon, View, Text, Button,
} from 'native-base';
import { connect } from 'react-redux';
import { Modal } from 'react-native';
import { isEmpty, isTablet, apiWithTokenAction } from '../../../utilities';
import { FEEDBACK_POINT } from '../ConfigActivity';
import Style from '../../../styles';
import _ from '../../../lang';

class FeedbackPointComponent extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      showInfo: false,
    };
  }

  componentDidMount = () => {
    if (!this.props.point) this.props.getFeedbackPoint(this.props.resAuth.access_token);
  }

  onModalClose = () => this.setState({ showInfo: false })

  render() {
    const { points = [], iconStyle } = this.props;
    return (
      <React.Fragment>
        <Icon
          name="information-outline"
          type="MaterialCommunityIcons"
          style={[Style.Main.pl15, iconStyle]}
          onPress={() => (isEmpty(points) ? {} : this.setState({ showInfo: true }))}
        />
        <Modal transparent visible={this.state.showInfo} onRequestClose={this.onModalClose}>
          <View style={[Style.Main.backgroundLightSmoke, Style.Main.center, Style.Main.container]}>
            <View style={[Style.Main.backgroundWhite,
              Style.Main.borderRadius5,
              Style.Main.padding12,
              isTablet() ? Style.Main.halfWidth : Style.Main.width80pr,
            ]}
            >
              <Text style={[Style.Main.fontAlbert12, Style.Main.mb12, Style.Main.textBlack]}>
                {_('Berikut daftar Feedback yang memiliki Poin')} :
              </Text>
              {points.map((item, index) => (
                <View key={index} style={[Style.Main.rowDirectionSpaceBetween, Style.Main.mb10]}>
                  <Text style={[Style.Main.fontAlbert12, Style.Main.mr20, Style.Main.textWrap]}>{index + 1}. {item.description}</Text>
                  <Text style={[Style.Main.fontAlbert12]}>{item.point} {_('Poin')}</Text>
                </View>
              ))}
              <Button block style={[Style.Main.btnPrimary, Style.Main.mt12]} onPress={this.onModalClose}>
                <Text>{_('Tutup')} </Text>
              </Button>
            </View>
          </View>
        </Modal>
      </React.Fragment>
    );
  }
}

const mapStateToProps = state => ({
  resAuth: state.auth.res,
  points: state.activity.feedbackPoint.data,
});

const mapDispatchToProps = dispatch => ({
  getFeedbackPoint: token => dispatch(apiWithTokenAction(FEEDBACK_POINT.FETCH, `["${token}"]`, token)),
});


export const FeedbackPointInfo = connect(mapStateToProps, mapDispatchToProps)(FeedbackPointComponent);
