/**
 * @author:
 * dwi.setiyadi@gmail.com
 * sutanibrahim10@gmail.com
*/

import React, { Component } from 'react';
import { Text } from 'react-native';
import PropTypes from 'prop-types';
import Style from '../../styles';

class PruText extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  render() {
    return (
      <Text>
        <Text style={[Style.Main.font16, this.props.pruStyle]}>PRU</Text>
        <Text style={[Style.Main.font16, this.props.labelStyle]}>
          {this.props.label}
        </Text>
      </Text>
    );
  }
}

PruText.propTypes = {
  label: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.object,
    PropTypes.array,
    PropTypes.arrayOf(PropTypes.object),
  ]),
  labelStyle: PropTypes.oneOfType([
    PropTypes.object,
    PropTypes.arrayOf(PropTypes.object),
  ]),
  pruStyle: PropTypes.oneOfType([
    PropTypes.object,
    PropTypes.arrayOf(PropTypes.object),
  ]),
};

PruText.defaultProps = {
  label: '',
  labelStyle: {},
  pruStyle: {},
};

export default PruText;
