/**
 * @author: dwi.setiyadi@gmail.com
*/

import {
  SIGNINFETCH,
  SIGNINSUCCESS,
  SIGNINFAILED,

  USERPROFILEFETCH,
  USERPROFILESUCCESS,
  USERPROFILEFAILED,

  USERAVATARFETCH,
  USERAVATARSUCCESS,
  USERAVATARFAILED,

  SIGNOUTFETCH,
  SIGNOUTSUCCESS,
  SIGNOUTFAILED,

  VAFETCH,
  VAFAILED,
  VASUCCESS,

  // added
  HASHINGPASSWORD,
  UPDATEONLINEDATE,
  UPDATESIGNINDATE,
  // Connection
  // CONNECTIONONLINE,
  // CONNECTIONOFFLINE,
  CONNECTIONONLINE,
  CONNECTIONOFFLINE,
  VAUPDATE,
} from './ConfigAuth';

export const signInFetch = value => ({ type: SIGNINFETCH, send: value });
export const signInSuccess = value => ({ type: SIGNINSUCCESS, res: value });
export const signInFailed = value => ({ type: SIGNINFAILED, err: value });

export const userProfileFetch = value => ({ type: USERPROFILEFETCH, send: value });
export const userProfileSuccess = value => ({ type: USERPROFILESUCCESS, res: value });
export const userProfileFailed = value => ({ type: USERPROFILEFAILED, err: value });

export const userAvatarFetch = value => ({ type: USERAVATARFETCH, send: value });
export const userAvatarSuccess = value => ({ type: USERAVATARSUCCESS, res: value });
export const userAvatarFailed = value => ({ type: USERAVATARFAILED, err: value });

export const signOutFetch = value => ({ type: SIGNOUTFETCH, send: value });
export const signOutSuccess = value => ({ type: SIGNOUTSUCCESS, res: value });
export const signOutFailed = value => ({ type: SIGNOUTFAILED, err: value });

export const vaFetch = value => ({ type: VAFETCH, send: value });
export const vaSuccess = value => ({ type: VASUCCESS, res: value });
export const vaFailed = value => ({ type: VAFAILED, err: value });
export const vaUpdate = value => ({ type: VAUPDATE, res: value });

// added

export const hashingPassword = value => ({ type: HASHINGPASSWORD, value });
export const updateOnlineDate = value => ({ type: UPDATEONLINEDATE, value });
export const updateSignInDate = value => ({ type: UPDATESIGNINDATE, value });
// export const connectionOnline = value => ({ type: CONNECTIONONLINE, err: value });
// export const connectionOffline = value => ({ type: CONNECTIONOFFLINE, err: value });
export const updateConnectionStatus = (type, value) => ({ type, value });
export const connectionOnline = value => ({ type: CONNECTIONONLINE, err: value });
export const connectionOffline = value => ({ type: CONNECTIONOFFLINE, err: value });
